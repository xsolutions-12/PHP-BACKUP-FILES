<!DOCTYPE html>
<html>
<head>
	<title>Tele Education</title>
	<?php include_once 'include/css.php'; ?>
</head>
<body class="about-page">
	<div class="container">
		<div class="main-wrap">
			<?php include_once 'include/header.php'; ?>
			<div class="row">
				<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="inner-page-sec list-in">
						<div class="inner-head">
							<h1 class="inner-title">Tele Education</h1>
							<span></span>
						</div>
						<p class="text-center">The educational component involves participation in Continuing Medical Education (CME), training of students (physicians in residency training), and exchange of state-of-the-art practices and expertise between participating institutions.</p>
					</div>
				</div>
				<?php include_once 'include/footer.php'; ?>
			</div>
		</div>
	</div>




	
	<?php include_once 'include/js.php'; ?>

</body>
</html>