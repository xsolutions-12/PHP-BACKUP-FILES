<!DOCTYPE html>
<html>
<head>
	<title>Health Information System(HIS)</title>
	<?php include_once 'include/css.php'; ?>
</head>
<body class="about-page">
	<div class="container">
		<div class="main-wrap">
			<?php include_once 'include/header.php'; ?>
			<div class="row">
				<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="inner-page-sec list-in">
						<div class="inner-head">
							<h1 class="inner-title">Health Information System(HIS)</h1>
							<span></span>
						</div>
						<h4 style="text-align: center;"><span style="color: #000000;"><strong style="line-height: 150%;">Designed and Developed under the guidance of SGPGIMS, Lucknow <br>(National Resource Centre for
Telemedicine)</strong></span><br><span style="color: #000000;">meets the requirement of the 12<sup>th</sup> Five-Year Plan and NRHM</span></h4>
<p>&nbsp;</p>
<p style="text-align: justify;">The composite HIS developed and deployed in
OTTET Telemedicine Network based on the PPP mode can regularly track the
progress of the state in achieving the national health outcome indicators, and
in identifying areas and populations which lag behind on health indicators,
with sufficient accuracy, so as to enable remedial action. To achieve this goal,
the HIS has to necessarily rely on universal vital registration, and the
networking of all health service providers, public and private laboratories. This is possible because of the
deployment and installation of wireless Telemedicine devices using which data
fidelity is assured by triangulation with data from periodic surveys and
community based monitoring, which should continue with a greater frequency.
Strict compliance with the right of privacy is also maintained.</p>
<p style="text-align: justify;">&nbsp;</p>
<p><strong>OTTET Telemedicine HIS incorporating the followings:</strong></p>
<ol style="list-style-type: lower-roman;">
<li>Universalregistration of births, deaths and cause of death. Vital registration providesbase-line data on cause specific mortality at national and disaggregatedlevels. Maternal and infant death reviews are integral components of thesystem.</li>
<li>Nutritionalsurveillance, particularly among women in the reproductive age group and undersix children, linked to the ICDS Programme.</li>
<li>Diseasesurveillance based on reporting by providers and clinical laboratories (publicand private) to detect and act on disease outbreaks and epidemics.</li>
<li>Out-patientand in-patient information through Electronic Medical Records (EMR). This willhelp provide the best care based on Standard Treatment Guidelines, reduceresponse time in emergencies, support the organ retrieval and transplantationprogramme and improve general hospital administration. It would also helpestimate burden of disease and facilitate policy decisions at State andnational levels.</li>
<li>Dataon Human Resource within the public health system.</li>
<li>Financialmanagement in the public health system. This will help streamline resourceallocation and transfers, and accounting and payments to facilities, providersand beneficiaries. Ultimately, it would enable timely compilation of the NationalHealth Accounts on an annual basis.</li>
<li>Useof Communication and Information Technology (ICT) in medical education bypromoting a national repository of teaching modules, case records for differentmedical conditions in textual and audio-visual formats for use both by theteaching faculty, students and practitioners for Continuing Medical Education.</li>
<li>Tele-medicineand consultation support to doctors at primary and secondary facilities fromspecialists at tertiary centres.</li>
<li>Nation-wideregistries of clinical establishments, manufacturing units, drug-testinglaboratories, licensed drugs and approved clinical trials to support regulatoryfunctions of Government.</li>
<li>Accessof public to their own health information and medical records, while preservingconfidentiality of data.</li>
<li>ProgrammeMonitoring support for National Health Programmes to help identify programmegaps or areas where there are greater challenges.</li>
<li>Informationgenerated from the proposed HIS should be used at all levels to plan, executeand evaluate performance.<strong><br></strong></li>
</ol>
					</div>
				</div>
				<?php include_once 'include/footer.php'; ?>
			</div>
		</div>
	</div>




	
	<?php include_once 'include/js.php'; ?>

</body>
</html>