<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/jquery.magnific-popup.min.js"></script>
	<script type="text/javascript" src="js/owl.carousel.min.js"></script>
	<script type="text/javascript" src="js/jquery.newsTicker.min.js"></script>
	<script type="text/javascript" src="js/script.js"></script>

	<script type="text/javascript">
		var banner = $('.banner-slider').owlCarousel({
			items:1,
		    loop:true,
		    margin:10,
		    responsiveClass:true,
		    dots: true,
		    autoplay: true,
			autoplayTimeout: 3000,
    		animateOut: 'fadeOut',
        	responsiveClass:true,
    		autoplaySpeed: 10,
		    responsive:{
		        0:{
		            items:1,
		            nav:true,
		            dots: true
		        },
		        600:{
		            items:1,
		            nav:false,
		            dots: true
		        },
		        1000:{
		            items:1,
		            nav:true,
		            loop:true,
		            dots: true
		        }
		    }
		});
	</script>

	

	<script type="text/javascript">
		var nt_example1 = $('#nt-example').newsTicker({
	    row_height: 90,
	    max_rows: 5,
	    duration: 4000,
	    prevButton: $('#nt-example1-prev'),
	    nextButton: $('#nt-example1-next')
	});
	</script>

	<script type="text/javascript">
		var logo = $('.logo-slider').owlCarousel({
			items:2,
		    loop:true,
		    margin:10,
		    responsiveClass:true,
		    dots: false,
		    autoplay: true,
			autoplayTimeout: 3000,
        	responsiveClass:true,
		    responsive:{
		        0:{
		            items:2,
		            nav:false,
		            dots: false
		        },
		        600:{
		            items:2,
		            nav:false,
		            dots: false
		        },
		        1000:{
		            items:2,
		            nav:false,
		            loop:true,
		            dots: false
		        }
		    }
		});
	</script>