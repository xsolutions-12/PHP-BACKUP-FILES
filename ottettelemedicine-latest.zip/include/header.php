<header>
				<div class="row align-items-center">
					<div class="col-xl-6 col-lg-6 col-md-6">
						<a href="index.php" style="display: block;"><img src="images/logo2.jpg" class="img-fluid"></a>
					</div>
					<div class="col-xl-2 col-lg-2 col-md-2">
						<h4><span>548178</span>
						Patients Benefitted</h4>
					</div>
					<div class="col-xl-4 col-lg-4 col-md-4">
						<a href="#" class="head-link">Odisha Telemedicine »</a>
					</div>
				</div>
			</header>
			<nav class="navbar navbar-expand-sm navbar-light bg-light">
			  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
			    <span class="navbar-toggler-icon"></span>
			  </button>

			  <div class="collapse navbar-collapse" id="navbarSupportedContent">
			    <ul class="navbar-nav mr-auto">
			      <li class="nav-item active">
			        <a class="nav-link" href="index.php"><img src="images/home.png"> Home <span class="sr-only">(current)</span></a>
			      </li>
			      <li class="nav-item dropdown">
			        <a class="nav-link dropdown-toggle" href="javascript:void(0)" id="navbarDropdown" role="button" data-hover="dropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
			          <img src="images/about-us.png"> About Us
			        </a>
			        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
			          	<a class="dropdown-item" href="ottet.php">OTTET</a>
						<a class="dropdown-item" href="mission-vision.php">Mission &amp; Vision</a>
						<a class="dropdown-item" href="source-of-inspiration.php">Source of Inspiration</a>
						<a class="dropdown-item" href="road-map.php">Road Map</a>
						<a class="dropdown-item" href="technology.php">Technology</a>
						<a class="dropdown-item" href="manpower.php">Manpower</a>
						<a class="dropdown-item" href="network.php">Network</a>
						<a class="dropdown-item" href="nodes.php">Nodes</a>
						<a class="dropdown-item" href="partners-associates.php">Partners &amp; Associates</a>
						<a class="dropdown-item" href="news-media.php">News &amp; Media</a>
			        </div>
			      </li>
			      <li class="nav-item dropdown">
			        <a class="nav-link dropdown-toggle" href="javascript:void(0)" id="navbarDropdown" role="button" data-hover="dropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
			          <img src="images/services.png"> Services
			        </a>
			        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
			          <a class="dropdown-item" href="overview.php">Overview</a>
						<a class="dropdown-item" href="school-health.php">School Health</a>
						<a class="dropdown-item" href="corporate-health.php">Corporate Health</a>
						<a class="dropdown-item" href="individuals-housing-societies.php">Individuals &amp; Housing Societies</a>
						<a class="dropdown-item" href="typical-targetted-programmes.php">Typical Targetted Programmes</a>
						<a class="dropdown-item" href="opd-ipd-registration-system.php">OPD &amp; IPD Registration System</a>
						<a class="dropdown-item" href="health-information-system-his.php">Health Information System(HIS)</a>
						<a class="dropdown-item" href="diagnostic-services.php">Diagnostic Services</a>
						<a class="dropdown-item" href="tele-education.php">Tele-Education</a>
			        </div>
			      </li>
			      <li class="nav-item dropdown">
			        <a class="nav-link dropdown-toggle" href="javascript:void(0)" id="navbarDropdown" role="button" data-hover="dropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
			          <img src="images/career.png"> Opportunities
			        </a>
			        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
			          <a class="dropdown-item" href="admission-procedure.php">Admission Procedure </a>
			          <a class="dropdown-item" href="mba-syllabus.php">MCA Syllabus</a>
			          <a class="dropdown-item" href="academic-calendar.php">Academic Calendar  </a>
			          <a class="dropdown-item" href="holiday-list.php">Holiday List </a>
			          <a class="dropdown-item" href="jee.php">JEE</a>
			        </div>
			      </li>
			      <li class="nav-item dropdown">
			        <a class="nav-link dropdown-toggle" href="javascript:void(0)" id="navbarDropdown" role="button" data-hover="dropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
			          <img src="images/workshop.png"> Activities
			        </a>
			        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
			          <a class="dropdown-item" href="faculty.php">Milestones</a>
			          <a class="dropdown-item" href="faculty-mca.php">Workshops</a>
			        </div>
			      </li>
			      <li class="nav-item">
			        <a class="nav-link" href="awards-accolades.php"><img src="images/accolades.png"> Awards & Accolades</a>
			      </li>
			      <li class="nav-item dropdown">
			        <a class="nav-link dropdown-toggle" href="javascript:void(0)" id="navbarDropdown" role="button" data-hover="dropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
			          <img src="images/gallery.png"> Gallery
			        </a>
			        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
			          <a class="dropdown-item" href=".php">Photo Gallery </a>
			          <a class="dropdown-item" href=".php">Video Gallery</a>
			        </div>
			      </li>
			      <li class="nav-item">
			        <a class="nav-link" href="contact-us.php"><img src="images/contact-us.png"> Contact Us</a>
			      </li>
			    </ul>
			  </div>
			</nav>