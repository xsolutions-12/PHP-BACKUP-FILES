<!DOCTYPE html>
<html>
<head>
	<title>About OTEET</title>
	<?php include_once 'include/css.php'; ?>
</head>
<body class="about-page">
	<div class="container">
		<div class="main-wrap">
			<?php include_once 'include/header.php'; ?>
			<div class="row">
				<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="inner-page-sec">
						<div class="inner-head">
							<h1 class="inner-title">About ISIT</h1>
							<span></span>
						</div>

						<div class="row">
							<div class="col-lg-3 col-md-3">
								<div class="img-box">
									<img src="images/mt.png" class="img-fluid">
									<h5>K N Bhagat <span>(Managing Trustee)</span></h5>
								</div>
							</div>

							<div class="col-lg-9 col-md-9">
								<p>The Orissa Trust of Technical Education and Training (OTTET), created in the year 1993 and born out of the Grace and Blessings of Bhagwan Sri Sathya Sai Baba, was conceived with the idea to foster and encourage Education of quality learning.</p>

								<p>OTTET is a Not for profit organisation registered under Indian Trust Act in the year 1993 located in Bhubaneswar and is involved in education, training and healthcare services and poverty eradication programmes in the state of Orissa since the year 1993. The detailed activities and the Philosophy of OTTET are as following;</p>
								<h2 class="center-bold">" Education is for Life and Not for Mere Living. <br> Soul of Education is Education of Soul "</h2>
							</div>
						</div>
						<p>Unfolding a newer approach to awakening an integral Education that would mean "Education for life and not mere living" the trust, ever since its inception has been making prodigious efforts in blending the invaluable Indian heritage and culture with the modern based education.</p>

						<p>Being responsive to the dramatic age of culmination of aeon of computer evolution and channelling computer studies at its best, OTTET has had the experience to contribute to technical education and advance and disseminate learning and knowledge by a diversity of means.</p>
						<h2 class="center-bold2">" There are no under developed countries in the world <br>there are only under managed ones "</h2>

						<p class="text-center">OTTET has moved ahead with the project linking several districts, hospitals, doctors etc. It has also kept in mind its basic philosophy regarding healthcare. In today's world, to achieve the goal of providing healthcare to all and specially the underprivileged, OTTET has kept the following in mind :</p>
						<ol>
							<li>Globalisation of Medicare : To get proper medical relief should be the very birth right of anydiseased person.</li>
							<li>De-commercialisation of Medicare : Receiving medical relief should not be beyond the means of any human being.</li>
							<li>Humanisation of Medical Aid : Doctors and para-medical staff should have a 'human' approach in thought, word and deed. They should practice 'Human Values'.</li>
							<li>Spiritualisation of Medical Profession : Attempt should be made not only to provide physical and psychological well being, but also to strengthen the Spirit of Man.</li>
						</ol>
						<p>by designing, developing and deploying of Rural Tele-health Network through creation of e-infrastructure at Village level, to facilitate delivery of healthcare advice and knowledge towards Preventive and Promotive Health, to the citizens at their doorstep.</p>
						<p>OTTET is the 1st organization of the country to roll out India’s 1st Telemedicine Project i.e ICT Enabled Model Healthcare Delivery Services in Allopathy & Alternative Medicine at the door step of Villagers.</p>

						<p>Based on the Public Private Partnership (PPP) model, OTTET in association with Government of Odisha rolled out such a platform in technical collaboration with School of Telemedicine & Biomedical Informatics, SGPGI, Lucknow, NATIONAL RESOURCE CENTER(NRC) for Telemedicine under the Ministry of Communication & IT and Ministry of Health & Family Welfare, Government of India with the support & co-operation of Government of Odisha.</p>
						<p><strong>OTTET Telemedicine has the following objectives:</strong></p>
						<ul>
							<li>Creation of e-Infrastructure at Village level to facilitate delivery of healthcare advice and knowledge towards Preventive and Promotive Health, to the citizens at their door step.</li>

							<li>Imparting training and skill to local unemployed youth in Tele-health technology and hand holdin them to develop self-employment through entrepreneurship, to act as ancillary unit of OTTET.</li>
							<li>Creating a technical pool of skilled healthcare ICT human resource for the state government to handle the health ICT infrastructure of the State, there by generating employment opportunity from which economic connectivity are going to emanate.</li>
						</ul>

						<div class="row">
							<div class="col-lg-4">
								<a class="f-btn" href="#">Source of Inspiration</a>
							</div>
							<div class="col-lg-4">
								<a class="f-btn" href="#">OTTET Roadmap</a>
							</div>
							<div class="col-lg-4">
								<a class="f-btn" href="#">Divine Grace</a>
							</div>
						</div>
					</div>
				</div>
				<?php include_once 'include/footer.php'; ?>
			</div>
		</div>
	</div>




	
	<?php include_once 'include/js.php'; ?>

</body>
</html>