<!DOCTYPE html>
<html>
<head>
	<title>News</title>
	<?php include_once 'include/css.php'; ?>
</head>
<body class="about-page">
	<div class="container">
		<div class="main-wrap">
			<?php include_once 'include/header.php'; ?>
			<div class="row">
				<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="inner-page-sec list-in">
						<div class="inner-head">
							<h1 class="inner-title">News</h1>
							<span></span>
						</div>
						<img src="images/network.jpg" class="mx-auto d-block img-fluid">
						<ul style=" margin-top: 15px;">
							<li><a href="#">Centre to Make OTTET a Model for Virtual Healtcare Plan</a></li>
							<li><a href="#">Indian Express - Telemedicine centre at RGH Inaugurated</a></li>
							<li><a href="#">Indian express - Scheme for screening kids health</a></li>
							<li><a href="#">Fundoscopy facility introduced in Berhampur hospital</a></li>
							<li><a href="#">Telemedicine Facility and Service</a></li>
							<li><a href="#">AIIMS Telemedicine Centre</a></li>
							<li><a href="#">Sunday Express - Wellness at their doorstep</a></li>
							<li><a href="#">Take Heart, Healthcare Now at your doorstep (Indian Express)</a></li>
						</ul>
					</div>
				</div>
				<?php include_once 'include/footer.php'; ?>
			</div>
		</div>
	</div>




	
	<?php include_once 'include/js.php'; ?>

</body>
</html>