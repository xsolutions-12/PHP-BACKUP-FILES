<!DOCTYPE html>
<html>
<head>
	<title>Partners Associates</title>
	<?php include_once 'include/css.php'; ?>
</head>
<body class="about-page">
	<div class="container">
		<div class="main-wrap">
			<?php include_once 'include/header.php'; ?>
			<div class="row">
				<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="inner-page-sec list-in">
						<div class="inner-head">
							<h1 class="inner-title">Major Partners and Associates</h1>
							<span></span>
						</div>
						<ul style=" margin-top: 15px;">
							<li>Govt. of Odisha
							<li>School of Telemedicine & Biomedical Informatics, SGPGIMS, Lucknow (National Resource Center for Telemedicine under Ministry of Communication & IT and Ministry of H& FW. Govt. of India )</li>
							<li>AIIMS, Bhubaneswar</li>
							<li>Narayan Hrudayalaya group of Hospitals</li>
							<li>Apollo group of Hospitals</li>
							<li>Global Hospitals Group</li>
							<li>Asian Institute of Gastroenterology, Hyderabad</li>
							<li>LV Prasad Eye Institute</li>
							<li>Ruban group of Hospitals, Bihar</li>
							<li>Kanangoo Institute of Diabetes Speciality</li>
							<li>Sri Sri Borda Hospital & Community Health Centre</li>
							<li>Asian Health Meter, Karnataka</li>
							<li>Healthcare Telebiomedical Pvt Ltd, Mumbai</li>
							<li>Surendra Hospital, Angul</li>
							<li>Sushrutam Clinic, Bhubaneswar</li>
							<li>Jaganath Seva Sadan, Bhubaneswar</li>
							<li>Kar Clinic & Hospital, Bhubaneswar</li>
							<li>Maharashtra Institute of Medical Education and Research, Maharashtra</li>
							<li>Ripplesoft Pvt. Ltd.</li>
							<li>Health Innovative Pvt. Ltd.</li>
							<li>Entrepreneurship Development Institute of India (EDI), Ahmadabad</li>
							<li>Indian Institute of Science and Information Technology, Bhubaneswar</li>
							<li>Bhubaneswar Institute of Management and Information Technology, Bhubaneswar</li>
						</ul>
					</div>
				</div>
				<?php include_once 'include/footer.php'; ?>
			</div>
		</div>
	</div>




	
	<?php include_once 'include/js.php'; ?>

</body>
</html>