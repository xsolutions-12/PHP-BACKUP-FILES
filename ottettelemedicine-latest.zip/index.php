<!DOCTYPE html>
<html>
<head>
	<title>Welcome iisit</title>
	<?php include_once 'include/css.php'; ?>
</head>
<body class="home-page">
	<div class="container">
		<div class="main-wrap">
			<?php include_once 'include/header.php'; ?>

			<div class="owl-carousel banner-slider">
				<div class="slider-item">
					<img src="images/slider1.jpg" class="img-fluid">
				</div>
				<div class="slider-item">
					<img src="images/slider2.jpg" class="img-fluid">
				</div>
				<div class="slider-item">
					<img src="images/slider3.jpg" class="img-fluid">
				</div>
				<div class="slider-item">
					<img src="images/slider4.jpg" class="img-fluid">
				</div>
				<div class="slider-item">
					<img src="images/slider5.jpg" class="img-fluid">
				</div>
				<div class="slider-item">
					<img src="images/slider6.jpg" class="img-fluid">
				</div>
				<div class="slider-item">
					<img src="images/slider7.jpg" class="img-fluid">
				</div>
				<div class="slider-item">
					<img src="images/slider8.jpg" class="img-fluid">
				</div>
				<div class="slider-item">
					<img src="images/slider9.jpg" class="img-fluid">
				</div>
				<div class="slider-item">
					<img src="images/slider10.jpg" class="img-fluid">
				</div>
			</div>

			<div class="notice-sec">
				<p><marquee onmouseover="this.stop()" onmouseout="this.start()"><a href="http://odisha.ottettelemedicine.com">Rollout of <strong>HEALTHCARE FOR ALL</strong> in PPP mode with Govt. of Odisha</a></marquee></p>
			</div>

			<div class="row">
				<div class="col-xl-9 col-lg-9 col-md-9 col-sm-12 col-xs-12">
					<div class="row">
						<div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-xs-12">
							<div class="wel-sec">
								<h4 class="head-bg">Our Inspiration</h4>
								<img src="images/baba1.jpg" class="img-fluid">
								<p>With the Grace & Blessings of Bhagavan Sri Sathya Sai Baba, OTTET Telemedicine inaugurated India's 1st ICT enabed Model Healthcare Delivery Services on the 94th birth anniversary of Biju Patnaik on 5th March, 2010.</p>
							</div>
						</div>

						<div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-xs-12 pad-r-5">
							<div class="row">
								<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
									<div class="list-box">
										<h4 class="head-bg">Telemedicine Initiative</h4>
										<ul class="panel-list">
											<li><a href="#">Vision/Mission</a></li>
											<li><a href="#">PPP Mode</a></li>
											<li><a href="#">Shared Observation</a></li>
											<li><a href="#">In News</a></li>
										</ul>
									</div>
								</div>
								<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
									<div class="list-box">
										<h4 class="head-bg">Our Strength</h4>
										<ul class="panel-list">
											<li><a href="#">Technology</a></li>
											<li><a href="#">Manpower</a></li>
											<li><a href="#">Network</a></li>
											<li><a href="#">Nodes</a></li>
											<li><a href="#">Partners & Associates</a></li>
										</ul>
									</div>
								</div>
							</div>
						</div>

						<div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-xs-12">
							<div class="row">
								<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
									<div class="list-box">
										<h4 class="head-bg">Where we are?</h4>
										<ul class="panel-list">
											<li><a href="#">RoadMap</a></li>
											<li><a href="#">BPL Programs</a></li>
											<li><a href="#">APL Programs</a></li>
											<li><a href="#">OPD/IPD</a></li>
											<li><a href="#">Specialist Consulting</a></li>
											<li><a href="#">Tele-Education</a></li>
										</ul>
									</div>
								</div>
								<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
									<div class="list-box">
										<h4 class="head-bg">Social Impact</h4>
										<ul class="panel-list">
											<li><a href="#">Employment Generation</a></li>
											<li><a href="#">Cost Effective Healthcare</a></li>
											<li><a href="#">Rural Healthcare</a></li>
										</ul>
									</div>
								</div>
							</div>
						</div>
						<div class="col-xl-12 col-lg-12 col-sm-12">
							<div class="list-box">
							<h4 class="head-bg">Project Highlights</h4>
							<ul class="high-list">
								<li><img src="images/icon-tick.gif" class="">A unique Mega ICT based e-Health project in the country with an employment opportunity for more than 100000 youths ;&nbsp; minimum 1 from each village of Odisha.</li>
								<li><img src="images/icon-tick.gif" class="">A unique &amp; transparent model of Resource convergence in PPP mode for Educare, Medicare &amp; Sociocare.</li>
								<li><img src="images/icon-tick.gif" class="">Fulfills&nbsp; the&nbsp; Universal&nbsp; Health&nbsp; Care&nbsp; (UHC)&nbsp; mandated&nbsp; in&nbsp; the 12th five years plan of the Country &amp; ICT Policy-2014 of Odisha</li>
								<li><img src="images/icon-tick.gif" class="">Health Care for All through Bridging the gap of Demand Supply mismatch Doctor-wise &amp; Facility-wise.</li>
								<li><img src="images/icon-tick.gif" class="">The initiative could able to bring leading Bio-pharmaceuticals multinational company &amp; Electronic System Design &amp; Manufacturing (ESDM) companies to the state.</li>
								<li><img src="images/icon-tick.gif" class=""> Pro-Poor &amp; Pro-People approach through Employment generation for All-round Health Care and Socio-Economic Development.&nbsp;</li>
								<li><img src="images/icon-tick.gif" class="">Created&nbsp; Ã¢â‚¬Å“Brand OdishaÃ¢â‚¬Â across the globe.</li>
								<li><img src="images/icon-tick.gif" class="">Installation of e-Health and Telemedicine infrastructure in all Govt. &amp; Pvt. Medical Colleges, DHHs, CHCs, PHCs, Sub-Centers, etc in order to give access to healthcare at the doorsteps to population living in far flung areas of 51.000 villages of Odisha using ICT platform in PPP mode.</li>
								<li><img src="images/icon-tick.gif" class="">Involvement of Govt. Partners from Design, Planning architecture of network and service model throughout implementation process with strict monitoring guidelines.</li>
								<li><img src="images/icon-tick.gif" class="">Unique Telehealth enterprise on PPP model first of its kind in the country in such dimension.</li>
								<li><img src="images/icon-tick.gif" class="">First project of its kind exploring potential of employment generation among unemployed rural youth, school drop outs, women segment of the society.</li>
								<li><img src="images/icon-tick.gif" class="">Potential for creating a mass of semi-skilled productive workers from among unskilled young unproductive population reducing burden on the society.</li>
								<li><img src="images/icon-tick.gif" class="">Access to Quality Healthcare at the doorstep of 51,000 villages</li>
								<li><img src="images/icon-tick.gif" class="">All the SUPER SPECIALITY HOSPITALS Interconnected with the Govt. &amp; Pvt. Medical Colleges, DHHs, SDHs, AHs, CHCs, PHCs, Sub-Centers.</li>
								<li><img src="images/icon-tick.gif" class="">Well equipped diagnostic facilities and innovative, easy-to-use and highly reliable biomedical devices available are installed at each node.</li>
								<li><img src="images/icon-tick.gif" class="">Computer System equipped with multimedia components to undertake audio-video consultations.</li>
								<li><img src="images/icon-tick.gif" class="">Deployment of trained manpower and management.</li>
								<li><img src="images/icon-tick.gif" class="">Tamper proof prescription mechanism.</li>
								<li><img src="images/icon-tick.gif" class="">Regular Health Screening facilities for All.</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
				<div class="col-xl-3 col-lg-3col-md-3 col-sm-12 col-xs-12 pad-l-0">
					<a href="#" class="down-ap">Download <br>Application Form</a>
					<iframe style="margin-bottom: 10px;" width="100%" height="168" src="https://www.youtube.com/embed/WHOAspv1B8k" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
					<iframe width="100%" height="168" src="https://www.youtube.com/embed/xN_XP55jbe4" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
					<p class="text-right"><a href="#">More Videos Ã‚Â»</a></p>
					<div class="full-sec">
						<h4 class="head-bg2">Highlights</h4>
						<div class="nt">
							<ul class="list-news" id="nt-example">
							   	<li style="overflow: hidden; float: none; width: 246px; height: 63px;">
							   		<img class="thumbnail" width="80" height="60" src="images/inauguration_kadaligarh_thumbnail.jpg" alt="Milestones's image">
							   		<a href="/posts/milestones/35/" title="Inauguration of OTTET Telemedicine Center at Kadaligarh, Sambalpur District, Orissa">Inauguration of OTTET Telemedicine Center at Kadaligarh, Sambalpur District, Orissa</a>
							   	</li>
								<li>
									<img class="thumbnail" width="80" height="60" src="images/health_camp_delanga_thumbnail.jpg" alt="Workshops's image">
									<a href="/posts/workshops/37/" title="Health Camp at Delanga Puri">Health Camp at Delanga Puri</a>
								</li>
								<li style="overflow: hidden; float: none; width: 246px; height: 63px;">
									<img class="thumbnail" width="80" height="60" src="images/health_camp_kalahandi_thumbnail.jpg" alt="Workshops's image">
									<a href="/posts/workshops/28/" title="Kalahandi Health Camp">Kalahandi Health Camp</a>
								</li>
								<li>
									<img class="thumbnail" width="80" height="60" src="images/health_camp_nayagarh_thumbnail.jpg" alt="Workshops's image">
									<a href="/posts/workshops/31/" title="Health Camp at Gambharidiha, Nayagarh">Health Camp at Gambharidiha, Nayagarh</a></li>
								<li style="overflow: hidden; float: none; width: 246px; height: 63px;">
									<img class="thumbnail" width="80" height="60" src="images/awareness_kalahandi_thumbnail.jpg" alt="Workshops's image">
									<a href="/posts/workshops/27/" title="Awareness Program on eHealth &amp; Telemedicine at Kalahandi">Awareness Program on eHealth &amp; Telemedicine at Kalahandi</a>
								</li>
								<li style="overflow: hidden; float: none; width: 246px; height: 63px;">
									<a href="/posts/milestones/63/" title="Contributes in fulfilling the mandate of WHO for #UHC &amp; UN for #SDGs">Contributes in fulfilling the mandate of WHO for #UHC &amp; UN for #SDGs</a></li>
								<li>
									<img class="thumbnail" width="80" height="60" src="images/inauguration-polsara_thumbnail.jpg" alt="Milestones's image">
									<a href="/posts/milestones/58/" title="Inauguration of Telemedicine Centre at Kabisurya nagar and Polsara, Ganjam">Inauguration of Telemedicine Centre at Kabisurya nagar and Polsara, Ganjam</a>
								</li>
								<li style="overflow: hidden; float: none; width: 246px; height: 63px;">
									<img class="thumbnail" width="80" height="60" src="images/kodala_inaugural_page_web_thumbnail_thumbnail.jpg" alt="Workshops's image">
									<a href="/posts/workshops/57/" title="Inauguration of Kodala Telemedicine Centre (Ganjam Dist)">Inauguration of Kodala Telemedicine Centre (Ganjam Dist)</a>
								</li>
								<li>
									<img class="thumbnail" width="80" height="60" src="images/rgh_rourkela_summary_thumbnail.jpg" alt="Milestones's image">
									<a href="/posts/milestones/51/" title="Telemedicine center at Rourkela Govt. Hospital">Telemedicine center at Rourkela Govt. Hospital</a>
								</li>
								<li style="overflow: hidden; float: none; width: 246px; height: 63px;">
									<img class="thumbnail" width="80" height="60" src="images/inauguration-ganjam-berhampur_summary_thumbnail.jpg" alt="Milestones's image">
									<a href="/posts/milestones/50/" title="Installation of e-Health &amp; Telemedicine Facilities in the District of Ganjam, Odisha">Installation of e-Health &amp; Telemedicine Facilities in the District of Ganjam, Odisha</a>
								</li>
								<li>
									<img class="thumbnail" width="80" height="60" src="images/aiims_inauguration1_thumbnail.jpg" alt="Milestones's image">
									<a href="/posts/milestones/45/" title="AIIMS-Bhubaneswar launches Telemedicine Centre in partnership with OTTET and SGPGI-Lucknow">AIIMS-Bhubaneswar launches Telemedicine Centre in partnership with OTTET and SGPGI-Lucknow</a>
								</li>
								<li style="overflow: hidden; float: none; width: 246px; height: 63px;">
									<img class="thumbnail" width="80" height="60" src="images/launching_nationwide_thumbnail.jpg" alt="Milestones's image">
									<a href="/posts/milestones/39/" title="Launching of OTTET Telemedicine Nationwide Network">Launching of OTTET Telemedicine Nationwide Network</a>
								</li>
								<li>
									<img class="thumbnail" width="80" height="60" src="images/inauguration_rairakhol_thumbnail.jpg" alt="Milestones's image">
									<a href="/posts/milestones/33/" title="Inauguration of Telemedicine Center at Rairakhol, Sambalpur, Orissa">Inauguration of Telemedicine Center at Rairakhol, Sambalpur, Orissa</a>
								</li>
								<li style="overflow: hidden; float: none; width: 246px; height: 63px;">
									<img class="thumbnail" width="80" height="60" src="images/initiative_tele_ophthalmology_thumbnail.jpg" alt="Milestones's image">
									<a href="/posts/milestones/40/" title="OTTET-SGPGI Tele Ophthalmology Initiative">OTTET-SGPGI Tele Ophthalmology Initiative</a>
								</li>
								<li>
									<img class="thumbnail" width="80" height="60" src="images/inauguration_tele_ophthalmology_thumbnail.jpg" alt="Milestones's image">
									<a href="/posts/milestones/36/" title="Inauguration  of OTTET's Tele-Ophthalmology Programme for Prevention of Blindness">Inauguration  of OTTET's Tele-Ophthalmology Programme for Prevention of Blindness</a>
								</li>
								<li style="overflow: hidden; float: none; width: 246px; height: 63px;">
									<img class="thumbnail" width="80" height="60" src="images/inauguration_kadaligarh_thumbnail.jpg" alt="Milestones's image">
									<a href="/posts/milestones/35/" title="Inauguration of OTTET Telemedicine Center at Kadaligarh, Sambalpur District, Orissa">Inauguration of OTTET Telemedicine Center at Kadaligarh, Sambalpur District, Orissa</a>
								</li>
								<li>
									<img class="thumbnail" width="80" height="60" src="images/health_camp_delanga_thumbnail.jpg" alt="Workshops's image">
									<a href="/posts/workshops/37/" title="Health Camp at Delanga Puri">Health Camp at Delanga Puri</a>
								</li>
								<li style="overflow: hidden; float: none; width: 246px; height: 63px;">
									<img class="thumbnail" width="80" height="60" src="images/health_camp_kalahandi_thumbnail.jpg" alt="Workshops's image">
									<a href="/posts/workshops/28/" title="Kalahandi Health Camp">Kalahandi Health Camp</a>
								</li>
								<li>
									<img class="thumbnail" width="80" height="60" src="images/health_camp_nayagarh_thumbnail.jpg" alt="Workshops's image">
									<a href="/posts/workshops/31/" title="Health Camp at Gambharidiha, Nayagarh">Health Camp at Gambharidiha, Nayagarh</a>
								</li>
								<li style="overflow: hidden; float: none; width: 246px; height: 63px;">
									<img class="thumbnail" width="80" height="60" src="images/awareness_kalahandi_thumbnail.jpg" alt="Workshops's image">
									<a href="/posts/workshops/27/" title="Awareness Program on eHealth &amp; Telemedicine at Kalahandi">Awareness Program on eHealth &amp; Telemedicine at Kalahandi</a>
								</li>
								<li style="overflow: hidden; float: none; width: 246px; height: 63px;">
									<a href="/posts/milestones/63/" title="Contributes in fulfilling the mandate of WHO for #UHC &amp; UN for #SDGs">Contributes in fulfilling the mandate of WHO for #UHC &amp; UN for #SDGs</a>
								</li>
								<li>
									<img class="thumbnail" width="80" height="60" src="images/inauguration-polsara_thumbnail.jpg" alt="Milestones's image">
									<a href="/posts/milestones/58/" title="Inauguration of Telemedicine Centre at Kabisurya nagar and Polsara, Ganjam">Inauguration of Telemedicine Centre at Kabisurya nagar and Polsara, Ganjam</a>
								</li>
								<li style="overflow: hidden; float: none; width: 246px; height: 63px;">
									<img class="thumbnail" width="80" height="60" src="images/kodala_inaugural_page_web_thumbnail_thumbnail.jpg" alt="Workshops's image">
									<a href="/posts/workshops/57/" title="Inauguration of Kodala Telemedicine Centre (Ganjam Dist)">Inauguration of Kodala Telemedicine Centre (Ganjam Dist)</a>
								</li>
								<li>
									<img class="thumbnail" width="80" height="60" src="images/rgh_rourkela_summary_thumbnail.jpg" alt="Milestones's image">
									<a href="/posts/milestones/51/" title="Telemedicine center at Rourkela Govt. Hospital">Telemedicine center at Rourkela Govt. Hospital</a>
								</li>
								<li style="overflow: hidden; float: none; width: 246px; height: 63px;">
									<img class="thumbnail" width="80" height="60" src="images/inauguration-ganjam-berhampur_summary_thumbnail.jpg" alt="Milestones's image">
									<a href="/posts/milestones/50/" title="Installation of e-Health &amp; Telemedicine Facilities in the District of Ganjam, Odisha">Installation of e-Health &amp; Telemedicine Facilities in the District of Ganjam, Odisha</a>
								</li>
							</ul>
							<div class="news-ctrl">
								<a href="javascript:void(0)" id="nt-example1-prev"><img src="images/left.png"></a>
								<a href="javascript:void(0)" id="nt-example1-next"><img src="images/right.png"></a>
							</div>
						</div>
					</div>
				</div>
				<?php include_once 'include/footer.php'; ?>
			</div>
		</div>
	</div>




	
	<?php include_once 'include/js.php'; ?>

</body>
</html>