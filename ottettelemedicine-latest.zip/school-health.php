<!DOCTYPE html>
<html>
<head>
	<title>School Health Services</title>
	<?php include_once 'include/css.php'; ?>
</head>
<body class="about-page">
	<div class="container">
		<div class="main-wrap">
			<?php include_once 'include/header.php'; ?>
			<div class="row">
				<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="inner-page-sec list-in">
						<div class="inner-head">
							<h1 class="inner-title">School Health Services</h1>
							<span></span>
						</div>
						<h2 class="text-center">Screening of Students Under the School Health Programme</h2>
						<p><strong>The test includes:</strong></p>

						<p>Height, Weight, BMI, Vision Acuity, Refraction Errors, Blood Pressure, ECG, Heart Rate, Spirometry test, SPO2, Dental Screening, ENT, Skin Screening.</p>

						<p>We also take this opportunity to reiterate that the following services would be available both to the students as well as the school after installation of the telemedicine facility:</p>
						<p><strong>(a)   To the students</strong></p>
						<ol style=" margin-top: 15px;">
							<li>Annual Medical Checkup</li>
							<li>Recording data on the website to create PHR.</li>
							<li>Referral of students who require attention of a specialist, to referral centers and subsequent follow up of these cases.</li>
							<li>Access to school health portal.</li>
							<li>Unique Health ID card to every student.</li>
							<li>Comprehensive  personal health  information</li>
							<li>Global access to one’s own health record</li>
							<li>Allergies / Drug Reaction information</li>
							<li>Medication information</li>
							<li>Enhanced health awareness among the students</li>
							<li>Increased academic performance of the students as a result of improved health</li>
							<li>Easy access to one’s own health across the globe through Permanent Health Record</li>
						</ol>

						<p><strong>(b)   Service to School Management</strong></p>
						<ol style=" margin-top: 15px;">
							<li>Assistance in setting up a Medical Room within school Premises</li>
							<li>Close liaison is maintained by the school medical team with the school authorities</li>
							<li>Analysis of Medical Check-up to detect early warning signs</li>
							<li>Health profile of the school-Disease wise</li>
							<li>Regular MIS to school Authorities</li>
							<li>Accessibility  of  PHR to  School Medical Officer & Staff Nurse</li>
							<li>Regular updating data in PHR </li>
							<li>Discounted Consultations & Investigations</li>
							<li>All these facilities can be extended to parents and the siblings of the students.</li>
						</ol>

						<p><strong>(c)    Benefits of Program</strong></p>
						<ol style=" margin-top: 15px;">
							<li>Help students develop knowledge and skills to make smart choices.</li>
							<li>Detection of early warning signs.</li>
							<li>Future planning to meet any emergency situation.</li>
							<li>Nutritional supplements can be provided.</li>
							<li>Know how about the needs of special children.</li>
							<li>Access to health record in case of emergencies.</li>
						</ol>
					</div>
				</div>
				<?php include_once 'include/footer.php'; ?>
			</div>
		</div>
	</div>




	
	<?php include_once 'include/js.php'; ?>

</body>
</html>