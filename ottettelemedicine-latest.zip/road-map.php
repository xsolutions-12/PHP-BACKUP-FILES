<!DOCTYPE html>
<html>
<head>
	<title>Roadmap of OTTET Telemedicine</title>
	<?php include_once 'include/css.php'; ?>
</head>
<body class="about-page">
	<div class="container">
		<div class="main-wrap">
			<?php include_once 'include/header.php'; ?>
			<div class="row">
				<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="inner-page-sec list-in">
						<div class="inner-head">
							<h1 class="inner-title">Roadmap of OTTET Telemedicine</h1>
							<span></span>
						</div>
						<ol>
							<li>To provide Healthcare to all. To make available healthcare services at&nbsp;doorstep of 51,000 villages of the state within 3 years i.e by 30th November,2015.</li>
							<li><span>To connect 314 blocks through the telemedicine network, covering Block levels by&nbsp;</span>31st August<span>&nbsp;2013 &amp; all PHCs and CHCs by&nbsp;</span><span><span>31st December 2013</span></span><span>. Emphasis shall be given for covering all Health Institutions of Puri Districts in the 1st year of the 12th Plan.</span></li>
							<li>To extend the facility simultaneously upto Gram Panchayat level and every&nbsp;sub-centre level by 31st March, 2014.</li>
							<li>To extend the accessibility for consultation with specialists &amp; super-specialists for OPD and IPD patients which will not only save time and money but also provide quality healthcare service.</li>
							<li>To become the first state to train all 6688 ANM's, who will be trained with&nbsp;e-health programme by 31st March 2014.</li>
							<li>To train all 43000 ASHA workers to provide assistance for e-health at village&nbsp;level from 5th March, 2013.</li>
							<li>To extend Regular health screening facilities (Prevention is better than cure).</li>
							<li>To extend facility for reduction of out of pocket expenditure on healthcare</li>
							<li>To extend regular healthcare facility for<br>
								<ol style="list-style-type: lower-alpha;">
									<li>Preventive Care.</li>
									<li>Doctor Consultation &amp; Follow-ups.</li>
									<li>Specialist Consultation.</li>
									<li>Post Operative &amp; Chronic Disease Management.</li>
								</ol>
							</li>
							<li>Through creation of personal health record for the total population of Odisha within 2 years, an initiative 1<sup>st</sup> of its kind in the country for a quality healthcare delivery system as health is the real wealth.</li>
							<li>Through OTTET Telemedicine Network’s initiative in PPP mode with Govt of Odisha for<br>
								<ol style="list-style-type: lower-alpha;">
									<li>Creation of e-Infrastructure at Village level to facilitate delivery of healthcare advice and knowledge towards Preventive and Promotive Health, to the citizens at their door step.</li>
									<li>Creating a technical pool of skilled healthcare ICT human resource for the state government to handle the health ICT infrastructure of the State, there by generating direct and indirect employment opportunity for 7.5 lakhs people from which economic connectivity are going to emanate.</li>
								</ol>
							</li>
						</ol>
						<p style="text-align: center;font-size: 18px;line-height: 26px;width: 90%;margin: 0 auto;color: #449053; font-weight: 600;">“The need to protect the human body is of vital significance since it is the body that is responsible for performing any task.The human body is precious in the sense that it houses Divinity within itself.” </p>
					</div>
				</div>
				<?php include_once 'include/footer.php'; ?>
			</div>
		</div>
	</div>




	
	<?php include_once 'include/js.php'; ?>

</body>
</html>