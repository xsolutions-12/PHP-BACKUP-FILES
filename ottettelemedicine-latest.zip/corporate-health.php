<!DOCTYPE html>
<html>
<head>
	<title>Corporate Health Services</title>
	<?php include_once 'include/css.php'; ?>
</head>
<body class="about-page">
	<div class="container">
		<div class="main-wrap">
			<?php include_once 'include/header.php'; ?>
			<div class="row">
				<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="inner-page-sec list-in">
						<div class="inner-head">
							<h1 class="inner-title">Corporate Health Services</h1>
							<span></span>
						</div>
						<h2 class="text-center">Installation of OTTET Telemedicine Network for periodical health checkup of Employees with Videoconferencing Solution for Specialist/Super Specialist advice.</h2>
						<p>Orissa Trust of Technical Education and Training (OTTET) situated in Bhubaneswar was started in the year 1993 as a not-for-profit organization registered under Indian Trust Act. It is involved in education, training, healthcare services and poverty eradication programmes in PPP mode with the Govt. of Odisha.</p>

						<p>The OTTET Telemedicine model strives to strike a balance between curative and preventive services by utilizing the existing infrastructure of the public sector and the private sector to provide much needed health services and products in remote locations such as Mines, Industries and other PSUs. The network of facility centers created by OTTET addresses these needs with resources available locally and appropriate technology through a network of facility centers manned by trained telemedicine technicians. In this venture, SGPGIMS, Lucknow (National Resource Centre for telemedicine under ministry of IT and ministry of H& FW, Govt. of India), is our collaborating partner for providing the state-of-the-art technology and training.</p>
						<p><strong>The Proposal</strong></p>
 						<p>In keeping with the OTTET initiative of Holistic Health, it is proposed to install the telemedicine equipment with video conferencing facility at a suitable location within the premises of your esteemed organization to facilitate operations of our network infrastructure.</p>
						<p><strong>Services</strong></p>
						<ol style=" margin-top: 15px;">
							<li>We offer to undertake screening of health status of your employee, creation of Permanent Health records (PHR) and a health database for your organization.</li>
							<li>The tests include Height, Weight, BMI, Vision Acuity, Refraction Errors, Blood Pressure, ECG (charges extra), Heart Rate, Spirometry test, SPO2, Dental Screening & Skin Screening, Blood sugar test, Detection of Diabetic Retinopathy, Detection of Cataract, Detection of symptoms of Glaucoma, Urine test.</li>
							<li>In addition to the regular health screening, the network also provides for video consultation with empanelled doctors, in the following mode:
								<ol>
									<li>Patient – General Physician,</li>
									<li>Patient – Specialist and</li>
									<li>General Physician – Specialist</li>
								</ol>
							</li>
							<li>Presently our network provides consultations between the patient and a medical practitioner/specialist from some of the leading medical establishments like Narayan Hrudayalaya, Bangalore and it’s group of hospitals, Apollo Hospital, Kalinga Hospital, Bhubaneswar, Sri Sri Borda Hospital, Bhubaneswar, KIDS hospital, Bhubaneswar, LV Prasad Eye Institute, etc at an affordable cost through video conferencing using our network. It essentially obviates the patient having to travel to and from the speciality hospital location with its attendant expenses of boarding and lodging etc.</li>
						</ol>
						<p><strong>The Project</strong></p>
						<p>The project will be rolled out as follows: -</p>
						<ol style=" margin-top: 15px;">
							<li>The central hub should be ideally located in close proximity of the existing Medical Inspection room / First aid centre (if any). [A 12 feet x 12 feet enclosure would suffice]</li>
							<li>There would be two or more facility centers (depending on the spread of the establishment) dispersed within the Mining/Industrial area.</li>
							<li>These hub/facility centers could also be networked with other Industrial areas affiliated to the main establishment.</li>
							<li>Each central hub/facility center shall be manned by a telemedicine technician who is trained and certified by SGPGIMS, Lucknow.</li>
							<li>Each of the above centers would be connected to our empanelled hospitals (physicians/specialists/super specialists) through the OTTET Telemedicine network.</li>
							<li>Each center shall be equipped with specially designed and customized set of medical devices duly integrated to the OTTET Telemedicine network to perform the envisaged tasks. A minimum of 256 kbps bandwidth (upload and download) is required for the video consultation facility.</li>
							<li>Homecare services could be provided from any of these centers in emergencies and as and when required.</li>
						</ol>

						<p><strong>Benefits</strong></p>
						<p>The following benefits would accrue to the organization and employees:-</p>
						<ol style=" margin-top: 15px;">
							<li>Monthly/Quarterly/Annual Medical Checkup</li>
							<li>Recording data on the website to create PHR.</li>
							<li>Referral of Employees who require attention of a specialist, to referral centers and subsequent follow up of these cases.</li>
							<li>Access to health portal.</li>
							<li>Unique Health ID card to every Employee.</li>
							<li>Enhanced health awareness among the Employees.</li>
							<li>Access to Super Speciality Hospitals like Narayana Hrudayalaya, Apollo, AIIMS, Asian Institute of Gastroenterology, etc.</li>
							<li>Initial urgent evaluation of remote patients in case of emergency. Supervision and consultation for primary care in remote sites where a physician is not available.</li>
							<li>Medical and surgical follow-ups and medication checks.</li>
							<li>Transmission of diagnostic images (X-Ray, CT, MRI and Angiogram) and medical data.</li>
							<li>Management of chronic diseases and conditions requiring a specialist not available locally.</li>
							<li>Provide homecare services as desired by the organization.</li>
							<li>Could assist in CSR activities of the organization.</li>
							<li>Insurance coverage could be made available to employees as well as non-entitled persons as part of CSR activity.</li>
						</ol>

						<p><strong>Financial Aspects</strong></p>
						<p>The following to be borne by the company under:</p>
						<ol style=" margin-top: 15px;">
							<li>Equipment cost</li>
							<li>Uninterrupted electrical supply</li>
							<li>Bandwidth</li>
							<li>Appropriate accommodation for the technicians</li>
							<li>AMC of the equipments</li>
							<li>Insurance for the telemedicine setup</li>
						</ol>
						<p><strong>Conclusion</strong></p>
						<p>OTTET telemedicine network is a state of the art facility specially designed to make all state of medical assistance accessible to the patients/people residing in remotest of localities at very affordable costs.</p>
						<p class="text-center"><strong><i>“Make the medical information move… not the Patient”</i></strong></p>
					</div>
				</div>
				<?php include_once 'include/footer.php'; ?>
			</div>
		</div>
	</div>




	
	<?php include_once 'include/js.php'; ?>

</body>
</html>