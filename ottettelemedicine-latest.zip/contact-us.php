<!DOCTYPE html>
<html>
<head>
	<title>Contact Us</title>
	<?php include_once 'include/css.php'; ?>
</head>
<body class="about-page">
	<div class="container">
		<div class="main-wrap">
			<?php include_once 'include/header.php'; ?>
			<div class="inner-page-sec">
				<div class="row">
					<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<h1 class="inner-title">Contact Us</h1>
						<img src="images/iisit_locationmap.gif" class="img-fluid mx-auto d-block">
						<p class="text-center">Prasnagarbha, Plot. No-S-3/68, 69, & 83, Sec. A, Zone B</p>
						<p class="text-center">MancheswarInd.Estate, Bhubaneswar – 751010</p>
						<p class="text-center">Phone: 0674 - 600666666 / 600333333</p>
						<p class="text-center">Fax : 0674-2582001</p>
						<p class="text-center">Web site: www.iisit.in</p>
						<p class="text-center">Email Id : iisit@iisit.in</p>			
					<?php include_once 'include/footer.php'; ?>
				</div>
			</div>
		</div>
	</div>




	
	<?php include_once 'include/js.php'; ?>

</body>
</html>