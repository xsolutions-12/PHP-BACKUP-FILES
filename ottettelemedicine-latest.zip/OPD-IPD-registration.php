<!DOCTYPE html>
<html>
<head>
	<title>OPD and IPD Registration System with Vital Parameters and Creation of PHR</title>
	<?php include_once 'include/css.php'; ?>
</head>
<body class="about-page">
	<div class="container">
		<div class="main-wrap">
			<?php include_once 'include/header.php'; ?>
			<div class="row">
				<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="inner-page-sec list-in">
						<div class="inner-head">
							<h1 class="inner-title">OPD and IPD Registration System with Vital Parameters and Creation of PHR</h1>
							<span></span>
						</div>
						<h4 class="text-center">OTTET Telemedicine OPD & IPD Registration System <br>at all Govt. Hospitals upto Sub-Centre Level</h4>
						<ul style=" margin-top: 15px;">
							<li>At Dist. HQ Hospital (DHH) & Sub-Divisional Hospital (SDH) & Area Hospital, where all specialist services are available</li>
							<li>At CHC level where more than 2 specialist services are available & OPD patient load more than 100 per day</li></li>
							<li>Also at Medical Colleges, capital Hospital & Other big urban & rural hospitals</li>
						</ul>
						<img src="images/opd.jpg" class="mx-auto d-block img-fluid">

						<h3><strong>Objective of OPD &amp; IPD Registration System:</strong></h3>
<p><strong>&nbsp;</strong></p>
<h4><span style="text-decoration: underline;"><strong>OPD (Out-patient Department) SYSTEM:</strong></span></h4>
<ul>
<li>Not to keep the patients information but to know that how many specialist services utilized per day in OPD services</li>
<li>Optimum utilization of Doctors Services by centralizing the registration system</li>
<li>Reduced the paper work at department wise (Currently Doctor are recording the patient information like name, sex, age, address in register)</li>
<li>End of day we can generate the OPD reports :
<ul>
<li>Department wise</li>
<li>Age wise</li>
<li>Category wise (Male / Female / Child)</li>
<li>Also generate a report about <em>New case OPD registration &amp; Old Case OPD registration</em>. It implies that how many times a patient turns to a particular department for treatment or next time to which he/she has referred for treatment</li>
<li>How many cases referred to ward for taking admission in to bed</li>
<li>Also we can generate the user fee collection report day wise</li>
<li>Attendance &amp; available of Doctors list in OPD can be generated</li>
</ul>
</li>
</ul>
<h4><strong><span style="text-decoration: underline;">IPD (In-Patient Department) SYSTEM:</span></strong></h4>
<ul>
<li>Keep indoor patients information
<ul>
<li>Patients details &amp; brief history about his/her disease</li>
<li>Date of Admitted in to the Bed</li>
<li>Date of Discharge for Hospital</li>
</ul>
</li>
</ul>
<ul>
<li>End of day we can generate IPD reports :
<ul>
<li>Patients admitted in bed category wise (Male / Female / Child)</li>
<li>New patients admitted &amp; old patients continue department wise</li>
<li>No of patients admitted department wise</li>
<li>No of patients discharged department wise</li>
<li>Bed Occupancy Rate as a whole</li>
<li>Bed Occupancy Rate Department wise</li>
<li>Last day, the staffs were present in the duty department wise</li>
<li>How many Indoor patients referred to higher level hospitals for treatment department wise</li>
</ul>
</li>
</ul>
<p>&nbsp;</p>
<h3><strong><span style="text-decoration: underline;">In which way this small OPD &amp; IPD registration system will help the health administration in decision making?</span></strong></h3>
<p><strong><span style="text-decoration: underline;">&nbsp;</span></strong></p>
<p><strong>With help of this small registration system, we can analyze lot of activities: <br></strong></p>
<ul>
<li>The average OPD patient load department wise.</li>
<li>The trend of Bed Occupancy Rate department wise.</li>
<li>Departments in which more beds, more staff (Doctors, Paramedics, Cl-IV etc) or more civil infrastructure required.</li>
<li>Report on Patients treated in OPD by a individual Doctor calculated period wise.</li>
<li>% of Ambulance services used w.r.t referral cases can be generated.</li>
<li><em>24-Hrs staying of Preg. Mother after delivery can be tracked. By which we not only avoiding the Post partum complication but also ensuring the reduction of MMR.</em></li>
<li><em>JSY payment can be tracked &amp; false registration of deliveries in delivery register (Conversion of Home Delivery to institutional Delivery, No delivery to Instructional delivery) can be stopped.</em></li>
</ul>
					</div>
				</div>
				<?php include_once 'include/footer.php'; ?>
			</div>
		</div>
	</div>




	
	<?php include_once 'include/js.php'; ?>

</body>
</html>