<!DOCTYPE html>
<html>
<head>
	<title>Typical Targeted Programmes</title>
	<?php include_once 'include/css.php'; ?>
</head>
<body class="about-page">
	<div class="container">
		<div class="main-wrap">
			<?php include_once 'include/header.php'; ?>
			<div class="row">
				<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="inner-page-sec list-in">
						<div class="inner-head">
							<h1 class="inner-title">Typical Targeted Programmes</h1>
							<span></span>
						</div>
						<h4 class="text-center">OTTET Telemedicine supports - Handling of Typical Targeted Programmes</h4>
						<ol style=" margin-top: 15px;">
							<li>National Iodine Deficiency Disorder Control Programme (NIDDCP).</li>
							<li>National Vector Borne Disease Control Programme (NVBDCP)</li>
							<li>Integrated Disease Surveillance Project ( IDSP)</li>
							<li>National Leprosy Control Programme (NILCP)</li>
							<li>Reproductive and Child Health</li>
							<li>Revised National Tuberculosis Control Programme (RNTCP)</li>
							<li>Health awareness, social health (through videoconferencing, multimedia)</li>
							<li>Health records, immunization</li>
							<li>Health insurance</li>
							<li>Medicine inventory planning and tracking, reaching genuine medicines</li>
						</ol>
						<img src="images/ttp_initiatives.jpg" class="mx-auto d-block img-fluid">
					</div>
				</div>
				<?php include_once 'include/footer.php'; ?>
			</div>
		</div>
	</div>




	
	<?php include_once 'include/js.php'; ?>

</body>
</html>