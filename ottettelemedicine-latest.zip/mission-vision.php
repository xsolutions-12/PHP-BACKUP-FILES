<!DOCTYPE html>
<html>
<head>
	<title>Mission & Vision</title>
	<?php include_once 'include/css.php'; ?>
</head>
<body class="about-page">
	<div class="container">
		<div class="main-wrap">
			<?php include_once 'include/header.php'; ?>
			<div class="row">
				<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="inner-page-sec">
						<div class="inner-head">
							<h1 class="inner-title">Mission & Vision</h1>
							<span></span>
						</div>
						<img src="images/mission_and_vision.jpg" class="img-fluid mx-auto d-block">
					</div>
				</div>
				<?php include_once 'include/footer.php'; ?>
			</div>
		</div>
	</div>




	
	<?php include_once 'include/js.php'; ?>

</body>
</html>