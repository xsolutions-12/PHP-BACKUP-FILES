<!DOCTYPE html>
<html>
<head>
	<title>Overview</title>
	<?php include_once 'include/css.php'; ?>
</head>
<body class="about-page">
	<div class="container">
		<div class="main-wrap">
			<?php include_once 'include/header.php'; ?>
			<div class="row">
				<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="inner-page-sec list-in">
						<div class="inner-head">
							<h1 class="inner-title">Overview</h1>
							<span></span>
						</div>
						<h3>OTTET Telemedicine Services : <br> Direct Impact on Preventive and Curative Healthcare</h3>
						<img src="images/services_head.jpg" class="mx-auto d-block img-fluid">
						<div class="row">
						<div class="col-lg-5 col-md-5">
							<ul style="margin-top: 15px;">
								<li>Cardio-Vascular Diseases</li>
								<li>Hypertension, Anemia</li>
								<li>Diabetes</li>
								<li>Skin Diseases</li>
								<li>Respiratory Diseases</li>
								<li>Eye Care</li>
								<li>Chronic Disease Management</li>
								<li>Common Ailments & Non-Emergency Care</li>
								<li>Follow-ups & Referrals</li>
							</ul>
							<div style="float: left; font-weight: bold; color: #ffffff; background-color: #670004; padding: 20px; margin: 30px 10px 20px 20px; font-size: 130%; line-height: 150%; text-align: center; width: 100%;">
								<p>OTTET Telemedicine network  ensures that receiving medical relief is not beyond the means of any human being</p>
							</div>
						</div>
						<div class="col-lg-7 col-md-7">
							<img src="images/services_overview.jpg" class="mx-auto d-block img-fluid">
						</div>
					</div>
					<img src="images/services_category.jpg" class="mx-auto d-block img-fluid">
					</div>
				</div>
				<?php include_once 'include/footer.php'; ?>
			</div>
		</div>
	</div>




	
	<?php include_once 'include/js.php'; ?>

</body>
</html>