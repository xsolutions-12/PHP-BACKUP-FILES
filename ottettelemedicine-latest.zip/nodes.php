<!DOCTYPE html>
<html>
<head>
	<title>Nodes</title>
	<?php include_once 'include/css.php'; ?>
</head>
<body class="about-page">
	<div class="container">
		<div class="main-wrap">
			<?php include_once 'include/header.php'; ?>
			<div class="row">
				<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="inner-page-sec list-in">
						<div class="inner-head">
							<h1 class="inner-title">You Need to Log in to Access This Page.</h1>
							<span></span>
						</div>
						<form class="login-form">
							<h5 class="text-center">Login</h5>
							<label>Username</label>
							<input type="text" name="" placeholder="User Name">
							<label>Password</label>
							<input type="text" name="" placeholder="Password">
							<button class="login-btn">Login</button>
						</form>
					</div>
				</div>
				<?php include_once 'include/footer.php'; ?>
			</div>
		</div>
	</div>




	
	<?php include_once 'include/js.php'; ?>

</body>
</html>