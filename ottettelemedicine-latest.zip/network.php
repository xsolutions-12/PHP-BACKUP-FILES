<!DOCTYPE html>
<html>
<head>
	<title>Network</title>
	<?php include_once 'include/css.php'; ?>
</head>
<body class="about-page">
	<div class="container">
		<div class="main-wrap">
			<?php include_once 'include/header.php'; ?>
			<div class="row">
				<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="inner-page-sec list-in">
						<div class="inner-head">
							<h1 class="inner-title">Network</h1>
							<span></span>
						</div>
						<img src="images/network.jpg" class="mx-auto d-block img-fluid">
						<ul style=" margin-top: 15px;">
							<li>Government & Private Medical Colleges</li>
							<li>Government Hospital (District & Sub-Divisional Hospital, PHC, CHC, Sub-Center), Private Nursing Homes and Hospitals</li>
							<li>Speciality, Super-Speciality & Multi Speciality Hospitals in India</li>
							<li>Pathological Labs., Diagnostic Centers and Pharmacy outlets on our Telemedicine Network</li>
							<li>Common Service Centers</li>
							<li>Healthcare Service Centers</li>
						</ul>
					</div>
				</div>
				<?php include_once 'include/footer.php'; ?>
			</div>
		</div>
	</div>




	
	<?php include_once 'include/js.php'; ?>

</body>
</html>