<!DOCTYPE html>
<html>
<head>
	<title>Manpower</title>
	<?php include_once 'include/css.php'; ?>
</head>
<body class="about-page">
	<div class="container">
		<div class="main-wrap">
			<?php include_once 'include/header.php'; ?>
			<div class="row">
				<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="inner-page-sec list-in">
						<div class="inner-head">
							<h1 class="inner-title">Manpower</h1>
							<span></span>
						</div>
						<img src="images/manpower.jpg" class="mx-auto d-block img-fluid">
						<ul style=" margin-top: 15px;">
							<li><strong>Accredited Telemedicine Technicians</strong> certified by NRC<br>
							(School of Telemedicine & Biomedical Informatics)</li>
							<li><strong>Availability of Pool of Doctors & Specialists on the Telemedicine Network :</strong> Medical Professional<br>
							(General Physicians, Specialists, Super-specialists, Paramedics, Pharmacists)</li>
						</ul>
					</div>
				</div>
				<?php include_once 'include/footer.php'; ?>
			</div>
		</div>
	</div>




	
	<?php include_once 'include/js.php'; ?>

</body>
</html>