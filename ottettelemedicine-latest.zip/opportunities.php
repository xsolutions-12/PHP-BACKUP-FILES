<!DOCTYPE html>
<html>
<head>
	<title>Opportunities at OTTET Telemedicine</title>
	<?php include_once 'include/css.php'; ?>
</head>
<body class="about-page">
	<div class="container">
		<div class="main-wrap">
			<?php include_once 'include/header.php'; ?>
			<div class="row">
				<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="inner-page-sec list-in">
						<div class="inner-head">
							<h1 class="inner-title">Opportunities at OTTET Telemedicine</h1>
							<span></span>
						</div>
						<h2 style="text-align: left;"><strong>Employment Opportunities</strong> (<em>Applications Invited</em>)<strong><br></strong></h2>
						<p>OTTET Telemedicine in collaboration with the National Resource Center for Telemedicine established under Ministries of IT and H&amp;FW, Govt. of India, is imparting training and skill in Tele-health technology and hand holding to develop self-employment, to act as Venture Partners of OTTET.</p>
						<p><strong>Eligible Candidates:</strong></p>
						<ul>
						<li>Unemployed youth having 10+2 with basic computer knowledge</li>
						<li>BCA/DCA/O-level(DOEACC)/ITI/Polytechnic(IT/electronics/or equivalent) and Pathological Lab/Technicians</li>
						<li>Village Level Entrepreneurs managing CSC's (Common Service Centre) interested in extending Telemedicine Services</li>
						<li>SHG (Self Help Group) interested in extending Telemedicine Services</li>
						<li>ASHA Workers</li>
						<li>Pharmaceutical Stores</li>
						<li>Paramedics/ Nursing trained personnel / Pharmacists</li>
						</ul>
						<p><strong>Download Application Form : &nbsp;&nbsp;</strong></p>
						<p><a title="entrepreneur application form" target="_blank" href="images/entrepreneur_application_form.pdf">PDF Document</a></p>
						<p>&nbsp;</p>
						<h2><strong>Opportunity For Private Health Institutions, Nursing Homes and Clinics</strong></h2>
						<p>OTTET Telemedicine in Public Private Partnership(PPP) with Govt. of Odisha is establishing Telemedicine Centres across the state, both in public as well as in private health institutions starting from Medical colleges, Pvt Hospitals, Nursing Homes, CHCs, PHCs, Sub-centers, CSCs, etc.</p>
						<p>We are to identify and enroll suitable private Health institutions, nursing homes and clinics for providing healthcare services.</p>
						<p><strong>Download Institution Evaluation Form :</strong></p>
						<p><a title="Institution Evaluation Form - PDF Document" target="_blank" href="images/evaluation_form_for_enrollment_of_nursing_homes_clinics_pvt._hospitals.pdf">PDF Document</a>&nbsp; &nbsp;&nbsp;</p>
						<p>&nbsp;</p>
						<p><em><strong style="line-height: 150%;">All interested candidates please download the respective forms, fill out and send it to us.</strong></em></p>
					</div>
				</div>
				<?php include_once 'include/footer.php'; ?>
			</div>
		</div>
	</div>




	
	<?php include_once 'include/js.php'; ?>

</body>
</html>