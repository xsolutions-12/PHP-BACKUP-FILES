<section class="widget-section padding">
            <div class="container">
                <div class="widget-wrap row">
                    <div class="col-md-4 xs-padding">
                        <div class="widget-content">
                            <h3>ABOUT US</h3>
                            <p><span style="color: #f8b864">“Shree Shakti Bahumukhi Mahila Samabaya Samiti Limited”</span><br>A women institution commonly known as Shree Shakti Cooperative, has emerged as a model community-based organization in Sambalpur district of Odisha.</p>
                            <!-- <ul class="social-icon">
                                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fa fa-pinterest"></i></a></li>
                                <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                                <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                            </ul> -->
                        </div>
                    </div>
                    <div class="col-md-2 xs-padding">
                        <div class="widget-content">
                            <h3>QUICK LINKS</h3>
                            <ul class="address">
                                <li><i class="fa fa-angle-double-right"></i><a href="gallery.php" class="footer-link">Gallery</a></li>
                                <li><i class="fa fa-angle-double-right"></i><a href="#" class="footer-link">Governance</a></li>
                                <li><i class="fa fa-angle-double-right"></i><a href="#" class="footer-link">Privacy Policy</a></li>
                                <li><i class="fa fa-angle-double-right"></i><a href="#" class="footer-link">Terms & Conditions</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-3 xs-padding">
                        <div class="widget-content">
                            <h3>CONTACT US</h3>
                            <!-- <ul class="address">
                                <li><i class="ti-email"></i> <a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="1851767e775841776d6a5c7775797176367b7775">[email&#160;protected]</a></li>
                                <li><i class="ti-mobile"></i> +(333) 052 39876</li>
                                <li><i class="ti-world"></i> Www.YourWebsite.com</li>
                                <li><i class="ti-location-pin"></i> 60 Grand Avenue. Central New Road 0708, USA</li>
                            </ul> -->
                            <p><span style="color: #f8b864">(Regd No. 12/SBP/Dt.15.03.2024)</span><br> <br>At/Po : Thelkoloi, P.S. : Thelkoloi,<br>
                            Block : Rengali, District : Sambalpur, Odisha, India</p>
                        </div>
                    </div>
                    <div class="col-md-3 xs-padding">
                        <div class="widget-content">
                            <h3>REACH US</h3>
                            <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d474310.34616948926!2d84.012558!3d21.758981!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a20e1af962d2065%3A0x842f5c216ef209d3!2sThelkoloi%20Police%20Station!5e0!3m2!1sen!2sus!4v1757671951759!5m2!1sen!2sus" width="300" height="150" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                            <!-- <ul class="widget-link">
                                <li><a href="#">First charity activity of this summer. <span>-1 Year Ago</span></a></li>
                                <li><a href="#">Big charity: build school for poor children. <span>-2 Year Ago</span></a></li>
                                <li><a href="#">Clean-water system for rural poor. <span>-2 Year Ago</span></a></li>
                                <li><a href="#">Nepal earthqueak donation campaigns. <span>-3 Year Ago</span></a></li>
                            </ul> -->
                        </div>
                    </div>
                </div>
            </div>
</section><!-- ./Widget Section -->
<footer class="footer-section">
			<div class="container">
                <div class="row">
                    <div class="col-md-12 sm-padding">
                        <div class="copyright">&copy; 2024 Shree Shakti Bahumukhi Mahila Samabaya Samiti Limited. All Rights Reserved || Developed by <a href="chatbotsolutions.in" style="color: #ffffff;">CBSPL</a>.</div>
                    </div>
                    <!-- <div class="col-md-6 sm-padding">
                        <ul class="footer-social">
                            <li><a href="#">Orders</a></li>
                            <li><a href="#">Terms</a></li>
                            <li><a href="#">Report Problem</a></li>
                        </ul>
                    </div> -->
                </div>
			</div>
		</footer>