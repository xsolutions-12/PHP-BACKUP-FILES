<header id="header" class="header-section">
            <div class="top-header">
                <div class="container">
                    <div class="top-content-wrap row">
                        <div class="col-sm-8">
                            <ul class="left-info">
                                <li><a href="#"><i class="ti-email"></i><span>info@shreeshaktibahumukhi.com</span></a></li>
                                <!-- <li><a href="#"><i class="ti-mobile"></i>+(333) 052 39876</a></li> -->
                            </ul>
                        </div>
                        <div class="col-sm-4 d-none d-md-block">
                            <ul class="right-info">
                                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                                <li><a href="#"><i class="fa fa-youtube-play"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="bottom-header">
                <div class="container">
                    <div class="bottom-content-wrap row">
                        <div class="col-sm-2" style="padding-right: 0;padding-left: 0;">
                            <div class="site-branding">
                                <a href="index.php"><img src="img/logo/logo.png" alt="Brand" style="width: 50%; padding: 2px 0 2px 0;"></a>
                            </div>
                        </div>
                       <div class="col-sm-10 text-right">
                           <ul id="mainmenu" class="nav navbar-nav nav-menu">
                                <li class="active"> <a href="index.php">Home</a>
                                    <!-- <ul>
                                       <li><a href="index.html.htm">Home Default</a></li>
                                       <li><a href="index-2.html.htm">Home Modern</a></li>
                                    </ul> -->
                                </li>
                                <li><a href="#">Who We Are</a>
                                    <ul>
                                       <li><a href="about.php">About Us</a></li>
                                       <li><a href="cooperative.php">Our Cooperative’s</a></li>
                                       <li><a href="Legal-status.php">Legal Status</a></li>
                                       <li><a href="board-of-directors.php">Board of Directors</a></li>
                                       <li><a href="#">Governance</a></li>
                                       <li><a href="organisational-structure.php">Organisational structure</a></li>
                                       <li><a href="ourteam.php">Our Team</a></li>
                                    </ul>
                                </li>
                                <li><a href="#">Activities</a>
                                    <ul>
                                       <li><a href="capacity-building.php">Capacity Building & Livelyhood Initiative</a></li>
                                       <li><a href="ss-working-area.php">Shree Shakti Working Areas</a></li>
                                       <li><a href="activity-fy-24-25.php">Activity Details for FY 24-25</a></li>
                                    </ul>
                                </li>
                                <li><a href="#">Report</a>
                                    <ul>
                                       <li><a href="annual-report.php">Annual Report</a></li>
                                       <li><a href="#">Audit Report</a></li>
                                    </ul>
                                </li>
                                <li><a href="#">Events</a> 
                                    <ul>
                                       <li><a href="women's-day.php">International Women’s Day</a></li>
                                       <li><a href="workshop-ormas.php">Workshop on Financial Inclusion</a></li>
                                       <li><a href="events_24-25.php">Events FY: 2024-25</a></li>
                                       <li><a href="events_23-24.php">Events FY: 2023-24</a></li>
                                    </ul>
                                </li>
                                <li><a href="#">Training</a> 
                                    <ul>
                                       <li><a href="training-fy-2024-25.php">Training FY: 2024-25</a></li>
                                       <li><a href="training-fy-2023-24.php">Training FY: 2023-24</a></li>
                                    </ul>
                                </li>
                                <li><a href="#">Insights</a> 
                                    <ul>
                                       <li><a href="visit-fy-2024-25.php">Visit FY: 2024-25</a></li>
                                       <li><a href="visit-fy-2023-24.php">Visit FY: 2023-24</a></li>
                                    </ul>
                                </li>
                                <li> <a href="success-stories.php">Case Studies</a></li>
                                <li> <a href="contact.php">Contact Us</a></li>
                            </ul>
                            <a href="#" class="donate-btn">DONATE <img src="img/icon/donate.png" alt="donate" style="width: 18px; padding-bottom: 10px;"></a>
                       </div>
                    </div>
                </div>
            </div>
        </header>
        <div class="header-height"></div>