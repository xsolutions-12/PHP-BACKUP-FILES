<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="DynamicLayers">

    <title>Case Study 1 - Shree Shakti Bahumukhi</title>
    <!-- CSS Start -->
    <?php include 'includes/css.php';?>
    <!-- CSS End -->

</head>

<body>
    <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

    <div class="site-preloader-wrap">
        <div class="spinner"></div>
    </div><!-- Preloader -->

    <!-- Header Section Start -->
    <?php include 'includes/header.php';?>
    <!-- Header Section End -->



    <div class="pager-header" style="background-image: url(img/banner/banner-1.png);">
        <div class="container">
            <div class="page-content text-center">
                <h2>Case Study</h2>
                <!-- <p>Help today because tomorrow you may be the one who <br>needs more helping!</p> -->
                <ol class="breadcrumb justify-content-center">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item"><a href="success-stories.php">Success Stories</a></li>
                    <li class="breadcrumb-item active">Case Study</li>
                </ol>
            </div>
        </div>
    </div><!-- /Page Header -->



    <section class="about-section bg-grey bd-bottom padding">
        <div class="container">
            <div class="row about-wrap">

                <div class="col-md-7 xs-padding">
                    <div class="about-content">
                        <h2>Daring Dream – Story of Chumukti Santra (Fish Retail outlet)</h2>
                        <p><strong>Smt Khimeswari Meher</strong>, aged around 29 (twenty-nine), stands out as an example of individual
                            commitment towards agricultural practices in a sustainable way. She lives with her husband,
                            one son, and one daughter at Sunamal Village of Sripura GP. Her husband is the sole earning
                            member, working as a contract labourer. With a limited source of income, her life became not
                            so easy. She has land occupancy of .40 acres, in which she started farming and was able to
                            supplement nutrient food for her family in a meagre way. Besides that, she faced challenges
                            on the usage of alcohol by her husband, which created hurdles in her financial
                            sustainability and indiscipline life. Apart from this, her engagement in the agricultural
                            field generates income for her family’s survival and existence. Being an active member of
                            SHG, she is always able to save regularly, which acts as a saving property for her future.
                        </p>
                    </div>
                </div>
                <div class="col-md-5 xs-padding">
                    <div class="about-image">
                        <img src="img/success-stories/cs12.jpg" alt="Case Study 1">
                    </div>
                </div>
            </div>
            <div class="row about-wrap">

                <div class="col-md-12 xs-padding">
                    <div class="about-content">
                        <p>After obtaining a 10+2 pass qualification, Khimeswari made a rather curious choice of
                            adopting agriculture as her artistic medium. Being situated near the JSW Plant was famous
                            for its industry-based livelihood, but her quick adaptation to methods of vegetable farming
                            made her popular in this area. In such circumstances, the transformation of her livelihood
                            came into the picture when she continuously met with the JSW Shakti project team. Regular
                            visits to her SHG and meetings with them to explore the livelihood enhancement/income
                            generation path with the members. The curiosity shown by Khimeswari towards vegetable
                            farming and sale in the local market opened a new chapter for everybody. As time goes on,
                            the help from JSW Foundation shows the track of livelihood enhancement through the supply of
                            different seeds (leafy, tomato, brinjal, cowpea, lady’s finger, etc.). She started the
                            vegetable farming on a regular basis; in this connection, she was able to sell vegetables in
                            the local market easily. Her efforts have been shown on a large scale in their villages, and
                            she got an income of around Rs.6000 to Rs.8000. Apart from this, every Sunday she is
                            participating in SUNDAY HAAT, which is organized by JSW Foundation inside their JSW
                            Township.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section><!-- /About Section -->



    <!-- Footer Section Start -->
    <?php include 'includes/footer.php';?>
    <!-- Footer Section End -->

    <!-- Scroll To Top Section Start -->
    <?php include 'includes/scroll.php';?>
    <!-- Scroll To Top Section End -->

    <!-- JS Section Start -->
    <?php include 'includes/js.php';?>
    <!-- JS Section End -->
</body>

</html>