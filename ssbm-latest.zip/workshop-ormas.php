<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="DynamicLayers">

    <title>Workshop by ORMAS - Shree Shakti Bahumukhi</title>
    <!-- CSS Start -->
    <?php include 'includes/css.php';?>
    <!-- CSS End -->

</head>

<body>
    <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

    <div class="site-preloader-wrap">
        <div class="spinner"></div>
    </div><!-- Preloader -->

    <!-- Header Section Start -->
    <?php include 'includes/header.php';?>
    <!-- Header Section End -->



    <div class="pager-header" style="background-image: url(img/banner/banner-1.png);">
        <div class="container">
            <div class="page-content text-center">
                <h2>Workshop on Financial Inclusion</h2>
                <!-- <p>Help today because tomorrow you may be the one who <br>needs more helping!</p> -->
                <ol class="breadcrumb justify-content-center">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item active">Workshop on Financial Inclusion</li>
                </ol>
            </div>
        </div>
    </div><!-- /Page Header -->


    <section class="about-section bd-bottom padding">
        <div class="container">
            <div class="row about-wrap">

                <div class="col-md-8 xs-padding">
                    <div class="about-content">
                        <h2>District Level Workshop by ORMAS</h2>
                        <p>A district level marketing workshop organized by ORMAS Sambalpur at DRDA conference hall.
                            Basundhara SHG from Ghichamura participated from our project area. During this program CEO
                            from ORMAS, APD livelihood, GM RIC, GM Hindustan Sales ltd, DPC Mission Shakti presented and
                            encourages SHG Members. Packaging, Designing, Grading, Marketing and Value addition of
                            marketable products were discussed during meeting.</p>
                    </div>
                </div>
                <div class="col-md-4 xs-padding">
                    <div class="about-image">
                        <img src="img/about/workshop-ormas.jpg" alt="Case Study 1">
                    </div>
                </div>
            </div>


        </div>
    </section><!-- /About Section -->






    <!-- Footer Section Start -->
    <?php include 'includes/footer.php';?>
    <!-- Footer Section End -->

    <!-- Scroll To Top Section Start -->
    <?php include 'includes/scroll.php';?>
    <!-- Scroll To Top Section End -->

    <!-- JS Section Start -->
    <?php include 'includes/js.php';?>
    <!-- JS Section End -->
</body>

</html>