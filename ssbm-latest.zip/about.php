<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="en"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="">
        <meta name="author" content="DynamicLayers">
       
        <title>About Us || SSBM</title>
        
		<!-- CSS Start -->
         <?php include 'includes/css.php';?>
        <!-- CSS End -->
    </head>
    <body>
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
        
        <div class="site-preloader-wrap">
            <div class="spinner"></div>
        </div><!-- Preloader -->
        
        <!-- Header Section Start -->
        <?php include 'includes/header.php';?>
        <!-- Header Section End -->
                
        <div class="pager-header"  style="background-image: url(img/banner/banner-1.png);">
            <div class="container">
                <div class="page-content">
                    <h2>About Us</h2>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.html.htm">Home</a></li>
                        <li class="breadcrumb-item active">About Us</li>
                    </ol>
                </div>
            </div>
        </div><!-- /Page Header -->
        
        <section class="about-section padding">
            <div class="container">
                <div class="row about-wrap">
                    <div class="col-md-5 xs-padding">
                        <div class="about-image">
                            <img src="img/home/about.png" alt="about image">
                        </div>
                    </div>
                    <div class="col-md-7 xs-padding">
                        <div class="about-content">
                            <h2>Welcome to Shree Shakti Bahumukhi Mahila Sambaya Samiti LTD</h2>
                            <p style="color: #262525;margin-bottom: 5px;font-weight: 600;font-size: 14px;">“Shree Shakti Mahila Samabaya Samiti LTD” a women institution commonly known as Shree Shakti Cooperative, has emerged as a model community-based organization in Sambalpur district of Odisha.</p>
                            <p style="line-height: 25px;">“ <i style="color: #ed2719">Shree Shakti Bahumukhi Mahila Sambaya Samiti Ltd.</i> is an autonomous association of women members of Sambalpur District united voluntarily to meet their common economic, social and cultural needs and aspirations through a jointly owned and democratically controlled enterprise i.e. financial services”. Cooperatives as business enterprise possess some basic interests such as ownership and control but these interests are directly vested in the hands of the user. Therefore, Shree Shakti Bahumukhi Mahila Samabaya Samiti Ltd.follows certain broad values other than those associated purely with profit making. Here in Shree Shakti Cooperative the need for profitability is balanced by the needs of the members and the wider interest of the community.The values universally recognized as cornerstones of Shree Shakti principles are self-help, democracy, equality, equity and solidarity.Voluntary and open membership, democratic control, economic participation, autonomy, training and information and concern for community are the overarching features by which the Shree Shakti Cooperative put its values into practice. </p>
                        </div>
                    </div>
                </div>
                <div class="row about-wrap">
                    <div class="col-md-12 xs-padding">
                        <div class="about-content">
                            <p style="line-height: 25px; margin-left: -15px;">SHREE SHAKTI BAHUMUKHI MAHILA SAMABAYA LTD. is a self controlled and self managed women Cooperative, which is re-registered under Cooperative Societies Act 1962. The prime focus of the cooperative is to cater to the financial needs of the women in its operational areas and promote micro enterprises by providing Business Development Services and suitable market linkages to the potential entrepreneurs. <br>
                            On 15.03.2024 it is registered under Cooperative Society Act 1962 bearing Regd No. 12/SBP dated. 15.03.2024 at ARCS Sambalpur. Presently SHREE SHAKTI COOPERATIVE is operational in Rengali Block of Sambalpur district covering 15 villages from 4 Gram Panchyat (Lapanga, Khinda, Ghichamura, Thelkoloi). As per the requests of the other villagers, Shree Shakti Cooperative has a plan to expand its program area as and when required.
                        </p>
                        </div>
                    </div>
                </div>
            </div>
        </section><!-- /About Section -->

        <!-- Footer Section Start -->
        <?php include 'includes/footer.php';?>
        <!-- Footer Section End -->
        
        <!-- Scroll To Top Section Start -->
		<?php include 'includes/scroll.php';?>
        <!-- Scroll To Top Section End -->
	
        <!-- JS Section Start -->
        <?php include 'includes/js.php';?>
        <!-- JS Section End -->
</body>
</html>