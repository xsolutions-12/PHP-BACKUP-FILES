<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="DynamicLayers">

    <title>Gallery - Shree Shakti Bahumukhi</title>
    <!-- CSS Start -->
    <?php include 'includes/css.php';?>
    <!-- CSS End -->

</head>

<body>
    <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

    <div class="site-preloader-wrap">
        <div class="spinner"></div>
    </div><!-- Preloader -->

    <!-- Header Section Start -->
    <?php include 'includes/header.php';?>
    <!-- Header Section End -->



    <div class="pager-header" style="background-image: url(img/banner/banner-1.png);">
        <div class="container">
            <div class="page-content text-center">
                <h2>Gallery</h2>
                <!-- <p>Help today because tomorrow you may be the one who <br>needs more helping!</p> -->
                <ol class="breadcrumb justify-content-center">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item active">Gallery</li>
                </ol>
            </div>
        </div>
    </div><!-- /Page Header -->

    <section class="gallery-section bg-grey bd-bottom padding">
        <div class="container">

            <div class="row mt-none-30">

                <div class="col-md-3 xs-padding">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 0)">
                        <img src="img/gallery/1.jpg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 xs-padding">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 1)">
                        <img src="img/gallery/2.jpg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 xs-padding">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 2)">
                        <img src="img/gallery/3.jpg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 xs-padding">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 3)">
                        <img src="img/gallery/4.jpg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 xs-padding">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 4)">
                        <img src="img/gallery/5.jpg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 xs-padding">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 5)">
                        <img src="img/gallery/6.jpg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 xs-padding">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 6)">
                        <img src="img/gallery/7.jpg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 xs-padding">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 7)">
                        <img src="img/gallery/8.jpg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 xs-padding">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 8)">
                        <img src="img/gallery/9.jpg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 xs-padding">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 9)">
                        <img src="img/gallery/10.jpg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 xs-padding">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 10)">
                        <img src="img/gallery/11.jpg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 xs-padding">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 11)">
                        <img src="img/gallery/12.jpg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 xs-padding">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 12)">
                        <img src="img/gallery/13.jpg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 xs-padding">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 13)">
                        <img src="img/gallery/14.jpg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 xs-padding">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 14)">
                        <img src="img/gallery/15.jpg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 xs-padding">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 15)">
                        <img src="img/gallery/16.jpg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 xs-padding">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 16)">
                        <img src="img/gallery/17.jpg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 xs-padding">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 17)">
                        <img src="img/gallery/18.jpg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 xs-padding">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 18)">
                        <img src="img/gallery/19.jpg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div id="pictureGallery" class="d-none">
                    <a href="img/gallery/1.jpg"><img src="img/gallery/1.jpg"></a>
                    <a href="img/gallery/2.jpg"><img src="img/gallery/2.jpg"></a>
                    <a href="img/gallery/3.jpg"><img src="img/gallery/3.jpg"></a>
                    <a href="img/gallery/4.jpg"><img src="img/gallery/4.jpg"></a>
                    <a href="img/gallery/5.jpg"><img src="img/gallery/5.jpg"></a>
                    <a href="img/gallery/6.jpg"><img src="img/gallery/6.jpg"></a>
                    <a href="img/gallery/7.jpg"><img src="img/gallery/7.jpg"></a>
                    <a href="img/gallery/8.jpg"><img src="img/gallery/8.jpg"></a>
                    <a href="img/gallery/9.jpg"><img src="img/gallery/9.jpg"></a>
                    <a href="img/gallery/10.jpg"><img src="img/gallery/10.jpg"></a>
                    <a href="img/gallery/11.jpg"><img src="img/gallery/11.jpg"></a>
                    <a href="img/gallery/12.jpg"><img src="img/gallery/12.jpg"></a>
                    <a href="img/gallery/13.jpg"><img src="img/gallery/13.jpg"></a>
                    <a href="img/gallery/14.jpg"><img src="img/gallery/14.jpg"></a>
                    <a href="img/gallery/15.jpg"><img src="img/gallery/15.jpg"></a>
                    <a href="img/gallery/16.jpg"><img src="img/gallery/16.jpg"></a>
                    <a href="img/gallery/17.jpg"><img src="img/gallery/17.jpg"></a>
                    <a href="img/gallery/18.jpg"><img src="img/gallery/18.jpg"></a>
                    <a href="img/gallery/19.jpg"><img src="img/gallery/19.jpg"></a>
                    <a href="img/gallery/20.jpg"><img src="img/gallery/20.jpg"></a>
                    <a href="img/gallery/21.jpg"><img src="img/gallery/21.jpg"></a>
                    <a href="img/gallery/22.jpg"><img src="img/gallery/22.jpg"></a>
                </div>

            </div>

        </div>
    </section><!-- /Gallery Section -->

    <!-- Footer Section Start -->
    <?php include 'includes/footer.php';?>
    <!-- Footer Section End -->

    <!-- Scroll To Top Section Start -->
    <?php include 'includes/scroll.php';?>
    <!-- Scroll To Top Section End -->

    <!-- JS Section Start -->
    <?php include 'includes/js.php';?>
    <!-- JS Section End -->
</body>

</html>