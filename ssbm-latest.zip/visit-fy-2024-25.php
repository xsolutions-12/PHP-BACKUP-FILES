<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="DynamicLayers">

    <title>Visit FY 2024-25 - Shree Shakti Bahumukhi</title>
    <!-- CSS Start -->
    <?php include 'includes/css.php';?>
    <!-- CSS End -->

</head>

<body>
    <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

    <div class="site-preloader-wrap">
        <div class="spinner"></div>
    </div><!-- Preloader -->

    <!-- Header Section Start -->
    <?php include 'includes/header.php';?>
    <!-- Header Section End -->



    <div class="pager-header" style="background-image: url(img/banner/banner-1.png);">
        <div class="container">
            <div class="page-content text-center">
                <h2>Visit FY 2024-25</h2>
                <!-- <p>Help today because tomorrow you may be the one who <br>needs more helping!</p> -->
                <ol class="breadcrumb justify-content-center">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item active">Visit FY 2024-25</li>
                </ol>
            </div>
        </div>
    </div><!-- /Page Header -->



    <section class="about-section bg-grey bd-bottom padding">
        <div class="container">

            <div class="row about-wrap">
                <div class="col-md-12 xs-padding">
                    <div class="about-title">
                        <h2>Daring Dream – Story of Chumukti Santra (Fish Retail outlet)</h2>
                    </div>
                </div>
                <div class="col-md-12 xs-padding">
                    <div class="about-content">
                        <p>Esteemed officials from our Head office, Access Development Services, New Delhi visited our
                            project in three different occasions during this FY 2024-25. Mrs. Shomita Kundu, Associated
                            Vice President visited and interacted with our members. She visited various unit like Puffed
                            Rice, Paper plate, Vegetable Vending, Weaving etc. During her 2 days visit program she also
                            interacted with Board members from Shree Shakti Co-Operative and attend their monthly review
                            meeting. She added few suggestions for holistic movement of co-operative and encourage every
                            staff to move forward. Head office staff miss Yukti Kharbandha also visited various units
                            and collected success stories of campion farmers. She also added art of photography to
                            staff. During the month of July 2024, Mr. Subhendu Rout AVP, Access Development Services
                            also visited for two days in our project area.
                        </p>
                    </div>
                </div>
            </div>

            <div class="row about-wrap">
                <div class="col-md-12 xs-padding">
                    <div class="about-title">
                        <h2>Exposure visit to Maha Mauli Farm Producer Co, Ltd.</h2>
                    </div>
                </div>
                <div class="col-md-9 xs-padding">
                    <div class="about-content">
                        <p>An Exposure program was conducted for members during the month of Dec 2024. Where members got
                            an opportunity to visit Maha Mauli Farm at Kuchinda. Where members got to know about various
                            types of cultivation, water reservation, Soil Conservation etc. Mr Ramesh Hadvi acted as
                            resource person for this exposure program. He delivered a training session to members about
                            Mushroom cultivation, Paddy, Tomato, Onion Cultivation. Over all it was a great experience.
                        </p>
                    </div>
                </div>
                <div class="col-md-3 xs-padding">
                    <div class="about-image">
                        <img src="img/visit-fy-2024-25/1.jpg" alt="1">
                    </div>
                </div>
            </div>

            <div class="row about-wrap">
                <div class="col-md-12 xs-padding">
                    <div class="about-title">
                        <h2>Visit of Govt and other Officials</h2>
                    </div>
                </div>
                <div class="col-md-3 xs-padding">
                    <div class="about-image">
                        <img src="img/visit-fy-2024-25/2.jpg" alt="2">
                    </div>
                </div>
                <div class="col-md-9 xs-padding">
                    <div class="about-content">
                        <p>Block program manager (BPM) of Lapanga and BDO of Rengali block visited to our projected
                            area. Visit of ORMAS CEO Interacted with farmers from different units like floriculture,
                            Paper plate, weaving at Banjiberna. They also visited phenyl unit at Thelkoloi and made good
                            remarks towards SHG members.
                        </p>
                        <p>Mrs. Neelam Singh, President Akshyanshya Club JSW, visited Lapanga new weaving Unit and
                            interacted with new weaving members. Discussed about their current income source and
                            progress about their weaving arts. Along with her Mr. Vishal Raj, Head CSR dept JSW visited
                            to site and encourage women entrepreneur.
                        </p>
                    </div>
                </div>
            </div>

            <div class="row about-wrap">
                <div class="col-md-12 xs-padding">
                    <div class="about-title">
                        <h2>BOD Exposure Program</h2>
                    </div>
                </div>
                <div class="col-md-9 xs-padding">
                    <div class="about-content">
                        <p>An Exposure program conducted for BOD to Gruhalaxmi Co-Operative Dhenkanal During FY
                            2024-2025. Where all Board of Directors from Shree Shakti Co-Operative participated. It was
                            a inter learning process. The main objective behind conduction of this program was to know
                            about co-operative management, Co-Operative business etc. CEO from Shree shakti Co-Operative
                            along with JSW staff also presented during visit.
                        </p>
                    </div>
                </div>
                <div class="col-md-3 xs-padding">
                    <div class="about-image">
                        <img src="img/visit-fy-2024-25/3.jpg" alt="3">
                    </div>
                </div>
            </div>

            <div class="row about-wrap">
                <div class="col-md-12 xs-padding">
                    <div class="about-title">
                        <h2>Exposure of Weaving Community</h2>
                    </div>
                </div>
                <div class="col-md-3 xs-padding">
                    <div class="about-image">
                        <img src="img/visit-fy-2024-25/4.jpg" alt="4">
                    </div>
                </div>
                <div class="col-md-9 xs-padding">
                    <div class="about-content">
                        <p>During FY 2024-25 an Exposure program conducted for Weaving units on 30.07.2024 to Kardola,
                            Sambalpur. More than 21 weaving members from operation area of Shree Shakti Co-Operative
                            participated. It was also a inter learning process. The main objective behind conduction of
                            this program was to finetune of weaving skill, product design and marketing strategy etc.
                            CEO from Shree shakti Co-Operative along with Access staff also presented during visit. This
                            is an effective exposure for weaver beneficiary by which they are highly brain storm with
                            this weaving activity
                        </p>
                    </div>
                </div>
            </div>

            <div class="row about-wrap">
                <div class="col-md-12 xs-padding">
                    <div class="about-title">
                        <h2>Goat Rearing Exposure Visit</h2>
                    </div>
                </div>
                <div class="col-md-9 xs-padding">
                    <div class="about-content">
                        <p>An exposure visit held in the month of January 2025 in which total 18 women farmers are
                            participated. Exposure visit done to the PADHAN GOAT FARM, RAJPUR, Jharsugdua . The farmers
                            are able to explore rearing of goat, health management and nutrition management, etc during
                            this exposure visit. At the same time the beneficiary also decided to procure the goats as
                            per their requirement.
                        </p>
                    </div>
                </div>
                <div class="col-md-3 xs-padding">
                    <div class="about-image">
                        <img src="img/visit-fy-2024-25/5.jpg" alt="5">
                    </div>
                </div>
            </div>

            <div class="row about-wrap">
                <div class="col-md-12 xs-padding">
                    <div class="about-title">
                        <h2>Visit of COO from JSW Foundation</h2>
                    </div>
                </div>
                <div class="col-md-3 xs-padding">
                    <div class="about-image">
                        <img src="img/visit-fy-2024-25/6.jpg" alt="6">
                    </div>
                </div>
                <div class="col-md-9 xs-padding">
                    <div class="about-content">
                        <p>On 29th September 2024, COO from JSW Foundation visited to the project village to explore the
                            various activity going under the livelihood programme. He was visited and interacted with
                            beneficiary on different activity like Weekly HAAT, Weaver Communities, Attended mixture
                            training programme, backyard poultry, etc . During this visit he was appreciate the work
                            done by JSW Foundation. He also added the valuable suggestion on different activities
                        </p>
                    </div>
                </div>
            </div>

            <div class="row about-wrap">
                <div class="col-md-12 xs-padding">
                    <div class="about-title">
                        <h2>Exposure Visit</h2>
                    </div>
                </div>
                <div class="col-md-9 xs-padding">
                    <div class="about-content">
                        <p>An exposure visit held in the month of December 2024 in which total 24 women farmers are
                            participated. Exposure visit done to the MAHA MAULI FARM Producer Co, Ltd. Kuchinda,
                            Sambalpur. The farmers are able to explore different types agricultural practices.
                        </p>
                    </div>
                </div>
                <div class="col-md-3 xs-padding">
                    <div class="about-image">
                        <img src="img/visit-fy-2024-25/1.jpg" alt="1">
                    </div>
                </div>
            </div>


        </div>
    </section><!-- /About Section -->



    <!-- Footer Section Start -->
    <?php include 'includes/footer.php';?>
    <!-- Footer Section End -->

    <!-- Scroll To Top Section Start -->
    <?php include 'includes/scroll.php';?>
    <!-- Scroll To Top Section End -->

    <!-- JS Section Start -->
    <?php include 'includes/js.php';?>
    <!-- JS Section End -->
</body>

</html>