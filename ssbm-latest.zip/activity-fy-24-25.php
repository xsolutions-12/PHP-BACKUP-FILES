<!doctype html>

<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="DynamicLayers">

    <title>Activity Details for FY 24-25</title>
    <!-- CSS Start -->
    <?php include 'includes/css.php'; ?>
    <!-- CSS End -->

</head>

<body>
    <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

    <div class="site-preloader-wrap">
        <div class="spinner"></div>
    </div><!-- Preloader -->

    <!-- Header Section Start -->
    <?php include 'includes/header.php'; ?>
    <!-- Header Section End -->



    <div class="pager-header" style="background-image: url(img/banner/banner-1.png);">
        <div class="container">
            <div class="page-content text-center">
                <h2>Activity Details for FY 24-25</h2>
                <!-- <p>Help today because tomorrow you may be the one who <br>needs more helping!</p> -->
                <ol class="breadcrumb justify-content-center">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item"><a href="success-stories.php">Activities</a></li>
                    <li class="breadcrumb-item active">Activity Details for FY 24-25</li>
                </ol>
            </div>
        </div>
    </div><!-- /Page Header -->



    <section class="about-section bg-grey bd-bottom padding">
        <div class="container">

            <div class="row about-wrap">
                <div class="col-md-12 xs-padding">
                    <div class="about-content">
                        <h2>Liaising with the line department for convergence and with different government schemes</h2>
                        <h6 style="font-weight: 600; font-size:15px;">➭ Convergence with Department of Agriculture, Horticulture, Veterinary and Mission Shakti for leverage of various schemes and credit services through SHG bank linkages</h6>
                        <h6 style="font-weight: 600; font-size:15px;">➭ Regularly meeting with ARCS and DRCS office Sambalpur for Cooperative functions and operations</h6>
                        <h6 style="font-weight: 600; font-size:15px;">➭ KVK Jharsuguda supported the mushroom training programs for 10 beneficiaries from SRIPURA panchayat</h6>
                        <h6 style="font-weight: 600; font-size:15px;">➭ Marketing support given ORMAS Sambalpur & Jharsuguda for marketing of SHG product through different events</h6>
                        <h6 style="font-weight: 600; font-size:15px;">➭ Extensive support from Odisha livelihood Mission (OLM) for promotion PG (Producer Group) and healthy credit linkage for our SHG (approximately 40 Lacs) which was used for their livelihood purposes.</h6>
                    </div>
                </div>
            </div>

            <!-- Vegetable -->
            <div class="row about-wrap">
                <div class="col-md-8 xs-padding">
                    <div class="about-content">
                        <p class="act-heading">Sensitization meetings with SHGs and Share Capital Collection</p>
                        <p>During the FY 24-25, Continuous meetings with the SHGs through the help of CRP and MBK from OLM to sensitize the members regarding the benefits that they can avail by JSW Shakti project through the Cooperative/Producer company and how they are going to take actively participation to increase their livelihood income. Meeting with SHG is one of core activity since the project inception. The focus is to create awareness among the SHG members on our project activity. Within the FY 24-25 a total of 350 meeting conducted with coverage of 200 SHG within our project villages
                        </p>
                    </div>
                </div>
                <div class="col-md-4 xs-padding">
                    <img src="img/activities/act124-25.jpg">
                </div>
            </div>

            <div class="row about-wrap">
                <div class="col-md-12 xs-padding">
                    <div class="about-content">
                        <p class="act-heading">Monthly progress cum capacity building program for Core Project Team and BODs</p>
                        <p>A monthly interaction was conducted on 2nd March 2025 and 17th March 2025 with all the staffs and BODs in Co-operative office under the leadership of, Team Leader of ACCESS. Main objective of this interaction was to understand the project area and plan for different activities to achieve our target for this month. The objective was to sensitize Board members about Election Process and rule and regulation related to Co-Operative as it is going to complete one year tenure in the month of March 2025. We also reviewed different activities undertaken as per the timeline for the sustainability and success of the project. Vision of Society and inclusion of new member, were the major highlight points discussed during meeting. During this year every month we are conducting staff meeting and capacity building programme on project components and its sustainability.
                        </p>
                    </div>
                </div>

            </div>

            <!-- Puffed  -->
            <div class="row about-wrap">
                <div class="col-md-4 xs-padding">
                    <img src="img/activities/puffed-act24-25.jpg">
                </div>
                <div class="col-md-8 xs-padding">
                    <div class="about-content">
                        <p class="act-heading">Establishment of Puffed Rice Unit</p>
                        <p>A puffed rice unit was established in Sripura village during month of July 2023. As of now this unit is running successfully in this village. Total 5040 kg’s of puffed rice was produced from this unit which sold value around Rs. 3,27,600 and profit earned from this unit was Rs. 1,60, 684.00. Again from another unit from Lapanga village is going on. Smt Nitu Paule of Pragati SHG set up a puffed rice unit in her village. From Second unit total 1500 puffed rice was produced and sold amount was Rs. 92,600 and the profit came from this unit was Rs. 49,000/-
                        </p>
                    </div>
                </div>
            </div>

            <!-- Backyard -->
            <div class="row about-wrap">
                <div class="col-md-8 xs-padding">
                    <div class="about-content">
                        <p class="act-heading">Backyard Poultry</p>
                        <p>Last year we have distributed backyard poultry (Sonali Chicks) twice to 40 no’s of women beneficiary. Each member provided with 25 nos of chicks with feed of 10 kg. Members from Gourdihi, Banjiberna, Derba, Dhubenchapar covered under program. Regular monitoring and follow up is going on in all villages. It is found all chicks are in good conditions only 5% mortality found during initial phase of distribution. As such since the project inception total 1850 country birds provided to the women beneficiaries in this area. The duration of one cycle is 90 to 100 days. Each cycle members are getting approximately profit of Rs. 8000/- on a part time basis.
                        </p>
                    </div>
                </div>
                <div class="col-md-4 xs-padding">
                    <img src="img/activities/poultry24-25.jpg">
                </div>
            </div>

            <!-- Broiler Poultry Promotion -->
            <div class="row about-wrap">
                <div class="col-md-4 xs-padding">
                    <img src="img/activities/broiler-act124-25.jpg">
                </div>
                <div class="col-md-8 xs-padding">
                    <div class="about-content">
                        <p class="act-heading">Broiler Poultry Promotion</p>
                        <p>In this year we have distributed broiler chicks to the farmer two times, Total of 10 broiler unit’s setup while other 6 old beneficiaries are continuing their broiler activity by their own contribution. Each farmer received 100 broiler chicks from project fund. This year we have distributed total 800 broiler chicks and Starter & pre starter distributed to women beneficiary. Within this year (FY 24-25) from the project fund we have distributed broiler chicks twice to 8 no’s of beneficiary. Total amount sold under this activity was Rs.1,48,960/- and after the expenditure of Rs. 92160/- net profit earn from this activity was Rs. 56,800/-. For sustainability of the activity all the beneficiaries through their own fund.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Vegetable farming Activity -->
            <div class="row about-wrap">
                <div class="col-md-8 xs-padding">
                    <div class="about-content">
                        <p class="act-heading">Progress on Vegetable farming</p>
                        <p>As vegetable farming is one of our farm based intervention in which we have distributed vegetable seeds to farmer in our project villages. But during the year FY 24-25 the farmers are grown their vegetable by their own contribution. During the year (FY 23-24) in the month of September, October & Novembers, we have distributed different types of seeds like Pumkin, bottle guard, bin, cucumber, brinjal, tomato, Cowpea, Bottle gourd, Brinjal, Ridge gourd, Leafy Vegetable, Okra, etc. It is observed that Rs 720450/- sold during the month of March 2025. In this year vegetable sale was reached around Rs.38 Lacs from different villages. The source marketing place was Rural Gram Panchayat HAAT and JSW township.
                        </p>
                    </div>
                </div>
                <div class="col-md-4 xs-padding">
                    <img src="img/activities/vegetable-act24-25.jpg">
                </div>
            </div>

            <!-- Phenyl, Dish Wash -->
            <div class="row about-wrap">
                <div class="col-md-4 xs-padding">
                    <img src="img/activities/phenyl-act24-25.jpg">
                </div>
                <div class="col-md-8 xs-padding">
                    <div class="about-content">
                        <p class="act-heading">Phenyl, Dish Wash production and Marketing.</p>
                        <p>Since the inception of the project total 3 units are running their phenyl unit. As part marketing of phenyl it sold in local market. But in the month of March 2025, Phenyl production and marketing was quite average. The table show the report of Phenyl sale in local market. Apart from Phenyl production Maa Tarini SHG Lapanga sold Rs 1500 of Snacks items. During the year FY 24-25, around 6357-liter phenyl sold in local market. Apart from this groups are engaged in different income generative activity like petty business, snacks item making, etc.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Cotton Wick Activity -->
            <div class="row about-wrap">
                <div class="col-md-8 xs-padding">
                    <div class="about-content">
                        <p class="act-heading">Cotton Wick Activity</p>
                        <p>Since the project inception the cotton wick activity is one of the prime activity through which members are getting income by making cotton wick from raw cotton materials on part time basis. In which the project team supported the raw material and training to the cotton wick beneficiaries. This Cotton Wick is been always providing livelihood to women members, we are focusing on their marketing and also supplying of raw material from the project. Last month on Mar 2025, a total of 65 members has prepared 245 kg of cotton wick and sold for Rs 147500/. Hence total cotton wicks sale reached to 2102 Kg. Members from Banjiberna, Budhiapali, Lapanga, Budhiapali, Ghichamura, Thelkoloi and Gumkarama involved in production of cotton wicks. Through the community contribution an automatic cotton wick machine also installed at Banjiberna Village. By this machine they are producing more cotton wicks which leads to their increase income
                        </p>
                    </div>
                </div>
                <div class="col-md-4 xs-padding">
                    <img src="img/activities/cotton-act24-25.jpg">
                </div>
            </div>

            <!-- Puffed Rice unit -->
            <div class="row about-wrap">
                <div class="col-md-4 xs-padding">
                    <img src="img/activities/puffed-act24-25.jpg">
                </div>
                <div class="col-md-8 xs-padding">
                    <div class="about-content">
                        <p class="act-heading">Progress on Puffed Rice unit.</p>
                        <p>Since beginning of the project, we have installed a puffed unit from project fund at Sripura village and another unit from Lapanga village given the training support to the beneficiary. Under this activity, the puffed rice unit is functioning properly at Sripura village. Total 1040 Kgs of raw material (rice) was processed in this unit and again from this unit 80Kg of fried paddy and 100 kg of Green Gram are process in this unit which added extra income. As such the sale from this unit reached Rs 62400/- only in Puffed Rice. Again Rs. 20840/- profit earn by this unit. Again, from another unit at Lapanga village, Smt Nitu Paule of Pragati SHG set up a puffed rice unit. Last month 850 Kg of puffed rice was prepared from this unit and got profit of Rs. 17850/- from it. During FY 2024-2025 it is found that 20105 kg of puffed rice processed throughout the year. These two units are running regularly with good profit.
                        </p>
                    </div>
                </div>
            </div>
            <!-- Paper plate unit. -->
            <div class="row about-wrap">
                <div class="col-md-8 xs-padding">
                    <div class="about-content">
                        <p class="act-heading">Paper plate unit</p>
                        <p>As of now, two paper plates are running now with good profit. The machinery supports given by OLM (Odisha Livelihood Mission). Two nos. of Unit have been engaged in production and sell of Paper Plate, in local market to whom we have provided raw material support as well as marketing support. We have added few values to their unit. A regular follow up taken every month to know their production and sale data. During this current year (FY 24-25) the income from paper plate unit was reached sales to Rs. 9, 86,550 has been shown good business from both paper plate unit. From these two units a total amount profit of Rs. 4,92,700/- done in this year.
                        </p>
                    </div>
                </div>
                <div class="col-md-4 xs-padding">
                    <img src="img/activities/paper2-act24-25.jpg">
                </div>
            </div>

            <!-- Mixture production-->
            <div class="row about-wrap">
                <div class="col-md-4 xs-padding">
                    <img src="img/activities/mixture-act24-25.jpg">
                </div>
                <div class="col-md-8 xs-padding">
                    <div class="about-content">
                        <p class="act-heading">Mixture production</p>
                        <p>We are working with three nos. of mixture units in three different villages(Banjiberna, Lapanga and Ghichamura). Two units were started in July 2023. Electricity, Utensil and other essential materials were born by SHG and raw material supported from JSW Project. Another unit was setup in February 2024 at Ghichamura village. Out of three units, during this Year FY 24-25 one of the group (Ramchandi SHG) from Lapanga village got good approximately profit of Rs. 1,18,000/-.
                        </p>
                    </div>
                </div>
            </div>
            <!-- Dairy Development -->
            <div class="row about-wrap">
                <div class="col-md-8 xs-padding">
                    <div class="about-content">
                        <p class="act-heading">Dairy Development</p>
                        <p>Since the beginning of the project, Under dairy development activity we have distributed 4500 kg’s of cattle feed and 10-liter milk cane to 30 farmers. Then during the month of February total of 1700 kg’s of dairy feed distributed to 12 farmers. Sideways with this we have done a capacity building program for dairy farmers through the support of Assistant veterinary officer from Jharsuguda District. Again, we also distributed Mixture mineral and calcium to dairy farmers. The coping mechanism for dairy feed distribution was purely through the community contribution. As each month continuously with approach of collective marketing we have distributed feed to the dairy farmers. Since Sept 2024 feed distribution was started with 1000 kg and as on March 2025 the feed distribution reached to 3000 kg. The objective of the collective marketing of dairy feed is to enhance the milk production through quality feed supply, reduce transportation cost and health management of milky animal. Within this year more than 3 lacs liters of milk produced by farmer.
                        </p>
                    </div>
                </div>
                <div class="col-md-4 xs-padding">
                    <img src="img/activities/dairy-act24-25.jpg">
                </div>
            </div>

            <!-- Goat Rearing Activity -->
            <div class="row about-wrap">
                <div class="col-md-4 xs-padding">
                    <img src="img/activities/goat2-act24-25.jpg">
                </div>
                <div class="col-md-8 xs-padding">
                    <div class="about-content">
                        <p class="act-heading">Goat Rearing Activity</p>
                        <p>During the FY 22-23, Under this goat rearing activity we have distributed 24 goats (20 female goat and 4 male goats) to 12 beneficiaries. All goats are healthy and gaining weight. From government department goat tagging completed in Sripura village, and for goat insurance essential document with premium amount submitted at Government veterinary department Jharsuguda. Goats from Other villages from Lapanga and Ghichamura GP also completed tagging process through the support of Livestock Inspector from LAPANGA GP. Last year based on pass on gift concept No of goats are reached to 34 and all goats are reached to more than weight of 650 Kg’s Through the support of PADHAN Goat Farm, Rajpur we have distributed 24 goats to the 12 Women beneficiary.
                        </p>
                    </div>
                </div>
            </div>
            <!-- Floriculture Activity (Marigold) -->
            <div class="row about-wrap">
                <div class="col-md-8 xs-padding">
                    <div class="about-content">
                        <p class="act-heading">Floriculture Activity (Marigold)</p>
                        <p>On this activity, since the beginning training and seedling support given from JSW Shakti project. Since last two years around 82 farmers are involved in this activity. Around 15000 seedlings are received from Department of Horticulture. Again, exposure cum training program also arranged for marigold farmers from JSW Shakti project. Every year from September month onwards marigold production was started and it was closed by March As such in the year FY 24-25, Approximately a total of 2.3 tons of marigold flowers are sold in local market. Under this activity we have distributed seedlings to 15no’s of member from Gourdihi, Dhubenchapar, Derba and Banjiberna. Total 8500 seedling distributed during season. All members were instructed to planted in line method. Again, members from Banjiberna have prepared 2500 no’s of seedling and supplied to other members. Members have started selling their produce from the September- October month onward. As on the March 2025, a total of 850 kg of marigold sold at Rs 100 per kg generating income of Rs 85000/-. Due to summer the Production of Marigold production is goes down. We are providing marketing support to all beneficiaries on regular basis. We have provided 2000nos of sidling to a single beneficiary of Banjiberna during this summer season on trial basis to know the production and adoptability.
                        </p>
                    </div>
                </div>
                <div class="col-md-4 xs-padding">
                    <img src="img/activities/margold-act24-25.jpg">
                </div>
            </div>

            <!-- Weekly HAAT inside JSW Township. -->
            <div class="row about-wrap">
                <div class="col-md-4 xs-padding">
                    <img src="img/activities/haat-act24-25.jpg">
                </div>
                <div class="col-md-8 xs-padding">
                    <div class="about-content">
                        <p class="act-heading">Weekly HAAT inside JSW Township.</p>
                        <p>The SHG women of the Cooperative sell vegetables and other produce (flowers, Agarbatti, phenyl, cotton wicks, mushroom, fruits, etc.) at a weekly haat held inside the JSW township every Sunday. It provides a platform for the SHG women to sell their products and for the JSW township residents to procure fresh items from the source. As such Since the month of October 2023 with the support of JSW Foundation, we initiated Weekly HAAT (Every Sunday) inside JSW Township in which the different village level products are displayed in an outlet for their employees. Particularly the products like vegetables, Cotton Wicks, Mushroom, Fruits, Mixture, Phenyl, Dishwash, etc. are sold inside the premises. Last month (March 2025) total 5 number weekly HAATS were conducted inside township. It is found that more than Rs 45000 sold every week.
                        </p>
                    </div>
                </div>
            </div>
            <!--Agri Outlet (Vegetable Vending)-->
            <div class="row about-wrap">
                <div class="col-md-8 xs-padding">
                    <div class="about-content">
                        <p class="act-heading">Agri Outlet (Vegetable Vending)</p>
                        <p>Starting up a vegetable vending is a profitable venture as these are needed by every household in every season in everywhere. In continuation to Agri Outlet activity the beneficiaries have distributed the weight machine, Grading Table, Plastic carat through the support of JSW Shakti project. As such they are continuing their business throughout the month and they are getting good income form this outlet. In the month of April 2024, we have diverted this activity into Fish vending activity in which we have provided Standing Umbrella, Freezer box for Storage of fish and Weight Machine to 8 beneficiaries. It was found that member is getting income more than Rs 21 lacs during the year FY 2024-2025 from Agri Retail outlet.
                        </p>
                    </div>
                </div>
                <div class="col-md-4 xs-padding">
                    <img src="img/activities/outlet-act24-25.jpg">
                </div>
            </div>

            <!-- Fishery Activities (In Land Fisheries) -->
            <div class="row about-wrap">
                <div class="col-md-12 xs-padding">
                    <div class="about-content">
                        <p class="act-heading">Fishery Activities (In Land Fisheries)</p>
                        <p>In continuation with the fishery activities. Dantamura and Bansimal Villages which is commonly famous for their in-land fishery activities. As they are quite handy with traditional fishing from Bank of Mahanadi River, they are able to manage their livelihoods through this activity. From Dantamura village around 20-25 farmers are doing this activity. From the project we have provided the marketing support in a better price. They procure the fish from river and sale through the dealer in Jharshuguda. It is one of the regular livelihood activities for inland fishery farmers. Through this activity each farmer getting profit of Rs. 12000/- per month. Distribution of Fishing net (10 kg) to each will be distribute before April 2025.
                        </p>
                    </div>
                </div>
            </div>
            <!-- Fish Vending -->
            <div class="row about-wrap">
                <div class="col-md-8 xs-padding">
                    <div class="about-content">
                        <p class="act-heading">Fish Vending</p>
                        <p>We had identified and listed eight nos. of Fish vending members from our different project villages whose primary source of income is fish vending. It is decided to provided them a garden umbrella with weighting machine and an Icebox. To maintain the quality of perishable food stuff and save the vending members from daily losses these small initiatives will play a major role. Following are the details of their business. It was found that members getting profit of Rs. 18000/- per month throughout the FY 2024-2025. It helps to farmer to store the fish for long time and also helps for sitting long time below the gardening umbrella.
                        </p>
                    </div>
                </div>
                <div class="col-md-4 xs-padding">
                    <img src="img/activities/fish-act24-25.jpg">
                </div>
            </div>

            <!-- Petty -->
            <div class="row about-wrap">
                <div class="col-md-4 xs-padding">
                    <img src="img/activities/petty-act24-25.jpg">
                </div>
                <div class="col-md-8 xs-padding">
                    <div class="about-content">
                        <p class="act-heading">Petty Business</p>
                        <p>We are working with few beneficiaries who are engaged in petty business which functions on small scale level with less capital investment with less machine and labor. Regular follow up taken to bring out their sell. Through the SHG Bank linkage and loan support from Shree Shakti Co-Operative the petty business unit are established. We support them in market linkage and marketing their product. It is found that more total 152 members engaged in petty Business-like small shop, vending etc who are getting income from Rs 8000 to Rs 10000 every month. Under this activity, most of the beneficiaries are getting reasonable income through various trades like tea stall, tailoring, Stationaries shops, beauty parlor, ladies bangle shop, cycle repairing shop, etc.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Making of Sambalpuri Bandha design -->
            <div class="row about-wrap">
                <div class="col-md-8 xs-padding">
                    <div class="about-content">
                        <p class="act-heading">Making of Sambalpuri Bandha design</p>
                        <p>Continuous focus given on BANDHA work a part of Sambalpuri Saree Making. Since the beginning of the project, team has given emphasis on the training programme and exposure visit for weaver communities regarding making of BANDHA work and Sambalpuri Saree making. Total 24nos of members involves in the whole activity. Out of above said members 10no’s of members getting income from Bandha Design, while others are in learning process. At the same time 2 members are engaged in cotton roll work. Other 4 members are getting Sambalpuri Saree Making work. Last year with support of Akakhya ladies club provided 4 looms to beneficiary at Banjiberna villages. Around 2.42 lacs rupees got income from BANHDA design work during FY 24-25
                        </p>
                    </div>
                </div>
                <div class="col-md-4 xs-padding">
                    <img src="img/activities/bidha-act24-25.jpg">
                </div>
            </div>


            <!-- Repayment of Cooperative Loan -->
            <div class="row about-wrap">

                <div class="col-md-12 xs-padding">
                    <div class="about-content">
                        <p class="act-heading">Repayment of Cooperative Loan</p>
                        <p>As per project mandates we have registered a Cooperative under Odisha State Cooperative Act 1962. Hence during this year we have started our credit for the cooperative members. We have started micro finance loan through Shree Shakti Co-Operative from the month of Aug 2024 with a believe that our members will lift themselves out of poverty if they had access to affordable loan, they will invest it in income generating activities. Proper monitoring of loan and loan collection is a major part of project. Presently we have 166 nos. of loanee members. We have collected Rs 186268 during this month, out of which Principal amount is Rs 172000 and Interest amount is Rs 14268 which implies 100% of collection.
                        </p>
                    </div>
                </div>

            </div>

            <!-- Loan Appraisal and Loan Disbursement -->
            <div class="row about-wrap">
                <div class="col-md-8 xs-padding">
                    <div class="about-content">
                        <p class="act-heading">Loan Appraisal and Loan Disbursement</p>
                        <p>During FY 24-25 the Register Shree Shakti women cooperative started the loan programme since the month of August 2024. As of now an amount of Rs. 1860000 loan has been disbursed in 4 phases for Shree Shakti cooperative to 184 members for their livelihood enhancement. During this month we have generated loan proposal from different villages. Total 34nos of applications received from different villages and all are for different livelihood trades. Out of 20nos of loan applications we have disbursed total Rs 170000/- amount to 17nos of members.
                        </p>
                        <table>
                            <tbody>
                                <tr>
                                    <td width="280"><strong>Particulars</strong></td>
                                    <td width="280"><strong>No of Members Received Loan</strong></td>
                                    <td width="84"><strong>Amount</strong></td>
                                </tr>
                                <tr>
                                    <td width="280">Phase -01- August 2024</td>
                                    <td width="108">65</td>
                                    <td width="84">650000</td>
                                </tr>
                                <tr>
                                    <td width="280">Phase-02- September 2024</td>
                                    <td width="108">56</td>
                                    <td width="84">560000</td>
                                </tr>
                                <tr>
                                    <td width="280">Phase -03- October 2024</td>
                                    <td width="108">22</td>
                                    <td width="84">220000</td>
                                </tr>
                                <tr>
                                    <td width="280">Phase -04- February 2025</td>
                                    <td width="108">23</td>
                                    <td width="84">240000</td>
                                </tr>
                                <tr>
                                    <td width="280">Phase-05- March 2025</td>
                                    <td width="108">18</td>
                                    <td width="84">190000</td>
                                </tr>
                                <tr>
                                    <td width="280"><strong>Total</strong></td>
                                    <td width="108"><strong>184</strong></td>
                                    <td width="84"><strong>1860000</strong></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="col-md-4 xs-padding">
                    <img src="img/activities/loan-act24-25.jpg">
                </div>
            </div>
            <!-- Training on Sambalpuri Saree Designing for Weaver Communities -->
            <div class="row about-wrap" style="margin-top: 20px;">
                <div class="col-md-4 xs-padding">
                    <img src="img/activities/train-act24-25.jpg">
                </div>
                <div class="col-md-8 xs-padding">
                    <div class="about-content">
                        <p class="act-heading">Training on Sambalpuri Saree Designing for Weaver Communities</p>
                        <p>We are continuing training program on weaving skill for interested entrepreneur. This program will continue for 45 days at Banjiberna. More than 15 members are participating every day. Mrs. Bhumisuta Meher from Kardola, Chiplima acting as Resource Person. Making of graph, Weaving Skill, Designing are the few aspects discussed during training.
                        </p>
                    </div>
                </div>
            </div>
            <div class="row about-wrap">

                <div class="col-md-8 xs-padding">
                    <div class="about-content">
                        <p class="act-heading">Broom Stick Marketing</p>
                        <p>Under this project we have continuously giving marketing support to the broom stick beneficiaries. Normally in this area from the September month onward the broom stick making will start through drying and binding process. In this regard we have a collection point at Derba village from Ghichamura GP. Broom Sticks are collected from near by village and kept in the collection point. Finally it goes for marketing to other states through local traders. The member earns Rs 9000 per month from this marketing activity. Again, we have given credit support to the members from co-operative to enhance their marketing.
                        </p>
                    </div>
                </div>
                <div class="col-md-4 xs-padding">
                    <img src="img/activities/boom-act24-25.jpg">
                </div>
            </div>
        </div>
    </section>
    <!-- /About Section -->



    <!-- Footer Section Start -->
    <?php include 'includes/footer.php'; ?>
    <!-- Footer Section End -->

    <!-- Scroll To Top Section Start -->
    <?php include 'includes/scroll.php'; ?>
    <!-- Scroll To Top Section End -->

    <!-- JS Section Start -->
    <?php include 'includes/js.php'; ?>
    <!-- JS Section End -->
</body>

</html>