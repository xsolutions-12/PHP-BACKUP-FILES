<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="DynamicLayers">

    <title>Visit FY 2023-24 - Shree Shakti Bahumukhi</title>
    <!-- CSS Start -->
    <?php include 'includes/css.php';?>
    <!-- CSS End -->

</head>

<body>
    <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

    <div class="site-preloader-wrap">
        <div class="spinner"></div>
    </div><!-- Preloader -->

    <!-- Header Section Start -->
    <?php include 'includes/header.php';?>
    <!-- Header Section End -->



    <div class="pager-header" style="background-image: url(img/banner/banner-1.png);">
        <div class="container">
            <div class="page-content text-center">
                <h2>Visit FY 2023-24</h2>
                <!-- <p>Help today because tomorrow you may be the one who <br>needs more helping!</p> -->
                <ol class="breadcrumb justify-content-center">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item active">Visit FY 2023-24</li>
                </ol>
            </div>
        </div>
    </div><!-- /Page Header -->



    <section class="about-section bg-grey bd-bottom padding">
        <div class="container">

            <div class="row about-wrap">
                <div class="col-md-12 xs-padding">
                    <div class="about-title">
                        <h2>Visit of Assistant Register of Cooperative Society (ARCS)</h2>
                    </div>
                </div>
                <div class="col-md-9 xs-padding">
                    <div class="about-content">
                        <p>An official visit done by ARCS (Assistant Register of Cooperative Society) and Sr Clerk from
                            DRCS (District Register of Cooperative Society) on 4th January 2024. Had a fruitful
                            discussion on registration of Cooperative and also visited to different village to explore
                            the ongoing activities under JSW Shakti Project.
                        </p>
                    </div>
                </div>
                <div class="col-md-3 xs-padding">
                    <div class="about-image">
                        <img src="img/visit-fy-2023-24/1.jpg" alt="1">
                    </div>
                </div>
            </div>

            <div class="row about-wrap">
                <div class="col-md-12 xs-padding">
                    <div class="about-title">
                        <h2>Exposure to Goat Rearing Activity</h2>
                    </div>
                </div>
                <div class="col-md-3 xs-padding">
                    <div class="about-image">
                        <img src="img/visit-fy-2023-24/2.jpg" alt="2">
                    </div>
                </div>
                <div class="col-md-9 xs-padding">
                    <div class="about-content">
                        <p>There was an exposure visit done in the month June 2023 to PRADHAN GOAT FARM, RAJPUR
                            (BRAJRAJNAGAR) , in which total 12 famers are participated and got training on goat rearing
                            . The farmers are explored about feed, medicine, rearing of goats and shed construction
                            preparation during this training.
                        </p>
                    </div>
                </div>
            </div>

            <div class="row about-wrap">
                <div class="col-md-12 xs-padding">
                    <div class="about-title">
                        <h2>Exposure Visit to Horticulture Office , NILDUNGRI Day Orientation by Department of
                            Horticulture</h2>
                    </div>
                </div>
                <div class="col-md-9 xs-padding">
                    <div class="about-content">
                        <p>An intensive exposure visit made to NILDUNGRI(Sambalpur) horticulture office for training on
                            Mushroom cultivation. Around 25 Women’s are participated in this visit and they are explore
                            with theory and practical knowledge on Mushroom Cultivation. Most importantly members are
                            able to gain knowledge on management of mushroom bed in different climate situation.
                        </p>
                    </div>
                </div>
                <div class="col-md-3 xs-padding">
                    <div class="about-image">
                        <img src="img/visit-fy-2023-24/3.jpg" alt="3">
                    </div>
                </div>
            </div>

            <div class="row about-wrap">
                <div class="col-md-12 xs-padding">
                    <div class="about-title">
                        <h2>A Visit to Western Odisha Dairy Summit</h2>
                    </div>
                </div>
                <div class="col-md-3 xs-padding">
                    <div class="about-image">
                        <img src="img/visit-fy-2023-24/4.jpg" alt="4">
                    </div>
                </div>
                <div class="col-md-9 xs-padding">
                    <div class="about-content">
                        <p>By taking 20 Dairy farmers from project village are attended one day Western Odisha Summit
                            which was held in the month November 2023. In this dairy farmers are exposure to different
                            package of practices like feed mechanism, disease control, increase milk production and how
                            to manage the dairy farming in their area.
                        </p>
                    </div>
                </div>
            </div>

            <div class="row about-wrap">
                <div class="col-md-12 xs-padding">
                    <div class="about-title">
                        <h2>Exposure Visit on Marigold Cultivation</h2>
                    </div>
                </div>
                <div class="col-md-9 xs-padding">
                    <div class="about-content">
                        <p>During the month of November 2023, there was an exposure visit to Lakhanpur Village on
                            marigold cultivation. Total 25 members are visited to Mr. Lotan Sahu’s field to take the
                            inputs on different types marigold plants. Also the members are able to gain the knowledge
                            on management of temperature, watering to marigold plant variety of seedling available in
                            Kolkata Market.
                        </p>
                    </div>
                </div>
                <div class="col-md-3 xs-padding">
                    <div class="about-image">
                        <img src="img/visit-fy-2023-24/5.jpg" alt="5">
                    </div>
                </div>
            </div>


        </div>
    </section><!-- /About Section -->



    <!-- Footer Section Start -->
    <?php include 'includes/footer.php';?>
    <!-- Footer Section End -->

    <!-- Scroll To Top Section Start -->
    <?php include 'includes/scroll.php';?>
    <!-- Scroll To Top Section End -->

    <!-- JS Section Start -->
    <?php include 'includes/js.php';?>
    <!-- JS Section End -->
</body>

</html>