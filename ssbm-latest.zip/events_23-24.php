<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="en"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="">
        <meta name="author" content="DynamicLayers">
       
        <title>Events FY 2023-24 || SSBM</title>
        
		<!-- CSS Start -->
         <?php include 'includes/css.php';?>
        <!-- CSS End -->
    </head>
    <body>
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
        
        <div class="site-preloader-wrap">
            <div class="spinner"></div>
        </div><!-- Preloader -->
        
        <!-- Header Section Start -->
        <?php include 'includes/header.php';?>
        <!-- Header Section End -->
                
        <div class="pager-header" style="background-image: url(img/banner/banner-1.png);">
            <div class="container">
                <div class="page-content">
                    <h2>Events FY 2023-24</h2>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                        <li class="breadcrumb-item active">Events FY 2023-24</li>
                    </ol>
                </div>
            </div>
        </div><!-- /Page Header -->
        
        <!-- Accordion -->
        <section class="accordion-section">
            <div class="container">
                <div class="accordion" id="myAccordion">
                    <div class="acc-item">
                        <button class="acc-header" aria-expanded="false">
                            <span>Inauguration of PO</span>
                            <span class="acc-icon"><i class="fa fa-angle-double-right"></i></span>
                        </button>
                        <div class="acc-panel" aria-hidden="true">
                            <div class="acc-panel-inner content-side image-left">
                                <div class="text-side"><p>After getting the Registration Certificate from ARCS (Assistant Register of Cooperative Society), Sambalpur. Inauguration of PO done at Tehlkoloi office premises. In this event CSR Head from JSW Foundation , Manager from JSW Foundation and Mr. Summit Kumar (SBI Thelkoloi)  was attended as Guest of Honor. In the beginning of the program Team Leaders from ACCESS Development Services welcome the BOD’s and guest which followed by lightening of lamp. By attending this program CSR head from JSW Foundation  was focused on empowerment and sustainability of the PO and also urged  to everybody should be work in an Enterprise Model so that it helps to all women to be sustainable in their livelihood aspect.</p></div>
                                <div class="image-side" style="flex: 0 0 20%;"><img src="img/events/23-24/inaguration-po.jpg" alt="Inauguration PO"></div>
                            </div>
                        </div>
                    </div>

                    <div class="acc-item">
                        <button class="acc-header" aria-expanded="false">
                            <span>Awareness Program on MSME(Micro , Small and Medium Enterprise)</span>
                            <span class="acc-icon"><i class="fa fa-angle-double-right"></i></span>
                        </button>
                        <div class="acc-panel" aria-hidden="true">
                            <div class="acc-panel-inner content-side image-right">
                                <div class="text-side"><p>An one-day training cum awareness program on MSME sector was organized by Access Development Services on 30th Jan 2024 at Tailoring Centre, Thelkoloi. In this event Mr. Santun Bhoi (RIC, Sambalpur) and Mr. Jadumani Pradhan (SBI, RBO Sambalpur) was participated and elaborate on different Government schemes. This session provided the opportunity for learning about different scheme and program under Govt of India offering Individuals and Self-Help Groups.</p></div>
                                <div class="image-side" style="flex: 0 0 20%;"><img src="img/events/23-24/awareness.jpg" alt="Awareness Program"></div>
                            </div>
                        </div>
                    </div>

                    <div class="acc-item">
                        <button class="acc-header" aria-expanded="false">
                            <span>Distribution of Milk Cane</span>
                            <span class="acc-icon"><i class="fa fa-angle-double-right"></i></span>
                        </button>
                        <div class="acc-panel" aria-hidden="true">
                            <div class="acc-panel-inner content-side image-left">
                                <div class="text-side"><p>During December 2023, JSW Foundation distributed 10 liter Capacity milk container to 30 farmers A dairy farmer meeting w as conducted in the presence of the CSR Head. Subsequently, all Dairy farmers collectively decided to procure Cattle feed through a collective effort. Three community representatives were selected to engage in a meeting with the Trader for the collective purchase and negotiation of rates.</p></div>
                                <div class="image-side" style="flex: 0 0 15%;"><img src="img/events/23-24/milk-cane.jpg" alt="Milk Cane"></div>
                            </div>
                        </div>
                    </div>

                    <div class="acc-item">
                        <button class="acc-header" aria-expanded="false">
                            <span>One Day Orientation by Department of Horticulture</span>
                            <span class="acc-icon"><i class="fa fa-angle-double-right"></i></span>
                        </button>
                        <div class="acc-panel" aria-hidden="true">
                            <div class="acc-panel-inner content-side image-right">
                                <div class="text-side"><p>A one day Orientation program was conducted by Department of Horticulture from Rengli block at Lapan ga GP. Around 100 women participated in this program. The team gave information on different Government schemes and facilities available under horticulture department and they also shared their plan to supply Marigold Seedlings to targeted communities.</p></div>
                                <div class="image-side" style="flex: 0 0 15%;"><img src="img/events/23-24/horiculture.jpg" alt="Awareness Program"></div>
                            </div>
                        </div>
                    </div>

                    <div class="acc-item">
                        <button class="acc-header" aria-expanded="false">
                            <span>Visit of Assistant Register of Cooperative Society (ARCS)</span>
                            <span class="acc-icon"><i class="fa fa-angle-double-right"></i></span>
                        </button>
                        <div class="acc-panel" aria-hidden="true">
                            <div class="acc-panel-inner content-side image-left">
                                <div class="text-side"><p>An official visit done by ARCS (Assistant Register of Cooperative Society) and Sr Clerk from DRCS (District Register of Cooperative Society) on 4th January 2024. Had a fruitful discussion on registration of Cooperative and also visited to different village to explore the ongoing activities under JSW Shakti Project.</p></div>
                                <div class="image-side" style="flex: 0 0 15%;"><img src="img/events/23-24/arcs.jpg" alt="Milk Cane"></div>
                            </div>
                        </div>
                    </div>

                    <div class="acc-item">
                        <button class="acc-header" aria-expanded="false">
                            <span>Block Level Exhibition BY MO ODISHA</span>
                            <span class="acc-icon"><i class="fa fa-angle-double-right"></i></span>
                        </button>
                        <div class="acc-panel" aria-hidden="true">
                            <div class="acc-panel-inner content-side image-right">
                                <div class="text-side"><p>A block level exhibition was organized on 16th Feb 2024 at Lapanga. The program was inaugurated by BDO of Rengali Block. Beside that Mr. Chairperson, Sarpanch and Asst. Horticulture officer were presented and encourage all members. Smaranika SHG and Gayatri SHG from Banjiberna, Ramchandi SHG from Lapanga displayed their item like Mixture and Snacks, Cotton Wicks etc during exhibition.</p></div>
                                <!-- <div class="image-side" style="flex: 0 0 15%;"><img src="img/events/23-24/horiculture.jpg" alt="Awareness Program"></div> -->
                            </div>
                        </div>
                    </div>

                    <div class="acc-item">
                        <button class="acc-header" aria-expanded="false">
                            <span>Registration of Society</span>
                            <span class="acc-icon"><i class="fa fa-angle-double-right"></i></span>
                        </button>
                        <div class="acc-panel" aria-hidden="true">
                            <div class="acc-panel-inner content-side image-right">
                                <div class="text-side"><p>We got the registration certificate from ARCS office under O.C.S Act 1962 on dtd 15.03.2024 in name of “Shree Shakti Bahumukhi Mahila Samabaya Samiti Ltd.” Vide Registration No 12/SBP/Dt 15.03.2024 and subsequently we have opened a saving account in Rengali Co-Operative Bank. As of now total 137 Members are given their share Amount (Rs. 250 @ Each) to Cooperative.</p></div>
                                <div class="image-side" style="flex: 0 0 15%;"><img src="img/events/23-24/registration.jpg" alt="Awareness Program"></div>
                            </div>
                        </div>
                    </div>

                    <div class="acc-item">
                        <button class="acc-header" aria-expanded="false">
                            <span>Exposure to Goat Rearing Activity</span>
                            <span class="acc-icon"><i class="fa fa-angle-double-right"></i></span>
                        </button>
                        <div class="acc-panel" aria-hidden="true">
                            <div class="acc-panel-inner content-side image-left">
                                <div class="text-side"><p>There was an exposure visit done in the month June 2023 to PRADHAN GOAT FARM, RAJPUR (BRAJRAJNAGAR) , in which total 12 famers are participated and got training on goat rearing . The farmers are explored about feed, medicine, rearing of goats and shed construction preparation  during this training.</p></div>
                                <div class="image-side" style="flex: 0 0 15%;"><img src="img/events/23-24/goat-rearing.jpg" alt="Milk Cane"></div>
                            </div>
                        </div>
                    </div>

                    <div class="acc-item">
                        <button class="acc-header" aria-expanded="false">
                            <span>Exposure Visit to Horticulture Office , NILDUNGRIDay Orientation by Department of Horticulture</span>
                            <span class="acc-icon"><i class="fa fa-angle-double-right"></i></span>
                        </button>
                        <div class="acc-panel" aria-hidden="true">
                            <div class="acc-panel-inner content-side image-right">
                                <div class="text-side"><p>An intensive exposure visit made to NILDUNGRI(Sambalpur) horticulture office for training on Mushroom cultivation. Around 25 Women’s are participated in this visit and they are explore with theory and practical knowledge on Mushroom Cultivation. Most importantly members are able to gain knowledge on management of mushroom bed in different climate situation.</p></div>
                                <div class="image-side" style="flex: 0 0 10%;"><img src="img/events/23-24/nildungrid.jpg" alt="Awareness Program"></div>
                            </div>
                        </div>
                    </div>

                    <div class="acc-item">
                        <button class="acc-header" aria-expanded="false">
                            <span>A Visit to Western Odisha Dairy Summit</span>
                            <span class="acc-icon"><i class="fa fa-angle-double-right"></i></span>
                        </button>
                        <div class="acc-panel" aria-hidden="true">
                            <div class="acc-panel-inner content-side image-left">
                                <div class="text-side"><p>By taking 20 Dairy farmers from project village are attended one day Western Odisha Summit which was held in the month November 2023. In this dairy farmers are exposure to different package of practices like feed mechanism, disease control, increase milk production and how to manage the dairy farming in their area.</p></div>
                                <div class="image-side" style="flex: 0 0 15%;"><img src="img/events/23-24/west-diary.jpg" alt="Milk Cane"></div>
                            </div>
                        </div>
                    </div>

                    <div class="acc-item">
                        <button class="acc-header" aria-expanded="false">
                            <span>Exposure Visit on Marigold Cultivation</span>
                            <span class="acc-icon"><i class="fa fa-angle-double-right"></i></span>
                        </button>
                        <div class="acc-panel" aria-hidden="true">
                            <div class="acc-panel-inner content-side image-right">
                                <div class="text-side"><p>During the month of November 2023, there was an exposure visit to Lakhanpur Village on marigold cultivation. Total 25 members are visited to Mr. Lotan Sahu’s field to take the inputs on different  types marigold plants. Also the members are able to gain the knowledge on management of temperature, watering to marigold plant variety of seedling available in Kolkata Market.</p></div>
                                <div class="image-side" style="flex: 0 0 10%;"><img src="img/events/23-24/marigold.jpg" alt="Awareness Program"></div>
                            </div>
                        </div>
                    </div>

                    <div class="acc-item">
                        <button class="acc-header" aria-expanded="false">
                            <span>Inauguration of BANDHA Machine (Weaver Saree Design)</span>
                            <span class="acc-icon"><i class="fa fa-angle-double-right"></i></span>
                        </button>
                        <div class="acc-panel" aria-hidden="true">
                            <div class="acc-panel-inner content-side image-left">
                                <div class="text-side"><p>A weaving ( BANDHA) machine been installed at Smranika SHG, Banjiberna to encourage weaver community and inaugurated on dt 12th Jan 2024  by  CSR Head from JSW Foundation  and Manager CSR JSW Foundation. Total 11 nos. of members working in weaving community this month out of 11nos six added during this month. In this  event CSR Head encouraged and motivated all members and wished them best.</p></div>
                                <div class="image-side" style="flex: 0 0 15%;"><img src="img/events/23-24/bandha.jpg" alt="Milk Cane"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Footer Section Start -->
        <?php include 'includes/footer.php';?>
        <!-- Footer Section End -->
        
        <!-- Scroll To Top Section Start -->
		<?php include 'includes/scroll.php';?>
        <!-- Scroll To Top Section End -->
	
        <!-- JS Section Start -->
        <?php include 'includes/js.php';?>
        <!-- JS Section End -->
</body>
</html>