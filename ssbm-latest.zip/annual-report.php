<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="DynamicLayers">

    <title>Annual Report - Shree Shakti Bahumukhi</title>
    <!-- CSS Start -->
    <?php include 'includes/css.php';?>
    <!-- CSS End -->

</head>

<body>
    <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

    <div class="site-preloader-wrap">
        <div class="spinner"></div>
    </div><!-- Preloader -->

    <!-- Header Section Start -->
    <?php include 'includes/header.php';?>
    <!-- Header Section End -->



    <div class="pager-header" style="background-image: url(img/banner/banner-1.png);">
        <div class="container">
            <div class="page-content text-center">
                <h2>Annual Report</h2>
                <!-- <p>Help today because tomorrow you may be the one who <br>needs more helping!</p> -->
                <ol class="breadcrumb justify-content-center">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item active">Annual Report</li>
                </ol>
            </div>
        </div>
    </div><!-- /Page Header -->

    <div class="annual-table">
        <table>
            <thead>
                <tr>
                    <th>SL No</th>
                    <th>Activities</th>
                    <th>Target for 3 Years</th>
                    <th>Target for FY(2022-2023)</th>
                    <th>Achievement FY (2022-2023)</th>
                    <th>Achievement FY (2023-2024)</th>
                    <th>Cummulative Achievement</th>
                    <th>Balance for FY (23-24)</th>
                    <th>Target for FY (24-25)</th>
                    <th>Achievement for FY 24-25</th>
                    <th>Cumulative Achievement March 25</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td data-label="SL No">1</td>
                    <td data-label="Activities" class="act">Mushroom Cultivation &amp; cluster Development</td>
                    <td data-label="Target for 3 Years">209</td>
                    <td data-label="Target for FY(2022-2023)">139</td>
                    <td data-label="Achievement FY (2022-2023)">0</td>
                    <td data-label="Achievement FY (2023-2024)">60</td>
                    <td data-label="Cummulative Achievement">60</td>
                    <td data-label="Balance for FY (23-24)">79</td>
                    <td data-label="Target for FY (24-25)">149</td>
                    <td data-label="Achievement for FY 24-25">26</td>
                    <td data-label="Cumulative Achievement March 25">86</td>
                </tr>
                <tr>
                    <td data-label="SL No">2</td>
                    <td data-label="Activities" class="act">Promotion of Phenyl/Dishwash Production</td>
                    <td data-label="Target for 3 Years">40</td>
                    <td data-label="Target for FY(2022-2023)">30</td>
                    <td data-label="Achievement FY (2022-2023)">5</td>
                    <td data-label="Achievement FY (2023-2024)">26</td>
                    <td data-label="Cummulative Achievement">31</td>
                    <td data-label="Balance for FY (23-24)" class="negative">-1</td>
                    <td data-label="Target for FY (24-25)">9</td>
                    <td data-label="Achievement for FY 24-25">1</td>
                    <td data-label="Cumulative Achievement March 25">32</td>
                </tr>
                <tr>
                    <td data-label="SL No">3</td>
                    <td data-label="Activities" class="act">Dairy Development</td>
                    <td data-label="Target for 3 Years">70</td>
                    <td data-label="Target for FY(2022-2023)">40</td>
                    <td data-label="Achievement FY (2022-2023)">0</td>
                    <td data-label="Achievement FY (2023-2024)">37</td>
                    <td data-label="Cummulative Achievement">37</td>
                    <td data-label="Balance for FY (23-24)">3</td>
                    <td data-label="Target for FY (24-25)">33</td>
                    <td data-label="Achievement for FY 24-25">27</td>
                    <td data-label="Cumulative Achievement March 25">63</td>
                </tr>
                <tr>
                    <td data-label="SL No">4</td>
                    <td data-label="Activities" class="act">Paddy Processing Unit</td>
                    <td data-label="Target for 3 Years">15</td>
                    <td data-label="Target for FY(2022-2023)">10</td>
                    <td data-label="Achievement FY (2022-2023)">2</td>
                    <td data-label="Achievement FY (2023-2024)">8</td>
                    <td data-label="Cummulative Achievement">10</td>
                    <td data-label="Balance for FY (23-24)">0</td>
                    <td data-label="Target for FY (24-25)">5</td>
                    <td data-label="Achievement for FY 24-25">2</td>
                    <td data-label="Cumulative Achievement March 25">12</td>
                </tr>
                <tr>
                    <td data-label="SL No">5</td>
                    <td data-label="Activities" class="act">Leaf Plate Making</td>
                    <td data-label="Target for 3 Years">25</td>
                    <td data-label="Target for FY(2022-2023)">20</td>
                    <td data-label="Achievement FY (2022-2023)">5</td>
                    <td data-label="Achievement FY (2023-2024)">14</td>
                    <td data-label="Cummulative Achievement">19</td>
                    <td data-label="Balance for FY (23-24)">1</td>
                    <td data-label="Target for FY (24-25)">6</td>
                    <td data-label="Achievement for FY 24-25">3</td>
                    <td data-label="Cumulative Achievement March 25">22</td>
                </tr>
                <tr>
                    <td data-label="SL No">6</td>
                    <td data-label="Activities" class="act">Goat Rearing</td>
                    <td data-label="Target for 3 Years">200</td>
                    <td data-label="Target for FY(2022-2023)">100</td>
                    <td data-label="Achievement FY (2022-2023)">20</td>
                    <td data-label="Achievement FY (2023-2024)">110</td>
                    <td data-label="Cummulative Achievement">130</td>
                    <td data-label="Balance for FY (23-24)" class="negative">-10</td>
                    <td data-label="Target for FY (24-25)">100</td>
                    <td data-label="Achievement for FY 24-25">40</td>
                    <td data-label="Cumulative Achievement March 25">170</td>
                </tr>
                <tr>
                    <td data-label="SL No">7</td>
                    <td data-label="Activities" class="act">Handicraft Development</td>
                    <td data-label="Target for 3 Years">50</td>
                    <td data-label="Target for FY(2022-2023)">25</td>
                    <td data-label="Achievement FY (2022-2023)">7</td>
                    <td data-label="Achievement FY (2023-2024)">23</td>
                    <td data-label="Cummulative Achievement">30</td>
                    <td data-label="Balance for FY (23-24)" class="negative">-5</td>
                    <td data-label="Target for FY (24-25)">20</td>
                    <td data-label="Achievement for FY 24-25">10</td>
                    <td data-label="Cumulative Achievement March 25">40</td>
                </tr>
                <tr>
                    <td data-label="SL No">8</td>
                    <td data-label="Activities" class="act">Spices Processing Unit</td>
                    <td data-label="Target for 3 Years">30</td>
                    <td data-label="Target for FY(2022-2023)">20</td>
                    <td data-label="Achievement FY (2022-2023)">4</td>
                    <td data-label="Achievement FY (2023-2024)">15</td>
                    <td data-label="Cummulative Achievement">19</td>
                    <td data-label="Balance for FY (23-24)">1</td>
                    <td data-label="Target for FY (24-25)">10</td>
                    <td data-label="Achievement for FY 24-25">5</td>
                    <td data-label="Cumulative Achievement March 25">24</td>
                </tr>
                <tr>
                    <td data-label="SL No">9</td>
                    <td data-label="Activities" class="act">Poultry Farming</td>
                    <td data-label="Target for 3 Years">100</td>
                    <td data-label="Target for FY(2022-2023)">50</td>
                    <td data-label="Achievement FY (2022-2023)">12</td>
                    <td data-label="Achievement FY (2023-2024)">45</td>
                    <td data-label="Cummulative Achievement">57</td>
                    <td data-label="Balance for FY (23-24)" class="negative">-7</td>
                    <td data-label="Target for FY (24-25)">50</td>
                    <td data-label="Achievement for FY 24-25">30</td>
                    <td data-label="Cumulative Achievement March 25">87</td>
                </tr>
                <tr>
                    <td data-label="SL No">10</td>
                    <td data-label="Activities" class="act">Agro Service Centre</td>
                    <td data-label="Target for 3 Years">20</td>
                    <td data-label="Target for FY(2022-2023)">15</td>
                    <td data-label="Achievement FY (2022-2023)">3</td>
                    <td data-label="Achievement FY (2023-2024)">10</td>
                    <td data-label="Cummulative Achievement">13</td>
                    <td data-label="Balance for FY (23-24)">2</td>
                    <td data-label="Target for FY (24-25)">5</td>
                    <td data-label="Achievement for FY 24-25">2</td>
                    <td data-label="Cumulative Achievement March 25">15</td>
                </tr>
                <tr>
                    <td data-label="SL No">11</td>
                    <td data-label="Activities" class="act">Dairy Farming</td>
                    <td data-label="Target for 3 Years">150</td>
                    <td data-label="Target for FY(2022-2023)">100</td>
                    <td data-label="Achievement FY (2022-2023)">18</td>
                    <td data-label="Achievement FY (2023-2024)">70</td>
                    <td data-label="Cummulative Achievement">88</td>
                    <td data-label="Balance for FY (23-24)" class="negative">-30</td>
                    <td data-label="Target for FY (24-25)">50</td>
                    <td data-label="Achievement for FY 24-25">30</td>
                    <td data-label="Cumulative Achievement March 25">118</td>
                </tr>
                <tr>
                    <td data-label="SL No">12</td>
                    <td data-label="Activities" class="act">Fishery Development</td>
                    <td data-label="Target for 3 Years">100</td>
                    <td data-label="Target for FY(2022-2023)">60</td>
                    <td data-label="Achievement FY (2022-2023)">10</td>
                    <td data-label="Achievement FY (2023-2024)">45</td>
                    <td data-label="Cummulative Achievement">55</td>
                    <td data-label="Balance for FY (23-24)" class="negative">-15</td>
                    <td data-label="Target for FY (24-25)">40</td>
                    <td data-label="Achievement for FY 24-25">20</td>
                    <td data-label="Cumulative Achievement March 25">75</td>
                </tr>
                <tr>
                    <td data-label="SL No">13</td>
                    <td data-label="Activities" class="act">Mushroom Cultivation</td>
                    <td data-label="Target for 3 Years">60</td>
                    <td data-label="Target for FY(2022-2023)">30</td>
                    <td data-label="Achievement FY (2022-2023)">6</td>
                    <td data-label="Achievement FY (2023-2024)">25</td>
                    <td data-label="Cummulative Achievement">31</td>
                    <td data-label="Balance for FY (23-24)" class="negative">-1</td>
                    <td data-label="Target for FY (24-25)">30</td>
                    <td data-label="Achievement for FY 24-25">12</td>
                    <td data-label="Cumulative Achievement March 25">43</td>
                </tr>
                <tr>
                    <td data-label="SL No">14</td>
                    <td data-label="Activities" class="act">Bee Keeping</td>
                    <td data-label="Target for 3 Years">40</td>
                    <td data-label="Target for FY(2022-2023)">20</td>
                    <td data-label="Achievement FY (2022-2023)">4</td>
                    <td data-label="Achievement FY (2023-2024)">18</td>
                    <td data-label="Cummulative Achievement">22</td>
                    <td data-label="Balance for FY (23-24)" class="negative">-2</td>
                    <td data-label="Target for FY (24-25)">20</td>
                    <td data-label="Achievement for FY 24-25">8</td>
                    <td data-label="Cumulative Achievement March 25">30</td>
                </tr>
                <tr>
                    <td data-label="SL No">15</td>
                    <td data-label="Activities" class="act">Agro Forestry</td>
                    <td data-label="Target for 3 Years">70</td>
                    <td data-label="Target for FY(2022-2023)">40</td>
                    <td data-label="Achievement FY (2022-2023)">9</td>
                    <td data-label="Achievement FY (2023-2024)">35</td>
                    <td data-label="Cummulative Achievement">44</td>
                    <td data-label="Balance for FY (23-24)" class="negative">-5</td>
                    <td data-label="Target for FY (24-25)">30</td>
                    <td data-label="Achievement for FY 24-25">15</td>
                    <td data-label="Cumulative Achievement March 25">59</td>
                </tr>
                <tr>
                    <td data-label="SL No">16</td>
                    <td data-label="Activities" class="act">Handloom Weaving</td>
                    <td data-label="Target for 3 Years">50</td>
                    <td data-label="Target for FY(2022-2023)">25</td>
                    <td data-label="Achievement FY (2022-2023)">5</td>
                    <td data-label="Achievement FY (2023-2024)">20</td>
                    <td data-label="Cummulative Achievement">25</td>
                    <td data-label="Balance for FY (23-24)">0</td>
                    <td data-label="Target for FY (24-25)">25</td>
                    <td data-label="Achievement for FY 24-25">10</td>
                    <td data-label="Cumulative Achievement March 25">35</td>
                </tr>
                <tr>
                    <td data-label="SL No">17</td>
                    <td data-label="Activities" class="act">Agro Tourism</td>
                    <td data-label="Target for 3 Years">30</td>
                    <td data-label="Target for FY(2022-2023)">15</td>
                    <td data-label="Achievement FY (2022-2023)">2</td>
                    <td data-label="Achievement FY (2023-2024)">12</td>
                    <td data-label="Cummulative Achievement">14</td>
                    <td data-label="Balance for FY (23-24)">1</td>
                    <td data-label="Target for FY (24-25)">15</td>
                    <td data-label="Achievement for FY 24-25">8</td>
                    <td data-label="Cumulative Achievement March 25">22</td>
                </tr>
                <tr>
                    <td data-label="SL No">18</td>
                    <td data-label="Activities" class="act">Organic Manure Unit</td>
                    <td data-label="Target for 3 Years">40</td>
                    <td data-label="Target for FY(2022-2023)">20</td>
                    <td data-label="Achievement FY (2022-2023)">3</td>
                    <td data-label="Achievement FY (2023-2024)">15</td>
                    <td data-label="Cummulative Achievement">18</td>
                    <td data-label="Balance for FY (23-24)">2</td>
                    <td data-label="Target for FY (24-25)">20</td>
                    <td data-label="Achievement for FY 24-25">10</td>
                    <td data-label="Cumulative Achievement March 25">28</td>
                </tr>
                <tr>
                    <td data-label="SL No">19</td>
                    <td data-label="Activities" class="act">Vermicompost Unit</td>
                    <td data-label="Target for 3 Years">30</td>
                    <td data-label="Target for FY(2022-2023)">15</td>
                    <td data-label="Achievement FY (2022-2023)">2</td>
                    <td data-label="Achievement FY (2023-2024)">12</td>
                    <td data-label="Cummulative Achievement">14</td>
                    <td data-label="Balance for FY (23-24)">1</td>
                    <td data-label="Target for FY (24-25)">15</td>
                    <td data-label="Achievement for FY 24-25">5</td>
                    <td data-label="Cumulative Achievement March 25">19</td>
                </tr>
                <tr>
                    <td data-label="SL No">20</td>
                    <td data-label="Activities" class="act">Sericulture</td>
                    <td data-label="Target for 3 Years">25</td>
                    <td data-label="Target for FY(2022-2023)">15</td>
                    <td data-label="Achievement FY (2022-2023)">2</td>
                    <td data-label="Achievement FY (2023-2024)">10</td>
                    <td data-label="Cummulative Achievement">12</td>
                    <td data-label="Balance for FY (23-24)">3</td>
                    <td data-label="Target for FY (24-25)">10</td>
                    <td data-label="Achievement for FY 24-25">6</td>
                    <td data-label="Cumulative Achievement March 25">18</td>
                </tr>
                <tr>
                    <td data-label="SL No">21</td>
                    <td data-label="Activities" class="act">Agro Processing</td>
                    <td data-label="Target for 3 Years">20</td>
                    <td data-label="Target for FY(2022-2023)">10</td>
                    <td data-label="Achievement FY (2022-2023)">1</td>
                    <td data-label="Achievement FY (2023-2024)">7</td>
                    <td data-label="Cummulative Achievement">8</td>
                    <td data-label="Balance for FY (23-24)">2</td>
                    <td data-label="Target for FY (24-25)">10</td>
                    <td data-label="Achievement for FY 24-25">5</td>
                    <td data-label="Cumulative Achievement March 25">13</td>
                </tr>
                <tr>
                    <td data-label="SL No">22</td>
                    <td data-label="Activities" class="act">Medicinal Plantation</td>
                    <td data-label="Target for 3 Years">50</td>
                    <td data-label="Target for FY(2022-2023)">25</td>
                    <td data-label="Achievement FY (2022-2023)">3</td>
                    <td data-label="Achievement FY (2023-2024)">20</td>
                    <td data-label="Cummulative Achievement">23</td>
                    <td data-label="Balance for FY (23-24)">2</td>
                    <td data-label="Target for FY (24-25)">25</td>
                    <td data-label="Achievement for FY 24-25">12</td>
                    <td data-label="Cumulative Achievement March 25">35</td>
                </tr>
                <tr>
                    <td data-label="SL No">23</td>
                    <td data-label="Activities" class="act">Food Processing</td>
                    <td data-label="Target for 3 Years">40</td>
                    <td data-label="Target for FY(2022-2023)">20</td>
                    <td data-label="Achievement FY (2022-2023)">2</td>
                    <td data-label="Achievement FY (2023-2024)">18</td>
                    <td data-label="Cummulative Achievement">20</td>
                    <td data-label="Balance for FY (23-24)">0</td>
                    <td data-label="Target for FY (24-25)">20</td>
                    <td data-label="Achievement for FY 24-25">10</td>
                    <td data-label="Cumulative Achievement March 25">30</td>
                </tr>
                <tr>
                    <td data-label="SL No">24</td>
                    <td data-label="Activities" class="act">Agro Clinic</td>
                    <td data-label="Target for 3 Years">10</td>
                    <td data-label="Target for FY(2022-2023)">5</td>
                    <td data-label="Achievement FY (2022-2023)">0</td>
                    <td data-label="Achievement FY (2023-2024)">4</td>
                    <td data-label="Cummulative Achievement">4</td>
                    <td data-label="Balance for FY (23-24)">1</td>
                    <td data-label="Target for FY (24-25)">5</td>
                    <td data-label="Achievement for FY 24-25">3</td>
                    <td data-label="Cumulative Achievement March 25">7</td>
                </tr>
                 <tr>
                    <td data-label="SL No"></td>
                    <td data-label="Activities" class="act"><strong>Total</strong></td>
                    <td data-label="Target for 3 Years">2000</td>
                    <td data-label="Target for FY(2022-2023)">1292</td>
                    <td data-label="Achievement FY (2022-2023)">164</td>
                    <td data-label="Achievement FY (2023-2024)">1050</td>
                    <td data-label="Cummulative Achievement">1214</td>
                    <td data-label="Balance for FY (23-24)">78</td>
                    <td data-label="Target for FY (24-25)">786</td>
                    <td data-label="Achievement for FY 24-25">387</td>
                    <td data-label="Cumulative Achievement March 25">1592</td>
                </tr>

            </tbody>
        </table>
    </div>


    <!-- Footer Section Start -->
    <?php include 'includes/footer.php';?>
    <!-- Footer Section End -->

    <!-- Scroll To Top Section Start -->
    <?php include 'includes/scroll.php';?>
    <!-- Scroll To Top Section End -->

    <!-- JS Section Start -->
    <?php include 'includes/js.php';?>
    <!-- JS Section End -->
</body>

</html>