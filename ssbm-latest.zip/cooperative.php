<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="en"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="">
        <meta name="author" content="DynamicLayers">
       
        <title>Our Cooperatives || SSBM</title>
        
		<!-- CSS Start -->
         <?php include 'includes/css.php';?>
        <!-- CSS End -->
    </head>
    <body>
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
        
        <div class="site-preloader-wrap">
            <div class="spinner"></div>
        </div><!-- Preloader -->
        
        <!-- Header Section Start -->
        <?php include 'includes/header.php';?>
        <!-- Header Section End -->
                
        <div class="pager-header" style="background-image: url(img/banner/banner-1.png);">
            <div class="container">
                <div class="page-content">
                    <h2>Our Cooperatives</h2>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                        <li class="breadcrumb-item active">Our Cooperatives</li>
                    </ol>
                </div>
            </div>
        </div><!-- /Page Header -->
        
        <section class="about-section padding">
            <div class="container">
                <div class="row about-wrap">
                    <div class="col-md-5 xs-padding">
                        <div class="about-image">
                            <img src="img/cooperative/coop1.jpg" alt="Cooperative image">
                        </div>
                    </div>
                    <div class="col-md-7 xs-padding">
                        <div class="about-content">
                            <h2>Cooperative Principles</h2>
                            <p style="color: #262525;margin-bottom: 5px;font-weight: 600;font-size: 14px;">By March, 2025, Shree Shakti Cooperative will cater to 2000 women members of Rengali block of Sambalpur District.</p>
                            <p>
                                <span class="cooperative-txt">Voluntary and Open Membership :</span> <br>
                                Cooperatives are voluntary organizations, open to all people able to use its services and willing to accept the responsibilities of membership, without gender, social, racial, political or religious discrimination. <br><br>
                                <span class="cooperative-txt">Democratic Member Control :</span> <br>
                                Cooperatives are democratic organizations controlled by their members—those who buy the goods or use the services of the cooperative—who actively participate in setting policies and making decisions. <br><br>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="row about-wrap">
                    <div class="col-md-12 xs-padding">
                        <div class="about-content">
                            <p style="margin-left: -15px;">
                                <span class="cooperative-txt">Members’ Economic Participation :</span> <br>
                                Members contribute equally to, and democratically control, the capital of the cooperative. This benefits members in proportion to the business they conduct with the cooperative rather than on the capital invested.<br><br>
                                <span class="cooperative-txt">Autonomy and Independence :</span> <br>
                                Cooperatives are autonomous, self-help organizations controlled by their members. If the co-op enters into agreements with other organizations or raises capital from external sources, it is done so based on terms that ensure democratic control by the members and maintains the cooperative’s autonomy.<br><br>
                                <span class="cooperative-txt">Education, Training and Information :</span> <br>
                                Cooperatives provide education and training for members, elected representatives, managers and employees so they can contribute effectively to the development of their cooperative. Members also inform the general public about the nature and benefits of cooperatives. <br><br>
                                <span class="cooperative-txt">Cooperation among Cooperatives :</span> <br>
                                Cooperatives serve their members most effectively and strengthen the cooperative movement by working together through local, national, regional and international structures. <br><br>
                                <span class="cooperative-txt">Concern for Community :</span> <br>
                                While focusing on member needs, cooperatives work for the sustainable development of communities through policies and programs accepted by the members.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="row about-wrap" style="margin: 0 -15px 0 -30px;">
                    <div class="col-md-9 xs-padding">
                        <div class="about-content">
                            <h2>Shree Shakti Cooperative’s Core Values</h2>
                            <p>
                                <span class="cooperative-txt">Integrity :</span> <br>
                                Our mission is to serve low-income clients-women and their families, providing them short term access to financial services, that are client focused, designed to enhance their well being, and delivered in a manner that is ethical, dignified, transparent, equitable and cost effective. <br><br>
                                <span class="cooperative-txt">Quality of Service :</span> <br>
                                We believe that our clients deserve fair and efficient microfinance services. We provide these services to them in as convenient, participatory and timely manner as possible. <br><br>
                            </p>
                        </div>
                    </div>
                    <div class="col-md-3 xs-padding">
                        <div class="about-image">
                            <img src="img/cooperative/coop2.jpg" alt="Cooperative image">
                        </div>
                    </div>
                </div>
                <div class="row about-wrap" style="margin: 0 -15px 0 -30px;">
                    <div class="col-md-3 xs-padding">
                        <div class="about-image">
                            <img src="img/cooperative/coop3.jpg" alt="Cooperative image">
                        </div>
                    </div>
                    <div class="col-md-9 xs-padding">
                        <div class="about-content">
                            <p>
                                <span class="cooperative-txt">Transparency :</span> <br>
                                We give our clients complete and accurate information and educate them about the terms of financial services offered by us in a manner that is understandable by them. <br><br>
                                <span class="cooperative-txt">Fair Practices :</span> <br>
                                We are committed to ensure that our services to our clients are not unethical and deceptive. In providing microfinance services including lending and collection of dues, we are committed to fair practices, which balance respect for client’s dignity and an understanding of a client’s vulnerable situation, with reasonable pursuit of recovery of loans. <br><br>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="row about-wrap" style="margin: 0 -15px 0 -30px;">
                    <div class="col-md-12 xs-padding">
                        <div class="about-content">
                            <p style="margin-left: -15px;">
                                <span class="cooperative-txt">Privacy of Client Information :</span> <br>
                                We safeguard personal information of clients, only allowing disclosures and exchange of such information to others who are authorized to see it, with the knowledge and consent of clients. <br><br>
                                <span class="cooperative-txt">Integrating Social Values into operations :</span> <br>
                                We believe that high standards of governance, participation, management and reporting are critical to our mission to serve our clients and to uphold core social values. <br><br>
                                <span class="cooperative-txt">Feedback mechanism :</span> <br>
                                We shall provide our clients formal and informal channels for their feedback and suggestions for building our competencies to serve our clients better.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </section><!-- /About Section -->

        <!-- Footer Section Start -->
        <?php include 'includes/footer.php';?>
        <!-- Footer Section End -->
        
        <!-- Scroll To Top Section Start -->
		<?php include 'includes/scroll.php';?>
        <!-- Scroll To Top Section End -->
	
        <!-- JS Section Start -->
        <?php include 'includes/js.php';?>
        <!-- JS Section End -->
</body>
</html>