<!doctype html>

<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="DynamicLayers">

    <title>Our Team</title>
    <!-- CSS Start -->
    <?php include 'includes/css.php'; ?>
    <!-- CSS End -->

</head>

<body>
    <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

    <div class="site-preloader-wrap">
        <div class="spinner"></div>
    </div><!-- Preloader -->

    <!-- Header Section Start -->
    <?php include 'includes/header.php'; ?>
    <!-- Header Section End -->



    <div class="pager-header" style="background-image: url(img/banner/banner-1.png);">
        <div class="container">
            <div class="page-content text-center">
                <h2>Our Team</h2>
                <!-- <p>Help today because tomorrow you may be the one who <br>needs more helping!</p> -->
                <ol class="breadcrumb justify-content-center">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item"><a href="success-stories.php">Who We are</a></li>
                    <li class="breadcrumb-item active">Our Team</li>
                </ol>
            </div>
        </div>
    </div><!-- /Page Header -->



    <section class="about-section bg-grey bd-bottom padding">
        <div class="container">

            <div class="row">
                <div class="col-md-12 xs-padding">
                    <div class="members-section">
                        <div class="member-card"></div>

                        <div class="member-card">
                            <div class="img-box">
                                <img src="img/team/sasmita podh.png" alt="">
                            </div>
                            <h3>Mrs. Sasmita Podh</h3>
                            <span>President</span>
                        </div>


                        <div class="member-card">
                            <div class="img-box">
                                <img src="img/team/rina pradhan.png" alt="">
                            </div>
                            <h3>Mrs. Rina Pradhan</h3>
                            <span>Vice-President</span>
                        </div>

                        <div class="member-card"></div>
                    </div>
                </div>

            </div>
            
            <div class="row" style="margin-top: 50px;">
                <div class="col-md-12 xs-padding">
                    <div class="members-section">

                        <div class="member-card">
                            <div class="img-box">
                                <img src="img/team/Lilabati.png" alt="">
                            </div>
                            <h3>Mrs. Lilabati Dhurva</h3>
                            <span>Member</span>
                        </div>

                        <div class="member-card">
                            <div class="img-box">
                                <img src="img/team/Manju  sahu.png" alt="">
                            </div>
                            <h3>Mrs. Manju Sahu</h3>
                            <span>Member</span>
                        </div>

                        <div class="member-card">
                            <div class="img-box">
                                <img src="img/team/Debaki.png" alt="">
                            </div>
                            <h3>Mrs. Debaki Kishan</h3>
                            <span>Member</span>
                        </div>


                        <div class="member-card">
                            <div class="img-box">
                                <img src="img/team/Laxmipriya.png" alt="">
                            </div>
                            <h3>Mrs. Laxmipriya Makar</h3>
                            <span>Member</span>
                        </div>

                    </div>
                </div>

            </div>

            <div class="row" style="margin-top: 50px;">
                <div class="col-md-12 xs-padding">
                    <div class="members-section">

                        <div class="member-card">
                            <div class="img-box">
                                <img src="img/team/Santoshini.png" alt="">
                            </div>
                            <h3>Mrs. Santoshini Sahu</h3>
                            <span>Member</span>
                        </div>

                        <div class="member-card">
                            <div class="img-box">
                                <img src="img/team/Subhadra.png" alt="">
                            </div>
                            <h3>Mrs. Subhadra Kumra</h3>
                            <span>Member</span>
                        </div>

                        <div class="member-card">
                            <div class="img-box">
                                <img src="img/team/Sanjukta.png" alt="">
                            </div>
                            <h3>Mrs. Sanjukta Paule</h3>
                            <span>Member</span>
                        </div>


                        <div class="member-card">
                          
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </section>
    <!-- /About Section -->



    <!-- Footer Section Start -->
    <?php include 'includes/footer.php'; ?>
    <!-- Footer Section End -->

    <!-- Scroll To Top Section Start -->
    <?php include 'includes/scroll.php'; ?>
    <!-- Scroll To Top Section End -->

    <!-- JS Section Start -->
    <?php include 'includes/js.php'; ?>
    <!-- JS Section End -->
</body>

</html>