<!doctype html>

<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="DynamicLayers">

    <title>Legal Status</title>
    <!-- CSS Start -->
    <?php include 'includes/css.php'; ?>
    <!-- CSS End -->

</head>

<body>
    <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

    <div class="site-preloader-wrap">
        <div class="spinner"></div>
    </div><!-- Preloader -->

    <!-- Header Section Start -->
    <?php include 'includes/header.php'; ?>
    <!-- Header Section End -->



    <div class="pager-header" style="background-image: url(img/banner/banner-1.png);">
        <div class="container">
            <div class="page-content text-center">
                <h2>Legal Status</h2>
                <!-- <p>Help today because tomorrow you may be the one who <br>needs more helping!</p> -->
                <ol class="breadcrumb justify-content-center">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item"><a href="success-stories.php">Who We are</a></li>
                    <li class="breadcrumb-item active">Legal Status</li>
                </ol>
            </div>
        </div>
    </div><!-- /Page Header -->



    <section class="about-section bg-grey bd-bottom padding">
        <div class="container">
            
            <div class="row about-wrap">
                <div class="col-md-12 xs-padding">
                    <div class="about-content" style="text-align:center">
                        <h2>Legal Status and regulatory requirements of SHREE SHAKTI COOPERATIVE</h2>
                        
                    </div>
                </div>
            </div>

            <!-- Vegetable -->
            <div class="row about-wrap">
                <div class="col-md-12 xs-padding">
                    <div class="about-content">
                        <ul>
                            <li>➧ On 15.03.2024 it is registered under Cooperative Society Act 1962 bearing Regd 12/SBP dated 15.03.2024 at DRCS Sambalpur. Cooperative will comply the reporting requirements of DRCS from time to time. Apart from this, the followings need to be done.</li>
                            <li>➧ Shree Shakti Cooperative shall display its name and the address of its registered office and its registration number on all its contracts, business letters, orders for goods, invoices, statements of accounts, receipts and letters and credit and on all bills of exchange, promissory notes, endorsements, cheques and orders for money it signs or that are signed on its behalf.</li>
                            <li>➧ Shree Shakti Cooperative will share its loan related data to a Credit Information Company i.e. HIGH MARK for transparency and to avoid over After disbursement of loan to a member needs to be uploaded in the data bank of the Credit Information Company. Similarly before loan processing, the data of the members regarding multiple loan, indebtedness and borrower’s behavior on timely loan repayment need to be accessed from the Credit Information Company. In case of two weeks of delay in disbursement of loan, further the information from the Credit Information Company need to be sought.</li>
                            <li>➧ The staff members of the cooperative and Board of Directors will be oriented on code of The staff members will get orientation how to implement it in thefield. The CEO will furnish a code of conduct compliance report to the Board for their understanding and to take stock of the developments. Among others the grievance redressal mechanisms need to be strengthened in the organization both for staff and members.</li>
                            
                        </ul>
                    </div>
                </div>
            </div>

        </div>
    </section>
    <!-- /About Section -->



    <!-- Footer Section Start -->
    <?php include 'includes/footer.php'; ?>
    <!-- Footer Section End -->

    <!-- Scroll To Top Section Start -->
    <?php include 'includes/scroll.php'; ?>
    <!-- Scroll To Top Section End -->

    <!-- JS Section Start -->
    <?php include 'includes/js.php'; ?>
    <!-- JS Section End -->
</body>

</html>