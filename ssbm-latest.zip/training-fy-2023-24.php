<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="DynamicLayers">

    <title>Training FY 2023-24 - Shree Shakti Bahumukhi</title>
    <!-- CSS Start -->
    <?php include 'includes/css.php';?>
    <!-- CSS End -->

</head>

<body>
    <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

    <div class="site-preloader-wrap">
        <div class="spinner"></div>
    </div><!-- Preloader -->

    <!-- Header Section Start -->
    <?php include 'includes/header.php';?>
    <!-- Header Section End -->



    <div class="pager-header" style="background-image: url(img/banner/banner-1.png);">
        <div class="container">
            <div class="page-content text-center">
                <h2>Training FY 2023-24</h2>
                <!-- <p>Help today because tomorrow you may be the one who <br>needs more helping!</p> -->
                <ol class="breadcrumb justify-content-center">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item active">Training FY 2023-24</li>
                </ol>
            </div>
        </div>
    </div><!-- /Page Header -->



    <section class="about-section bg-grey bd-bottom padding">
        <div class="container">

            <div class="row training-wrap">
                <div class="col-md-12 xs-padding">
                    <div class="training-title">
                        <h2>Training to BOD Members of PO</h2>
                    </div>
                </div>
                <div class="col-md-10 xs-padding">
                    <div class="about-content">
                        <p>A training program was organized for the BOD in the ACCESS office. The basic objective of the
                            training was to educate them on Mission & Vision building exercise along with introducing
                            the PO governance system to them. 10 members of the BoD participated in the training.
                        </p>
                    </div>
                </div>
                <div class="col-md-2 xs-padding">
                    <div class="about-image">
                        <img src="img/training-fy-23-24/1.jpg" alt="1">
                    </div>
                </div>
            </div>

            <div class="row training-wrap">
                <div class="col-md-12 xs-padding">
                    <div class="training-title">
                        <h2>Training to BOD Members of PO</h2>
                    </div>
                </div>
                <div class="col-md-10 xs-padding">
                    <div class="about-content">
                        <p>An orientation program was conducted for the Board of Directors on “Co-operative affairs “on
                            dt 17th Jan 2024 on Co-operative management. Visioning exercise, Mission and goal of
                            Co-operative were discussed during the meeting.
                        </p>
                    </div>
                </div>
                <div class="col-md-2 xs-padding">
                    <div class="about-image">
                        <img src="img/training-fy-23-24/2.jpg" alt="2">
                    </div>
                </div>
            </div>

            <div class="row training-wrap">
                <div class="col-md-12 xs-padding">
                    <div class="training-title">
                        <h2>Training on Mixture Unit</h2>
                    </div>
                </div>
                <div class="col-md-10 xs-padding">
                    <div class="about-content">
                        <p>Two Day’s Training program was conducted at Gourdhia village from Ghhechamura GP on mixture
                            promotion was organized by ACCESS Development Service on 19th and 20th February 2024. In
                            this mixture training CSR head from JSW Foundation, was attended and encouraged the
                            participants for their interest and also focus on marketing of these products. Total 22
                            members are participated in this training program.
                        </p>
                    </div>
                </div>
                <div class="col-md-2 xs-padding">
                    <div class="about-image">
                        <img src="img/training-fy-23-24/3.jpg" alt="3">
                    </div>
                </div>
            </div>

        </div>
    </section><!-- /About Section -->



    <!-- Footer Section Start -->
    <?php include 'includes/footer.php';?>
    <!-- Footer Section End -->

    <!-- Scroll To Top Section Start -->
    <?php include 'includes/scroll.php';?>
    <!-- Scroll To Top Section End -->

    <!-- JS Section Start -->
    <?php include 'includes/js.php';?>
    <!-- JS Section End -->
</body>

</html>