<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="DynamicLayers">

    <title>Case Study 3 - Shree Shakti Bahumukhi</title>
    <!-- CSS Start -->
    <?php include 'includes/css.php';?>
    <!-- CSS End -->

</head>

<body>
    <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

    <div class="site-preloader-wrap">
        <div class="spinner"></div>
    </div><!-- Preloader -->

    <!-- Header Section Start -->
    <?php include 'includes/header.php';?>
    <!-- Header Section End -->



    <div class="pager-header" style="background-image: url(img/banner/banner-1.png);">
        <div class="container">
            <div class="page-content text-center">
                <h2>Case Study</h2>
                <!-- <p>Help today because tomorrow you may be the one who <br>needs more helping!</p> -->
                <ol class="breadcrumb justify-content-center">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item"><a href="success-stories.php">Success Stories</a></li>
                    <li class="breadcrumb-item active">Case Study</li>
                </ol>
            </div>
        </div>
    </div><!-- /Page Header -->



    <section class="about-section bg-grey bd-bottom padding">
        <div class="container">
            <div class="row about-wrap">

                <div class="col-md-7 xs-padding">
                    <div class="about-content">
                        <h2>Marching towards Success- <br>Chitralekha Dharua (Petty Business)</h2>
                        <p><strong>Chitralekha Dharua</strong>, aged around 35, resides at Thelkoloi village, which is
                            situated
                            close to the JSW factory. Staying with her husband & son & daughter. With the growing
                            population and contextual challenges, she started her business 7 years ago. Dynamic
                            thinking and getting support from her husband are gearing the speed of business.
                        </p>
                        <p>“Simple living and high thinking” are the first things that come to mind in attraction with
                            Chitrarekha Dharua. This woman has some interesting thoughts about entrepreneurship that
                            could inspire many young businesswomen. Determination and hard work play an important role
                            in Chitrarekha’s venture.
                        </p>
                    </div>
                </div>
                <div class="col-md-5 xs-padding">
                    <div class="about-image">
                        <img src="img/success-stories/cs.png" alt="Case Study 1">
                    </div>
                </div>
            </div>
            <div class="row about-wrap">

                <div class="col-md-12 xs-padding">
                    <div class="about-content">
                        <p>Chitrarekha is a member of<strong> Shree Shakti Bahumuki Mahila Samabaya Samiti Ltd</strong>, which is formed
                            by ACCESS Development Services with the support of the JSW Foundation. She participated in
                            an enterprise development training program organized by ACCESS Development Services in 2022,
                            where entrepreneurs were encouraged and motivated to take her business to the upper level.
                            She jumped at the opportunity. She applied better business practices and enabled her to
                            manage her store more effectively. Their SHG, named Jagruti, started making phenyl in a
                            group and gaining income day by day with a reasonable demand from the local market. As time
                            goes on now, she has enhanced her business with gas refilling, vegetable vending, and many
                            more new items. She got a loan from Shree Shakti Co-Operative of Rs 10000 and invested in
                            her petty business. Now she is earning more than Rs 35000 every month. Chitrarekha is a real
                            inspiration for other women who often think they could not manage, but actually they really
                            can.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section><!-- /About Section -->



    <!-- Footer Section Start -->
    <?php include 'includes/footer.php';?>
    <!-- Footer Section End -->

    <!-- Scroll To Top Section Start -->
    <?php include 'includes/scroll.php';?>
    <!-- Scroll To Top Section End -->

    <!-- JS Section Start -->
    <?php include 'includes/js.php';?>
    <!-- JS Section End -->
</body>

</html>