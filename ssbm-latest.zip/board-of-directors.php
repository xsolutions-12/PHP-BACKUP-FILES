<!doctype html>

<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="DynamicLayers">

    <title>Board of Directors</title>
    <!-- CSS Start -->
    <?php include 'includes/css.php'; ?>
    <!-- CSS End -->

</head>

<body>
    <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

    <div class="site-preloader-wrap">
        <div class="spinner"></div>
    </div><!-- Preloader -->

    <!-- Header Section Start -->
    <?php include 'includes/header.php'; ?>
    <!-- Header Section End -->



    <div class="pager-header" style="background-image: url(img/banner/banner-1.png);">
        <div class="container">
            <div class="page-content text-center">
                <h2>Board of Directors</h2>
                <!-- <p>Help today because tomorrow you may be the one who <br>needs more helping!</p> -->
                <ol class="breadcrumb justify-content-center">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item"><a href="success-stories.php">Activities</a></li>
                    <li class="breadcrumb-item active">Board of Directors</li>
                </ol>
            </div>
        </div>
    </div><!-- /Page Header -->



    <section class="about-section bg-grey bd-bottom padding">
        <div class="container">



            <div class="row about-wrap">
                <div class="col-md-12 xs-padding">
                    <div class="testimonial-section">

                        <!-- Card 1 -->
                        <div class="testimonial-card">
                            <img src="img/board/ss_head1.jpg" alt="Mr. Vishal Raj Sinha">
                            <div class="testimonial-content">
                                <h3>Mr. Vishal Raj Sinha</h3>
                                <h4>Head – CSR, JSW Foundation</h4>
                                <p>
                                    We stopped us from thinking about “myself” and more “us” – a situation which will enable everyone
                                    to focus on family, rediscovering the importance of balance and calm, and where we are feeling the
                                    inadequacy of social and economic models. Here we should remember as cooperators that the cooperative
                                    movement has always been resilient, and at this moment, we all should build unexpected and fruitful
                                    alliances to seek open spaces for dialogue with various stakeholders, to forge inter-cooperation actions.
                                    This continues to guide the valuable exchange of ideas, support and in building a stronger future together.
                                </p>
                            </div>
                        </div>

                        <!-- Card 2 -->
                        <div class="testimonial-card">
                            <img src="img/board/ss_ceo1.jpg" alt="Mr. Amulya Thakur">
                            <div class="testimonial-content">
                                <h3>Mr. Amulya Thakur</h3>
                                <h4>CEO (Shree Shakti Cooperative Society)</h4>
                                <p>
                                    We stopped us from thinking about “myself” and more “us” – a situation which will enable everyone
                                    to focus on family, rediscovering the importance of balance and calm, and where we are feeling the
                                    inadequacy of social and economic models. Here we should remember as cooperators that the cooperative
                                    movement has always been resilient, and at this moment, we all should build unexpected and fruitful
                                    alliances to seek open spaces for dialogue with various stakeholders, to forge inter-cooperation actions.
                                    This continues to guide the valuable exchange of ideas, support and in building a stronger future together.
                                </p>
                            </div>
                        </div>

                    </div>

                </div>
            </div>

        </div>
    </section>
    <!-- /About Section -->



    <!-- Footer Section Start -->
    <?php include 'includes/footer.php'; ?>
    <!-- Footer Section End -->

    <!-- Scroll To Top Section Start -->
    <?php include 'includes/scroll.php'; ?>
    <!-- Scroll To Top Section End -->

    <!-- JS Section Start -->
    <?php include 'includes/js.php'; ?>
    <!-- JS Section End -->
</body>

</html>