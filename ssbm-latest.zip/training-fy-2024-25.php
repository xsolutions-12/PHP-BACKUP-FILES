<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="DynamicLayers">

    <title>Training FY 2024-25 - Shree Shakti Bahumukhi</title>
    <!-- CSS Start -->
    <?php include 'includes/css.php';?>
    <!-- CSS End -->

</head>

<body>
    <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

    <div class="site-preloader-wrap">
        <div class="spinner"></div>
    </div><!-- Preloader -->

    <!-- Header Section Start -->
    <?php include 'includes/header.php';?>
    <!-- Header Section End -->



    <div class="pager-header" style="background-image: url(img/banner/banner-1.png);">
        <div class="container">
            <div class="page-content text-center">
                <h2>Training FY 2024-25</h2>
                <!-- <p>Help today because tomorrow you may be the one who <br>needs more helping!</p> -->
                <ol class="breadcrumb justify-content-center">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item active">Training FY 2024-25</li>
                </ol>
            </div>
        </div>
    </div><!-- /Page Header -->



    <section class="about-section bg-grey bd-bottom padding">
        <div class="container">

            <div class="row training-wrap">
                <div class="col-md-12 xs-padding">
                    <div class="training-title">
                        <h2>Training Program to Dairy Farmers</h2>
                    </div>
                </div>
                <div class="col-md-10 xs-padding">
                    <div class="about-content">
                        <p>During the FY 2024-25 We have conducted a training program for Dairy farmers at GP office
                            Sripura. More than 25 farmers were presented in training session. Mr. Prasant Ku Kundu, ADVO
                            Jharsuguda acted as resource person for this program. The main objective behind organizing
                            this program was to increase collective procurement and got to know about various govt
                            schemes related to Dairy Business. Mr. Vishal Raj, Head CSR JSW also presented during
                            training and also distributed 1.5 kg of mineral mixture and 3 ltr of liquid calcium to each
                            farmer. He also encourages all farmers to associated with govt schemes.
                        </p>
                    </div>
                </div>
                <div class="col-md-2 xs-padding">
                    <div class="about-image">
                        <img src="img/training-fy-2024-25/1.jpg" alt="1">
                    </div>
                </div>
            </div>

            <div class="row training-wrap">
                <div class="col-md-12 xs-padding">
                    <div class="training-title">
                        <h2>Training Program on Cotton Wicks</h2>
                    </div>
                </div>
                <div class="col-md-10 xs-padding">
                    <div class="about-content">
                        <p>During FY 2024-25 We have conducted training program on cotton wicks at different villages
                            like Dudumkani, Thelkoloi, Budhiapali, Ghichamura. Where more than 60 members were trained.
                            Smt. Sankukta Meher and Gayatri Meher who herself an expert of cotton wicks from Banjiberna,
                            acted as resource person for different training schedule. All members were provided with raw
                            cotton wick for training and production. More than 100 kgs of Cotton distributed throughout
                            the year.
                        </p>
                    </div>
                </div>
                <div class="col-md-2 xs-padding">
                    <div class="about-image">
                        <img src="img/training-fy-2024-25/2.jpg" alt="2">
                    </div>
                </div>
            </div>

            <div class="row training-wrap">
                <div class="col-md-12 xs-padding">
                    <div class="training-title">
                        <h2>Training Programme for Women Entrepreneur at Lapanga, Sripura and Ghichamura</h2>
                    </div>
                </div>
                <div class="col-md-10 xs-padding">
                    <div class="about-content">
                        <p>During FY 2024-25 We have conducted several enterprises development training program in
                            Thelkoloi, Lapanga, Sripura and Ghichamura. Mr. C R Pattanaik acted as resources person for
                            these training. Under this training programme members were able to explore knowledge on
                            entrepreneurship nature, role and its sustainability. Another training program was conducted
                            for Board members of Shree Shakti Co-Operative along with field coordinator where members
                            were able know about business development plan for Shree Shakti.
                        </p>
                    </div>
                </div>
                <div class="col-md-2 xs-padding">
                    <div class="about-image">
                        <img src="img/training-fy-2024-25/3.jpg" alt="3">
                    </div>
                </div>
            </div>

            <div class="row training-wrap">
                <div class="col-md-12 xs-padding">
                    <div class="training-title">
                        <h2>Training on Business Development Plan for BOD Members</h2>
                    </div>
                </div>
                <div class="col-md-10 xs-padding">
                    <div class="about-content">
                        <p>During the month of Dec 2024, we have conducted a training programme for BOD members for
                            Shree Shakti Cooperative BOD members. In this training programme Resource Person was
                            imparted training on business development plan for Cooperatives. In this training programme
                            total one year business development plan was designed for this co-operative. Mr. C R
                            Pattnaik was resource person during program.
                        </p>
                    </div>
                </div>
                <div class="col-md-2 xs-padding">
                    <div class="about-image">
                        <img src="img/training-fy-2024-25/4.jpg" alt="4">
                    </div>
                </div>
            </div>

            <div class="row training-wrap">
                <div class="col-md-12 xs-padding">
                    <div class="training-title">
                        <h2>Training on pickle & Papad Making</h2>
                    </div>
                </div>
                <div class="col-md-10 xs-padding">
                    <div class="about-content">
                        <p>Six(06) days training programme was conducted during the month of November 2024 on Papad &
                            Pickle making for women beneficiary at LAPANGA village. Different products like Mixed
                            pickle, Chilly pickle, Papad, etc. are the part of this training programme. Total 27 members
                            are attended this training.
                        </p>
                    </div>
                </div>
                <div class="col-md-2 xs-padding">
                    <div class="about-image">
                        <img src="img/training-fy-2024-25/5.jpg" alt="5">
                    </div>
                </div>
            </div>

            <div class="row training-wrap">
                <div class="col-md-12 xs-padding">
                    <div class="training-title">
                        <h2>Training on Mushroom Cultivation</h2>
                    </div>
                </div>
                <div class="col-md-10 xs-padding">
                    <div class="about-content">
                        <p>Mushroom farming doesn’t require members to go out of the village for entire day for earning,
                            as It will take few hours to maintain and it is a viable and profitable venture for
                            livelihood options. Taking this as high consideration we have identified and training given
                            to new members from different villages like Dhubenchapar, Ghichamura and Gumkarama during FY
                            2024-25.
                        </p>
                    </div>
                </div>
                <div class="col-md-2 xs-padding">
                    <div class="about-image">
                        <img src="img/training-fy-2024-25/6.jpg" alt="6">
                    </div>
                </div>
            </div>

            <div class="row training-wrap">
                <div class="col-md-12 xs-padding">
                    <div class="training-title">
                        <h2>Training on Financial Literacy</h2>
                    </div>
                </div>
                <div class="col-md-10 xs-padding">
                    <div class="about-content">
                        <p>We have organized few financial literacy training programme during FY 2024-25 in different
                            villages like Ghichamura, Banjiberna, Thelkoloi etc. Mr. Murali Das from Dhan foundation
                            acted as resource person throughout the program. More than 100 members participated and
                            learnt about saving, investments, Govt Schemes etc.
                        </p>
                    </div>
                </div>
                <div class="col-md-2 xs-padding">
                    <div class="about-image">
                        <img src="img/training-fy-2024-25/7.jpg" alt="7">
                    </div>
                </div>
            </div>

            <div class="row training-wrap">
                <div class="col-md-12 xs-padding">
                    <div class="training-title">
                        <h2>Training on Sambalpuri Saree Design for Weaver Communities</h2>
                    </div>
                </div>
                <div class="col-md-10 xs-padding">
                    <div class="about-content">
                        <p>Total 40 days weaver training programme was started at Banjiberna village. Starting from
                            BANDHA making to saree manufacturing is main content of training programme.
                        </p>
                    </div>
                </div>
                <div class="col-md-2 xs-padding">
                    <div class="about-image">
                        <img src="img/training-fy-2024-25/8.jpg" alt="8">
                    </div>
                </div>
            </div>

            <div class="row training-wrap">
                <div class="col-md-12 xs-padding">
                    <div class="training-title">
                        <h2>Mixture & Dry Snacks Preparation</h2>
                    </div>
                </div>
                <div class="col-md-10 xs-padding">
                    <div class="about-content">
                        <p>Last Quarter focus given on prepration of Mixture and other dry snacks for District Level
                            events. Members from Baniberna, Lapanga and Ghichamura village are prepared different items
                            (Variety of Mixture, Cake, Muduku, etc).
                        </p>
                    </div>
                </div>
                <div class="col-md-2 xs-padding">
                    <div class="about-image">
                        <img src="img/training-fy-2024-25/9.jpg" alt="9">
                    </div>
                </div>
            </div>

            <div class="row training-wrap">
                <div class="col-md-12 xs-padding">
                    <div class="training-title">
                        <h2>Training to BOD Members on Cooperative Business Development Plan</h2>
                    </div>
                </div>
                <div class="col-md-10 xs-padding">
                    <div class="about-content">
                        <p>A training programme was conducted during the month December 2024 on Business Development
                            plan for our BOD members. The main topic covered under this training programme was how make
                            road map for Cooperative. How the BOD members are going take activity roles & responsibility
                            for Cooperative.
                        </p>
                    </div>
                </div>
                <div class="col-md-2 xs-padding">
                    <div class="about-image">
                        <img src="img/training-fy-2024-25/10.jpg" alt="10">
                    </div>
                </div>
            </div>

            <div class="row training-wrap">
                <div class="col-md-12 xs-padding">
                    <div class="training-title">
                        <h2>Training for Women Entrepreneur</h2>
                    </div>
                </div>
                <div class="col-md-10 xs-padding">
                    <div class="about-content">
                        <p>To empower the women entrepreneur in our area , there was a training programme conducted at
                            different panchayat. Around 100 women are undergone this training programme. External
                            resource person from Bhubaneswar was imparted training programme. The main thematic area was
                            What is enterprise, marketing strategy, understanding the sustainability road map for an
                            entrepreneur.
                        </p>
                    </div>
                </div>
                <div class="col-md-2 xs-padding">
                    <div class="about-image">
                        <img src="img/training-fy-2024-25/11.jpg" alt="11">
                    </div>
                </div>
            </div>

        </div>
    </section><!-- /About Section -->

    <!-- Footer Section Start -->
    <?php include 'includes/footer.php';?>
    <!-- Footer Section End -->

    <!-- Scroll To Top Section Start -->
    <?php include 'includes/scroll.php';?>
    <!-- Scroll To Top Section End -->

    <!-- JS Section Start -->
    <?php include 'includes/js.php';?>
    <!-- JS Section End -->
</body>

</html>