<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="DynamicLayers">

    <title>Success Stories - Shree Shakti Bahumukhi</title>
    <!-- CSS Start -->
    <?php include 'includes/css.php';?>
    <!-- CSS End -->

</head>

<body>
    <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

    <div class="site-preloader-wrap">
        <div class="spinner"></div>
    </div><!-- Preloader -->

    <!-- Header Section Start -->
    <?php include 'includes/header.php';?>
    <!-- Header Section End -->



    <div class="pager-header" style="background-image: url(img/banner/banner-1.png);">
        <div class="container">
            <div class="page-content text-center">
                <h2>Success Stories</h2>
                <!-- <p>Help today because tomorrow you may be the one who <br>needs more helping!</p> -->
                <ol class="breadcrumb justify-content-center">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item active">Success Stories</li>
                </ol>
            </div>
        </div>
    </div><!-- /Page Header -->

    <section class="causes-section bg-grey bd-bottom padding">
        <div class="container">
            <div class="causes-wrap row text-center">
                <div class="col-md-4 xs-padding mb-30">
                    <div class="causes-content">
                        <div class="causes-thumb">
                            <img src="img/success-stories/cs12.jpg" alt="causes">
                        </div>
                        <div class="causes-details">
                            <h3>Drops of life- A story of small farmer (Khimeswari Meher, Sunamal, Sripura)</h3>
                            <p style="line-height: 22.5px;">Smt Khimeswari Meher, aged around 29 (twenty-nine), stands out as an example of
                                individual commitment towards agricultural practices in a sustainable way.She lives with
                                her husband, one son, and one daughter at Sunamal Village of Sripura GP</p>
                            <a href="case-study1.php" class="read-more">Read More</a>
                        </div>
                    </div>
                </div><!-- /Causes-1 -->
                <div class="col-md-4 xs-padding mb-30">
                    <div class="causes-content">
                        <div class="causes-thumb">
                            <img src="img/success-stories/cs1.png" alt="causes">
                        </div>
                        <div class="causes-details">
                            <h3>Daring Dream – Story of Chumuki Santra (Fish Retail outlet)</h3>
                            <p>Mrs Chumuki Santra , residing at Landupalli village. The natures beauty village
                                Landupalli situated near the river bank of Mahanadi. She is staying with her husband and
                                two son’s are staying separately with their family.</p>
                            <a href="case-study2.php" class="read-more">Read More</a>
                        </div>
                    </div>
                </div><!-- /Causes-2 -->
                <div class="col-md-4 xs-padding mb-30">
                    <div class="causes-content">
                        <div class="causes-thumb">
                            <img src="img/success-stories/cs.png" alt="causes">
                        </div>
                        <div class="causes-details">
                            <h3>Marching towards Success- Chitralekha Dharua (Petty Business)</h3>
                            <p>Chitralekha Dharuaaged around 35, resides at Thelkoloi village, which is situated close
                                to the JSW factory. Staying with her husband & son & daughter. With the growing
                                population and contextual challenges, she started her business 7 years ago.</p>
                            <a href="case-study3.php" class="read-more">Read More</a>
                        </div>
                    </div>
                </div><!-- /Causes-3 -->
                <div class="col-md-4 xs-padding mb-30">
                    <div class="causes-content">
                        <div class="causes-thumb">
                            <img src="img/success-stories/cs2.png" alt="causes">
                        </div>
                        <div class="causes-details">
                            <h3>Be an Achiever- Story of Pushpalata Meher (Paper Plate unit, Banjiberna)</h3>
                            <p>Smt. Pushpalata Meher, aged around 45, is staying at Banjiberna village. Many years ago,
                                Pushpalata’s family shifted from the riverbank of the MAHANADI to Banjiberna village.
                            </p>
                            <a href="case-study4.php" class="read-more">Read More</a>
                        </div>
                    </div>
                </div><!-- /Causes-4 -->
            </div>
        </div>
    </section><!-- /Causes Section -->


    <!-- Footer Section Start -->
    <?php include 'includes/footer.php';?>
    <!-- Footer Section End -->

    <!-- Scroll To Top Section Start -->
    <?php include 'includes/scroll.php';?>
    <!-- Scroll To Top Section End -->

    <!-- JS Section Start -->
    <?php include 'includes/js.php';?>
    <!-- JS Section End -->
</body>

</html>