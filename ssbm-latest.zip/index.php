<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="en"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="">
        <meta name="author" content="DynamicLayers">
       
        <title>Shree Shakti Bahumukhi</title>
        <!-- CSS Start -->
         <?php include 'includes/css.php';?>
        <!-- CSS End -->

    </head>
    <body>
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
        
        <div class="site-preloader-wrap">
            <div class="spinner"></div>
        </div><!-- Preloader -->
        
        <!-- Header Section Start -->
        <?php include 'includes/header.php';?>
        <!-- Header Section End -->
        
        <section class="slider-section">
            <div class="slider-wrapper">
                <div id="main-slider" class="nivoSlider">
                    <img src="img/home/slider/1.png" alt="" title="#slider-caption-1">
                    <img src="img/home/slider/2.png" alt="" title="#slider-caption-2">
                    <img src="img/home/slider/3.png" alt="" title="#slider-caption-3">
                </div><!-- /#main-slider -->

                    <!-- <div id="slider-caption-1" class="nivo-html-caption slider-caption">
                        <div class="display-table">
                            <div class="table-cell">
                                <div class="container">
                                <div class="slider-text">
                                    <h5 class="wow cssanimation fadeInBottom">Join Us Today</h5>
                                    <h1 class="wow cssanimation leFadeInRight sequence">Better Life for People</h1>
                                        <p class="wow cssanimation fadeInTop" data-wow-delay="1s">Help today because tomorrow you may be the one who needs helping! <br>Forget what you can get and see what you can give.</p>
                                        <a href="#" class="default-btn wow cssanimation fadeInBottom" data-wow-delay="0.8s">Join With Us</a>
                                        <a href="#" class="default-btn wow cssanimation fadeInBottom" data-wow-delay="0.8s">Donet Now</a>
                                    </div>
                            </div>
                            </div>
                        </div>
                    </div>  -->
                <!-- /#slider-caption-1 -->
                <!-- <div id="slider-caption-2" class="nivo-html-caption slider-caption">
                    <div class="display-table">
                        <div class="table-cell">
                            <div class="container">
                               <div class="slider-text">
                                    <h1 class="wow cssanimation fadeInTop" data-wow-delay="1s" data-wow-duration="800ms">Together we  <br>can make a Difference</h1>
                                    <p class="wow cssanimation fadeInBottom" data-wow-delay="1s">Help today because tomorrow you may be the one who needs helping! <br>Forget what you can get and see what you can give.</p>
                                    <a href="#" class="default-btn wow cssanimation fadeInBottom" data-wow-delay="0.8s">Join With Us</a>
                                    <a href="#" class="default-btn wow cssanimation fadeInBottom" data-wow-delay="0.8s">Donet Now</a>
                                </div>
                           </div>
                        </div>
                    </div>
                </div>  -->
                <!-- /#slider-caption-2 -->
                <!-- <div id="slider-caption-3" class="nivo-html-caption slider-caption">
                    <div class="display-table">
                        <div class="table-cell">
                            <div class="container">
                               <div class="slider-text">
                                    <h5 class="wow cssanimation fadeInBottom">Join Us Today</h5>
                                    <h1 class="wow cssanimation lePushReleaseFrom sequence" data-wow-delay="1s">Give a little. Change a lot.</h1>
                                    <p class="wow cssanimation fadeInTop" data-wow-delay="1s">Help today because tomorrow you may be the one who needs helping! <br>Forget what you can get and see what you can give.</p>
                                    <a href="#" class="default-btn wow cssanimation fadeInBottom" data-wow-delay="0.8s">Join With Us</a>
                                    <a href="#" class="default-btn wow cssanimation fadeInBottom" data-wow-delay="0.8s">Donet Now</a>
                                </div>
                           </div>
                        </div>
                    </div>
                </div>  -->
                <!-- /#slider-caption-3 -->
            </div>
        </section>
        <!-- /#slider-Section -->

        <section id="counter" class="counter-section">
		    <div class="container">
                <div class="section-heading text-center mb-40">
                    <h2>OUR FOOTPRINTS</h2>
                    <span class="heading-border"></span>
                </div>
                <ul class="row counters">
                    <li class="col-md-3 col-sm-6 sm-padding">
                        <div class="counter-content">
                            <!-- <i class="ti-money"></i> -->
                             <img src="img/icon/location.png" alt="counter-img-1">
                            <h3 class="counter">2</h3>
                            <h4>STATE</h4>
                        </div>
                    </li>
                    <li class="col-md-3 col-sm-6 sm-padding">
                        <div class="counter-content">
                            <!-- <i class="ti-face-smile"></i> -->
                             <img src="img/icon/office.png" alt="counter-img-2">
                            <h3 class="counter">40</h3>
                            <h4>PROJECT OFFICES</h4>
                        </div>
                    </li>
                    <li class="col-md-3 col-sm-6 sm-padding">
                        <div class="counter-content">
                            <!-- <i class="ti-user"></i> -->
                             <img src="img/icon/rupee.png" alt="counter-img-3">
                            <h3 class="counter">50,000</h3>
                            <h4>BENEFICIARIES</h4>
                        </div>
                    </li>
                    <li class="col-md-3 col-sm-6 sm-padding">
                        <div class="counter-content">
                            <!-- <i class="ti-comments"></i> -->
                             <img src="img/icon/group.png" alt="counter-img-4">
                            <h3 class="counter">50</h3>
                            <h4>EMPLOYEES</h4>
                        </div>
                    </li>
                </ul>
		    </div>
		</section><!-- Counter Section -->
        
        <section class="about-section padding">
            <div class="container">
                <div class="row about-wrap">
                    <div class="col-md-5 xs-padding">
                        <div class="about-image">
                            <img src="img/home/about.png" alt="about image">
                        </div>
                    </div>
                    <div class="col-md-7 xs-padding">
                        <div class="about-content">
                            <h2>Welcome to Shree Shakti Bahumukhi Mahila Sambaya Samiti LTD</h2>
                            <p style="color: #262525;margin-bottom: 5px;font-weight: 600;font-size: 14px;">“Shree Shakti Mahila Samabaya Samiti LTD” a women institution commonly known as Shree Shakti Cooperative, has emerged as a model community-based organization in Sambalpur district of Odisha.</p>
                            <p style="line-height: 25px;">“ <i style="color: #ed2719">Shree Shakti Bahumukhi Mahila Sambaya Samiti Ltd.</i> is an autonomous association of women members of Sambalpur District united voluntarily to meet their common economic, social and cultural needs and aspirations through a jointly owned and democratically controlled enterprise i.e. financial services”. Cooperatives as business enterprise possess some basic interests such as ownership and control but these interests are directly vested in the hands of the user. Therefore, Shree Shakti Bahumukhi Mahila Samabaya Samiti Ltd.follows certain broad values other than those associated purely with profit making. Here in Shree Shakti Cooperative the need for profitability is balanced by the needs of the members and the wider interest of the community.The values universally recognized as cornerstones of Shree Shakti principles are self-help, democracy, equality, equity and solidarity. </p>
                            <a href="about.php" class="default-btn"><i class="fa fa-angle-double-right rightDoubleAngle"></i>View More</a>
                        </div>
                    </div>
                </div>
            </div>
        </section><!-- /About Section -->

        <section class="abt-section">
            <div class="container">
                <div class="row g-4"><!-- g-4 adds gap between columns -->
            
                    <!-- Box 1 -->
                    <div class="col-md-6">
                        <div class="about-box d-flex align-items-start p-3">
                            <div class="icon-img me-3">
                                <img src="img/icon/vision.png" alt="about-thumb" style="width: 64px">
                            </div>
                            <div class="abt-txt">
                                <h2>MISSION & VISION</h2>
                                <p>envisages itself as a sustainable micro Finance Institution which will capitalize the poor & marginalized family and provide them social & financial independence in their life.</p>
                            </div>
                        </div>
                    </div>

                    <!-- Box 2 -->
                    <div class="col-md-6">
                        <div class="about-box d-flex align-items-start p-3">
                            <div class="icon-img me-3">
                                <img src="img/icon/goal.png" alt="about-thumb" style="width: 64px">
                            </div>
                            <div class="abt-txt">
                                <h2>GOAL</h2>
                                <p style="line-height: 20px;">To enable the members of the Cooperative is to provide the Capacity buildings, livelihood enhancement, financial services(Savings & Credit) , health and education services to poor & marginal women in rural areas to live with dignity.</p>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </section><!-- /Vision Mission & Goal Section -->
        
        <section class="causes-section bd-bottom padding">
            <div class="container">
                <div class="section-heading text-center mb-40">
                    <h2>OUR EVENTS</h2>
                    <span class="heading-border"></span>
                </div><!-- /Section Heading -->
                <div class="causes-wrap row">
                    <div class="col-md-3 xs-padding">
                        <div class="causes-content">
                           <div class="causes-thumb">
                                <img src="img/home/ev1.png" alt="causes">
                                <div class="progress">
                                    <div class="progress-bar" role="progressbar" style="width: 25%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"><span class="wow cssanimation fadeInLeft">25%</span></div>
                                </div>
                           </div>
                            <div class="causes-details-front">
                                <!-- <h3>First charity activity of this summer.</h3> -->
                                <p style="line-height: 24.4px;">A one day Orientation programme was conducted by Department of Horticulture from Rengli block at Lapan ga GP. Around 100 women participated in this programme. The team gave information on different Government schemes and facilities available under horticulture department and they also shared their plan to supply Marigold Seedlings to targeted communities.</p>
                                <!-- <a href="#" class="read-more">Read More</a> -->
                            </div>
                        </div>
                    </div><!-- /Causes-1 -->
                    <div class="col-md-3 xs-padding">
                        <div class="causes-content">
                           <div class="causes-thumb">
                                <img src="img/home/ev2.jpg" alt="causes">
                                <div class="progress">
                                    <div class="progress-bar" role="progressbar" style="width: 45%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"><span class="wow cssanimation fadeInLeft">45%</span></div>
                                </div>
                           </div>
                            <div class="causes-details-front">
                                <!-- <h3>Big charity: build school for poor children.</h3> -->
                                <p style="line-height: 22.4px;">Two Day’s training programme was conducted at Gourdhia Village from GHEECHAMURA GP on Mixture promotion was organized by ACCESS Development Services on 19th and 20th February 2024. In this mixture training programme CSR head from JSW Foundation, was attended and encouraged the participants for their interest and also focus on marketing of these products.</p>
                                <!-- <a href="#" class="read-more">Read More</a> -->
                            </div>
                        </div>
                    </div><!-- /Causes-2 -->
                    <div class="col-md-3 xs-padding">
                        <div class="causes-content">
                           <div class="causes-thumb">
                                <img src="img/home/ev3.png" alt="causes">
                                <div class="progress">
                                    <div class="progress-bar" role="progressbar" style="width: 75%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"><span class="wow cssanimation fadeInLeft">75%</span></div>
                                </div>
                           </div>
                            <div class="causes-details-front">
                                <!-- <h3>Building clean-water system for rural poor.</h3> -->
                                <p>An one-day training cum awareness program on MSME sector was organized by Access Developme nt Services on 30th Jan 2024 at Tailoring Centre, Thelkoloi. In this event Mr. Santun Bhoi (RIC, Sambalpur) and Mr. Jadumani Pradhan (SBI, RBO Sambalpur) was participated and elaborate on different Government schemes.</p>
                                <!-- <a href="#" class="read-more">Read More</a> -->
                            </div>
                        </div>
                    </div><!-- /Causes-3 -->
                    <div class="col-md-3 xs-padding">
                        <div class="causes-content">
                           <div class="causes-thumb">
                                <img src="img/home/ev4.png" alt="causes">
                                <div class="progress">
                                    <div class="progress-bar" role="progressbar" style="width: 75%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"><span class="wow cssanimation fadeInLeft">75%</span></div>
                                </div>
                           </div>
                            <div class="causes-details-front">
                                <!-- <h3>Building clean-water system for rural poor.</h3> -->
                                <p>A weaving ( BANDHA) machine been installed at Smranika SHG, Banjiberna to encourage weaver community and inaugurated on dt 12th Jan 2024 by CSR Head from JSW Foundation and Manager CSR JSW Foundation. Total 11 nos. of members working in weaving community this month out of 11nos six added during this month.</p>
                                <!-- <a href="#" class="read-more">Read More</a> -->
                            </div>
                        </div>
                    </div><!-- /Causes-4 -->
                </div>
            </div>
        </section><!-- /Event Section -->
        
        <section class="directors-section py-5">
            <div class="container">
                <div class="section-heading text-center mb-40">
                    <h2>BOARD OF DIRECTORS</h2>
                    <span class="heading-border"></span>
                </div>
                <div class="row g-4 justify-content-center">
      
                    <!-- Card 1 -->
                    <div class="col-md-6">
                        <div class="director-card p-4 border rounded shadow-sm h-100">
                            <div class="row g-3 align-items-center">
                                <div class="col-md-4 text-center">
                                    <img src="img/home/vishal.png" alt="Director" class="img-fluid rounded">
                                    <p class="mt-2 fw-bold small">Head – CSR, JSW Foundation</p>
                                </div>
                                <div class="col-md-8">
                                    <h3 class="fw-bold">Mr. Vishal Raj Sinha</h3>
                                    <hr>
                                    <p class="mb-3">
                                         We stopped us from thinking about “myself” and more “us” — a situation which will enable everyone to focus on family, rediscovering the importance of balance and calm, and where we are feeling the inadequacy of social and economic models.
                                    </p>
                                    <a href="about.php" class="default-btn"><i class="fa fa-angle-double-right rightDoubleAngle"></i>View More</a>
                                </div>
                            </div>
                        </div>
                    </div>
      
                    <!-- Card 2 -->
                    <div class="col-md-6">
                        <div class="director-card p-4 border rounded shadow-sm h-100">
                            <div class="row g-3 align-items-center">
                                <div class="col-md-4 text-center">
                                    <img src="img/home/amulya.png" alt="Director" class="img-fluid rounded">
                                    <p class="mt-2 fw-bold small">CEO (Shree Shakti Cooperative Society)</p>
                                </div>
                                <div class="col-md-8">
                                    <h3 class="fw-bold">Mr. Amulya Thakur</h3>
                                    <hr>
                                    <p class="mb-3">
                                        We stopped us from thinking about “myself” and more “us” — a situation which will enable everyone to focus on family, rediscovering the importance of balance and calm, and where we are feeling the inadequacy of social and economic models.
                                    </p>
                                    <a href="about.php" class="default-btn"><i class="fa fa-angle-double-right rightDoubleAngle"></i>View More</a>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </section><!-- Board of Directors Section -->
        
        <!-- Footer Section Start -->
        <?php include 'includes/footer.php';?>
        <!-- Footer Section End -->
        
        <!-- Scroll To Top Section Start -->
		<?php include 'includes/scroll.php';?>
        <!-- Scroll To Top Section End -->
	
        <!-- JS Section Start -->
        <?php include 'includes/js.php';?>
        <!-- JS Section End -->
</body>
</html>