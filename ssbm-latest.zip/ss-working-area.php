<!doctype html>

<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="DynamicLayers">

    <title>Shree Shakti Working Areas</title>
    <!-- CSS Start -->
    <?php include 'includes/css.php'; ?>
    <!-- CSS End -->

</head>

<body>
    <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

    <div class="site-preloader-wrap">
        <div class="spinner"></div>
    </div><!-- Preloader -->

    <!-- Header Section Start -->
    <?php include 'includes/header.php'; ?>
    <!-- Header Section End -->



    <div class="pager-header" style="background-image: url(img/banner/banner-1.png);">
        <div class="container">
            <div class="page-content text-center">
                <h2>Shree Shakti Working Areas</h2>
                <!-- <p>Help today because tomorrow you may be the one who <br>needs more helping!</p> -->
                <ol class="breadcrumb justify-content-center">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item"><a href="success-stories.php">Activities</a></li>
                    <li class="breadcrumb-item active">Shree Shakti Working Areas</li>
                </ol>
            </div>
        </div>
    </div><!-- /Page Header -->



    <section class="about-section bg-grey bd-bottom padding">
        <div class="container">
            
            <div class="row about-wrap">
                <div class="col-md-12 xs-padding">
                    <div class="about-content" style="text-align:center">
                        <h2>Shree Shakti Working Areas</h2>
                        <h6 style="font-weight: 600; font-size:15px; line-height:30px">Top management of Shree Shakti Cooperative identifies a new area to be included in the operational area taking into account the potentiality to provide financial services as per cooperative operational ambit. A senior staff resides in the area and collects the following information.</h6>
                    </div>
                </div>
            </div>

            <!-- Vegetable -->
            <div class="row about-wrap">
                <div class="col-md-6 xs-padding">
                    <div class="about-content">
                        <ul>
                            <li>➧ No of poor families in the area</li>
                            <li>➧ Name and number of Cooperative/MFIs working in the area</li>
                            <li>➧ Availability of commercial banks</li>
                            <li>➧ Socio-economic condition of the area</li>
                            <li>➧ Roads and communication in the area</li>
                            <li>➧ Information regarding the handicrafts, cottage industries and agricultural products of the area</li>
                            <li>➧ The senior person sends the information to the relevant officer in the head office with a proposal of starting MF program in the new area. When the source of fund is confirmed, an approval for starting MF program in new area is given by the head Trained Credit Officers are being sent to the new area.</li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-6 xs-padding">
                    <img src="img/activities/working-area.jpg">
                </div>
            </div>

        </div>
    </section>
    <!-- /About Section -->



    <!-- Footer Section Start -->
    <?php include 'includes/footer.php'; ?>
    <!-- Footer Section End -->

    <!-- Scroll To Top Section Start -->
    <?php include 'includes/scroll.php'; ?>
    <!-- Scroll To Top Section End -->

    <!-- JS Section Start -->
    <?php include 'includes/js.php'; ?>
    <!-- JS Section End -->
</body>

</html>