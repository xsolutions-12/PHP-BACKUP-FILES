<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="DynamicLayers">

    <title>Case Study 4 - Shree Shakti Bahumukhi</title>
    <!-- CSS Start -->
    <?php include 'includes/css.php';?>
    <!-- CSS End -->

</head>

<body>
    <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

    <div class="site-preloader-wrap">
        <div class="spinner"></div>
    </div><!-- Preloader -->

    <!-- Header Section Start -->
    <?php include 'includes/header.php';?>
    <!-- Header Section End -->



    <div class="pager-header" style="background-image: url(img/banner/banner-1.png);">
        <div class="container">
            <div class="page-content text-center">
                <h2>Case Study</h2>
                <!-- <p>Help today because tomorrow you may be the one who <br>needs more helping!</p> -->
                <ol class="breadcrumb justify-content-center">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item"><a href="success-stories.php">Success Stories</a></li>
                    <li class="breadcrumb-item active">Case Study</li>
                </ol>
            </div>
        </div>
    </div><!-- /Page Header -->



    <section class="about-section bg-grey bd-bottom padding">
        <div class="container">
            <div class="row about-wrap">

                <div class="col-md-7 xs-padding">
                    <div class="about-content">
                        <h2>Be an Achiever- Story of Pushpalata Meher (Paper Plate unit, Banjiberna)</h2>
                        <p><strong>Smt. Pushpalata Meher</strong>, aged around 45, is staying at Banjiberna village.
                            Many years
                            ago, Pushpalata’s family shifted from the riverbank of the MAHANADI to Banjiberna
                            village. As their forefathers shifted their nativity from the Mahanadi River Bank
                            village to Banjiberna for social establishment, their permanent village became
                            Banjiberna. Besides this, Pushpalata is residing with her husband, son who is studying
                            (10+2), and daughter at this village. Her husband is working as contract labour in a
                            nearby factory. Pushpalata is well known for her simple nature and also loves to work
                            hard in each aspect. Her contribution of her engagement for income generation towards
                            her family became highly appreciable because she equally gave importance to her family
                            life and professional life.
                        </p>
                        <p>The story of Pushpalata’s life begins with full of challenges and struggles. During those
                            days she survived with her family on a piece of bread & butter. Without having a piece of
                            land, it makes it very difficult to cater to the livelihood services for income generation.
                            In fact, there was a lot of chaos and confusion that came into her life, but still, she
                            survived with the solo income of her husband.
                        </p>
                    </div>
                </div>
                <div class="col-md-5 xs-padding">
                    <div class="about-image">
                        <img src="img/success-stories/cs32.jpg" alt="Case Study 1">
                    </div>
                </div>
            </div>
            <div class="row about-wrap">

                <div class="col-md-12 xs-padding">
                    <div class="about-content">
                        <p>The impact of Pushpalata was seen when she became part of the SHG movement. Credit business
                            makes her life easier for their petty business. During the year 2014-15, she became a member
                            of SHG and brought a loan from SHG, then started her small business in her home. Gradually,
                            when she attached to the JSW project team, she explored the facilities provided by the
                            Livelihood project. Meanwhile, she established a paper plate machine with the support of the
                            Odisha Livelihood Mission (OLM) and got raw material support from the JSW Foundation for the
                            preparation of paper plates. Again, it was not sufficient for her family. Then she
                            established a petty business center inside JSW Township on a weekly basis. The multiple
                            sources of income, like the paper plate production unit, petty business, and retail outlet
                            inside JSW Township, are the value addition to their livelihoods. Now she is becoming a
                            successful entrepreneur, getting an income of Rs. 7000 to 8000 per month apart from her
                            husband’s regular income.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section><!-- /About Section -->



    <!-- Footer Section Start -->
    <?php include 'includes/footer.php';?>
    <!-- Footer Section End -->

    <!-- Scroll To Top Section Start -->
    <?php include 'includes/scroll.php';?>
    <!-- Scroll To Top Section End -->

    <!-- JS Section Start -->
    <?php include 'includes/js.php';?>
    <!-- JS Section End -->
</body>

</html>