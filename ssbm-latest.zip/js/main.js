/*Charitify Theme Scripts */

(function($){
    "use strict";
             
    $(window).on('load', function() {
        $('body').addClass('loaded');
    });

/*=========================================================================
    	Sticky Header
=========================================================================*/ 
    $(function() {
        var header = $("#header"),
            height = header.height(),
            yOffset = 0,
            triggerPoint = 100;
        $('.header-height').css('height', height+'px');
        $(window).on( 'scroll', function() {
            yOffset = $(window).scrollTop();

            if (yOffset >= triggerPoint) {
            	header.removeClass("animated cssanimation fadeIn");
                header.addClass("navbar-fixed-top  cssanimation animated fadeInTop");
            } else {
                header.removeClass("navbar-fixed-top cssanimation  animated fadeInTop");
                header.addClass("animated cssanimation fadeIn");
            }

        });
    });

/*=========================================================================
    Nivo slider 
=========================================================================*/
    $('#main-slider').nivoSlider({
        effect: 'random',
        animSpeed: 300,
        pauseTime: 5000,
        directionNav: true,
        manualAdvance: false,
        controlNavThumbs: false,
        pauseOnHover: true,
        controlNav: false,
        prevText: "<i class='ti-arrow-left'></i>",
        nextText: "<i class='ti-arrow-right'></i>"
    });

/*=========================================================================
    Mobile Menu
=========================================================================*/  
    $(function(){
        $('#mainmenu').slicknav({
            prependTo: '.site-branding',
            label: '',
            allowParentLinks: true
        });
    });
             
/*=========================================================================
	Counter Up Active
=========================================================================*/
	var counterSelector = $('.counter');
	counterSelector.counterUp({
		delay: 10,
		time: 1000
	});
             
/*=========================================================================
    Event Carousel
=========================================================================*/
    $('#event-carousel').owlCarousel({
        loop: true,
        margin: 15,
        autoplay: false,
        smartSpeed: 500,
        nav: true,
        navText: ['<i class="ti-arrow-left"></i>', '<i class="ti-arrow-right"></i>'],
        dots: false,
        responsive : {
            0 : {
                items: 1
            },
            480 : {
                items: 1,
            },
            768 : {
                items: 2,
            },
            992 : {
                items: 2,
            }
        }
    });          
             
/*=========================================================================
    Isotope Active
=========================================================================*/
	$('.gallery-items').imagesLoaded( function() {

		 // Add isotope click function
		$('.gallery-filter li').on( 'click', function(){
	        $(".gallery-filter li").removeClass("active");
	        $(this).addClass("active");
	 
	        var selector = $(this).attr('data-filter');
	        $(".gallery-items").isotope({
	            filter: selector,
	            animationOptions: {
	                duration: 750,
	                easing: 'linear',
	                queue: false,
	            }
	        });
	        return false;
	    });

	    $(".gallery-items").isotope({
	        itemSelector: '.single-item',
	        layoutMode: 'masonry',
	    });
	});

/*=========================================================================
    Initialize smoothscroll plugin
=========================================================================*/
	smoothScroll.init({
		offset: 60
	});

/*=========================================================================
    Testimonial Carousel
=========================================================================*/
	$('#testimonial-carousel').owlCarousel({
        loop: true,
        margin: 15,
        autoplay: true,
        smartSpeed: 500,
        items: 1,
        nav: false,
        dots: true,
        responsive : {
			0 : {
				items: 1,
			},
			480 : {
				items: 2,
			},
			768 : {
				items: 2
			},
			992 : {
				items: 3
			}
		}
    });

/*=========================================================================
        Sponsor Carousel
=========================================================================*/
    $('#sponsor-carousel').owlCarousel({
        loop: true,
        margin: 40,
        autoplay: true,
        smartSpeed: 500,
        nav: false,
        dots: false,
        responsive : {
            0 : {
                items: 2
            },
            480 : {
                items: 3,
            },
            768 : {
                items: 4
            },
            992 : {
                items: 6
            }
        }
    });
		
/*=========================================================================
        Active venobox
=========================================================================*/
	$('.img-popup').venobox({
		numeratio: true,
		infinigall: true
	}); 

/*=========================================================================
	WOW Active
=========================================================================*/ 
    new WOW().init();             
             
/*=========================================================================
  Scroll To Top
=========================================================================*/     
    $(window).on( 'scroll', function () {
        if ($(this).scrollTop() > 100) {
            $('#scroll-to-top').fadeIn();
        } else {
            $('#scroll-to-top').fadeOut();
        }
    });
             
})(jQuery);


// For Event Accordion
const headers = document.querySelectorAll(".acc-header");

headers.forEach((header, index) => {
  const panel = header.nextElementSibling;
  const icon = header.querySelector(".acc-icon i");

  // Make first panel active on page load
  if (index === 0) {
    panel.classList.add("open");
    panel.style.maxHeight = panel.scrollHeight + "px"; // first panel height according to content
    header.setAttribute("aria-expanded", "true");
    panel.setAttribute("aria-hidden", "false");
    icon.className = "fa fa-angle-double-down";
  } else {
    panel.style.maxHeight = "0"; // closed panels initially
    header.setAttribute("aria-expanded", "false");
    panel.setAttribute("aria-hidden", "true");
    icon.className = "fa fa-angle-double-right";
  }

  header.addEventListener("click", () => {
    const isOpen = panel.classList.contains("open");

    // Close all other panels
    document.querySelectorAll(".acc-panel").forEach(p => {
      p.classList.remove("open");
      p.style.maxHeight = "0"; // hide closed panels
      p.previousElementSibling.setAttribute("aria-expanded", "false");
      p.setAttribute("aria-hidden", "true");
      p.previousElementSibling.querySelector(".acc-icon i").className =
        "fa fa-angle-double-right";
    });

    // Open clicked panel if it wasn’t already open
    if (!isOpen) {
      panel.classList.add("open");
      panel.style.maxHeight = "100%"; // open to full height of its content
      header.setAttribute("aria-expanded", "true");
      panel.setAttribute("aria-hidden", "false");
      icon.className = "fa fa-angle-double-down";
    }
  });
});

// gallery
//   Thumbnail LightGallery Scripts 
function openGallery(id, index = 0) {
      const galleryEl = document.getElementById(id);
      const lg = lightGallery(galleryEl, {
        plugins: [lgThumbnail],
        thumbnail: true,
        download: true,
        zoom: true,
        hideBarsDelay: 3000,
        mode: 'lg-fade'
      });
      lg.openGallery(index);
    }