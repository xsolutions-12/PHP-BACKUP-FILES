<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="DynamicLayers">

    <title>Case Study 2 - Shree Shakti Bahumukhi</title>
    <!-- CSS Start -->
    <?php include 'includes/css.php';?>
    <!-- CSS End -->

</head>

<body>
    <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

    <div class="site-preloader-wrap">
        <div class="spinner"></div>
    </div><!-- Preloader -->

    <!-- Header Section Start -->
    <?php include 'includes/header.php';?>
    <!-- Header Section End -->



    <div class="pager-header" style="background-image: url(img/banner/banner-1.png);">
        <div class="container">
            <div class="page-content text-center">
                <h2>Case Study</h2>
                <!-- <p>Help today because tomorrow you may be the one who <br>needs more helping!</p> -->
                <ol class="breadcrumb justify-content-center">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item"><a href="success-stories.php">Success Stories</a></li>
                    <li class="breadcrumb-item active">Case Study</li>
                </ol>
            </div>
        </div>
    </div><!-- /Page Header -->



    <section class="about-section bg-grey bd-bottom padding">
        <div class="container">
            <div class="row about-wrap">

                <div class="col-md-7 xs-padding">
                    <div class="about-content">
                        <h2>Drops of life- A story of small farmer (Khimeswari Meher, Sunamal, Sripura)</h2>
                        <p><strong>Mrs Chumuki Santra</strong>, residing at Landupalli village. The natures beauty
                            village Landupalli
                            situated near the river bank of Mahanadi. She is staying with her husband and two son’s are
                            staying separately with their family. The livelihood scenario of her family is fish
                            retailing and labour work occasionally done by her husband. Moreover, both husband & wife
                            are laborious and always busy in their primary source of income (Fish retailing). Being an
                            unqualified lady but she used to handle the retail business efficiently. The journey of
                            Chumuki Santra begins with different situation and contextual challenges. After her marriage
                            in the initial day of her life they used to survive with financial sustainability. Beginning
                            from his career her source of income is fish retailing with very minimal income and restrict
                            them to live in below poverty line. Gradually she was blessed with two children. As the time
                            passes away the two children’s are grown up they were settled separately from their parents.
                            The passionate of her work increases her financial strength through business and SHG
                            movement.
                        </p>
                    </div>
                </div>
                <div class="col-md-5 xs-padding">
                    <div class="about-image">
                        <img src="img/success-stories/cs1.png" alt="Case Study 1">
                    </div>
                </div>
            </div>
            <div class="row about-wrap">

                <div class="col-md-12 xs-padding">
                    <div class="about-content">
                        <p>At the same time her husband provides 100% support in their daily work/business.
                            With this they are having small piece of land used rarely for Kitchen Garden. Apart from
                            this her regular fish retail outlet was set up in SARBAHAL area of Jharsuguda. She used to
                            sit in an open space for fish retail outlet which was very challenging for run business
                            throughout year.
                        </p>
                    </div>
                    <div class="about-content">
                        <p>With the SHG movement she became self-dependable with Savings & Credit business. She is an
                            active member of SHG. She used to take loan from SHG and utilized it in their business &
                            consumption. Along with this her husband also engaged as part time labour rarely in local
                            area. During Project initial stage she came across with project team and shared her
                            constraints on their running fish retail outlet. Continuously meeting with beneficiary from
                            project team and visited to her village, it was decided to provide logistic support to save
                            her time, projection from sunlight & rain, storage of fish for long time. Hence, she got
                            logistic support like Weight machine, ice box and Gardening umbrella. It helps her to run
                            the business without much loss. she used to get income of Rs. 10000-12000/- per month.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section><!-- /About Section -->



    <!-- Footer Section Start -->
    <?php include 'includes/footer.php';?>
    <!-- Footer Section End -->

    <!-- Scroll To Top Section Start -->
    <?php include 'includes/scroll.php';?>
    <!-- Scroll To Top Section End -->

    <!-- JS Section Start -->
    <?php include 'includes/js.php';?>
    <!-- JS Section End -->
</body>

</html>