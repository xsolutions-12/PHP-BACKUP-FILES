<!doctype html>

<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="DynamicLayers">

    <title>Capacity Building & Livelyhood Initiative</title>
    <!-- CSS Start -->
    <?php include 'includes/css.php'; ?>
    <!-- CSS End -->

</head>

<body>
    <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

    <div class="site-preloader-wrap">
        <div class="spinner"></div>
    </div><!-- Preloader -->

    <!-- Header Section Start -->
    <?php include 'includes/header.php'; ?>
    <!-- Header Section End -->



    <div class="pager-header" style="background-image: url(img/banner/banner-1.png);">
        <div class="container">
            <div class="page-content text-center">
                <h2>Capacity Building & Livelyhood Initiative</h2>
                <!-- <p>Help today because tomorrow you may be the one who <br>needs more helping!</p> -->
                <ol class="breadcrumb justify-content-center">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item"><a href="success-stories.php">Activities</a></li>
                    <li class="breadcrumb-item active">Capacity Building & Livelyhood Initiative</li>
                </ol>
            </div>
        </div>
    </div><!-- /Page Header -->



    <section class="about-section bg-grey bd-bottom padding">
        <div class="container">
            
            <div class="row about-wrap">
                <div class="col-md-12 xs-padding">
                    <div class="about-content" style="text-align:center">
                        <h2>Livelihood Activities under take by Shree Shakti Cooperative</h2>
                        <h6 style="font-weight: 600; font-size:15px; line-height:30px">To enhance the income rural households , Shree Shakti took initiative of Empowerment and Entrepreneurship programme in a sustainable way. By seeing the potential of the women’s members whose covered under Cooperative Shree shakti begins with training & Capacity building programme for their income generation.</h6>
                    </div>
                </div>
            </div>

            <!-- Vegetable -->
            <div class="row about-wrap">
                <div class="col-md-8 xs-padding">
                    <div class="about-content">
                        <p class="act-heading">Vegetable Cultivation Promotion</p>
                        <p>During the year(FY 23-24), we have distributed different types of seeds like Pumkin, bottle guard, bin, cucumber, brinjal, tomato, Cowpea, Bottle gourd, Brinjal, Ridge gourd, Leafy Vegetable, Okra, etc. Sale of Vegetable reach to Rs 3,36,840/- in the month of November & December 2023 and Rs.1,86,700 in January 24 & Rs.3,72,100 in February 2024. Most importantly in the month of March total sale of vegetable reached to Rs, 4,60,900/- As such total sale reached from Phase 1 and Phase 2 is Rs. 14,87,783.00.
                        </p>
                    </div>
                </div>
                <div class="col-md-4 xs-padding">
                    <img src="img/activities/vegetable.jpg">
                </div>
            </div>

            <!-- Mushroom Cultivation -->
            <div class="row about-wrap">
                <div class="col-md-4 xs-padding">
                    <img src="img/activities/mushroom.jpg">
                </div>
                <div class="col-md-8 xs-padding">
                    <div class="about-content">
                        <p class="act-heading">Paddy Straw Mushroom Cultivation</p>
                        <p>In the first phase we have distributed 558 bottles to 29 Members, in which total 1106 beds are formed. Total income coming from selling of mushroom first phase was Rs. 1,58,100/- . In Continuation to this activity in the second phase embers from Khaliapali and Gumkarama wished to better their income by starting mushroom enterprise. In order to strengthen the women self-help, group we have distributed 30 nos. of mushroom spawn bottles in order to complete 60nos of beds to 6 members. These farming doesn’t require members to go out of the village for entire day for earning, as It will take few hours to maintain and it is a viable and profitable venture for livelihood options
                        </p>
                    </div>
                </div>
            </div>

            <!-- Puffed Rice Unit -->
            <div class="row about-wrap">
                <div class="col-md-8 xs-padding">
                    <div class="about-content">
                        <p class="act-heading">Establishment of Puffed Rice Unit</p>
                        <p>A puffed rice unit was established in Sripura village during month of July 2023. As of now this unit is running successfully in this village. Total 5040 kg’s of puffed rice was produced from this unit which sold value around Rs. 3,27,600 and profit earned from this unit was Rs. 1,60, 684.00. Again from another unit from Lapanga village is going on. Smt Nitu Paule of Pragati SHG set up a puffed rice unit in her village. From Second unit total 1500 puffed rice was produced and sold amount was Rs. 92,600 and the profit came from this unit was Rs. 49,000/-
                        </p>
                    </div>
                </div>
                <div class="col-md-4 xs-padding">
                    <img src="img/activities/puffed.jpg">
                </div>
            </div>

            <!-- Floriculture Activity -->
            <div class="row about-wrap">
                <div class="col-md-4 xs-padding">
                    <img src="img/activities/marigold.jpg">
                </div>
                <div class="col-md-8 xs-padding">
                    <div class="about-content">
                        <p class="act-heading">Marigold Promotion Under Floriculture Activity</p>
                        <p>During the month of August 2023, we have distributed 5000 s eedlings to 45 farmers. Then in the 3rd Week of October 2024 the production of marigold flower stared . The Income of marigold flower is reached in the month of March 2024 is Rs. 1,53,760.00
                        </p>
                    </div>
                </div>
            </div>

            <!-- Goat Rearing Activity -->
            <div class="row about-wrap">
                <div class="col-md-8 xs-padding">
                    <div class="about-content">
                        <p class="act-heading">Goat Rearing Activity</p>
                        <p>During the month of August 2023, we have distributed 5000 s eedlings to 45 farmers. Then in the 3rd Week of October 2024 the production of marigold flower stared . The Income of marigold flower is reached in the month of March 2024 is Rs. 1,53,760.00
                        </p>
                    </div>
                </div>
                <div class="col-md-4 xs-padding">
                    <img src="img\activities\goat.jpg">
                </div>
            </div>

            <!-- Cotton Wicks Activity -->
            <div class="row about-wrap">
                <div class="col-md-4 xs-padding">
                    <img src="img\activities\cotton.jpg">
                </div>
                <div class="col-md-8 xs-padding">
                    <div class="about-content">
                        <p class="act-heading">Cotton Wicks Activity</p>
                        <p>Under this activity we have supplied 200 kg’s raw cotton to 16 beneficiary and also provided a training programme to them for preparation different types of cotton wicks which is normally used in temples. Hence Cumulative Sale of Cotton wick reached to 3,84,000/-.
                        </p>
                    </div>
                </div>
            </div>

            <!-- Dairy Development -->
            <div class="row about-wrap">
                <div class="col-md-8 xs-padding">
                    <div class="about-content">
                        <p class="act-heading">Dairy Development</p>
                        <p>For this activity we have supplied dairy feed and milk storage cane (10 Liter capacity) for dairy farmers in this area. Around 30 farmers are received this support from Cooperative. The objective of this is to procure the dairy feed collectively which reduce the transportation and retail cost for farmers. Again we also given support linkage for vaccination through veterinary department Gov’t of Odisha.
                        </p>
                    </div>
                </div>
                <div class="col-md-4 xs-padding">
                    <img src="img/activities/dairy.jpg">
                </div>
            </div>

            <!-- Paper Plate Unit -->
            <div class="row about-wrap">
                <div class="col-md-4 xs-padding">
                    <img src="img\activities\paper.jpg">
                </div>
                <div class="col-md-8 xs-padding">
                    <div class="about-content">
                        <p class="act-heading">Paper Plate Unit</p>
                        <p>For this activity we have supplied dairy feed and milk storage cane 10 Based on market demand we set up 3 paper plate unit in this area in which total 30 members from 3 SHG’s were involved in this activity. Last year around Rs.5,60,000/- income came from these 3(three) units.
                        </p>
                    </div>
                </div>
                
            </div>
        </div>
    </section>
    <!-- /About Section -->



    <!-- Footer Section Start -->
    <?php include 'includes/footer.php'; ?>
    <!-- Footer Section End -->

    <!-- Scroll To Top Section Start -->
    <?php include 'includes/scroll.php'; ?>
    <!-- Scroll To Top Section End -->

    <!-- JS Section Start -->
    <?php include 'includes/js.php'; ?>
    <!-- JS Section End -->
</body>

</html>