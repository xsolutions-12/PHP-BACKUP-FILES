<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="en"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="">
        <meta name="author" content="DynamicLayers">
       
        <title>Events FY 2024-25 || SSBM</title>
        
		<!-- CSS Start -->
         <?php include 'includes/css.php';?>
        <!-- CSS End -->
    </head>
    <body>
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
        
        <div class="site-preloader-wrap">
            <div class="spinner"></div>
        </div><!-- Preloader -->
        
        <!-- Header Section Start -->
        <?php include 'includes/header.php';?>
        <!-- Header Section End -->
                
        <div class="pager-header" style="background-image: url(img/banner/banner-1.png);">
            <div class="container">
                <div class="page-content">
                    <h2>Events FY 2024-25</h2>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                        <li class="breadcrumb-item active">Events FY 2024-25</li>
                    </ol>
                </div>
            </div>
        </div><!-- /Page Header -->
        
        <!-- Accordion -->
        <section class="accordion-section">
            <div class="container">
                <div class="accordion" id="myAccordion">
                    <div class="acc-item">
                        <button class="acc-header" aria-expanded="false">
                            <span>Annual General Body meeting</span>
                            <span class="acc-icon"><i class="fa fa-angle-double-right"></i></span>
                        </button>
                        <div class="acc-panel" aria-hidden="true">
                            <div class="acc-panel-inner content-side image-left">
                                <div class="text-side"><p>The first Annual General Body meeting conducted by Shree Shakti Co-Operative on dt. 26.07.2024 at Community Hall, Sripura. More than 100 general body members from different villages participated to give their view in major decision-making process of Co-operative and the main objective to conduct this program to aware all members about AGBM and its importance. Mr. Vishal Raj, Head CSR Dept JSW, Dr. Puspashree Naik, DPM -OLM, Mr Ajit Bagarty, ARCS Sambalpur and Mr Sushil Mishra from DRCS office invited as guest of honor. All the guest are focused on the sustainability of institution through collective effort.</p></div>
                                <div class="image-side" style="flex: 0 0 20%;"><img src="img/events/24-25/annual.jpg" alt="Annual"></div>
                            </div>
                        </div>
                    </div>

                    <div class="acc-item">
                        <button class="acc-header" aria-expanded="false">
                            <span>Distribution of Sambalpuri Saree Making Machine</span>
                            <span class="acc-icon"><i class="fa fa-angle-double-right"></i></span>
                        </button>
                        <div class="acc-panel" aria-hidden="true">
                            <div class="acc-panel-inner content-side image-right">
                                <div class="text-side"><p>With the support of AKANKHYA ladies club and JSW Foundation , distribution of weaving machine was done during the month November 2024. The basic target is to establish sambaluri saree manufacturing unit at Banjiberna village.</p></div>
                                <div class="image-side" style="flex: 0 0 10%;"><img src="img/events/24-25/sambalpuri.jpg" alt="Awareness Program"></div>
                            </div>
                        </div>
                    </div>

                    <div class="acc-item">
                        <button class="acc-header" aria-expanded="false">
                            <span>Impact of Training on Sambalpuri Saree making for Weaver Activity</span>
                            <span class="acc-icon"><i class="fa fa-angle-double-right"></i></span>
                        </button>
                        <div class="acc-panel" aria-hidden="true">
                            <div class="acc-panel-inner content-side image-left">
                                <div class="text-side"><p>With support from JSW Foundation , there is a samablpuri saree  making training programme initiated at BANJIBERNA village from LAPANGA GP for weaver communities. The training programme was begun from The December 2024 and it will continue upto March 2025. Duration of training programme will be 40 days by resourceful trainer. The focus of Training will be given on BANDHA Design to Saree Making. <br><br>Distribution of Cotton roll machine, Cotton Binding Machine and Saree making machine (looms) done by JSW Project and Akankhya Ladies Club.</p></div>
                                <div class="image-side" style="flex: 0 0 15%;"><img src="img/events/24-25/impact-samb1.jpg" alt="Milk Cane"></div>
                            </div>
                        </div>
                    </div>

                    <div class="acc-item">
                        <button class="acc-header" aria-expanded="false">
                            <span>D. DULLDULLI and LOKAMAHOSAV at Sambalpur and Jharsuguda</span>
                            <span class="acc-icon"><i class="fa fa-angle-double-right"></i></span>
                        </button>
                        <div class="acc-panel" aria-hidden="true">
                            <div class="acc-panel-inner content-side image-right">
                                <div class="text-side"><p>Lok Mohotsav is the district level annual festival cum exhibition hosted by district administration of Sambalpur and Jharsuguda. Event was organized from 1st Jan 2025 to 5th Jan 2025 in Jharsuguda whereas from 4th Jan to 12th Jan at PHD ground Sambalpur. Unlike every year Access Development Services participated in this event and displayed its rural items from our Women entrepreneurship Program. Amounting of Rs 1,20,000 sold during these days. Mr. Srimanta Hota, CEO ORMAS, Mr. Vishal Raj Head CSR dept. JSW, Mr. Bikash Mohanty APD Livelihood from DRDA, Mr. Sushil Mishra from DRCS office among the major persons visited our stalls and appreciate the efforts of members. Mr. Tankadhar Tripathy MLA, Jharsuguda purchase cloth material from ADS Stall was a great accomplishment. Our members also participated in “Makar Mohatsav” at Bamra (Rengali Block, Sambalpur) and display their items in festival.</p></div>
                                <div class="image-side" style="flex: 0 0 15%;"><img src="img/events/24-25/dulduli.jpg" alt="Awareness Program"></div>
                            </div>
                        </div>
                    </div>

                    <div class="acc-item">
                        <button class="acc-header" aria-expanded="false">
                            <span>Milan Mela (Fair)</span>
                            <span class="acc-icon"><i class="fa fa-angle-double-right"></i></span>
                        </button>
                        <div class="acc-panel" aria-hidden="true">
                            <div class="acc-panel-inner content-side image-left">
                                <div class="text-side"><p>A mela was organized by JSW Sambalpur, inside JSW Township. Where different SHG products like dry snacks, pickle, Sambalpuri sarees, etc.  were displayed. Mrs. Kiran Singh, President Akshyankya Ladies Club along with Mr. Vishal Raj, Head CSR Dept presented and encourages members from Shree Shakti Co-Operative.</p></div>
                                <div class="image-side" style="flex: 0 0 15%;"><img src="img/events/24-25/milan.jpg" alt="Milk Cane"></div>
                            </div>
                        </div>
                    </div>

                    <div class="acc-item">
                        <button class="acc-header" aria-expanded="false">
                            <span>Distribution of Fish Vending material</span>
                            <span class="acc-icon"><i class="fa fa-angle-double-right"></i></span>
                        </button>
                        <div class="acc-panel" aria-hidden="true">
                            <div class="acc-panel-inner content-side image-right">
                                <div class="text-side"><p>During Fy 2024-25 We had identified and listed eight nos. of Fish vending members from our different project villages whose primary source of income is fish vending. It was decided to provided them a garden umbrella with weighting machine and an Icebox. To maintain the quality of perishable food stuff and save the vending members from daily losses these small initiatives will play a major role.</p></div>
                                <div class="image-side" style="flex: 0 0 15%;"><img src="img/events/24-25/fish-vending.jpg" alt="Awareness Program"></div>
                            </div>
                        </div>
                    </div>

                    <div class="acc-item">
                        <button class="acc-header" aria-expanded="false">
                            <span>Stake Holder Meeting</span>
                            <span class="acc-icon"><i class="fa fa-angle-double-right"></i></span>
                        </button>
                        <div class="acc-panel" aria-hidden="true">
                            <div class="acc-panel-inner content-side image-left">
                                <div class="text-side"><p>During the financial Year 2024-25 we had organized a stake holder meeting at our office premises. Mr. Sushil Mishra, DRCS office, Mr. Ajit Bagarty ARCS Sambalpur Circle, Mr. Vishal Raj Head CSR Dept presented during the program. During Program Shree Shakti Co-Op celebrated her one year of Successful journey. A booklet on champions farmers shown and inaugurated to all members.</p></div>
                                <div class="image-side" style="flex: 0 0 15%;"><img src="img/events/24-25/stake.jpg" alt="Awareness Program"></div>
                            </div>
                        </div>
                    </div>

                    <div class="acc-item">
                        <button class="acc-header" aria-expanded="false">
                            <span>Buyer Seller Meeting</span>
                            <span class="acc-icon"><i class="fa fa-angle-double-right"></i></span>
                        </button>
                        <div class="acc-panel" aria-hidden="true">
                            <div class="acc-panel-inner content-side image-right">
                                <div class="text-side"><p>During this financial year 24-25 we have participated in buyer and Seller meet organized by ORMAS dept. Sambalpur. To create a platform to sell rural product and overcome all obstacles was the main agenda for the meeting.</p></div>
                                <div class="image-side" style="flex: 0 0 15%;"><img src="img/events/24-25/buyer.jpg" alt="Milk Cane"></div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </section>

        <!-- Footer Section Start -->
        <?php include 'includes/footer.php';?>
        <!-- Footer Section End -->
        
        <!-- Scroll To Top Section Start -->
		<?php include 'includes/scroll.php';?>
        <!-- Scroll To Top Section End -->
	
        <!-- JS Section Start -->
        <?php include 'includes/js.php';?>
        <!-- JS Section End -->
</body>
</html>