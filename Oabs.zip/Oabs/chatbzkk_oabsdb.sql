-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 22, 2025 at 04:59 PM
-- Server version: 5.7.23-23
-- PHP Version: 8.1.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `chatbzkk_oabsdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `acknwldge`
--

CREATE TABLE `acknwldge` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `type` varchar(10) NOT NULL,
  `req_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `acknwldge`
--

INSERT INTO `acknwldge` (`id`, `name`, `address`, `phone`, `type`, `req_id`) VALUES
(1, 'Sai Medicals', 'Patia Square', '7799885533', 'Store', 0),
(2, 'Sai Medicals', 'Patia Square', '7799885533', 'Store', 0),
(3, 'Sai Medicals', 'Patia Square', '7799885533', 'Store', 0),
(4, 'Sai Medicals', 'Patia Square', '7799885533', 'Store', 17),
(5, 'Sai Medicals', 'Patia Square', '7799885533', 'Store', 18),
(6, 'Sai Medicals', 'Patia Square', '7799885533', 'Store', 17),
(7, 'Sai Medicals', 'Patia Square', '7799885533', 'Store', 18),
(8, 'Sai Medicals', 'Patia Square', '7799885533', 'Store', 19),
(9, 'Sai Medicals', 'Patia Square', '7799885533', 'Store', 17),
(10, 'Sai Medicals', 'Patia Square', '7799885533', 'Store', 18),
(11, 'Sai Medicals', 'Patia Square', '7799885533', 'Store', 19),
(12, 'Sai Medicals', 'Patia Square', '7799885533', 'Store', 25),
(13, 'Sai Medicals', 'Patia Square', '7799885533', 'Store', 27),
(14, 'Sai Medicals', 'Patia Square', '7799885533', 'Store', 22),
(15, 'Sai Medicals', 'Patia Square', '7799885533', 'Store', 22),
(16, 'Sai Medicals', 'Patia Square', '7799885533', 'Store', 23),
(17, 'Sai Medicals', 'Patia Square', '7799885533', 'Store', 24),
(18, 'Sai Medicals', 'Patia Square', '7799885533', 'Store', 27),
(19, 'Sai Medicals', 'Patia Square', '7799885533', 'Store', 22),
(20, 'Sai Medicals', 'Patia Square', '7799885533', 'Store', 22),
(21, 'Sai Medicals', 'Patia Square', '7799885533', 'Store', 24),
(22, 'Sai Medicals', 'Patia Square', '7799885533', 'Store', 22),
(23, 'Sai Medicals', 'Patia Square', '7799885533', 'Store', 22),
(24, 'Sai Medicals', 'Patia Square', '7799885533', 'Store', 22),
(25, 'Sai Medicals', 'Patia Square', '7799885533', 'Store', 23);

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `UserName` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `updationDate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `UserName`, `Password`, `updationDate`) VALUES
(1, 'admin', '5c428d8875d2948607f3e3fe134d71b4', '2017-06-18 12:22:38');

-- --------------------------------------------------------

--
-- Table structure for table `blooddetails`
--

CREATE TABLE `blooddetails` (
  `id` int(11) NOT NULL,
  `BloodGroup` varchar(20) DEFAULT NULL,
  `PriceperBottle` varchar(22) DEFAULT NULL,
  `PostingDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blooddetails`
--

INSERT INTO `blooddetails` (`id`, `BloodGroup`, `PriceperBottle`, `PostingDate`) VALUES
(1, 'A-', '', '2017-06-30 20:33:50'),
(2, 'AB-', NULL, '2017-06-30 20:34:00'),
(3, 'O-', '', '2017-06-30 20:34:05'),
(5, 'A+', NULL, '2017-06-30 20:34:13'),
(6, 'AB+', '', '2017-06-30 20:34:18');

-- --------------------------------------------------------

--
-- Table structure for table `branch`
--

CREATE TABLE `branch` (
  `Id` int(11) NOT NULL,
  `OrganisationId` varchar(20) DEFAULT NULL,
  `BranchName` varchar(300) DEFAULT NULL,
  `StoreName` varchar(300) DEFAULT NULL,
  `StoreAddress` varchar(50) NOT NULL,
  `Password` varchar(100) DEFAULT NULL,
  `Address` varchar(200) DEFAULT NULL,
  `area` varchar(50) NOT NULL,
  `Email` varchar(30) DEFAULT NULL,
  `Mobile` varchar(20) DEFAULT NULL,
  `IsActive` int(11) DEFAULT '0',
  `IsDelete` int(11) NOT NULL DEFAULT '0',
  `EntryBy` varchar(20) DEFAULT NULL,
  `EntryOn` varchar(20) DEFAULT NULL,
  `blood_quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `branch`
--

INSERT INTO `branch` (`Id`, `OrganisationId`, `BranchName`, `StoreName`, `StoreAddress`, `Password`, `Address`, `area`, `Email`, `Mobile`, `IsActive`, `IsDelete`, `EntryBy`, `EntryOn`, `blood_quantity`) VALUES
(1, 'ABC123EFG', 'Sai Medicals', 'Sai Medicals', 'Patia Square', 'ceb6c970658f31504a901b89dcd3e461', 'Patia Square', '', 'saimedicals@gmail.com', '7799885533', 1, 0, 'admin', '01-10-2019', 17),
(2, 'AEW111EW', 'New Test Branch', '', '', 'ceb6c970658f31504a901b89dcd3e461', 'New Place', '', 'new@gmail.com', '08338004423', 1, 0, 'admin', '01-10-2019', 0);

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `Id` int(11) NOT NULL,
  `Name` varchar(50) DEFAULT NULL,
  `OrderId` int(20) DEFAULT NULL,
  `IconName` varchar(200) DEFAULT NULL,
  `IsActive` int(11) NOT NULL DEFAULT '0',
  `IsDelete` int(11) NOT NULL DEFAULT '0',
  `EntryBy` varchar(50) DEFAULT NULL,
  `EntryOn` varchar(20) DEFAULT NULL,
  `UpdateBy` varchar(20) DEFAULT NULL,
  `UpdateOn` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`Id`, `Name`, `OrderId`, `IconName`, `IsActive`, `IsDelete`, `EntryBy`, `EntryOn`, `UpdateBy`, `UpdateOn`) VALUES
(1, 'Blood Group', 1, 'fa fa-address-book-o', 0, 0, 'admin', '18-09-2019', NULL, NULL),
(2, 'Request Blood', 2, 'fa fa-address-book-o', 0, 0, 'admin', '19-09-2019', NULL, NULL),
(3, 'dfyt', 2, 'ty', 0, 0, 'admin', '19-09-2019', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE `role` (
  `Id` int(11) NOT NULL,
  `Name` varchar(50) DEFAULT NULL,
  `Role` varchar(50) DEFAULT NULL,
  `IsActive` int(11) NOT NULL DEFAULT '0',
  `IsDelete` int(11) NOT NULL DEFAULT '0',
  `EntryBy` varchar(50) DEFAULT NULL,
  `EntryOn` varchar(20) DEFAULT NULL,
  `UpdateBy` varchar(50) DEFAULT NULL,
  `UpdateOn` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`Id`, `Name`, `Role`, `IsActive`, `IsDelete`, `EntryBy`, `EntryOn`, `UpdateBy`, `UpdateOn`) VALUES
(1, 'Admin', 'Admin', 0, 0, 'admin', '18-09-2019', NULL, NULL),
(2, 'User', 'User', 0, 0, 'admin', '18-09-2019', NULL, NULL),
(3, 'Company1', 'Company', 0, 0, 'admin', '01-01-2002', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `setting`
--

CREATE TABLE `setting` (
  `id` int(11) NOT NULL,
  `CompanyName` varchar(200) NOT NULL,
  `Address` tinytext,
  `EmailId` varchar(255) DEFAULT NULL,
  `ContactNo` char(11) DEFAULT NULL,
  `AdminUrl` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `setting`
--

INSERT INTO `setting` (`id`, `CompanyName`, `Address`, `EmailId`, `ContactNo`, `AdminUrl`) VALUES
(1, 'BloodBank & Donor Management System', 'Test Demo test demo test																									', 'test@test.com', '8585233222', 'http://localhost/bloodbank');

-- --------------------------------------------------------

--
-- Table structure for table `store`
--

CREATE TABLE `store` (
  `id` int(11) NOT NULL,
  `StoreName` varchar(100) NOT NULL,
  `StoreAddress` varchar(100) NOT NULL,
  `OrganisationId` varchar(50) NOT NULL,
  `contact_number` varchar(50) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `store`
--

INSERT INTO `store` (`id`, `StoreName`, `StoreAddress`, `OrganisationId`, `contact_number`, `status`) VALUES
(1, 'Sai Medicals', 'Patia Square', 'ABC123EFG', '7799885533', 1),
(2, 'Santoshi Medicals', 'Damana Square', 'ABC123EFG', '7799885533', 1),
(3, 'Sri Store', 'Jayadev Vihar', 'ABC123EFG', '7722998833', 1);

-- --------------------------------------------------------

--
-- Table structure for table `submenu`
--

CREATE TABLE `submenu` (
  `Id` int(11) NOT NULL,
  `Name` varchar(50) DEFAULT NULL,
  `MenuId` int(20) DEFAULT NULL,
  `PageUrl` varchar(50) DEFAULT NULL,
  `OrderId` int(20) DEFAULT NULL,
  `IsActive` int(11) NOT NULL DEFAULT '0',
  `IsDelete` int(11) NOT NULL DEFAULT '0',
  `EntryBy` varchar(30) DEFAULT NULL,
  `EntryOn` varchar(20) DEFAULT NULL,
  `UpdateBy` varchar(20) DEFAULT NULL,
  `UpdateOn` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `submenu`
--

INSERT INTO `submenu` (`Id`, `Name`, `MenuId`, `PageUrl`, `OrderId`, `IsActive`, `IsDelete`, `EntryBy`, `EntryOn`, `UpdateBy`, `UpdateOn`) VALUES
(1, 'Add Blood Group', NULL, 'BloodGroup.php', NULL, 0, 0, 'admin', '19-09-2019', NULL, NULL),
(2, 'Add Blood Group', NULL, 'BloodGroup.php', NULL, 0, 0, 'admin', '19-09-2019', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblblooddonars`
--

CREATE TABLE `tblblooddonars` (
  `id` int(11) NOT NULL,
  `FullName` varchar(100) DEFAULT NULL,
  `MobileNumber` char(11) DEFAULT NULL,
  `EmailId` varchar(100) DEFAULT NULL,
  `Gender` varchar(20) DEFAULT NULL,
  `dob` varchar(10) NOT NULL,
  `last_donate` varchar(10) NOT NULL,
  `Age` int(11) DEFAULT NULL,
  `BloodGroup` varchar(20) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `state` varchar(50) NOT NULL,
  `district` varchar(50) NOT NULL,
  `block` varchar(50) NOT NULL,
  `panchayat` varchar(50) NOT NULL,
  `village` varchar(50) NOT NULL,
  `donorarea` varchar(50) NOT NULL,
  `donor_store` varchar(50) NOT NULL,
  `handicap` varchar(10) NOT NULL,
  `PostingDate` varchar(50) NOT NULL,
  `branch-code` varchar(50) NOT NULL,
  `status` int(1) DEFAULT NULL,
  `donate_when_required` varchar(10) NOT NULL COMMENT 'Yes , No',
  `receipt` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblblooddonars`
--

INSERT INTO `tblblooddonars` (`id`, `FullName`, `MobileNumber`, `EmailId`, `Gender`, `dob`, `last_donate`, `Age`, `BloodGroup`, `Address`, `state`, `district`, `block`, `panchayat`, `village`, `donorarea`, `donor_store`, `handicap`, `PostingDate`, `branch-code`, `status`, `donate_when_required`, `receipt`) VALUES
(2, 'Abhisek', '7788888893', 'abhi@gmail.com', 'Male', '05/31/2019', '', 26, 'A+', 'Bhubaneswar', '', '', '', '', '', ' Patia Square', '', 'No', '01-10-2019', 'ABC123EFG', 0, '', ''),
(3, 'Rabindra kumar rashmi ranjan sahoo', '09958375927', 'saumya@gmail.com', 'Male', '05/14/2019', '', 26, 'A+', 'bbsr', '', '', '', '', '', 'Damana Square', '', 'No', '01-10-2019', 'ABC123EFG', 0, '', ''),
(4, 'Rabindra kumar rashmi ranjan sahoo', '09958375927', 'saumya@gmail.com', 'Male', '2019-10-31', '', 26, 'A+', 'cuttack', '', '', '', '', '', ' Jayadev Vihar', '', 'No', '01-10-2019', 'ABC123EFG', 0, '', ''),
(5, 'Rabindra kumar rashmi ranjan sahoo', '09958375927', 'saumya@gmail.com', 'Male', '2019-10-08', '', 21, 'A+', 'cuttack', '', '', '', '', '', ' Patia Square', '', 'Yes', '01-10-2019', 'ABC123EFG', 0, '', ''),
(6, 'Abhisek', '56456', 'a@gmail.com', 'Male', '2019-10-09', '', 23, 'A+', 'sds', '', '', '', '', '', ' Patia Square', '', 'Yes', '02-10-2019', 'ABC123EFG', 0, 'Yes', ''),
(7, 'Abhisek', '56456415615', 'a@gmail.com', 'Male', '2019-10-16', '', 23, 'A+', 'sds', '', '', '', '', '', ' Jayadev Vihar', '', 'Yes', '02-10-2019', 'ABC123EFG', 0, 'Yes', ''),
(8, 'Sam', '455651', 'a@gmail.com', 'Male', '2019-10-16', '', 23, 'A+', 'sds', '', '', '', '', '', ' Patia Square', '', 'Yes', '02-10-2019', 'ABC123EFG', 0, 'Yes', ''),
(9, 'Sammy', '7864893451', 'sam@gmail.com', 'Male', '2018-02-06', '', 2, 'O', 'BBsr', '', '', '', '', '', ' Damana Square', '', 'No', '02-10-2019', 'ABC123EFG', 0, 'No', ''),
(10, 'Abhisek', '546', 'a@gmail.com', 'Male', '2019-10-02', '', 23, 'A+', 'sds', '', '', '', '', '', ' Patia Square', '', 'Yes', '02-10-2019', 'ABC123EFG', 0, 'Yes', ''),
(11, 'Abhisek', '45654', 'a@gmail.com', 'Male', '2019-10-02', '', 23, 'A+', 'sds', '', '', '', '', '', ' Patia Square', '', 'Yes', '02-10-2019', 'ABC123EFG', 1, 'Yes', ''),
(12, 'Abhisek', '5654654', 'a@gmail.com', 'Male', '2019-10-02', '', 23, 'A+', 'sds', '', '', '', '', '', ' Patia Square', '', 'Yes', '02-10-2019', 'ABC123EFG', 0, 'Yes', ''),
(13, 'Abhisek', '546354', 'ABC123EFG@gmail.com', 'Male', '2019-10-02', '', 23, 'A+', 'asdas', 'a', 'ad', 'asdas', 'asdas', 'asdas', ' Damana Square', 'Santoshi Medicals ', 'No', '05-10-2019', 'ABC123EFG', 0, 'No', ''),
(14, 'Rabindra', '4759631548', 'a@gmail.com', 'Male', '2019-10-03', 'last_donat', 23, 'A+', 'sds', 'odisha', 'xfdcg', 'fgdfg', 'dfgdf', 'dfgfdg', ' Jayadev Vihar', 'Sri Store ', 'No', '05-10-2019', 'ABC123EFG', 1, 'Yes', ''),
(15, 'Sam', '07845965874', 'sam@gmail.com', 'Male', '2019-10-01', '2019-10-03', 23, 'AB+', 'sds', 'odisha', 'xfdcg', 'fgdfg', 'dfgdf', 'dfgfdg', ' Damana Square', 'Santoshi Medicals ', 'Yes', '05-10-2019', 'ABC123EFG', 1, 'No', ''),
(16, 'Aliean Singh', '77112233996', 'aliean@gmail.com', 'Other', '2020-02-28', '2020-02-04', 28, 'AB-', 'dsfffgdfgfd', 'Oddisha', 'New Dist', 'aedrt', 'dsfdf', 'fdgdfgdfg', ' Jayadev Vihar', 'Sri Store ', 'No', '28-02-2020', 'ABC123EFG', 0, 'Yes', ''),
(17, 'Abhisek Pandey', '7788888893', 'abhisek@xsolutions.co.in', 'Male', '2020-02-06', '2020-02-28', 29, 'A+', 'CDA', 'Odisha', 'Cuttack', 'Markat nagar', 'CDA', 'CDA', ' Damana Square', 'Santoshi Medicals ', 'No', '28-02-2020', 'ABC123EFG', 0, 'No', ''),
(18, 'Abhisek Xsolutions', '7766998822', 'abhisek@xsolutions.co.in', 'Male', '2020-02-14', '2020-02-11', 23, 'A+', 'sdghfgvbhjbvfds', 'Odisha', 'sdfsdf', 'sdfsdf', 'CDA', 'CDA', ' Damana Square', 'Santoshi Medicals ', 'No', '28-02-2020', 'ABC123EFG', 0, 'Yes', ''),
(19, 'Abhisek Xsolutions', '07766998822', 'abhisek@xsolutions.co.in', 'Male', '2020-02-18', '2020-02-04', 23, 'A-', 'sdghfgvbhjbvfds', 'Odisha', 'dfgd', 'gdfgdfg', 'dfgdg', 'dfgdfgdf', ' Damana Square', 'Santoshi Medicals ', 'Yes', '28-02-2020', 'ABC123EFG', 0, 'No', ''),
(20, 'Abhisek Xsolutions', '07766998822', 'abhisek@xsolutions.co.in', 'Male', '2020-02-04', '2020-02-11', 34, 'A-', 'sdghfgvbhjbvfds', 'Odisha', 'fdg', 'gdfg', 'fdgdf', 'dfgdfgdfg', ' Patia Square', 'Sai Medicals ', 'Yes', '28-02-2020', 'ABC123EFG', 1, 'Yes', 'Abhisek Xsolutions-28-02-2020-11-20-01 am.pdf'),
(21, 'Abhisek Xsolutions', '07766998822', 'abhisek@xsolutions.co.in', 'Male', '2020-02-04', '2020-02-11', 34, 'A-', 'sdghfgvbhjbvfds', 'Odisha', 'fdg', 'gdfg', 'fdgdf', 'dfgdfgdfg', ' Patia Square', 'Sai Medicals ', 'Yes', '28-02-2020', 'ABC123EFG', 1, 'Yes', 'Abhisek Xsolutions-28-02-2020-11-21-15 am.pdf'),
(22, 'Abhisek Xsolutions', '07766998822', 'abhisek@xsolutions.co.in', 'Male', '2020-02-02', '2020-02-11', 23, 'A-', 'sdghfgvbhjbvfds', 'Odisha', 'sdfsdf', 'dsfsdf', 'dsfsdfsd', 'sdfsdfsf', ' Patia Square', 'Sai Medicals ', 'Yes', '28-02-2020', 'ABC123EFG', 1, 'Yes', 'Abhisek Xsolutions-28-02-2020-12-19-07 pm.pdf'),
(23, 'Partha(Testing)', '7894341937', 'parthamohanty@xsolutions.co.in', 'Male', '2021-09-07', '2021-09-16', 26, 'AB-', 'BBSR', 'Odisha', 'Khordha', 'NA', 'NA', 'NA', ' Patia Square', 'Sai Medicals ', 'No', '15-09-2021', 'ABC123EFG', 1, 'Yes', ''),
(24, 'Partha(Testing)', '7894341937', 'parthamohanty@xsolutions.co.in', 'Male', '2021-09-07', '2021-09-16', 26, 'AB-', 'BBSR', 'Odisha', 'Khordha', 'NA', 'NA', 'NA', ' Patia Square', 'Sai Medicals ', 'No', '15-09-2021', 'ABC123EFG', 1, 'Yes', ''),
(25, 'Partha(Testing)', '7894341937', 'parthamohanty@xsolutions.co.in', 'Male', '2021-09-07', '2021-09-16', 26, 'AB-', 'BBSR', 'Odisha', 'Khordha', 'NA', 'NA', 'NA', ' Patia Square', 'Sai Medicals ', 'No', '15-09-2021', 'ABC123EFG', 1, 'Yes', ''),
(26, 'Partha(Testing)', '7894341937', 'parthamohanty@xsolutions.co.in', 'Male', '2021-09-07', '2021-09-16', 26, 'AB-', 'BBSR', 'Odisha', 'Khordha', 'NA', 'NA', 'NA', ' Patia Square', 'Sai Medicals ', 'No', '15-09-2021', 'ABC123EFG', 1, 'Yes', ''),
(27, 'Partha(Testing)', '7894341937', 'parthamohanty@xsolutions.co.in', 'Male', '2021-09-07', '2021-09-16', 26, 'AB-', 'BBSR', 'Odisha', 'Khordha', 'NA', 'NA', 'NA', ' Patia Square', 'Sai Medicals ', 'No', '15-09-2021', 'ABC123EFG', 1, 'Yes', ''),
(28, 'Partha(Testing)', '1472583695', 'parthamohanty@xsolutions.co.in', 'Male', '2021-09-08', '2021-09-16', 26, 'A-', 'BBSR', 'Odisha', 'Khordha', 'NA', 'NA', 'NA', ' Area', 'Select Store Name ', 'No', '15-09-2021', '', 1, 'Yes', ''),
(29, 'Partha(Testing)0', '4152415759', 'parthamohanty@xsolutions.co.in', 'Male', '2021-09-01', '2021-09-01', 26, 'A+', 'BBSR', 'Odisha', 'Khordha', 'NA', 'NA', 'NA', ' Area', 'Select Store Name ', 'Yes', '15-09-2021', '', 1, 'Yes', ''),
(30, 'Partha(Testing)', '7487584587', 'parthamohanty@xsolutions.co.in', 'Male', '2021-09-08', '2021-09-23', 26, 'AB-', 'BBSR', 'Odisha', 'Khordha', 'NA', 'NA', 'NA', ' Area', 'Select Store Name ', 'No', '15-09-2021', '', 1, 'Yes', ''),
(31, 'xyz', '4785859658', 'parthamohanty@xsolutions.co.in', 'Male', '2021-09-08', '2021-09-02', 26, 'A-', 'BBSR', 'Odisha', 'Khordha', 'NA', 'NA', 'NA', ' Patia Square', 'Sai Medicals ', 'No', '15-09-2021', 'ABC123EFG', 1, 'Yes', ''),
(32, 'xyz', '7457854589', 'parthamohanty@xsolutions.co.in', 'Male', '2021-09-14', '2021-09-16', 26, 'A-', 'BBSR', 'Odisha', 'Khordha', 'NA', 'NA', 'NA', ' Damana Square', 'Santoshi Medicals ', 'No', '15-09-2021', 'ABC123EFG', 1, 'Yes', ''),
(33, 'xyz', '7458569856', 'parthamohanty@xsolutions.co.in', 'Male', '2021-09-01', '2021-09-17', 26, 'AB-', 'BBSR', 'Odisha', 'Khordha', 'NA', 'NA', 'NA', ' Damana Square', 'Santoshi Medicals ', 'No', '15-09-2021', 'ABC123EFG', 1, 'Yes', ''),
(34, 'dfdf', '1234567894', 'parthamohanty@xsolutions.co.in', 'Male', '2021-09-02', '2021-09-04', 26, 'O-', 'BBSR', 'Odisha', 'Khordha', 'NA', 'NA', 'NA', ' Patia Square', 'Sai Medicals ', 'No', '15-09-2021', 'ABC123EFG', 1, 'Yes', ''),
(35, 'rryry', '4758684578', 'partha@xsolutions.co.in', 'Male', '2021-09-07', '2021-09-17', 26, 'O-', 'BBSR', 'Odisha', 'Khordha', 'NA', 'NA', 'NA', ' Patia Square', 'Sai Medicals ', 'No', '16-09-2021', 'ABC123EFG', 1, 'Yes', ''),
(36, 'rtrtrt', '7414574587', 'partha@xsolutions.co.in', 'Male', '2021-09-04', '2021-09-17', 26, 'AB-', 'BBSR', 'Odisha', 'Khordha', 'NA', 'NA', 'NA', ' Patia Square', 'Sai Medicals ', 'No', '16-09-2021', 'ABC123EFG', 1, 'Yes', '');

-- --------------------------------------------------------

--
-- Table structure for table `tblbloodrequest`
--

CREATE TABLE `tblbloodrequest` (
  `id` int(11) NOT NULL,
  `FullName` varchar(100) DEFAULT NULL,
  `MobileNumber` char(11) DEFAULT NULL,
  `EmailId` varchar(100) DEFAULT NULL,
  `Gender` varchar(20) DEFAULT NULL,
  `Age` int(11) DEFAULT NULL,
  `BloodGroup` varchar(20) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `state` varchar(50) NOT NULL,
  `district` varchar(50) NOT NULL,
  `block` varchar(50) NOT NULL,
  `panchayat` varchar(50) NOT NULL,
  `village` varchar(50) NOT NULL,
  `requestarea` varchar(50) NOT NULL,
  `bloodrecvdate` varchar(10) DEFAULT NULL,
  `PostingDate` varchar(50) NOT NULL,
  `dob` varchar(10) NOT NULL,
  `Physicayhandicap` varchar(5) NOT NULL,
  `status` int(1) DEFAULT NULL COMMENT '0 close, 1 Required, 2 Pending',
  `request_area_id` varchar(50) NOT NULL,
  `store_request_id` varchar(10) NOT NULL,
  `ackn_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblbloodrequest`
--

INSERT INTO `tblbloodrequest` (`id`, `FullName`, `MobileNumber`, `EmailId`, `Gender`, `Age`, `BloodGroup`, `Address`, `state`, `district`, `block`, `panchayat`, `village`, `requestarea`, `bloodrecvdate`, `PostingDate`, `dob`, `Physicayhandicap`, `status`, `request_area_id`, `store_request_id`, `ackn_id`) VALUES
(1, 'Sam', '09958375927', 'saumya@gmail.com', 'Male', 26, 'A ', 'cuttack', '0', '0', '0', '', '', 'Patia Square', '2019-10-03', '01-10-2019', '1996-05-01', 'No', 0, 'ABC123EFG', '', 0),
(2, 'Rabindra kumar rashmi ranjan sahoo', '09958375927', 'saumya@gmail.com', 'Male', 26, 'A ', 'cuttack', '0', '0', '0', '', '', 'Damana Square', '2019-10-02', '01-10-2019', '2019-10-30', 'No', 0, 'ABC123EFG', '', 0),
(3, 'Rabindra kumar rashmi ranjan sahoo', '09958375927', 'saumya@gmail.com', 'Male', 26, 'A ', 'cuttack', '0', '0', '0', '', '', 'Damana Square', '2019-10-02', '01-10-2019', '2019-10-30', 'No', 0, 'ABC123EFG', '', 0),
(4, 'Rabindra kumar rashmi ranjan sahoo', '09958375927', 'saumya@gmail.com', 'Male', 26, 'A ', 'cuttack', '0', '0', '0', '', '', ' Jayadev Vihar', '2019-10-02', '02-10-2019', '2019-10-11', 'No', 0, 'ABC123EFG', '', 0),
(9, 'Abhisek', '52356', 'a@gmail.com', 'Male', 23, 'A ', 'sds', '0', '0', '0', '', '', 'Patia Square', '2019-10-01', '02-10-2019', '2019-10-05', 'No', 0, 'ABC123EFG', '5', 0),
(10, 'Abhisek', '5464', 'a@gmail.com', 'Male', 23, 'A ', 'sds', '0', '0', '0', '', '', ' Jayadev Vihar', '2019-10-29', '02-10-2019', '2019-10-03', 'No', 0, 'ABC123EFG', '7', 0),
(11, 'Ram', '54645', 'a@gmail.com', 'Male', 23, 'A ', 'sds', '0', '0', '0', '', '', ' Patia Square', '2019-10-02', '02-10-2019', '2019-10-01', 'No', 0, 'ABC123EFG', '8', 0),
(12, 'Raghav', '78548547858', 'rag@gmail.com', 'Male', 23, 'A ', 'Bbsr', '0', '0', '0', '', '', ' Patia Square', '2019-10-02', '02-10-2019', '1991-02-05', 'No', 0, 'ABC123EFG', '5', 0),
(13, 'Abhisek', '7412589637', 'a@gmail.com', 'Male', 23, 'O', 'sds', '0', '0', '0', '', '', ' Damana Square', '2019-10-02', '02-10-2019', '2019-10-03', 'No', 0, 'ABC123EFG', '9', 0),
(14, 'Abhisek', '8645645', 'a@gmail.com', 'Male', 23, 'A ', 'sds', '0', '0', '0', '', '', ' Patia Square', '2019-10-02', '02-10-2019', '2019-10-02', 'No', 0, 'ABC123EFG', '10', 0),
(15, 'Abhisek', '45645654', 'a@gmail.com', 'Male', 23, 'A ', 'sds', '0', '0', '0', '', '', ' Patia Square', '2019-10-03', '02-10-2019', '2019-10-02', 'No', 1, 'ABC123EFG', '12', 0),
(16, 'Abhisek', '56423132', 'a@gmail.com', 'Male', 23, 'A ', 'sds', '0', '0', '0', '', '', ' Damana Square', '2019-10-09', '09-10-2019', '2019-10-03', 'No', 0, 'ABC123EFG', '13', 0),
(17, 'Abhisek', '544545', 'a@gmail.com', 'Male', 23, 'A', 'sds', 'odisha', '', 'fgdfg', 'dfgdf', 'dfgfdg', 'gfyh', '2019-10-09', '09-10-2019', '2019-10-09', 'No', 1, '', '', 9),
(18, 'Abhisek', '453453543', 'a@gmail.com', 'Male', 23, 'A', 'sds', 'odisha', 'xfdcg', 'fgdfg', 'dfgdf', 'dfgfdg', 'fdhgdchg', '2019-10-09', '09-10-2019', '2019-10-09', 'No', 0, 'ABC123EFG', '13', 0),
(19, 'Abhisek', '453453543', 'a@gmail.com', 'Male', 23, 'A', 'sds', 'odisha', 'xfdcg', 'fgdfg', 'dfgdf', 'dfgfdg', 'fdhgdchg', '2019-10-09', '09-10-2019', '2019-10-09', 'No', 0, 'ABC123EFG', '13', 0),
(20, 'Abhisek', '536456465', 'a@gmail.com', 'Male', 23, 'A ', 'sds', 'odisha', 'xfdcg', 'fgdfg', 'dfgdf', 'dfgfdg', ' Damana Square', '2019-10-09', '09-10-2019', '2019-10-10', 'No', 0, 'ABC123EFG', '13', 0),
(21, 'Abhisek', '536456465', 'a@gmail.com', 'Male', 23, 'A ', 'sds', 'odisha', 'xfdcg', 'fgdfg', 'dfgdf', 'dfgfdg', ' Damana Square', '2019-10-09', '09-10-2019', '2019-10-10', 'No', 1, 'ABC123EFG', '17', 0),
(22, 'Abhisek Xsolutions', '07766998822', 'abhisek@xsolutions.co.in', 'Male', 23, 'A ', 'sdghfgvbhjbvfds', 'Odisha', 'tretrt', 'rft', 'ertertrt', 'retertrt', ' Patia Square', '2020-02-28', '27-02-2020', '2020-02-27', 'No', 1, 'ABC123EFG', '17', 24),
(23, 'Abhisek Xsolutions', '07766998822', 'abhisek@xsolutions.co.in', 'Male', 0, 'A ', 'sdghfgvbhjbvfds', 'Odisha', 'er', 'werwer', 'ewrwer', 'werwer', ' Damana Square', '2020-02-28', '28-02-2020', '2020-02-28', 'No', 1, 'ABC123EFG', '17', 25),
(24, 'sadasd', '07766998822', 'abhisek@xsolutions.co.in', 'Male', 33, 'AB-', 'sdghfgvbhjbvfds', 'Odisha', 'sadasd', 'dadsas', 'dasdasd', 'sadasdasd', ' Jayadev Vihar', '2020-02-28', '28-02-2020', '2020-02-28', 'No', 1, 'ABC123EFG', '17', 0),
(25, 'Abhisek Xsolutions', '07766998822', 'abhisek@xsolutions.co.in', 'Male', 32, 'A-', 'sdghfgvbhjbvfds', 'Odisha', 'dasd', 'sadas', 'asdasdasd', 'sdasdasd', ' Damana Square', '2020-02-25', '28-02-2020', '2020-02-19', 'No', 0, 'ABC123EFG', '17', 12),
(26, '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '28-02-2020', '', '', 1, '', '19', 0),
(27, 'Abhisek Xsolutions', '07766998822', 'abhisek@xsolutions.co.in', 'Male', 32, 'A ', 'sdghfgvbhjbvfds', 'Odisha', 'dfgdfg', 'dfgdfg', 'dfgdfg', 'fdgdfgdfg', ' Damana Square', '2020-02-28', '28-02-2020', '2020-02-20', 'No', 1, 'ABC123EFG', '17', 18),
(28, 'Partha(Testing)', '7894341937', 'parthamohanty@xsolutions.co.in', 'Male', 26, 'A ', 'BBSR', 'Odisha', 'Khordha', 'NA', 'NA', 'NA', ' Damana Square', '2021-09-17', '15-09-2021', '1995-06-26', 'No', 1, 'ABC123EFG', '18', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tblcontactusquery`
--

CREATE TABLE `tblcontactusquery` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `EmailId` varchar(120) DEFAULT NULL,
  `ContactNumber` char(11) DEFAULT NULL,
  `Message` longtext,
  `PostingDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblpages`
--

CREATE TABLE `tblpages` (
  `id` int(11) NOT NULL,
  `PageName` varchar(255) DEFAULT NULL,
  `type` varchar(255) NOT NULL DEFAULT '',
  `detail` longtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblpages`
--

INSERT INTO `tblpages` (`id`, `PageName`, `type`, `detail`) VALUES
(2, 'Why Become Donor', 'donor', '<span style=\"color: rgb(0, 0, 0); font-family: &quot;Open Sans&quot;, Arial, sans-serif; font-size: 14px; text-align: justify;\">At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat</span>'),
(3, 'About Us ', 'aboutus', '<span style=\"color: rgb(0, 0, 0); font-family: &quot;Open Sans&quot;, Arial, sans-serif; text-align: justify;\">At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat</span>');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `Id` int(11) NOT NULL,
  `OrganisationId` int(20) DEFAULT NULL,
  `BranchName` varchar(50) DEFAULT NULL,
  `UserName` varchar(50) DEFAULT NULL,
  `Password` varchar(100) DEFAULT NULL,
  `Address` varchar(200) DEFAULT NULL,
  `Email` varchar(30) DEFAULT NULL,
  `Mobile` varchar(20) DEFAULT NULL,
  `IsActive` int(11) DEFAULT '0',
  `IsDelete` int(11) NOT NULL DEFAULT '0',
  `EntryBy` varchar(20) DEFAULT NULL,
  `EntryOn` varchar(20) DEFAULT NULL,
  `UpdateBy` varchar(20) DEFAULT NULL,
  `UpdateOn` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`Id`, `OrganisationId`, `BranchName`, `UserName`, `Password`, `Address`, `Email`, `Mobile`, `IsActive`, `IsDelete`, `EntryBy`, `EntryOn`, `UpdateBy`, `UpdateOn`) VALUES
(1, NULL, 'manini bhuyan', 'manu', 'manu123!@#', 'plotn0-35/3 bda colone ,bhunaswar,odisha', 'jdsgj@jdfhj.dfhj', '9583284851', 0, 0, 'admin', '21-09-2019', NULL, NULL),
(2, NULL, 'manini bhuyan', 'manu', 'manu123!@#', 'plotn0-35/3 bda colone ,bhunaswar,odisha', 'jdsgj@jdfhj.dfhj', '9583284851', 0, 0, 'admin', '21-09-2019', NULL, NULL),
(3, NULL, 'kulamini', 'dfg', 'dfxgdfg', 'plotn0-35/3 bda colone ,bhunaswar,odisha', 'test@gmail.dhdfh', '9583284851', 0, 0, 'admin', '21-09-2019', NULL, NULL),
(4, NULL, 'kulamini', 'hjghjg', 'jkijkl', 'plotn0-35/3 bda colone ,bhunaswar,odisha', 'fghfgh@cvfh.fch', '9583284851', 0, 0, 'admin', '21-09-2019', NULL, NULL),
(5, 2, 'kulamini', 'gfdcgfd', 'hgfghfghf', 'plotn0-35/3 bda colone ,bhunaswar,odisha', 'jdsgj@jdfhj.dfhj', '9583284851', 0, 0, 'admin', '21-09-2019', NULL, NULL),
(6, 2, 'kulamini', 'gfjgfh', 'reygredh', 'plotn0-35/3 bda colone ,bhunaswar,odisha', 'gfjgf@fgju.tfj', '9583284851', 0, 0, 'admin', '21-09-2019', NULL, NULL),
(7, 2, 'kulamini', 'dsgdfg', 'fdhgdfh', 'plotn0-35/3 bda colone ,bhunaswar,odisha', 'dfhdfh@gk.dgfj', '9583284851', 0, 0, 'admin', '21-09-2019', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `userright`
--

CREATE TABLE `userright` (
  `Id` int(11) NOT NULL,
  `RoleId` int(20) NOT NULL,
  `SubMenuId` int(20) NOT NULL,
  `IsActive` int(11) NOT NULL DEFAULT '0',
  `IsDelete` int(11) NOT NULL DEFAULT '0',
  `EntryBy` varchar(20) NOT NULL,
  `EntryOn` varchar(20) NOT NULL,
  `UpdateBy` varchar(20) NOT NULL,
  `UpdateOn` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `acknwldge`
--
ALTER TABLE `acknwldge`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blooddetails`
--
ALTER TABLE `blooddetails`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `branch`
--
ALTER TABLE `branch`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `setting`
--
ALTER TABLE `setting`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `store`
--
ALTER TABLE `store`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `submenu`
--
ALTER TABLE `submenu`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tblblooddonars`
--
ALTER TABLE `tblblooddonars`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblbloodrequest`
--
ALTER TABLE `tblbloodrequest`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblcontactusquery`
--
ALTER TABLE `tblcontactusquery`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblpages`
--
ALTER TABLE `tblpages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `userright`
--
ALTER TABLE `userright`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `acknwldge`
--
ALTER TABLE `acknwldge`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `blooddetails`
--
ALTER TABLE `blooddetails`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `branch`
--
ALTER TABLE `branch`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `role`
--
ALTER TABLE `role`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `setting`
--
ALTER TABLE `setting`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `store`
--
ALTER TABLE `store`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `submenu`
--
ALTER TABLE `submenu`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblblooddonars`
--
ALTER TABLE `tblblooddonars`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `tblbloodrequest`
--
ALTER TABLE `tblbloodrequest`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `tblcontactusquery`
--
ALTER TABLE `tblcontactusquery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblpages`
--
ALTER TABLE `tblpages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `userright`
--
ALTER TABLE `userright`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
