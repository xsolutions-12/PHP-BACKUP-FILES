<!doctype html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <link rel="icon" href="images/fav.png" type="image/png">
      <!-- Bootstrap CSS -->
      <link rel="stylesheet" href="css/custom.css">
      <link rel="stylesheet" href="css/responsive.css">
      <link rel="stylesheet" href="css/color.css">
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <link rel="stylesheet" href="css/fontawesome.css">
      <link rel="stylesheet" href="css/owl.carousel.min.css">
      <link rel="stylesheet" href="css/prettyPhoto.css">
      <title>Tigers Sports HTML Template</title>
   </head>
   <body>
      <!--Wrapper Start-->
      <div class="wrapper">
        <!--Header Start-->
    <?php include('includeFiles/header.php') ?>
         <!--Header End--> 
         <!--Main Slider Start-->
         <div class="inner-banner-header wf100">
            <h1 data-generated="Groups">Groups</h1>
            <div class="gt-breadcrumbs">
               <ul>
                  <li> <a href="#" class="active"> <i class="fas fa-home"></i> Home </a> </li>
                  <li> <a href="#"> Pages </a> </li>
                  <li> <a href="#"> Groups </a> </li>
               </ul>
            </div>
         </div>
         <!--Main Slider Start--> 
         <!--Main Content Start-->
         <div class="main-content innerpagebg wf100">
            <!--team Page Start-->
            <div class="team wf100 p80">
               <!--Start-->
               <div class="matach-groups">
                  <div class="container">
                     <div class="row">
                        <!--col start-->
                        <div class="col-lg-3 col-md-6">
                           <div class="group-box">
                              <h6>Group A</h6>
                              <ul>
                                 <li><img src="images/flags/ru-flag.jpg" alt="">Russia </li>
                                 <li><img src="images/flags/sa-flag.jpg" alt="">Saudia Arabia </li>
                                 <li><img src="images/flags/eg-flag.jpg" alt="">Egypt</li>
                                 <li><img src="images/flags/ur-flag.jpg" alt="">Uruguay</li>
                              </ul>
                           </div>
                        </div>
                        <!--col end--> 
                        <!--col start-->
                        <div class="col-lg-3 col-md-6">
                           <div class="group-box">
                              <h6>Group B</h6>
                              <ul>
                                 <li><img src="images/flags/por-flag.jpg" alt="">Portugal</li>
                                 <li><img src="images/flags/sp-flag.jpg" alt="">Spain</li>
                                 <li><img src="images/flags/moro-flag.jpg" alt="">Morocco</li>
                                 <li><img src="images/flags/ir--flag.jpg" alt="">IR Iran</li>
                              </ul>
                           </div>
                        </div>
                        <!--col end--> 
                        <!--col start-->
                        <div class="col-lg-3 col-md-6">
                           <div class="group-box">
                              <h6>Group C</h6>
                              <ul>
                                 <li><img src="images/flags/fr-flag.jpg" alt="">France</li>
                                 <li><img src="images/flags/aus-flag.jpg" alt="">Australia</li>
                                 <li><img src="images/flags/peru-flag.jpg" alt="">Peru</li>
                                 <li><img src="images/flags/den-flag.jpg" alt="">Denmark</li>
                              </ul>
                           </div>
                        </div>
                        <!--col end--> 
                        <!--col start-->
                        <div class="col-lg-3 col-md-6">
                           <div class="group-box">
                              <h6>Group D</h6>
                              <ul>
                                 <li><img src="images/flags/arg-flag.jpg" alt="">Argentina</li>
                                 <li><img src="images/flags/ice-flag.jpg" alt="">Iceland</li>
                                 <li><img src="images/flags/cro-flag.jpg" alt="">Croatia</li>
                                 <li><img src="images/flags/niger-flag.jpg" alt="">Nigeria</li>
                              </ul>
                           </div>
                        </div>
                        <!--col end--> 
                        <!--col start-->
                        <div class="col-lg-3 col-md-6">
                           <div class="group-box">
                              <h6>Group E</h6>
                              <ul>
                                 <li><img src="images/flags/braz-flag.jpg" alt="">Brazil</li>
                                 <li><img src="images/flags/swit-flag.jpg" alt="">Switzerland</li>
                                 <li><img src="images/flags/cr-flag.jpg" alt="">Costa Rica</li>
                                 <li><img src="images/flags/serbia-flag.jpg" alt="">Serbia</li>
                              </ul>
                           </div>
                        </div>
                        <!--col end--> 
                        <!--col start-->
                        <div class="col-lg-3 col-md-6">
                           <div class="group-box">
                              <h6>Group F</h6>
                              <ul>
                                 <li><img src="images/flags/ger-flag.jpg" alt="">Germany</li>
                                 <li><img src="images/flags/mexi-flag.jpg" alt="">Mexico</li>
                                 <li><img src="images/flags/swe-flag.jpg" alt="">Sweden</li>
                                 <li><img src="images/flags/korea-flag.jpg" alt="">Korea Rep</li>
                              </ul>
                           </div>
                        </div>
                        <!--col end--> 
                        <!--col start-->
                        <div class="col-lg-3 col-md-6">
                           <div class="group-box">
                              <h6>Group G</h6>
                              <ul>
                                 <li><img src="images/flags/bel-flag.jpg" alt="">Belgium</li>
                                 <li><img src="images/flags/pana-flag.jpg" alt="">Panama</li>
                                 <li><img src="images/flags/tuni-flag.jpg" alt="">Tunisia</li>
                                 <li><img src="images/flags/eng-flag.jpg" alt="">England</li>
                              </ul>
                           </div>
                        </div>
                        <!--col end--> 
                        <!--col start-->
                        <div class="col-lg-3 col-md-6">
                           <div class="group-box">
                              <h6>Group H</h6>
                              <ul>
                                 <li><img src="images/flags/pol-flag.jpg" alt="">Poland</li>
                                 <li><img src="images/flags/sen-flag.jpg" alt="">Senegal</li>
                                 <li><img src="images/flags/col-flag.jpg" alt="">Columbia</li>
                                 <li><img src="images/flags/jp-flag.jpg" alt="">Japan</li>
                              </ul>
                           </div>
                        </div>
                        <!--col end--> 
                     </div>
                  </div>
               </div>
               <!--End--> 
            </div>
            <!--team Page End--> 
         </div>
         <!--Main Content End--> 
         <!--Main Footer Start-->
         <footer class="wf100 main-footer">
            <div class="container">
               <div class="row">
                  <!--Footer Widget Start-->
                  <div class="col-lg-3 col-md-6">
                     <div class="footer-widget about-widget">
                        <img src="images/logo.png" alt="">
                        <p> Fusce ac pharetra urna. Duis non lacus sit amet lacus interdum facilisis sed non est ut mi metus semper. </p>
                        <address>
                           <ul>
                              <li><i class="fas fa-map-marker-alt"></i> 4700 Millenia Blvd # 175, Orlando, FL 32839, USA</li>
                              <li><i class="fas fa-phone"></i> +1 321 2345 678-7</li>
                              <li><i class="fas fa-envelope"></i> info@soccer.com
                                 contact@soccer.com 
                              </li>
                           </ul>
                        </address>
                     </div>
                  </div>
                  <!--Footer Widget End--> 
                  <!--Footer Widget Start-->
                  <div class="col-lg-3 col-md-6">
                     <div class="footer-widget">
                        <h4>About Soccer</h4>
                        <ul class="footer-links">
                           <li><a href="#"><i class="fas fa-angle-double-right"></i> About Club</a></li>
                           <li><a href="#"><i class="fas fa-angle-double-right"></i> Matche Schedules</a></li>
                           <li><a href="#"><i class="fas fa-angle-double-right"></i> Groups Table</a></li>
                           <li><a href="#"><i class="fas fa-angle-double-right"></i> Teams</a></li>
                           <li><a href="#"><i class="fas fa-angle-double-right"></i> Statistics</a></li>
                           <li><a href="#"><i class="fas fa-angle-double-right"></i> Qualifiers</a></li>
                           <li><a href="#"><i class="fas fa-angle-double-right"></i> Ticket Bookings</a></li>
                           <li><a href="#"><i class="fas fa-angle-double-right"></i> Shoes</a></li>
                           <li><a href="#"><i class="fas fa-angle-double-right"></i> T-Shirts</a></li>
                           <li><a href="#"><i class="fas fa-angle-double-right"></i> Sports Wear</a></li>
                           <li><a href="#"><i class="fas fa-angle-double-right"></i> Accessories</a></li>
                           <li><a href="#"><i class="fas fa-angle-double-right"></i> Shop</a></li>
                           <li><a href="#"><i class="fas fa-angle-double-right"></i> Contact us</a></li>
                           <li><a href="#"><i class="fas fa-angle-double-right"></i> Media Room</a></li>
                        </ul>
                     </div>
                  </div>
                  <!--Footer Widget End--> 
                  <!--Footer Widget Start-->
                  <div class="col-lg-3 col-md-6">
                     <div class="footer-widget">
                        <h4>Recent Instagram</h4>
                        <ul class="instagram">
                           <li><img src="images/insta1.jpg" alt=""></li>
                           <li><img src="images/insta2.jpg" alt=""></li>
                           <li><img src="images/insta3.jpg" alt=""></li>
                           <li><img src="images/insta4.jpg" alt=""></li>
                           <li><img src="images/insta5.jpg" alt=""></li>
                           <li><img src="images/insta6.jpg" alt=""></li>
                        </ul>
                     </div>
                  </div>
                  <!--Footer Widget End--> 
                  <!--Footer Widget Start-->
                  <div class="col-lg-3 col-md-6">
                     <div class="footer-widget">
                        <h4>Get Updated</h4>
                        <p> Sign up to Get Updated & latest offers with our Newsletter. </p>
                        <ul class="newsletter">
                           <li>
                              <input type="text" class="form-control" placeholder="Your Name">
                           </li>
                           <li>
                              <input type="text" class="form-control" placeholder="Your Emaill Address">
                           </li>
                           <li> <strong>We respect your privacy</strong>
                              <button><span>Subscribe</span></button>
                           </li>
                        </ul>
                     </div>
                  </div>
                  <!--Footer Widget End--> 
               </div>
            </div>
            <div class="container brtop">
               <div class="row">
                  <div class="col-lg-6 col-md-6">
                     <p class="copyr"> All Rights Reserved of Sports © 2020, Design & Developed By: <a href="#">GramoTech</a> </p>
                  </div>
                  <div class="col-lg-6 col-md-6">
                     <ul class="quick-links">
                        <li><a href="#">Home</a></li>
                        <li><a href="#">Players</a></li>
                        <li><a href="#">Fixtures</a></li>
                        <li><a href="#">Point Table</a></li>
                        <li><a href="#">Tickets</a></li>
                        <li><a href="#">Contact</a></li>
                     </ul>
                  </div>
               </div>
            </div>
         </footer>
         <!--Main Footer End--> 
      </div>
      <!--Wrapper End--> 
      <!-- Optional JavaScript --> 
      <script src="js/jquery-3.3.1.min.js"></script> 
      <script src="js/popper.min.js"></script> 
      <script src="js/bootstrap.min.js"></script> 
<script src="js/mobile-nav.js"></script>  
      <script src="js/owl.carousel.min.js"></script> 
      <script src="js/isotope.js"></script> 
      <script src="js/jquery.prettyPhoto.js"></script> 
      <script src="js/jquery.countdown.js"></script> 
      <script src="js/custom.js"></script>
   </body>
</html>