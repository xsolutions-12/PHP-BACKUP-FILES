<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="images/logopic01.jpg" type="image/png">
    <!-- Bootstrap CSS -->
    <?php include('includeFiles/cssFiles.php') ?>
    <!--Rev Slider End-->
    <title>Government College of Physical Education, Kulundi, Sambalpur</title>
</head>

<body>
    <!--Wrapper Start-->
    <div class="wrapper">
        <!--Header Start-->
        <!--Header Start-->
        <?php include('includeFiles/header.php') ?>
        <!--Header End-->
        <!--Main Slider Start-->
        <div class="inner-banner-header wf100">
            <h1 data-generated="Job Opportunity">Job Opportunity</h1>
            <div class="gt-breadcrumbs">
                <ul>
                    <li> <a href="index.php" class="active"> <i class="fas fa-home"></i> Home </a> </li>
                    <li> <a href="#"> Career </a> </li>
                    <li> <a href="jobOpportunity.php"> Job Opportunity </a> </li>

                </ul>
            </div>
        </div>
        <!--Main Slider Start-->
        <!--Main Content Start-->
        <div class="main-content p80 innerpagebg wf100">
            <!--Contact Page Start-->
            <div class="contact">
                <div class="container">
                    <div class="row">
                        <!--Form Start-->

                        <div class="col-lg-12">
                        <div class="h3-section-title">
                            <!-- <strong style="color:white">featured News</strong> -->
                            <h2 style="color:black">Job Opportunity</h2>
                        </div>

                        <!--news start-->
                        <div class="news-list-post">
                            

                            <div class="post-txt" style="height: 500px;width:888px;text-align: justify;">
                                <a href="#" style="color: black;">This page is under construction.</a><br>
                            </div>


                        </div>


                    </div>
                    <!--col end-->
                    </div>
                </div>
            </div>
            <!--Contact Page End-->
        </div>
        <!--Main Content End-->
        <!--Main Footer Start-->
        <?php include('includeFiles/footer.php') ?>
        <!--Main Footer End-->
    </div>
    <!--Wrapper End-->
    <!-- Optional JavaScript -->
    <?php include('includeFiles/scriptFile.php')?>
</body>

</html> 