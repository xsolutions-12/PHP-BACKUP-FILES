<footer class="wf100 main-footer">
            <div class="container">
               <div class="row">
                  <!--Footer Widget Start-->
                  <div class="col-lg-3 col-md-6">
                     <div class="footer-widget about-widget">
                        <img src="images/college_pics/logopic01.jpg" alt=" LOGO..." style="max-width: 255px;height: 50px;">
                        <p style="text-align: justify;"> Government College of Physical Education was founded in 1993 and is recognized by the National Council for Teacher Education (NCTE) approved by and affiliated to Sambalpur University.</p>
                        <address>
                           <ul>
                              <li><i class="fas fa-map-marker-alt"></i> Sambalpur, Odisha </li>
                              <li><i class="fas fa-phone"></i> +91 9938546949</li>
                              <li><i class="fas fa-envelope"></i>gcpekulundi1993@gmail.com 
                              </li>
                           </ul>
                        </address>
                     </div>
                  </div>
                  <!--Footer Widget End--> 
                  <!--Footer Widget Start-->
                  <div class="col-lg-3 col-md-6">
                     <div class="footer-widget">
                        <h4>About Soccer</h4>
                        <ul class="footer-links">
                           <li><a href="aboutUs.php"><i class="fas fa-angle-double-right"></i> About</a></li>
                           <li><a href="research.php"><i class="fas fa-angle-double-right"></i> Research</a></li>
                           <li><a href="contact.php"><i class="fas fa-angle-double-right"></i> Contact us</a></li>
                           <li><a href="gallery-3-col.php"><i class="fas fa-angle-double-right"></i> Gallery</a></li>
                        </ul>
                     </div>
                  </div>
                  <!--Footer Widget End--> 
                  <!--Footer Widget Start-->
                  <div class="col-lg-3 col-md-6">
                     <div class="footer-widget">
                        <h4>Recent Instagram</h4>
                        <ul class="instagram">
                           <li><img src="images/college_pics/insta006.jpg" alt=""></li>
                           <li><img src="images/college_pics/insta001.jpg" alt=""></li>
                           <li><img src="images/college_pics/insta002.jpg" alt=""></li>
                           <li><img src="images/college_pics/insta003.jpg" alt=""></li>
                           <li><img src="images/college_pics/insta004.jpg" alt=""></li>
                           <li><img src="images/college_pics/insta005.jpg" alt=""></li>
                        </ul>
                     </div>
                  </div>
                  <!--Footer Widget End--> 
                  <!--Footer Widget Start-->
                  <div class="col-lg-3 col-md-6">
                     <div class="footer-widget">
                        <h4>Get Updated</h4>
                        <p> Sign up to Get Updated & latest offers with our Newsletter. </p>
                        <ul class="newsletter">
                           <li>
                              <input type="text" class="form-control" placeholder="Your Name">
                           </li>
                           <li>
                              <input type="text" class="form-control" placeholder="Your Emaill Address">
                           </li>
                           <li> <strong>We respect your privacy</strong>
                              <button><span>Subscribe</span></button>
                           </li>
                        </ul>
                     </div>
                  </div>
                  <!--Footer Widget End--> 
               </div>
            </div>
            <div class="container brtop">
               <div class="row">
                  <div class="col-lg-6 col-md-6">
                     <p class="copyr"> All Rights Reserved of Sports © 2023, Design & Developed By: <a href="#">CBSPL</a> </p>
                  </div>
                  <div class="col-lg-6 col-md-6">
                     
                  </div>
               </div>
            </div>
         </footer>