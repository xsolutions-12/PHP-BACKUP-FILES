<section class="news-updates wf100 p90">
        <div class="container">
          <div class="row">
            <div class="col-md-12">
              <div class="section-title">
                <h2>Infrastructure</h2>
              </div>
            </div>
            <div class="col-md-12">
              <div id="newsupdate-slider" class="owl-carousel owl-theme">

                <!--Item Start-->
                <div class="item">
                  <div class="hnews-box">
                    <div class="thumb"><a href="#"><i class="fas fa-link"></i></a><img src="images/sports_new/TennisCenterKalingaStadiumSportsComplex.png" alt=""></div>
                    <div class="hnews-txt">
                      <ul class="news-meta">
                        <li><i class="fas fa-calendar-alt"></i> 27 June, 1978</li>
                      </ul>
                      <h4> <a href="#">Tennis Center, Kalinga Stadium Sports Complex</a> </h4>
                      <a href="#" style="color: blue;"><i class="fa fa-map-marker" aria-hidden="true"></i> Bhubaneswar</a>
                      <p style="text-align: justify;">The Tennis Centre is certified by the International Tennis Federation and has a synthetic center court with gallery seating for 1400, a gym, player changing room, auditorium, rooms for dignitaries, a media room, broadcast, and administrative facilities. With 8 additional synthetic courts, it can now host International matches.</p>
                      <a class="rm" href="#">Visit for more info <i class="fas fa-arrow-right"></i></a>
                    </div>
                  </div>
                </div>
                <!--Item End-->

                <!--Item Start-->
                <div class="item">
                  <div class="hnews-box">
                    <div class="thumb"><a href="#"><i class="fas fa-link"></i></a><img src="images/sports_new/BirsaMundaAthleticStadiumComplex.jpg" alt=""></div>
                    <div class="hnews-txt">
                      <ul class="news-meta">
                        <li><i class="fas fa-calendar-alt"></i> 27 June, 2020</li>
                      </ul>
                      <h4> <a href="#">Birsa Munda Athletic Stadium Complex</a> </h4>
                      <a href="#" style="color: blue;"><i class="fa fa-map-marker" aria-hidden="true"></i> Rourkela</a>
                      <p style="text-align: justify;">It features an athletics stadium with 400 m synthetic athletic track and a natural turf football field with floodlights. The stadium has four galleries with a seating capacity of more than 9000 spectators, including seating for differently abled people. It also houses an Olympic-sized indoor swimming pool along with players’ changing rooms and allied facilities.</p>
                      <a class="rm" href="#">Visit for more info <i class="fas fa-arrow-right"></i></a>
                    </div>
                  </div>
                </div>
                <!--Item End-->

                <!--Item Start-->
                <div class="item">
                  <div class="hnews-box">
                    <div class="thumb"><a href="#"><i class="fas fa-link"></i></a><img src="images/sports_new/BirsaMundaHockeyStadium.jpg" alt=""></div>
                    <div class="hnews-txt">
                      <ul class="news-meta">
                        <li><i class="fas fa-calendar-alt"></i> 27 June, 2020</li>
                      </ul>
                      <h4> <a href="#">Birsa Munda Hockey Stadium</a> </h4>
                      <a href="#" style="color: blue;"><i class="fa fa-map-marker" aria-hidden="true"></i> Rourkela</a>
                      <p style="text-align: justify;">It is the largest seated hockey stadium officially recognized by the Guinness World Records as the largest fully seated hockey arena in the world. The picturesque stadium, built in 15 months, also boasts two world-class FIH approved turfs for hockey, apart from gymnasiums and World Cup Village.</p>
                      <a class="rm" href="#">Visit for more info <i class="fas fa-arrow-right"></i></a>
                    </div>
                  </div>
                </div>
                <!--Item End-->

                <!--Item Start-->
                <div class="item">
                  <div class="hnews-box">
                    <div class="thumb"><a href="#"><i class="fas fa-link"></i></a><img src="images/sports_new/DharaniDharSports.jpg" alt=""></div>
                    <div class="hnews-txt">
                      <ul class="news-meta">
                        <li><i class="fas fa-calendar-alt"></i> 27 June, 2020</li>
                      </ul>
                      <h4> <a href="#">Dharani Dhar Sports Complex</a> </h4>
                      <a href="#" style="color: blue;"><i class="fa fa-map-marker" aria-hidden="true"></i> Keonjhar</a>
                      <p style="text-align: justify;">It features a natural turf football field, 400 m synthetic track with LED floodlights as well as a 1000 seating capacity gallery. Additionally, an archery arena has been developed. It has an indoor hall with six badminton courts and is complemented with a 200-bedded fully furnished residential facilities for athletes and staff.</p>
                      <a class="rm" href="#">Visit for more info <i class="fas fa-arrow-right"></i></a>
                    </div>
                  </div>
                </div>
                <!--Item End-->

                <!--Item Start-->
                <div class="item">
                  <div class="hnews-box">
                    <div class="thumb"><a href="#"><i class="fas fa-link"></i></a><img src="images/sports_new/BijuPatnaikstadium.jpeg" alt=""></div>
                    <div class="hnews-txt">
                      <ul class="news-meta">
                        <li><i class="fas fa-calendar-alt"></i> 27 June, 2020</li>
                      </ul>
                      <h4> <a href="#">Biju Patnaik Indoor Stadium </a> </h4>
                          <a href="#" style="color: blue;"><i class="fa fa-map-marker" aria-hidden="true"></i>  Rourkela</a>
                      <p style="text-align: justify;">The Biju Patnaik Indoor Stadium in Rourkela has 3 indoor badminton court as per World Badminton Federation standard and a 350 spectator seating capacity, making it a perfect facility for shuttlers of the region a and good venue for competitions.The stadium also has a multipurpose outdoor court for Volleyball and Tennis.</p>
                      <a class="rm" href="#">News Detail <i class="fas fa-arrow-right"></i></a>
                    </div>
                  </div>
                </div>
                <!--Item End-->

                <!--Item Start-->
                <!-- <div class="item">
                  <div class="hnews-box">
                    <div class="thumb"><a href="#"><i class="fas fa-link"></i></a><img src="images/newsupdate-3.jpg" alt=""></div>
                    <div class="hnews-txt">
                      <ul class="news-meta">
                        <li><i class="fas fa-calendar-alt"></i> 27 June, 2020</li>
                      </ul>
                      <h4> <a href="#">Tigers’s Defender Williams
                          Announced Retiremen</a> </h4>
                      <a class="rm" href="#">News Detail <i class="fas fa-arrow-right"></i></a>
                    </div>
                  </div>
                </div> -->
                <!--Item End-->

              </div>
            </div>
          </div>
        </div>
      </section>