<link rel="stylesheet" href="css/custom.css">
  <link rel="stylesheet" href="css/responsive.css">
  <link rel="stylesheet" href="css/color.css">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/fontawesome.css">
  <link rel="stylesheet" href="css/owl.carousel.min.css">
  <link rel="stylesheet" href="css/prettyPhoto.css">
  <!--Rev Slider Start-->
  <link rel="stylesheet" href="js/rev-slider/css/settings.css" type='text/css' media='all' />
  <link rel="stylesheet" href="js/rev-slider/css/layers.css" type='text/css' media='all' />
  <link rel="stylesheet" href="js/rev-slider/css/navigation.css" type='text/css' media='all' />