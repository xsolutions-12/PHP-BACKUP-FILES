<section class="wf100 featured-news p90">
  <div class="container">
    <div class="row">

      <!--col start-->
      <div class="col-lg-4">
        <div class="h3-section-title">
          <!-- <strong style="color:black">featured News</strong> -->
          <h2 style="color:black">Notice</h2>
        </div>

        <!--news start-->
        <div class="news-list-post" id="overflowTest">
          <!-- <div class="post-thumb"> <a href="#"><i class="fas fa-link"></i></a> <img src="images/news-media-img1.jpg" alt=""></div> -->

          <div class="trending-news">

            <!-- Expand-->
            <div class="list-box-expand active">
              <div class="news-caption">
                <div class="news-txt">
                  <!--<h4><a href="#">Best Football Skills of 2023</a> </h4>-->
                  <!--<ul class="news-meta">-->
                  <!--  <li><i class="fas fa-calendar-alt"></i> 27 June, 2023</li>-->
                  <!--  <li><i class="far fa-comment"></i> 89 Comments</li>-->
                  <!--</ul>-->
                </div>
              </div>
              <div class="expand-news-img"><img src="images/college_pics/pic007.jpg" alt=""></div>
            </div>
            <!--Expand-->

            <!--Expand-->
            <div class="list-box-expand">
              <div class="news-caption">
                <div class="news-txt">
                  <!--<h4><a href="#">Be A Game Changer: Tackling blues</a> </h4>-->
                  <!--<ul class="news-meta">-->
                  <!--  <li><i class="fas fa-calendar-alt"></i> 27 June, 2023</li>-->
                  <!--  <li><i class="far fa-comment"></i> 89 Comments</li>-->
                  <!--</ul>-->
                </div>
              </div>
              <div class="expand-news-img"><img src="images/college_pics/pic008.jpg" alt=""></div>
            </div>
            <!--Expand-->

            <!--Expand-->
            <div class="list-box-expand">
              <div class="news-caption">
                <div class="news-txt">
                  <!--<h4><a href="#">Champs will learn from their mistake</a> </h4>-->
                  <!--<ul class="news-meta">-->
                  <!--  <li><i class="fas fa-calendar-alt"></i> 27 June, 2023</li>-->
                  <!--  <li><i class="far fa-comment"></i> 89 Comments</li>-->
                  <!--</ul>-->
                </div>
              </div>
              <div class="expand-news-img"><img src="images/college_pics/pic011.jpg" alt=""></div>
            </div>
            <!--Expand-->

            <!--Expand-->
            <div class="list-box-expand">
              <div class="news-caption">
                <div class="news-txt">
                  <!--<h4><a href="#">Premier League support for Heads Up</a> </h4>-->
                  <!--<ul class="news-meta">-->
                  <!--  <li><i class="fas fa-calendar-alt"></i> 27 June, 2023</li>-->
                  <!--  <li><i class="far fa-comment"></i> 89 Comments</li>-->
                  <!--</ul>-->
                </div>
              </div>
              <div class="expand-news-img"><img src="images/college_pics/pic009.jpg" alt=""></div>
            </div>
            <!--Expand -->

          </div>
        </div>
      </div>

      <div class="col-lg-4">
        <div class="h3-section-title">
          <!-- <strong style="color:black">featured News</strong> -->
          <h2 style="color:black">News</h2>
        </div>

        <div class="sidebar" style="height: 500px;">
          <!--widget start-->
          <!-- <div class="widget sidebar-ad"> <img src="images/sideadbanner1.png" alt=""> </div> -->
          <!--widget end-->
          <!--widget start-->
          <div class="widget">
            <h4>Latest News</h4>
            <div class="side-products">
              <div id="side-products" class="owl-carousel owl-theme owl-loaded owl-drag">
                <!--Item Start-->

                <!--Item End-->
                <!--Item Start-->

                <!--Item End-->
                <!--Item Start-->

                <!--Item End-->
                <div class="owl-stage-outer">
                  <div class="owl-stage" style="transform: translate3d(-600px, 0px, 0px); transition: all 0.25s ease 0s; width: 900px;">
                    <div class="owl-item" style="width: 300px;">
                      <div class="item">
                        <div class="pro-box">
                          <div class="pro-thumb"> <a href="gallery-3-col.php"><i class="fas fa-link"></i></a><img src="images/college_pics/pic001.jpg" alt="" style="height:150px;">
                          </div>
                          <div class="pro-txt">
                            <!-- <h4> <a href="#">Sports Team T-Shirt</a> </h4> -->
                            <p class="price"> Hello everyone follow me for latest news... </p>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="owl-item" style="width: 300px;">
                      <div class="item">
                        <div class="pro-box">
                          <div class="pro-thumb"> <a href="gallery-3-col.php"><i class="fas fa-link"></i></a><img src="images/college_pics/pic002.jpg" alt="" style="height:150px;"> </div>
                          <div class="pro-txt">
                            <!-- <h4> <a href="#">Sports Team T-Shirt</a> </h4> -->
                            <p class="price">Hello everyone follow me for latest news... </p>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="owl-item active" style="width: 300px;">
                      <div class="item">
                        <div class="pro-box">
                          <div class="pro-thumb"> <a href="gallery-3-col.php"><i class="fas fa-link"></i></a><img src="images/college_pics/pic003.jpg" alt="" style="height:150px;"> </div>
                          <div class="pro-txt">
                            <!-- <h4> <a href="#">Sports Team T-Shirt</a> </h4> -->
                            <p class="price">Hello everyone follow me for latest news... </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="owl-nav"><button type="button" role="presentation" class="owl-prev"><span aria-label="Previous">‹</span></button><button type="button" role="presentation" class="owl-next disabled"><span aria-label="Next">›</span></button></div>
                <div class="owl-dots disabled"></div>
              </div>
            </div>
          </div>
          <!--widget End-->


          <!--widget End-->
        </div>
      </div>

      <!--col end-->
      <div class="col-md-4">
        <div class="h3-section-title">
          <!-- <strong style="color:black">featured News</strong> -->
          <h2 style="color:black">Social Widgets</h2>
        </div>
        <div class="product-tabs">
          <!-- <nav> -->
            <div class="card">
          <div class="nav nav-tabs" id="nav-tab" role="tablist">
            
              <a class="nav-item nav-link active" id="nav-one-tab" data-toggle="tab" href="#nav-one" role="tab" aria-controls="nav-one" aria-selected="true" style="margin: 10px 10px 25px 10px;"><svg xmlns="http://www.w3.org/2000/svg" height="1em" viewBox="0 0 320 512">
                  <path d="M279.14 288l14.22-92.66h-88.91v-60.13c0-25.35 12.42-50.06 52.24-50.06h40.42V6.26S260.43 0 225.36 0c-73.22 0-121.08 44.38-121.08 124.72v70.62H22.89V288h81.39v224h100.17V288z" />
                </svg></a>
              <a class="nav-item nav-link" id="nav-three-tab" data-toggle="tab" href="#nav-three" role="tab" aria-controls="nav-three" aria-selected="false" style="margin: 10px 10px 25px 0px;"><svg xmlns="http://www.w3.org/2000/svg" height="1em" viewBox="0 0 448 512">
                  <path d="M64 32C28.7 32 0 60.7 0 96V416c0 35.3 28.7 64 64 64H384c35.3 0 64-28.7 64-64V96c0-35.3-28.7-64-64-64H64zm297.1 84L257.3 234.6 379.4 396H283.8L209 298.1 123.3 396H75.8l111-126.9L69.7 116h98l67.7 89.5L313.6 116h47.5zM323.3 367.6L153.4 142.9H125.1L296.9 367.6h26.3z" />
                </svg></a>
            </div>
          </div>
          <!-- </nav> -->
          <div class="news-list-post" id="overflowTest" style="height: 440px;">
            <div class="tab-content" id="nav-tabContent">
              <div class="tab-pane fade show active" id="nav-one" role="tabpanel" aria-labelledby="nav-one-tab">
                <p> We are going to run a solid educational campaign for the orphan children study. There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words slightly believable. If you are going to use a passage of Lorem Ipsum.</p>
                <p>You need to be sure there isn't anything embarrassing hidden in the middle of text. To take a trivial example, which of us ever undertakes laborious physical exercise, except to obtain some advantage. Etiam venenatis eleifend urna eget scelerisque. Aliquam in nunc quis dui sollicitudin ornare ac vitae lectus. Aliquam interdum dolor aliquet dolor sollicitudin fermentum. Donec congue lorem a molestie bibendum. </p>
              </div>
              <!-- <div class="tab-pane fade" id="nav-two" role="tabpanel" aria-labelledby="nav-two-tab">
                <table>
                  <tbody>
                    <tr>
                      <td>Weight</td>
                      <td>130 gm</td>
                    </tr>
                    <tr>
                      <td>Dimensions</td>
                      <td>70 x 40 x 50 cm</td>
                    </tr>
                    <tr>
                      <td>Small</td>
                      <td>Mauris consequat odio turpis, sed ultricies libero tincidunt i</td>
                    </tr>
                    <tr>
                      <td>Large</td>
                      <td>Condimentum nisi vitae, consequat libero integer sit amet velit neque. </td>
                    </tr>
                  </tbody>
                </table>
              </div> -->
              <div class="tab-pane fade" id="nav-three" role="tabpanel" aria-labelledby="nav-three-tab">
                <ul class="comments">
                  <!--Comment Start-->
                  <li class="comment">
                    <div class="user-thumb"> <img src="images/auser.jpg" alt=""></div>
                    <div class="comment-txt">
                      <h6> Mason Gray </h6>
                      <p> Personally I think a combination of all these methods is most effective, but in today’s post I will be focusing specifically on how to use and style WordPress’ built-in sticky post feature and highlighting it’s best use case based on my own experience. </p>
                      <!-- <ul class="comment-time">
                        <li>Posted: 09 July, 2023 at 2:37 pm</li>
                        <li> <a href="#"><i class="fas fa-reply"></i> Reply</a> </li>
                      </ul> -->
                    </div>
                  </li>
                  <!--Comment End-->
                  <!--Comment Start-->
                  <li class="comment">
                    <div class="user-thumb"> <img src="images/auser.jpg" alt=""></div>
                    <div class="comment-txt">
                      <h6> Harry Butler </h6>
                      <p> Personally I think a combination of all these methods is most effective, but in today’s post I will be focusing specifically on how to use and style WordPress’ built-in sticky post feature and highlighting it’s best use case based on my own experience. </p>
                      <!-- <ul class="comment-time">
                        <li>Posted: 09 July, 2023 at 2:37 pm</li>
                        <li> <a href="#"><i class="fas fa-reply"></i> Reply</a> </li>
                      </ul> -->
                    </div>
                  </li>
                  <!--Comment End-->
                </ul>
                <div class="wf100 comment-form">
                  <h4>Leave a Review</h4>
                  <p class="comment-notes"><span id="email-notes">Your email address will not be published.</span> Required fields are marked <span class="required">*</span></p>
                  <div class="comment-form-rating">
                    <label>Your rating</label>
                    <p class="stars"><span><a class="star-1" href="#">1</a><a class="star-2" href="#">2</a><a class="star-3" href="#">3</a><a class="star-4" href="#">4</a><a class="star-5" href="#">5</a></span></p>
                  </div>
                  <ul>
                    <li class="w3">
                      <input type="text" class="form-control" placeholder="Full Name">
                    </li>
                    <li class="w3">
                      <input type="text" class="form-control" placeholder="Email">
                    </li>
                    <li class="w3 np">
                      <input type="text" class="form-control" placeholder="Subject">
                    </li>
                    <li class="full">
                      <textarea class="form-control" placeholder="Write Comments"></textarea>
                    </li>
                    <li class="full">
                      <button class="post-btn">Post Your Review</button>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!--col end-->



    </div>
  </div>
</section>