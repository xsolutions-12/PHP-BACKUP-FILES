<section class="wf100 h3-twitter">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <h3 style="font-size: 26px;
    font-weight: 600;text-align:center;margin: 10px auto;color:#016A70  "> Testimonials </h3>
            <div id="h3-twitter-slider" class="owl-carousel owl-theme">
              
              <!--Start-->
              <div class="item">
                <div class="h3-tweets"> <span class="tw-icon"><i class="fab fa-twitter"></i></span>
                  <h4>Chairman Name</h4>
                  <p>Some people think football [soccer]is a matter of life and death. I don’t like that attitude. I can assure them it is much more serious than that.</p>
                </div>
              </div>
              <!--End-->

              <!--Start-->
              <div class="item">
                <div class="h3-tweets"> <span class="tw-icon"><i class="fab fa-twitter"></i></span>
                  <h4>Governor Name</h4>
                  <p>Some people think football [soccer]is a matter of life and death. I don’t like that attitude. I can assure them it is much more serious than that.</p>
                </div>
              </div>
              <!--End-->

              <!--Start-->
              <div class="item">
                <div class="h3-tweets"> <span class="tw-icon"><i class="fab fa-twitter"></i></span>
                  <h4>Principal Name</h4>
                  <p>Some people think football [soccer]is a matter of life and death. I don’t like that attitude. I can assure them it is much more serious than that.</p>
                </div>
              </div>
              <!--End-->

            </div>
          </div>
        </div>
      </div>
    </section>