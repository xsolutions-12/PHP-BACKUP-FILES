<script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/mobile-nav.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/isotope.js"></script>
  <script src="js/jquery.prettyPhoto.js"></script>
  <script src="js/jquery.countdown.js"></script>
  <script src="js/custom.js"></script>
  <!--Rev Slider Start-->
  <script type="text/javascript" src="js/rev-slider/js/jquery.themepunch.tools.min.js"></script>
  <script type="text/javascript" src="js/rev-slider/js/jquery.themepunch.revolution.min.js"></script>
  <script type="text/javascript" src="js/rev-slider.js"></script>
  <script type="text/javascript" src="js/rev-slider/js/extensions/revolution.extension.actions.min.js"></script>
  <script type="text/javascript" src="js/rev-slider/js/extensions/revolution.extension.carousel.min.js"></script>
  <script type="text/javascript" src="js/rev-slider/js/extensions/revolution.extension.kenburn.min.js"></script>
  <script type="text/javascript" src="js/rev-slider/js/extensions/revolution.extension.layeranimation.min.js"></script>
  <script type="text/javascript" src="js/rev-slider/js/extensions/revolution.extension.migration.min.js"></script>
  <script type="text/javascript" src="js/rev-slider/js/extensions/revolution.extension.navigation.min.js"></script>
  <script type="text/javascript" src="js/rev-slider/js/extensions/revolution.extension.parallax.min.js"></script>
  <script type="text/javascript" src="js/rev-slider/js/extensions/revolution.extension.slideanims.min.js"></script>
  <script type="text/javascript" src="js/rev-slider/js/extensions/revolution.extension.video.min.js"></script>