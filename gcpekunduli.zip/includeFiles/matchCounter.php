<div class="h3-match-counter">
      <button class="hide"><i class="fas fa-times"></i></button>
      <div class="container">
        <div class="row">
          <ul>
            <li class="col-md-1">
              <div class="team-left"><img src="images/nmf-logo1.png" alt=""> <strong>FC Champs</strong></div>
            </li>
            <li class="col-md-3">
              <p class="mdate-time"> 20 December. 2018 <strong>04:00 PM GMT+</strong> </p>
            </li>
            <li class="col-md-4">
              <div class="defaultCountdown"></div>
            </li>
            <li class="col-md-3">
              <p class="match-loc"><i class="fas fa-location-arrow"></i> Expo Center Main Hall, NY</p>
            </li>
            <li class="col-md-1">
              <div class="team-right"><img src="images/nmf-logo2.png" alt=""> <strong>Tigers</strong></div>
            </li>
          </ul>
        </div>
      </div>
    </div>