<div class="wf100 footer-three">
      <h3 style="color:black;margin-left: 188px;padding-top: 20px;font-weight: bolder;">Administrations</h3>
      <!--Partner Logos Start-->
      <div class="partner-logos">
        <div class="container">
          <div class="row">
            <ul class="row">
              <li class="col-md-2 col-sm-2"> <a href="#"><img src="images/auser.jpg" alt=""></a> </li>
              <li class="col-md-2 col-sm-2"> <a href="#"><img src="images/auser.jpg" alt=""></a> </li>
              <li class="col-md-2 col-sm-2"> <a href="#"><img src="images/auser.jpg" alt=""></a> </li>
              <li class="col-md-2 col-sm-2"> <a href="#"><img src="images/auser.jpg" alt=""></a> </li>
              <li class="col-md-2 col-sm-2"> <a href="#"><img src="images/auser.jpg" alt=""></a> </li>
              <li class="col-md-2 col-sm-2"> <a href="#"><img src="images/auser.jpg" alt=""></a> </li>
            </ul>
          </div>
        </div>
      </div>
    </div>