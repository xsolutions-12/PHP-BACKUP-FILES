<section class="wf100 featured-news p90">
  <div class="container">
    <div class="row">

      <!--col start-->
      <div class="col-lg-8">
        <div class="h3-section-title"> 
          <!-- <strong style="color:white">featured News</strong> -->
          <h2 style="color:black">About</h2>
        </div>

        <!--news start-->
        <div class="news-list-post" >
          <!-- <div class="post-thumb"> <a href="#"><i class="fas fa-link"></i></a> <img src="images/news-media-img1.jpg" alt=""></div> -->
          
          <div class="post-txt" style="height: 500px;">
            <a href="#" style="color: black;">Sport pertains to any form of physical activity or game, often competitive and organized, that aims to use, maintain, or improve physical ability and skills while providing enjoyment to participants and, in some cases, entertainment to spectators. Sports can, through casual or organized participation, improve participants' physical health. Hundreds of sports exist, from those between single contestants, through to those with hundreds of simultaneous participants, either in teams or competing as individuals. Sport is generally recognised as system of activities based in physical athleticism or physical dexterity, with major competitions such as the Olympic Games admitting only sports meeting this definition. Other organisations, such as the Council of Europe, preclude activities without a physical element from classification as sports. However, a number of competitive, but non-physical, activities claim recognition as mind sports. The International Olympic Committee (through ARISF) recognises both chess and bridge as bona fide sports, and SportAccord, the international sports federation association, recognises five non-physical sports: bridge, chess, draughts (checkers), Go and xiangqi, and limits the number of mind games which can be admitted as sports.</a><br>
          </div>
          
          
        </div>
     

      </div>
      <!--col end-->

      <!--col start-->
      <div class="col-lg-4">
        <div class="h3-section-title"> 
          <!-- <strong style="color:white">Trending News</strong> -->
          <h2 style="color:black">Events</h2>
        </div>
        <div class="sidebar">
          <div class="widget">

            <h4>Top Events</h4>
            <div class="top-stories-widget">
              <div id="top-stories" class="owl-carousel owl-theme">
                <!--Slide 1 Start-->
                <div class="item">
                  <ul class="top-stories">
                    <!--Story Start-->
                    <li class="story-row">
                      <div class="ts-thumb"><img src="images/college_pics/side010.jpg" alt=""> </div>
                      <div class="ts-txt">
                        <h5> <a href="#">Success is not Accident it’s a Result of Hard Work </a>
                        </h5>
                        <ul class="tsw-meta">
                          <li><a href="#">NFL League</a></li>
                          <li>12 Mar, 2020</li>
                        </ul>
                      </div>
                    </li>
                    <!--Story End-->
                    <!--Story Start-->
                    <li class="story-row">
                      <div class="ts-thumb"><img src="images/college_pics/side010.jpg" alt=""> </div>
                      <div class="ts-txt">
                        <h5> <a href="#">Toon stage injury-time come back at Everton </a>
                        </h5>
                        <ul class="tsw-meta">
                          <li><a href="#">NFL League</a></li>
                          <li>12 Mar, 2020</li>
                        </ul>
                      </div>
                    </li>
                    <!--Story End-->
                    <!--Story Start-->
                    <li class="story-row">
                      <div class="ts-thumb"><img src="images/college_pics/side010.jpg" alt=""> </div>
                      <div class="ts-txt">
                        <h5> <a href="#">League continues support for Rainbow Laces </a>
                        </h5>
                        <ul class="tsw-meta">
                          <li><a href="#">NFL League</a></li>
                          <li>12 Mar, 2020</li>
                        </ul>
                      </div>
                    </li>
                    <!--Story End-->
                    <!--Story Start-->
                    <li class="story-row">
                      <div class="ts-thumb"><img src="images/college_pics/side010.jpg" alt=""> </div>
                      <div class="ts-txt">
                        <h5> <a href="#">Tigers would’ve ‘loved’ to play for Tigers </a>
                        </h5>
                        <ul class="tsw-meta">
                          <li><a href="#">NFL League</a></li>
                          <li>12 Mar, 2020</li>
                        </ul>
                      </div>
                    </li>
                    <!--Story End-->
                  </ul>
                </div>
                <!--Slide 1 End-->
                <!--Slide 2 Start-->
                <div class="item">
                  <ul class="top-stories">
                    <!--Story Start-->
                    <li class="story-row">
                      <div class="ts-thumb"><img src="images/college_pics/side010.jpg" alt=""> </div>
                      <div class="ts-txt">
                        <h5> <a href="#">FC Champs will learn from Tigers mistake </a>
                        </h5>
                        <ul class="tsw-meta">
                          <li><a href="#">NFL League</a></li>
                          <li>12 Mar, 2020</li>
                        </ul>
                      </div>
                    </li>
                    <!--Story End-->
                    <!--Story Start-->
                    <li class="story-row">
                      <div class="ts-thumb"><img src="images/college_pics/side010.jpg" alt=""> </div>
                      <div class="ts-txt">
                        <h5> <a href="#">Toon stage injury-time come back at Everton </a>
                        </h5>
                        <ul class="tsw-meta">
                          <li><a href="#">NFL League</a></li>
                          <li>12 Mar, 2020</li>
                        </ul>
                      </div>
                    </li>
                    <!--Story End-->
                    <!--Story Start-->
                    <li class="story-row">
                      <div class="ts-thumb"><img src="images/college_pics/side010.jpg" alt=""> </div>
                      <div class="ts-txt">
                        <h5> <a href="#">Tigers would’ve ‘loved’ to play for Tigers </a>
                        </h5>
                        <ul class="tsw-meta">
                          <li><a href="#">NFL League</a></li>
                          <li>12 Mar, 2020</li>
                        </ul>
                      </div>
                    </li>
                    <!--Story End-->
                    <!--Story Start-->
                    <li class="story-row">
                      <div class="ts-thumb"><img src="images/college_pics/side010.jpg" alt=""> </div>
                      <div class="ts-txt">
                        <h5> <a href="#">Success is not Accident
                            it’s a Result of Hard Work </a>
                        </h5>
                        <ul class="tsw-meta">
                          <li><a href="#">NFL League</a></li>
                          <li>12 Mar, 2020</li>
                        </ul>
                      </div>
                    </li>
                    <!--Story End-->
                  </ul>
                </div>
                <!--Slide 2 End-->
                <!--Slide 3 Start-->
                <div class="item">
                  <ul class="top-stories">
                    <!--Story Start-->
                    <li class="story-row">
                      <div class="ts-thumb"><img src="images/college_pics/side010.jpg" alt=""> </div>
                      <div class="ts-txt">
                        <h5> <a href="#">Success is not Accident
                            it’s a Result of Hard Work </a>
                        </h5>
                        <ul class="tsw-meta">
                          <li><a href="#">NFL League</a></li>
                          <li>12 Mar, 2020</li>
                        </ul>
                      </div>
                    </li>
                    <!--Story End-->
                    <!--Story Start-->
                    <li class="story-row">
                      <div class="ts-thumb"><img src="images//college_pics/side010.jpg" alt=""> </div>
                      <div class="ts-txt">
                        <h5> <a href="#">Success is not Accident
                            it’s a Result of Hard Work </a>
                        </h5>
                        <ul class="tsw-meta">
                          <li><a href="#">NFL League</a></li>
                          <li>12 Mar, 2020</li>
                        </ul>
                      </div>
                    </li>
                    <!--Story End-->
                    <!--Story Start-->
                    <li class="story-row">
                      <div class="ts-thumb"><img src="images/college_pics/side010.jpg" alt=""> </div>
                      <div class="ts-txt">
                        <h5> <a href="#">Success is not Accident
                            it’s a Result of Hard Work </a>
                        </h5>
                        <ul class="tsw-meta">
                          <li><a href="#">NFL League</a></li>
                          <li>12 Mar, 2020</li>
                        </ul>
                      </div>
                    </li>
                    <!--Story End-->
                    <!--Story Start-->
                    <li class="story-row">
                      <div class="ts-thumb"><img src="images/college_pics/side010.jpg" alt=""> </div>
                      <div class="ts-txt">
                        <h5> <a href="#">Success is not Accident
                            it’s a Result of Hard Work </a>
                        </h5>
                        <ul class="tsw-meta">
                          <li><a href="#">NFL League</a></li>
                          <li>12 Mar, 2020</li>
                        </ul>
                      </div>
                    </li>
                    <!--Story End-->
                  </ul>
                </div>
                <!--Slide 3 End-->
              </div>
            </div>
          </div>
        </div>
        <!--widget end-->
        
      </div>
      <!--col end-->

    </div>
  </div>
</section>