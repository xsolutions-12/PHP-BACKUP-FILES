<section class="latestnews">
      <div class="comtainer-fluid">
        <div class="row" style="border-bottom: 1px solid #96B6C5;">
          <div class="col-md-2" style="background-color: #0e5587;color: white;">
            <div class="latestnewsbx">
              <h5 style="padding: 5px 0px 0px 30px;">Announcements:</h5>
            </div>
          </div>
          <div class="col-md-10">
            <div class="latestnewssrl">
              <marquee onmouseover="this.stop()" onmouseout="this.start()" style="margin-top: 7px;">
                <a target="_blank" href="#">
                  Welcome to the Government College of Physical Education, Kulundi, Sambalpur... <img src="images/new1.webp" alt="new" style="height: 20px;">
                  <!-- <img src="#" width="40" height="40"> -->
                </a> |
                <a target="_blank" href="#">
                  Welcome to the Government College of Physical Education, Kulundi, Sambalpur...<img src="images/new1.webp" alt="new" style="height: 20px;">
                  <!-- <img src="#" width="40" height="40"> -->
                </a> |
                <a target="_blank" href="">
                  Welcome to the Government College of Physical Education, Kulundi, Sambalpur...<img src="images/new1.webp" alt="new" style="height: 20px;">
                  <!-- <img src="#" width="40" height="40"> -->
                </a> |
                <a target="_blank" href="#">
                  Welcome to the Government College of Physical Education, Kulundi, Sambalpur...<img src="images/new1.webp" alt="new" style="height: 20px;">
                  <!-- <img src="#" width="40" height="40"> -->
                </a> |
                <a target="_blank" href="#">
                  Welcome to the Government College of Physical Education, Kulundi, Sambalpur...<img src="images/new1.webp" alt="new" style="height: 20px;">
                  <!-- <img src="#" width="40" height="40"> -->
                </a> |
                <a target="_blank" href="#">
                  Welcome to the Government College of Physical Education, Kulundi, Sambalpur...<img src="images/new1.webp" alt="new" style="height: 20px;">
                  <!-- <img src="" width="40" height="40"> -->
                </a> |
                <a target="_blank" href="#">
                  Welcome to the Government College of Physical Education, Kulundi, Sambalpur...<img src="images/new1.webp" alt="new" style="height: 20px;">
                  <!-- <img src="" width="40" height="40"> -->
                </a> |
                <a target="_blank" href="#">
                  Welcome to the Government College of Physical Education, Kulundi, Sambalpur...<img src="images/new1.webp" alt="new" style="height: 20px;">
                  <!-- <img src="" width="40" height="40"> -->
                </a> |
                <a target="_blank" href="#">
                  Welcome to the Government College of Physical Education, Kulundi, Sambalpur...<img src="images/new1.webp" alt="new" style="height: 20px;">
                  <!-- <img src="" width="40" height="40"> -->
                </a> |
                <a target="_blank" href="#">
                  Welcome to the Government College of Physical Education, Kulundi, Sambalpur...<img src="images/new1.webp" alt="new" style="height: 20px;">
                  <!-- <img src="" width="40" height="40"> -->
                </a> |
                <a target="_blank" href="#">
                  Welcome to the Government College of Physical Education, Kulundi, Sambalpur...<img src="images/new1.webp" alt="new" style="height: 20px;">
                  <!-- <img src="" width="40" height="40"> -->
                </a> |
                <a target="_blank" href="#">
                  Welcome to the Government College of Physical Education, Kulundi, Sambalpur...<img src="images/new1.webp" alt="new" style="height: 20px;">
                  <!-- <img src="" width="40" height="40"> -->
                </a> |
                <a target="_blank" href="">
                  Welcome to the Government College of Physical Education, Kulundi, Sambalpur...<img src="images/new1.webp" alt="new" style="height: 20px;">
                  <!-- <img src="" width="40" height="40"> -->
                </a> |
              </marquee>
            </div>
          </div>

        </div>

      </div>
    </section>