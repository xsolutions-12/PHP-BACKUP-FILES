<section class="wf100 h3-twitter">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div id="h3-twitter-slider" class="owl-carousel owl-theme">

              <!--Start-->
              <div class="item">
                <div class="h3-tweets"> <span class="tw-icon"><i class="fab fa-twitter"></i></span>
                  <h4>Jack Denly</h4>
                  <strong>@jack.denly</strong>
                  <p>Some people think football [soccer]is a matter of life and death. I don’t like that attitude. I can assure them it is much more serious than that.</p>
                </div>
              </div>
              <!--End-->

              <!--Start-->
              <div class="item">
                <div class="h3-tweets"> <span class="tw-icon"><i class="fab fa-twitter"></i></span>
                  <h4>Jack Denly</h4>
                  <strong>@jack.denly</strong>
                  <p>Some people think football [soccer]is a matter of life and death. I don’t like that attitude. I can assure them it is much more serious than that.</p>
                </div>
              </div>
              <!--End-->

              <!--Start-->
              <div class="item">
                <div class="h3-tweets"> <span class="tw-icon"><i class="fab fa-twitter"></i></span>
                  <h4>Jack Denly</h4>
                  <strong>@jack.denly</strong>
                  <p>Some people think football [soccer]is a matter of life and death. I don’t like that attitude. I can assure them it is much more serious than that.</p>
                </div>
              </div>
              <!--End-->

            </div>
          </div>
        </div>
      </div>
    </section>