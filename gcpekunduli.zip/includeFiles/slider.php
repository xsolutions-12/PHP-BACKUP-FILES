<div class="main-slider">
      <div class="home2-slider rev_slider_wrapper">
        <!-- START REVOLUTION SLIDER -->
        <div class="rev_slider_wrapper fullwidthbanner-container">
          <div id="rev-slider2" class="rev_slider fullwidthabanner">
            <ul>
              <li data-transition="fade"> <img src="images/college_pics/kulundi-sambalpur.jpeg" alt="" width="1920" height="750" data-bgposition="top center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="1"></li>
              <li data-transition="fade"> <img src="images/college_pics/pic001.jpg" alt="" width="1920" height="750" data-bgposition="top center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="1"></li>
              <li data-transition="fade"> <img src="images/college_pics/pic007.jpg" alt="" width="1920" height="750" data-bgposition="top center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="1"></li>
              <li data-transition="fade"> <img src="images/college_pics/pic003.jpg" alt="" width="1920" height="750" data-bgposition="top center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="1"></li>
              <li data-transition="fade"> <img src="images/college_pics/pic004.jpg" alt="" width="1920" height="750" data-bgposition="top center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="1"></li>
              <li data-transition="fade"> <img src="images/college_pics/pic005.jpg" alt="" width="1920" height="750" data-bgposition="top center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="1"></li>
              <li data-transition="fade"> <img src="images/college_pics/pic006.jpg" alt="" width="1920" height="750" data-bgposition="top center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="1"></li>
            </ul>
          </div>
        </div>
        <!-- END REVOLUTION SLIDER -->
      </div>
    </div>