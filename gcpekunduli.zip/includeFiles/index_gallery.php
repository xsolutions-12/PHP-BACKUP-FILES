<section class="wf100 p90 h3-match-gallery">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="h3-section-title"> <strong>Match Image Collection</strong>
              <h2>Match Image Collection</h2>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-9">
            <ul class="gallery-row">
              <li class="gall-cal">
                <div class="mgall-box">
                  <div class="mgall-caption"> <a href="gallery-3-col.php"><i class="fas fa-link"></i></a>
                    <h4>Our Champions</h4>
                  </div>
                  <img src="images/college_pics/pic009.jpg" alt="">
                </div>
                <div class="mgall-box">
                  <div class="mgall-caption"> <a href="gallery-3-col.php"><i class="fas fa-link"></i></a>
                    <h4>Our Champions</h4>
                  </div>
                  <img src="images/college_pics/pic0030.jpg" alt="">
                </div>
              </li>
              <li class="gall-cal">
                <div class="mgall-box">
                  <div class="mgall-caption"> <a href="gallery-3-col.php"><i class="fas fa-link"></i></a>
                    <h4>Our Champions</h4>
                  </div>
                  <img src="images/college_pics/pic012.jpg" alt="">
                </div>
              </li>
              <li class="gall-cal">
                <div class="mgall-box">
                  <div class="mgall-caption"> <a href="gallery-3-col.php"><i class="fas fa-link"></i></a>
                    <h4>Our Champions</h4>
                  </div>
                  <img src="images/college_pics/pic0040.jpg" alt="">
                </div>
                <div class="mgall-box">
                  <div class="mgall-caption"> <a href="gallery-3-col.php"><i class="fas fa-link"></i></a>
                    <h4>Our Champions</h4>
                  </div>
                  <img src="images/college_pics/pic0050.jpg" alt="">
                </div>
              </li>
            </ul>
          </div>
          <div class="col-lg-3 dnm"> <img src="images/college_pics/pic0130.jpg" alt=""> </div>
        </div>
      </div>
    </section>