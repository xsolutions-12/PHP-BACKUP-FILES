<section class="wf100 h3-team">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-sm-4">
                <div class="h3-section-title"> <strong>Awards / Honour</strong>
                    <h2>Awards</h2>
                </div>
            </div>
            <div class="col-md-6 col-sm-8">
                <nav>
                    <div class="nav" id="nav-tab" role="tablist">
                        <a class="nav-item nav-link active" id="nav-1-tab" data-toggle="tab" href="#nav-defenders" role="tab" aria-controls="nav-defenders" aria-selected="true">Arjuna Award</a>
                        <a class="nav-item nav-link" id="nav-2-tab" data-toggle="tab" href="#nav-gk" role="tab" aria-controls="nav-gk" aria-selected="false">Khel Ratna Award</a>
                        <!-- <a class="nav-item nav-link" id="nav-3-tab" data-toggle="tab" href="#nav-forwarders" role="tab" aria-controls="nav-forwarders" aria-selected="false">Forwarders</a> </div> -->
                </nav>
            </div>
        </div>
        <div class="tab-content wf100" id="nav-tabContent">
            <div class="tab-pane fade show active" id="nav-defenders" role="tabpanel" aria-labelledby="nav-1-tab">
                <div class="row">

                    <!--Player Start-->
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="lp-box">
                            <div class="lp-thumb"> <a class="vp" href="#">View Profile</a>
                                <img src="images/sports_new/Deep-Grace-Ekka.jpg" alt="">
                            </div>
                            <div class="lp-name">
                                <h4><a href="#" style="font-size: 20px;">Deep Grace Ekka</a></h4>
                                <strong>Hockey(2022)</strong>
                            </div>
                        </div>
                    </div>
                    <!--Player End-->

                    <!--Player Start-->
                    <!-- <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="lp-box">
                            <div class="lp-thumb"> <a class="vp" href="#">View Profile</a>
                                <ul class="lp-social">
                                    <li><a href="#" class="fb"><i class="fab fa-facebook-f"></i></a></li>
                                    <li><a href="#" class="tw"><i class="fab fa-twitter"></i></a></li>
                                    <li><a href="#" class="pin"><i class="fab fa-pinterest-p"></i></a></li>
                                    <li><a href="#" class="insta"><i class="fab fa-instagram"></i></a></li>
                                </ul>
                                <img src="images/sports_new/Pramod-Bhagat.jpg" alt="">
                            </div>
                            <div class="lp-name">
                                <h4><a href="#">Pramod Bhagat</a></h4>
                                <strong>Para-Badminton(2019)</strong>
                            </div>
                        </div>
                    </div> -->
                    <!--Player End-->

                    <!--Player Start-->
                    <!-- <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="lp-box">
                            <div class="lp-thumb"> <a class="vp" href="#">View Profile</a>
                                <ul class="lp-social">
                                    <li><a href="#" class="fb"><i class="fab fa-facebook-f"></i></a></li>
                                    <li><a href="#" class="tw"><i class="fab fa-twitter"></i></a></li>
                                    <li><a href="#" class="pin"><i class="fab fa-pinterest-p"></i></a></li>
                                    <li><a href="#" class="insta"><i class="fab fa-instagram"></i></a></li>
                                </ul>
                                <img src="images/sports_new/Ravi-Kumar.jpg" alt="">
                            </div>
                            <div class="lp-name">
                                <h4><a href="#">K.Ravi Kumar</a></h4>
                                <strong>Weightlifting(2010)</strong>
                            </div>
                        </div>
                    </div> -->
                    <!--Player End-->

                    <!--Player Start-->
                    <!-- <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="lp-box">
                            <div class="lp-thumb"> <a class="vp" href="#">View Profile</a>
                                <ul class="lp-social">
                                    <li><a href="#" class="fb"><i class="fab fa-facebook-f"></i></a></li>
                                    <li><a href="#" class="tw"><i class="fab fa-twitter"></i></a></li>
                                    <li><a href="#" class="pin"><i class="fab fa-pinterest-p"></i></a></li>
                                    <li><a href="#" class="insta"><i class="fab fa-instagram"></i></a></li>
                                </ul>
                                <img src="images/sports_new/ignesh.jpg" alt="">
                            </div>
                            <div class="lp-name">
                                <h4><a href="#">Ignace Tirkey</a></h4>
                                <strong>Hockey(2009)</strong>
                            </div>
                        </div>
                    </div> -->
                    <!--Player End-->
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="lp-box">
                            <div class="lp-thumb"> <a class="vp" href="#">View Profile</a>
                                <img src="images/sports_new/Dilip-Tirkey.jpg" alt="">
                            </div>
                            <div class="lp-name">
                                <h4><a href="#" style="font-size: 20px;">Padma Shri Dilip Tirkey</a></h4>
                                <strong>Hockey(2002)</strong>
                            </div>
                        </div>
                    </div>
                    <!--Player End-->
                    <!--Player Start-->
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="lp-box">
                            <div class="lp-thumb"> <a class="vp" href="#">View Profile</a>
                                <img src="images/sports_new/BirendraLakraAward.jpg" alt="">
                            </div>
                            <div class="lp-name">
                                <h4><a href="#" style="font-size: 20px;">Birendra Lakra</a></h4>
                                <strong>Hockey(2021)</strong>
                            </div>
                        </div>
                    </div>
                    <!--Player Start-->
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="lp-box">
                            <div class="lp-thumb"> <a class="vp" href="#">View Profile</a>
                                <img src="images/sports_new/dutee-chand-img.jpg" alt="">
                            </div>
                            <div class="lp-name">
                                <h4><a href="#" style="font-size: 20px;">Dutee Chanda</a></h4>
                                <strong>Athletics(2020)</strong>
                            </div>
                        </div>
                    </div>
                    <!--Player End-->
                </div>
                <!-- <div class="row" style="padding-top: 10px;">
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="lp-box">
                            <div class="lp-thumb"> <a class="vp" href="#">View Profile</a>
                                <ul class="lp-social">
                                    <li><a href="#" class="fb"><i class="fab fa-facebook-f"></i></a></li>
                                    <li><a href="#" class="tw"><i class="fab fa-twitter"></i></a></li>
                                    <li><a href="#" class="pin"><i class="fab fa-pinterest-p"></i></a></li>
                                    <li><a href="#" class="insta"><i class="fab fa-instagram"></i></a></li>
                                </ul>
                                <img src="images/sports_new/Dilip-Tirkey.jpg" alt="">
                            </div>
                            <div class="lp-name">
                                <h4><a href="#">Padma Shri Dilip Tirkey</a></h4>
                                <strong>Hockey(2002)</strong>
                            </div>
                        </div>
                    </div> -->
                    <!--Player End-->

                    <!--Player Start-->
                    <!-- <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="lp-box">
                            <div class="lp-thumb"> <a class="vp" href="#">View Profile</a>
                                <ul class="lp-social">
                                    <li><a href="#" class="fb"><i class="fab fa-facebook-f"></i></a></li>
                                    <li><a href="#" class="tw"><i class="fab fa-twitter"></i></a></li>
                                    <li><a href="#" class="pin"><i class="fab fa-pinterest-p"></i></a></li>
                                    <li><a href="#" class="insta"><i class="fab fa-instagram"></i></a></li>
                                </ul>
                                <img src="images/sports_new/bijay-k.jpg" alt="">
                            </div>
                            <div class="lp-name">
                                <h4><a href="#">Bijaya kumar Satapathy</a></h4>
                                <strong>Weightlifting(1982)</strong>
                            </div>
                        </div>
                    </div> -->
                    <!--Player End-->

                    <!--Player Start-->
                    <!-- <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="lp-box">
                            <div class="lp-thumb"> <a class="vp" href="#">View Profile</a>
                                <ul class="lp-social">
                                    <li><a href="#" class="fb"><i class="fab fa-facebook-f"></i></a></li>
                                    <li><a href="#" class="tw"><i class="fab fa-twitter"></i></a></li>
                                    <li><a href="#" class="pin"><i class="fab fa-pinterest-p"></i></a></li>
                                    <li><a href="#" class="insta"><i class="fab fa-instagram"></i></a></li>
                                </ul>
                                <img src="images/sports_new/AmitRohidasAward.jpg" alt="">
                            </div>
                            <div class="lp-name">
                                <h4><a href="#">Amit Rohidas</a></h4>
                                <strong>Hockey(2021)</strong>
                            </div>
                        </div>
                    </div> -->
                    <!--Player End-->

                    <!--Player Start-->
                    <!-- <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="lp-box">
                            <div class="lp-thumb"> <a class="vp" href="#">View Profile</a>
                                <ul class="lp-social">
                                    <li><a href="#" class="fb"><i class="fab fa-facebook-f"></i></a></li>
                                    <li><a href="#" class="tw"><i class="fab fa-twitter"></i></a></li>
                                    <li><a href="#" class="pin"><i class="fab fa-pinterest-p"></i></a></li>
                                    <li><a href="#" class="insta"><i class="fab fa-instagram"></i></a></li>
                                </ul>
                                <img src="images/sports_new/BirendraLakraAward.jpg" alt="">
                            </div>
                            <div class="lp-name">
                                <h4><a href="#">Birendra Lakra</a></h4>
                                <strong>Hockey(2021)</strong>
                            </div>
                        </div>
                    </div> -->
                    <!--Player End-->
                <!-- </div>
                <div class="row" style="padding-top: 10px;"> -->
                    <!--Player Start-->
                    <!-- <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="lp-box">
                            <div class="lp-thumb"> <a class="vp" href="#">View Profile</a>
                                <ul class="lp-social">
                                    <li><a href="#" class="fb"><i class="fab fa-facebook-f"></i></a></li>
                                    <li><a href="#" class="tw"><i class="fab fa-twitter"></i></a></li>
                                    <li><a href="#" class="pin"><i class="fab fa-pinterest-p"></i></a></li>
                                    <li><a href="#" class="insta"><i class="fab fa-instagram"></i></a></li>
                                </ul>
                                <img src="images/sports_new/dutee-chand-img.jpg" alt="">
                            </div>
                            <div class="lp-name">
                                <h4><a href="#">Dutee Chanda</a></h4>
                                <strong>Athletics(2020)</strong>
                            </div>
                        </div>
                    </div> -->
                    <!--Player End-->

                    <!--Player Start-->
                    <!-- <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="lp-box">
                            <div class="lp-thumb"> <a class="vp" href="#">View Profile</a>
                                <ul class="lp-social">
                                    <li><a href="#" class="fb"><i class="fab fa-facebook-f"></i></a></li>
                                    <li><a href="#" class="tw"><i class="fab fa-twitter"></i></a></li>
                                    <li><a href="#" class="pin"><i class="fab fa-pinterest-p"></i></a></li>
                                    <li><a href="#" class="insta"><i class="fab fa-instagram"></i></a></li>
                                </ul>
                                <img src="images/sports_new/jyoti.jpg" alt="">
                            </div>
                            <div class="lp-name">
                                <h4><a href="#">Jyoti Sunita Kullu</a></h4>
                                <strong>Hockey(2007)</strong>
                            </div>
                        </div>
                    </div> -->
                    <!--Player End-->

                    <!--Player Start-->
                    <!-- <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="lp-box">
                            <div class="lp-thumb"> <a class="vp" href="#">View Profile</a>
                                <ul class="lp-social">
                                    <li><a href="#" class="fb"><i class="fab fa-facebook-f"></i></a></li>
                                    <li><a href="#" class="tw"><i class="fab fa-twitter"></i></a></li>
                                    <li><a href="#" class="pin"><i class="fab fa-pinterest-p"></i></a></li>
                                    <li><a href="#" class="insta"><i class="fab fa-instagram"></i></a></li>
                                </ul>
                                <img src="images/sports_new/rachita.jpg" alt="">
                            </div>
                            <div class="lp-name">
                                <h4><a href="#">Rachita Mistri Panda</a></h4>
                                <strong>Athletics(1998)</strong>
                            </div>
                        </div>
                    </div> -->
                    <!--Player End-->

                    <!--Player Start-->
                    <!-- <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="lp-box">
                            <div class="lp-thumb"> <a class="vp" href="#">View Profile</a>
                                <ul class="lp-social">
                                    <li><a href="#" class="fb"><i class="fab fa-facebook-f"></i></a></li>
                                    <li><a href="#" class="tw"><i class="fab fa-twitter"></i></a></li>
                                    <li><a href="#" class="pin"><i class="fab fa-pinterest-p"></i></a></li>
                                    <li><a href="#" class="insta"><i class="fab fa-instagram"></i></a></li>
                                </ul>
                                <img src="images/sports_new/minati-m.jpg" alt="">
                            </div>
                            <div class="lp-name">
                                <h4><a href="#">Minati Mohapatra</a></h4>
                                <strong>Cycling(1980)</strong>
                            </div>
                        </div>
                    </div> -->
                    <!--Player End-->
                <!-- </div> -->
            </div>
            <div class="tab-pane fade" id="nav-gk" role="tabpanel" aria-labelledby="nav-2-tab">
                <div class="row">

                    <!--Player Start-->
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="lp-box">
                            <div class="lp-thumb"> <a class="vp" href="#">View Profile</a>
                                <img src="images/sports_new/Pramod-Bhagat.jpg" alt="">
                            </div>
                            <div class="lp-name">
                                <h4><a href="#">Pramod Bhagat</a></h4>
                                <strong>Para-Badminton(2019)</strong>
                            </div>
                        </div>
                    </div>
                    <!--Player End-->

                    <!--Player Start-->
                    <!-- <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="lp-box">
                            <div class="lp-thumb"> <a class="vp" href="#">View Profile</a>
                                <ul class="lp-social">
                                    <li><a href="#" class="fb"><i class="fab fa-facebook-f"></i></a></li>
                                    <li><a href="#" class="tw"><i class="fab fa-twitter"></i></a></li>
                                    <li><a href="#" class="pin"><i class="fab fa-pinterest-p"></i></a></li>
                                    <li><a href="#" class="insta"><i class="fab fa-instagram"></i></a></li>
                                </ul>
                                <img src="images/lp-img1.jpg" alt="">
                            </div>
                            <div class="lp-name">
                                <h4><a href="#">Kevin Rob</a></h4>
                                <strong>Defender</strong>
                            </div>
                        </div>
                    </div> -->
                    <!--Player End-->

                    <!--Player Start-->
                    <!-- <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="lp-box">
                            <div class="lp-thumb"> <a class="vp" href="#">View Profile</a>
                                <ul class="lp-social">
                                    <li><a href="#" class="fb"><i class="fab fa-facebook-f"></i></a></li>
                                    <li><a href="#" class="tw"><i class="fab fa-twitter"></i></a></li>
                                    <li><a href="#" class="pin"><i class="fab fa-pinterest-p"></i></a></li>
                                    <li><a href="#" class="insta"><i class="fab fa-instagram"></i></a></li>
                                </ul>
                                <img src="images/lp-img4.jpg" alt="">
                            </div>
                            <div class="lp-name">
                                <h4><a href="#">Smith Ross</a></h4>
                                <strong>Goal Keeper</strong>
                            </div>
                        </div>
                    </div> -->
                    <!--Player End-->

                    <!--Player Start-->
                    <!-- <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="lp-box">
                            <div class="lp-thumb"> <a class="vp" href="#">View Profile</a>
                                <ul class="lp-social">
                                    <li><a href="#" class="fb"><i class="fab fa-facebook-f"></i></a></li>
                                    <li><a href="#" class="tw"><i class="fab fa-twitter"></i></a></li>
                                    <li><a href="#" class="pin"><i class="fab fa-pinterest-p"></i></a></li>
                                    <li><a href="#" class="insta"><i class="fab fa-instagram"></i></a></li>
                                </ul>
                                <img src="images/lp-img3.jpg" alt="">
                            </div>
                            <div class="lp-name">
                                <h4><a href="#">Aden Hezard</a></h4>
                                <strong>Forwarder</strong>
                            </div>
                        </div>
                    </div> -->
                    <!--Player End-->

                </div>
            </div>
            <!-- <div class="tab-pane fade" id="nav-forwarders" role="tabpanel" aria-labelledby="nav-3-tab">
                <div class="row">

                 
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="lp-box">
                            <div class="lp-thumb"> <a class="vp" href="#">View Profile</a>
                                <ul class="lp-social">
                                    <li><a href="#" class="fb"><i class="fab fa-facebook-f"></i></a></li>
                                    <li><a href="#" class="tw"><i class="fab fa-twitter"></i></a></li>
                                    <li><a href="#" class="pin"><i class="fab fa-pinterest-p"></i></a></li>
                                    <li><a href="#" class="insta"><i class="fab fa-instagram"></i></a></li>
                                </ul>
                                <img src="images/lp-img1.jpg" alt="">
                            </div>
                            <div class="lp-name">
                                <h4><a href="#">Aden Hezard</a></h4>
                                <strong>Defender</strong>
                            </div>
                        </div>
                    </div>
                
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="lp-box">
                            <div class="lp-thumb"> <a class="vp" href="#">View Profile</a>
                                <ul class="lp-social">
                                    <li><a href="#" class="fb"><i class="fab fa-facebook-f"></i></a></li>
                                    <li><a href="#" class="tw"><i class="fab fa-twitter"></i></a></li>
                                    <li><a href="#" class="pin"><i class="fab fa-pinterest-p"></i></a></li>
                                    <li><a href="#" class="insta"><i class="fab fa-instagram"></i></a></li>
                                </ul>
                                <img src="images/lp-img2.jpg" alt="">
                            </div>
                            <div class="lp-name">
                                <h4><a href="#">Aden Hezard</a></h4>
                                <strong>League Captain</strong>
                            </div>
                        </div>
                    </div>
              
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="lp-box">
                            <div class="lp-thumb"> <a class="vp" href="#">View Profile</a>
                                <ul class="lp-social">
                                    <li><a href="#" class="fb"><i class="fab fa-facebook-f"></i></a></li>
                                    <li><a href="#" class="tw"><i class="fab fa-twitter"></i></a></li>
                                    <li><a href="#" class="pin"><i class="fab fa-pinterest-p"></i></a></li>
                                    <li><a href="#" class="insta"><i class="fab fa-instagram"></i></a></li>
                                </ul>
                                <img src="images/lp-img3.jpg" alt="">
                            </div>
                            <div class="lp-name">
                                <h4><a href="#">Aden Hezard</a></h4>
                                <strong>Forwarder</strong>
                            </div>
                        </div>
                    </div>
                 
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="lp-box">
                            <div class="lp-thumb"> <a class="vp" href="#">View Profile</a>
                                <ul class="lp-social">
                                    <li><a href="#" class="fb"><i class="fab fa-facebook-f"></i></a></li>
                                    <li><a href="#" class="tw"><i class="fab fa-twitter"></i></a></li>
                                    <li><a href="#" class="pin"><i class="fab fa-pinterest-p"></i></a></li>
                                    <li><a href="#" class="insta"><i class="fab fa-instagram"></i></a></li>
                                </ul>
                                <img src="images/lp-img4.jpg" alt="">
                            </div>
                            <div class="lp-name">
                                <h4><a href="#">Aden Hezard</a></h4>
                                <strong>Goal Keeper</strong>
                            </div>
                        </div>
                    </div>
                  

                </div>
            </div> -->
        </div>
    </div>
</section>