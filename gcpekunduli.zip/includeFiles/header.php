<header id="main-header" class="main-header white-header">
  <!--topbar-->
  <div class="topbar" style="padding: 0 5px;">
    <div class="container-fluid">
      <div class="row">
        <!--<div class="col-md-6 col-sm-6">-->

        <!--</div>-->
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="text-align:end;">
          <ul class="topsocial">
            <li><a href="#" class="fb"><i class="fab fa-facebook-f"></i></a></li>
            <li><a href="#" class="insta"><i class="fab fa-instagram"></i></a></li>
            <li><a href="#" class="yt"><i class="fab fa-youtube"></i></a></li>
          </ul>

        </div>
      </div>
    </div>
  </div>
  <!--topbar end-->

  <!--Logo + Navbar Start-->
  <div class="logo-navbar govt-logo">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12 col-sm-5">
          <div class="logo logo-pic">
            <a href="index.php">
              <img class="img-pic" src="images/college_pics/logopic01.jpg" alt="" style="image-rendering: high-quality;">
              <img class="img-side" src="images/image100.jpg" alt="image" style="position:absolute;">
            </a>
          </div>
        </div>
        
      </div>
    </div>
  </div>
  <!--Logo + Navbar End-->

  <!--Logo + Navbar Start-->
  <div class="logo-navbar low-nav" style="display: contents;">
    <div class="container-fluid">
      <div class="row" style="background-color: #00406e;">
        <!-- <div class="col-md-2 col-sm-5">
              <div class="logo"><a href="index.php"><img src="images/logo-dark.png" alt=""></a></div>
            </div> -->
        <div class="col-md-12 col-sm-12" style="margin-left: 60px;">
        <nav class="main-nav">
          <ul>
            <li class="nav-item"> <a href="index.php">Home</a>
            </li>
            <li class="nav-item drop-down"> <a href="">About</a>
              <ul>
                <li><a href="aboutUs.php">About Us</a></li>
                <li><a href="principalDesk.php">Principal's Desk</a></li>
                <li><a href="staffDetails.php">Staff Details</a></li>
                <li><a href="gallery-3-col.php">Image Gallery</a></li>
              </ul>
            </li>
            <!-- <li class="nav-item drop-down">
              <a href="organization.php">Organization</a>
            </li> -->
            <li class="nav-item drop-down"> <a href="">Academics</a>
              <ul>
                <li class=" drop-down"><a href="#">Courses</a>
                <ul>
                  <li><a href="#">Course...1</a></li>
                  <li><a href="#">Course...2</a></li>
                  <li><a href="#">Course...3</a></li>
                  <li><a href="#">Course...4</a></li>
                </ul>
              </li><!-- B.P.Ed- Bachelor of Physical Education-->
                <li><a href="results.php">Results</a></li>
                <li><a href="seminar.php">Seminars</a></li>
                <li><a href="research.php">Research Activities</a></li>
              </ul>
            </li>

            <li class="nav-item drop-down"> <a href="">Facilities</a>
              <ul>
                <li><a href="instructional_Facilities.php">Instructional facility</a></li>
                <li><a href="infrastructure.php">Infrastructure</a></li>
              </ul>
            </li>


            <li class="nav-item drop-down"> <a href="">Information</a>
              <ul>
              <li><a href="journals.php">Journal</a></li>
              <li><a href="campusNews.php">Campus News</a></li>
              <li><a href="tenderDetails.php">Tender</a></li>
              <li><a href="notice.php">Notice</a></li>
              <li><a href="document.php">Documents</a></li>
              <li><a href="forms_&_Prospectus.php">Forms & Prospectus</a></li>
              </ul>
            </li>
            
            <li class="nav-item drop-down"> <a href="#">Career</a> 
              <ul>
              <li><a href="aluminiAssociation.php">Alumini Association</a></li>
              <li><a href="jobOpportunity.php">Job Opportunity</a></li>
              </ul>
            </li>
            <li class="nav-item drop-down">
              <a href="mandatory_Disclosure.php">Mandatory Discloser</a>
            </li>

            <li class="nav-item drop-down">
              <a href="#">Contact</a>
              <ul>
              <!-- <li><a href="#">Location</a></li>
              <li><a href="#">Mail</a></li> -->
              <li><a href="contact.php">Contact Us</a></li>
            </li>
          </ul>
        </nav>

        </div>
      </div>
    </div>
  </div>
  <!--Logo + Navbar End-->
</header>