<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="images/logopic01.jpg" type="image/png">
    <!-- Bootstrap CSS -->
    <?php include('includeFiles/cssFiles.php') ?>
    <!--Rev Slider End-->
    <title>Government College of Physical Education, Kulundi, Sambalpur</title>
</head>

<body>
    <!--Wrapper Start-->
    <div class="wrapper">
        <!--Header Start-->
        <!--Header Start-->
        <?php include('includeFiles/header.php') ?>
        <!--Header End-->
        <!--Main Slider Start-->
        <div class="inner-banner-header wf100">
            <h1 data-generated="Mandatory Discloser">Mandatory Discloser</h1>
            <div class="gt-breadcrumbs">
                <ul>
                    <li> <a href="index.php" class="active"> <i class="fas fa-home"></i> Home </a> </li>
                    <li> <a href="mandatory_Disclosure.php"> Mandatory Discloser </a> </li>
                </ul>
            </div>
        </div>

        <!--Main Slider Start-->
        <!--Main Content Start-->
        <section class="wf100 featured-news p90">
            <div class="container">
                <div class="row">

                    <!--col start-->
                    <div class="col-lg-12">
                        <div class="h3-section-title">
                            <!-- <strong style="color:white">featured News</strong> -->
                            <h2 style="color:black">Mandatory Discloser</h2>
                        </div>

                        <!--news start-->
                        <div class="news-list-post">
                           

                            <div class="post-txt" style="height: 500px;width:888px;text-align: justify;">
                                <a href="#" style="color: black;">This page is under Construction</a><br>
                            </div>


                        </div>


                    </div>
                    <!--col end-->



                </div>
            </div>
        </section>
        <!--Main Content End-->
        <!--Main Footer Start-->
        <?php include('includeFiles/footer.php') ?>
        <!--Main Footer End-->
    </div>
    <!--Wrapper End-->
    <!-- Optional JavaScript -->
    <?php include('includeFiles/scriptFile.php') ?>
</body>

</html>