<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="icon" href="images/logopic01.jpg" type="image/png">
  <!-- Bootstrap CSS -->
  <?php include('includeFiles/cssFiles.php') ?>
  <!--Rev Slider End-->
  <title>Government College of Physical Education, Kulundi, Sambalpur</title>
  <style>
    @media screen and (max-width: 500px) {

      .logo-pic,
      .img-pic {
        max-width: 300px;
      }

      .main-header,
      .low-nav {
        height: 150px !important;
        background-color: #ffff;
      }

      .img-side {
        position: absolute;
        top: 160px;
        left: -65rem;
        max-height: 65px;
      }
    }

    .logo-pic,
    .img-pic {
      width: 500px;
    }

    @media screen and (min-width:1500px) {

      .main-header,
      .low-nav {
        background-color: #0a4066 !important;
      }
    }

    .govt-logo {
      height: 90px;
    }

    #overflowTest {
      color: white;
      padding: 15px;
      height: 500px;
      overflow: auto;
      border: 1px solid #ccc;
    }

    .post-txt {
      color: black;
    }

    a {
      color: red;
    }
  </style>
</head>

<body>
  <!--Wrapper Start-->
  <div class="wrapper gray-bg">

   

    <!--Header Start-->
    <?php include('includeFiles/header.php') ?>
    <!--Header End-->
    <!--Main Slider Start-->
    <?php include('includeFiles/slider.php') ?>
    <!--Main Slider Start-->
    <!--Announcement section-->
    <?php include('includeFiles/announcement.php') ?>
    <!--Announcement section End-->
    <!--About Start-->
    <?php include('includeFiles/about.php') ?>
    <!--About SUCCESS End-->
    <!--TEAM SUCCESS Start-->
    <section class="wf100 teams-video p90">
      <?php include('includeFiles/featuredNews.php') ?>
    </section>

    <!--TEAM SUCCESS End-->

    <!-- Administration Start-->
    <?php include('includeFiles/administrations.php') ?>
    <!-- Administration End-->

    <!--News & Updates Start-->
    <?php include('includeFiles/Infrastructure.php') ?>
    <!--News & Updates End-->

    <!--Gallery Start-->
    <?php include('includeFiles/index_gallery.php') ?>
    <!--Gallery End-->

    <!--Twitter Slider Start-->
    <?php include('includeFiles/twitter.php') ?>
    <!--Twitter Slider End-->

    <!--Awards Section Start-->
    <?php include('includeFiles/awards.php') ?>
    <!--Awords Section End-->

  </div>

  <!--Main Footer Start-->
  <?php include('includeFiles/footer.php') ?>
  <!--Main Footer End-->
  <!--Wrapper End-->
  <!-- Optional JavaScript -->
  <?php include('includeFiles/scriptFile.php') ?>
</body>

</html>