<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="images/fav.png" type="image/png">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/custom.css">
    <link rel="stylesheet" href="css/responsive.css">
    <link rel="stylesheet" href="css/color.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/fontawesome.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/prettyPhoto.css">
    <link rel="stylesheet" href="css/audioplayer.css">
    <title>Tigers Sports HTML Template</title>
  </head>
  <body>
    <!--Wrapper Start-->
    <div class="wrapper">
      <!--Header Start-->
      <!--Header Start-->
    <?php include('includeFiles/header.php') ?>
      <!--Header End--> 
      <!--Main Slider Start-->
      <div class="inner-banner-header wf100">
        <h1 data-generated="News Large">News Details</h1>
        <div class="gt-breadcrumbs">
          <ul>
            <li> <a href="#" class="active"> <i class="fas fa-home"></i> Home </a> </li>
            <li> <a href="#"> News </a> </li>
            <li> <a href="#"> News Details </a> </li>
          </ul>
        </div>
      </div>
      <!--Main Slider Start--> 
      <!--Main Content Start-->
      <div class="main-content innerpagebg wf100 p80">
        <!--News Large Page Start--> 
        <!--Start-->
        <div class="news-details">
          <div class="container">
            <div class="row">
              <!--News Start-->
              <div class="col-lg-8">
                <div class="news-details-wrap">
                  <div class="news-large-post">
                    <div class="post-thumb"> <img src="images/nlarge2.jpg" alt=""></div>
                    <div class="post-txt">
                      <h3>The will to prepare to win that makes the difference</h3>
                      <ul class="post-meta">
                        <li><i class="fas fa-user"></i> Phillips Hunt</li>
                        <li><i class="fas fa-calendar-alt"></i> 27 June, 2020</li>
                        <li><i class="far fa-comment"></i> 89 Comments</li>
                        <li><i class="far fa-heart"></i> 52 Likes</li>
                      </ul>
                      <p> Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Mauris in leo pretium neque ullamcorper volutpat a in sapien. Aenean ut nulla a urna gravida eleifend nec eu tortor. Phasellus euismod ligula in quam porta hendrerit. <strong>Proin sit amet tincidu ex, eget iaculis enim. Donec viverra pulvinar est et gravida.</strong> In elementum, lectus sit amet finibus facilisis, felis ligula feugiat turpis, a facilisis neque magna a lorem. Mauris varius dui quis turpis sollicitudin mattis sed vitae arcu. Sed tincidunt ac turpis sed rutrum.</p>
                      <p>Proin cursus commodo odio dignissim sollicitudin. Donec porta mi ut justo efficitur urna gravida. Integer in molestie ante, et feugiat erat. Praesent a rutrum nulla vitae conseqt turpis. Phasellus elementum massa non justo volutpat consequat. Cras vulputate et leo in scelerisque. </p>
                      <blockquote>
                        <p>wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat</p>
                      </blockquote>
                      <p> Maecenas porta dui sit amet libero bibendum pellentesque. Pellentesque ac lorem diam. Quisque in commodo nibh, et varius magna. Pellentesque congue eros ac justo suscipit congue. Praesent non sagittis est. Nam vehicula erat mollis libero accumsan blandit. Sed quam neque, condimentum at ultricies et, faucibus consequat orci. </p>
                      <h4>Donec tempor tristique velit ut consequat nceu.</h4>
                      <p> Mauris rutrum sit amet mauris at sodales. Vivamus laoreet tempus purus molestie. Aenean fringilla est ac egestas dapibus. Donec ut iaculis ipsum, elementum molestie metus. Donec pharetra non eros quis rhoncus. Vivamus ex ligula, auctor eu feugiat elementum.</p>
                      <ul class="checklist">
                        <li><i class="fas fa-check"></i> Aliquam eget tellus sed dolor accumsan imperdiet. </li>
                        <li><i class="fas fa-check"></i> Nunc interdum arcu vel massa faucibus imperdiet. </li>
                        <li><i class="fas fa-check"></i> Vestibulum sollicitudin odio nec faucibus venenatis. </li>
                        <li><i class="fas fa-check"></i> Etiam iaculis nunc et iaculis sodales. </li>
                      </ul>
                      <ul class="small-gallery">
                        <li><img src="images/ndimg1.jpg" alt=""></li>
                        <li><img src="images/ndimg2.jpg" alt=""></li>
                        <li><img src="images/ndimg3.jpg" alt=""></li>
                      </ul>
                    </div>
                    <div class="post-bottom">
                      <!--Post Tags start-->
                      <ul class="post-tags">
                        <li><a href="#">World cup</a></li>
                        <li><a href="#">Awards</a></li>
                        <li><a href="#">Football</a></li>
                        <li><a href="#">champion Leauge</a></li>
                        <li><a href="#">Soccer</a></li>
                        <li><a href="#">Sports News</a></li>
                      </ul>
                      <!--Post Tags End--> 
                      <!--Author Box Start-->
                      <div class="post-author-box">
                        <img src="images/postauthor.jpg" alt="">
                        <h4>About Author</h4>
                        <p> Curabitur imperdiet ante non vehicula condimentum. Suspendisse id enim iaculis, maximus mi id, sodales dui. Aenean quis neque rutrum, dignissim nunc vestibulum, suscipit arcu. Quisque ullamcorper quis nibh sed. </p>
                      </div>
                      <!--Author Box End--> 
                      <!--Post Comments Start-->
                      <div class="post-comments">
                        <h3 class="stitle">Comments on Post (03)</h3>
                        <ul class="comments">
                          <li class="comment">
                            <div class="user-thumb"><img src="images/cuser1.jpg" alt=""></div>
                            <div class="user-comments">
                              <h6 class="aname">Mason Gray</h6>
                              <ul class="post-time">
                                <li>Posted: 09 July, 2020 at 2:37 pm</li>
                                <li><a href="#"><i class="fas fa-reply"></i> review</a></li>
                              </ul>
                              <p>Many communities in the disease zones have inadequate sanitation that allow frequent trash piles and open sewers to serve as mosquito breeding and feeding grounds, according to the final outcome statement from the Aedes aegypti summit last month.</p>
                            </div>
                            <ul class="child-comments">
                              <li class="comment">
                                <div class="user-thumb"><img src="images/cuser2.jpg" alt=""></div>
                                <div class="user-comments">
                                  <h6 class="aname">Johny Elite</h6>
                                  <ul class="post-time">
                                    <li>Posted: 09 July, 2020 at 2:37 pm</li>
                                    <li><a href="#"><i class="fas fa-reply"></i> review</a></li>
                                  </ul>
                                  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam viverra euismod odio, gravida pellentesque urna varius vitae, gravida pellentesque urna varius vitae.</p>
                                </div>
                              </li>
                              <li class="comment">
                                <div class="user-thumb"><img src="images/cuser3.jpg" alt=""></div>
                                <div class="user-comments">
                                  <h6 class="aname">Rog Kelly</h6>
                                  <ul class="post-time">
                                    <li>Posted: 09 July, 2020 at 2:37 pm</li>
                                    <li><a href="#"><i class="fas fa-reply"></i> review</a></li>
                                  </ul>
                                  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam viverra euismod odio, gravida pellentesque urna varius vitae, gravida pellentesque urna varius vitae.</p>
                                </div>
                              </li>
                            </ul>
                          </li>
                          <li class="comment">
                            <div class="user-thumb"><img src="images/cuser4.jpg" alt=""></div>
                            <div class="user-comments">
                              <h6 class="aname">James Warson</h6>
                              <ul class="post-time">
                                <li>Posted: 09 July, 2020 at 2:37 pm</li>
                                <li><a href="#"><i class="fas fa-reply"></i> review</a></li>
                              </ul>
                              <p>Many communities in the disease zones have inadequate sanitation that allow frequent trash piles and open sewers to serve as mosquito breeding and feeding grounds.</p>
                            </div>
                          </li>
                        </ul>
                      </div>
                      <!--Post Comments End--> 
                      <!--comments form Start-->
                      <div class="post-comments-form">
                        <h3 class="stitle">Leave a Comment</h3>
                        <ul>
                          <li class="half-col">
                            <input type="text" placeholder="Full Name">
                          </li>
                          <li class="half-col">
                            <input type="text" placeholder="Email">
                          </li>
                          <li class="full-col">
                            <textarea placeholder="Write Comments"></textarea>
                          </li>
                          <li class="full-col">
                            <input type="submit" value="Post Your Comment">
                          </li>
                        </ul>
                      </div>
                      <!--comments form End--> 
                    </div>
                  </div>
                </div>
              </div>
              <!--News End--> 
              <!--Sidebar Start-->
              <div class="col-lg-4">
                <div class="sidebar">
                  <!--widget start-->
                  <div class="widget sidebar-ad"> <img src="images/sidelbanner.png" alt=""> </div>
                  <!--widget end--> 
                  <!--widget start-->
                  <div class="widget">
                    <h4>Featured Videos</h4>
                    <div class="featured-video-widget">
                      <div class="fvideo-box mb15">
                        <div class="fvid-cap">
                          <a class="vicon" href="#"><img src="images/play.png" alt=""></a>
                          <div class="fvid-right">
                            <h5><a href="#">Success is a Result of Hard Work </a></h5>
                            <span><i class="far fa-clock"></i> 4:32</span> <span><i class="far fa-eye"></i> 174</span> 
                          </div>
                        </div>
                        <img src="images/fvid1.jpg" alt=""> 
                      </div>
                      <div class="fvideo-box">
                        <div class="fvid-cap">
                          <a class="vicon" href="#"><img src="images/play.png" alt=""></a>
                          <div class="fvid-right">
                            <h5><a href="#">Success is a Result of Hard Work </a></h5>
                            <span><i class="far fa-clock"></i> 4:32</span> <span><i class="far fa-eye"></i> 174</span>
                          </div>
                        </div>
                        <img src="images/fvid2.jpg" alt=""> 
                      </div>
                    </div>
                  </div>
                  <!--widget end--> 
                  <!--widget start-->
                  <div class="widget">
                    <h4>Top Stories</h4>
                    <div class="top-stories-widget">
                      <div id="top-stories" class="owl-carousel owl-theme">
                        <!--Slide 1 Start-->
                        <div class="item">
                          <ul class="top-stories">
                            <!--Story Start-->
                            <li class="story-row">
                              <div class="ts-thumb"><img src="images/tsimg1.jpg" alt=""> </div>
                              <div class="ts-txt">
                                <h5> <a href="#">Success is not Accident it’s a Result of Hard Work </a> 
                                </h5>
                                <ul class="tsw-meta">
                                  <li><a href="#">NFL League</a></li>
                                  <li>12 Mar, 2020</li>
                                </ul>
                              </div>
                            </li>
                            <!--Story End--> 
                            <!--Story Start-->
                            <li class="story-row">
                              <div class="ts-thumb"><img src="images/tsimg1.jpg" alt=""> </div>
                              <div class="ts-txt">
                                <h5> <a href="#">Toon stage injury-time come back at Everton </a> 
                                </h5>
                                <ul class="tsw-meta">
                                  <li><a href="#">NFL League</a></li>
                                  <li>12 Mar, 2020</li>
                                </ul>
                              </div>
                            </li>
                            <!--Story End--> 
                            <!--Story Start-->
                            <li class="story-row">
                              <div class="ts-thumb"><img src="images/tsimg1.jpg" alt=""> </div>
                              <div class="ts-txt">
                                <h5> <a href="#">League continues support for Rainbow Laces </a> 
                                </h5>
                                <ul class="tsw-meta">
                                  <li><a href="#">NFL League</a></li>
                                  <li>12 Mar, 2020</li>
                                </ul>
                              </div>
                            </li>
                            <!--Story End--> 
                            <!--Story Start-->
                            <li class="story-row">
                              <div class="ts-thumb"><img src="images/tsimg1.jpg" alt=""> </div>
                              <div class="ts-txt">
                                <h5> <a href="#">Tigers would’ve ‘loved’ to play for Tigers </a> 
                                </h5>
                                <ul class="tsw-meta">
                                  <li><a href="#">NFL League</a></li>
                                  <li>12 Mar, 2020</li>
                                </ul>
                              </div>
                            </li>
                            <!--Story End-->
                          </ul>
                        </div>
                        <!--Slide 1 End--> 
                        <!--Slide 2 Start-->
                        <div class="item">
                          <ul class="top-stories">
                            <!--Story Start-->
                            <li class="story-row">
                              <div class="ts-thumb"><img src="images/tsimg1.jpg" alt=""> </div>
                              <div class="ts-txt">
                                <h5> <a href="#">FC Champs will learn from Tigers mistake </a> 
                                </h5>
                                <ul class="tsw-meta">
                                  <li><a href="#">NFL League</a></li>
                                  <li>12 Mar, 2020</li>
                                </ul>
                              </div>
                            </li>
                            <!--Story End--> 
                            <!--Story Start-->
                            <li class="story-row">
                              <div class="ts-thumb"><img src="images/tsimg1.jpg" alt=""> </div>
                              <div class="ts-txt">
                                <h5> <a href="#">Toon stage injury-time come back at Everton </a> 
                                </h5>
                                <ul class="tsw-meta">
                                  <li><a href="#">NFL League</a></li>
                                  <li>12 Mar, 2020</li>
                                </ul>
                              </div>
                            </li>
                            <!--Story End--> 
                            <!--Story Start-->
                            <li class="story-row">
                              <div class="ts-thumb"><img src="images/tsimg1.jpg" alt=""> </div>
                              <div class="ts-txt">
                                <h5> <a href="#">Tigers would’ve ‘loved’ to play for Tigers </a> 
                                </h5>
                                <ul class="tsw-meta">
                                  <li><a href="#">NFL League</a></li>
                                  <li>12 Mar, 2020</li>
                                </ul>
                              </div>
                            </li>
                            <!--Story End--> 
                            <!--Story Start-->
                            <li class="story-row">
                              <div class="ts-thumb"><img src="images/tsimg1.jpg" alt=""> </div>
                              <div class="ts-txt">
                                <h5> <a href="#">Success is not Accident
                                  it’s a Result of Hard Work </a> 
                                </h5>
                                <ul class="tsw-meta">
                                  <li><a href="#">NFL League</a></li>
                                  <li>12 Mar, 2020</li>
                                </ul>
                              </div>
                            </li>
                            <!--Story End-->
                          </ul>
                        </div>
                        <!--Slide 2 End--> 
                        <!--Slide 3 Start-->
                        <div class="item">
                          <ul class="top-stories">
                            <!--Story Start-->
                            <li class="story-row">
                              <div class="ts-thumb"><img src="images/tsimg1.jpg" alt=""> </div>
                              <div class="ts-txt">
                                <h5> <a href="#">Success is not Accident
                                  it’s a Result of Hard Work </a> 
                                </h5>
                                <ul class="tsw-meta">
                                  <li><a href="#">NFL League</a></li>
                                  <li>12 Mar, 2020</li>
                                </ul>
                              </div>
                            </li>
                            <!--Story End--> 
                            <!--Story Start-->
                            <li class="story-row">
                              <div class="ts-thumb"><img src="images/tsimg1.jpg" alt=""> </div>
                              <div class="ts-txt">
                                <h5> <a href="#">Success is not Accident
                                  it’s a Result of Hard Work </a> 
                                </h5>
                                <ul class="tsw-meta">
                                  <li><a href="#">NFL League</a></li>
                                  <li>12 Mar, 2020</li>
                                </ul>
                              </div>
                            </li>
                            <!--Story End--> 
                            <!--Story Start-->
                            <li class="story-row">
                              <div class="ts-thumb"><img src="images/tsimg1.jpg" alt=""> </div>
                              <div class="ts-txt">
                                <h5> <a href="#">Success is not Accident
                                  it’s a Result of Hard Work </a> 
                                </h5>
                                <ul class="tsw-meta">
                                  <li><a href="#">NFL League</a></li>
                                  <li>12 Mar, 2020</li>
                                </ul>
                              </div>
                            </li>
                            <!--Story End--> 
                            <!--Story Start-->
                            <li class="story-row">
                              <div class="ts-thumb"><img src="images/tsimg1.jpg" alt=""> </div>
                              <div class="ts-txt">
                                <h5> <a href="#">Success is not Accident
                                  it’s a Result of Hard Work </a> 
                                </h5>
                                <ul class="tsw-meta">
                                  <li><a href="#">NFL League</a></li>
                                  <li>12 Mar, 2020</li>
                                </ul>
                              </div>
                            </li>
                            <!--Story End-->
                          </ul>
                        </div>
                        <!--Slide 3 End--> 
                      </div>
                    </div>
                  </div>
                  <!--widget end--> 
                  <!--widget start-->
                  <div class="widget">
                    <h4>Upcoming Match </h4>
                    <div class="last-match-widget">
                      <p> <strong>Super Asia Cup</strong> 18 Dec. 2018  |  04:00-07:00 </p>
                      <ul class="match-teams-vs">
                        <li class="team-logo"><img src="images/nmf-logo1.png" alt=""> <strong>FC Champs</strong> </li>
                        <li class="mvs"> <span class="vs">VS</span> </li>
                        <li class="team-logo"><img src="images/nmf-logo2.png" alt=""> <strong>Tigers</strong> </li>
                      </ul>
                      <p class="mloc"> <i class="fas fa-location-arrow"></i> Expo Center Stadium</p>
                      <div class="defaultCountdown"></div>
                      <div class="buyticket-btn"><a href="#">Buy Ticket</a></div>
                    </div>
                  </div>
                  <!--widget start--> 
                  <!--widget start-->
                  <div class="widget">
                    <h4>Team Player</h4>
                    <div class="team-squad-box">
                      <span class="star-tag"><i class="fas fa-star"></i></span> <a href="#" class="follow">Follow</a>
                      <div class="ts-cap">
                        <h4>Ramsy Geordion</h4>
                        <p>League Captain</p>
                        <ul>
                          <li>29 <span>Age</span></li>
                          <li>87 <span>matches</span></li>
                          <li>113 <span>Goals</span></li>
                          <li>87 <span>matches</span></li>
                        </ul>
                      </div>
                      <img src="images/tplayer5.jpg" alt=""> 
                    </div>
                  </div>
                  <!--widget start--> 
                  <!--widget start-->
                  <div class="widget">
                    <h4>Online Products</h4>
                    <div class="side-products">
                      <div id="side-products" class="owl-carousel owl-theme">
                        <!--Item Start-->
                        <div class="item">
                          <div class="pro-box">
                            <div class="pro-thumb"> <a href="#"><i class="fas fa-link"></i></a> <a href="#" class="a2cart"><i class="fas fa-shopping-basket"></i></a><img src="images/pro2.jpg" alt=""> </div>
                            <div class="pro-txt">
                              <h4> <a href="#">Sports Team T-Shirt</a> </h4>
                              <p class="price"> <del>£20.00</del> <strong>£17.50</strong> </p>
                            </div>
                          </div>
                        </div>
                        <!--Item End--> 
                        <!--Item Start-->
                        <div class="item">
                          <div class="pro-box">
                            <div class="pro-thumb"> <a href="#"><i class="fas fa-link"></i></a> <a href="#" class="a2cart"><i class="fas fa-shopping-basket"></i></a><img src="images/pro2.jpg" alt=""> </div>
                            <div class="pro-txt">
                              <h4> <a href="#">Sports Team T-Shirt</a> </h4>
                              <p class="price"> <del>£20.00</del> <strong>£17.50</strong> </p>
                            </div>
                          </div>
                        </div>
                        <!--Item End--> 
                        <!--Item Start-->
                        <div class="item">
                          <div class="pro-box">
                            <div class="pro-thumb"> <a href="#"><i class="fas fa-link"></i></a> <a href="#" class="a2cart"><i class="fas fa-shopping-basket"></i></a><img src="images/pro2.jpg" alt=""> </div>
                            <div class="pro-txt">
                              <h4> <a href="#">Sports Team T-Shirt</a> </h4>
                              <p class="price"> <del>£20.00</del> <strong>£17.50</strong> </p>
                            </div>
                          </div>
                        </div>
                        <!--Item End--> 
                      </div>
                    </div>
                  </div>
                  <!--widget End--> 
                  <!--widget Start-->
                  <div class="widget">
                    <h4>Be Social</h4>
                    <ul class="social-media">
                      <li>
                        <div class="social fb"> <i class="fab fa-facebook-f"></i> <strong> 25,345</strong> <span>Likes</span> </div>
                      </li>
                      <li>
                        <div class="social tw"> <i class="fab fa-twitter"></i> <strong> 5,345 </strong> <span>Followers</span> </div>
                      </li>
                      <li>
                        <div class="social yt"> <i class="fab fa-youtube"></i> <strong> 31,072 </strong> <span>Subscribers</span> </div>
                      </li>
                      <li>
                        <div class="social gp"> <i class="fab fa-google-plus-g"></i> <strong>3,345 </strong> <span>Plus</span> </div>
                      </li>
                      <li>
                        <div class="social insta"> <i class="fab fa-instagram"></i> <strong> 25,345 </strong> <span>Followers</span> </div>
                      </li>
                      <li>
                        <div class="social rss"> <i class="fas fa-rss"></i> <strong> 24,793 </strong> <span>Likes</span> </div>
                      </li>
                    </ul>
                  </div>
                  <!--widget End--> 
                </div>
              </div>
              <!--Sidebar End--> 
            </div>
          </div>
        </div>
        <!--End--> 
      </div>
      <!--Main Content End--> 
      <!--Main Footer Start-->
      <footer class="wf100 main-footer">
        <div class="container">
          <div class="row">
            <!--Footer Widget Start-->
            <div class="col-lg-3 col-md-6">
              <div class="footer-widget about-widget">
                <img src="images/logo.png" alt="">
                <p> Fusce ac pharetra urna. Duis non lacus sit amet lacus interdum facilisis sed non est ut mi metus semper. </p>
                <address>
                  <ul>
                    <li><i class="fas fa-map-marker-alt"></i> 4700 Millenia Blvd # 175, Orlando, FL 32839, USA</li>
                    <li><i class="fas fa-phone"></i> +1 321 2345 678-7</li>
                    <li><i class="fas fa-envelope"></i> info@soccer.com
                      contact@soccer.com 
                    </li>
                  </ul>
                </address>
              </div>
            </div>
            <!--Footer Widget End--> 
            <!--Footer Widget Start-->
            <div class="col-lg-3 col-md-6">
              <div class="footer-widget">
                <h4>About Soccer</h4>
                <ul class="footer-links">
                  <li><a href="#"><i class="fas fa-angle-double-right"></i> About Club</a></li>
                  <li><a href="#"><i class="fas fa-angle-double-right"></i> Matche Schedules</a></li>
                  <li><a href="#"><i class="fas fa-angle-double-right"></i> Groups Table</a></li>
                  <li><a href="#"><i class="fas fa-angle-double-right"></i> Teams</a></li>
                  <li><a href="#"><i class="fas fa-angle-double-right"></i> Statistics</a></li>
                  <li><a href="#"><i class="fas fa-angle-double-right"></i> Qualifiers</a></li>
                  <li><a href="#"><i class="fas fa-angle-double-right"></i> Ticket Bookings</a></li>
                  <li><a href="#"><i class="fas fa-angle-double-right"></i> Shoes</a></li>
                  <li><a href="#"><i class="fas fa-angle-double-right"></i> T-Shirts</a></li>
                  <li><a href="#"><i class="fas fa-angle-double-right"></i> Sports Wear</a></li>
                  <li><a href="#"><i class="fas fa-angle-double-right"></i> Accessories</a></li>
                  <li><a href="#"><i class="fas fa-angle-double-right"></i> Shop</a></li>
                  <li><a href="#"><i class="fas fa-angle-double-right"></i> Contact us</a></li>
                  <li><a href="#"><i class="fas fa-angle-double-right"></i> Media Room</a></li>
                </ul>
              </div>
            </div>
            <!--Footer Widget End--> 
            <!--Footer Widget Start-->
            <div class="col-lg-3 col-md-6">
              <div class="footer-widget">
                <h4>Recent Instagram</h4>
                <ul class="instagram">
                  <li><img src="images/insta1.jpg" alt=""></li>
                  <li><img src="images/insta2.jpg" alt=""></li>
                  <li><img src="images/insta3.jpg" alt=""></li>
                  <li><img src="images/insta4.jpg" alt=""></li>
                  <li><img src="images/insta5.jpg" alt=""></li>
                  <li><img src="images/insta6.jpg" alt=""></li>
                </ul>
              </div>
            </div>
            <!--Footer Widget End--> 
            <!--Footer Widget Start-->
            <div class="col-lg-3 col-md-6">
              <div class="footer-widget">
                <h4>Get Updated</h4>
                <p> Sign up to Get Updated & latest offers with our Newsletter. </p>
                <ul class="newsletter">
                  <li>
                    <input type="text" class="form-control" placeholder="Your Name">
                  </li>
                  <li>
                    <input type="text" class="form-control" placeholder="Your Emaill Address">
                  </li>
                  <li> <strong>We respect your privacy</strong>
                    <button><span>Subscribe</span></button>
                  </li>
                </ul>
              </div>
            </div>
            <!--Footer Widget End--> 
          </div>
        </div>
        <div class="container brtop">
          <div class="row">
            <div class="col-lg-6 col-md-6">
              <p class="copyr"> All Rights Reserved of Sports © 2020, Design & Developed By: <a href="#">GramoTech</a> </p>
            </div>
            <div class="col-lg-6 col-md-6">
              <ul class="quick-links">
                <li><a href="#">Home</a></li>
                <li><a href="#">Players</a></li>
                <li><a href="#">Fixtures</a></li>
                <li><a href="#">Point Table</a></li>
                <li><a href="#">Tickets</a></li>
                <li><a href="#">Contact</a></li>
              </ul>
            </div>
          </div>
        </div>
      </footer>
      <!--Main Footer End--> 
    </div>
    <!--Wrapper End--> 
    <!-- Optional JavaScript --> 
    <script src="js/jquery-3.3.1.min.js"></script> 
    <script src="js/jquery-migrate-3.0.1.js"></script> 
    <script src="js/popper.min.js"></script> 
    <script src="js/bootstrap.min.js"></script> 
<script src="js/mobile-nav.js"></script>  
    <script src="js/owl.carousel.min.js"></script> 
    <script src="js/jquery.prettyPhoto.js"></script> 
    <script src="js/jquery.countdown.js"></script> 
    <script src="js/audioplayer.min.js"></script> 
    <script src="js/custom.js"></script>
  </body>
</html>