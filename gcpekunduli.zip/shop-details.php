<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="images/fav.png" type="image/png">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/custom.css">
    <link rel="stylesheet" href="css/responsive.css">
    <link rel="stylesheet" href="css/color.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/fontawesome.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/prettyPhoto.css">
    <title>Tigers Sports HTML Template</title>
  </head>
  <body>
    <!--Wrapper Start-->
    <div class="wrapper">
      <!--Header Start-->
      <header id="main-header" class="main-header">
        <!--topbar-->
        <div class="topbar">
          <div class="container">
            <div class="row">
              <div class="col-md-6 col-sm-6">
                <ul class="topsocial">
                  <li><a href="#" class="fb"><i class="fab fa-facebook-f"></i></a></li>
                  <li><a href="#" class="tw"><i class="fab fa-twitter"></i></a></li>
                  <li><a href="#" class="insta"><i class="fab fa-instagram"></i></a></li>
                  <li><a href="#" class="in"><i class="fab fa-linkedin-in"></i></a></li>
                  <li><a href="#" class="yt"><i class="fab fa-youtube"></i></a></li>
                </ul>
              </div>
              <div class="col-md-6 col-sm-6">
                <ul class="toplinks">
                  <li class="lang-btn">
                    <div class="dropdown">
                      <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> ENG </button>
                      <div class="dropdown-menu" aria-labelledby="dropdownMenuButton"> <a class="dropdown-item" href="#">ENG</a> <a class="dropdown-item" href="#">FR</a> <a class="dropdown-item" href="#">GR</a> <a class="dropdown-item" href="#">AR</a> </div>
                    </div>
                  </li>
                  <li class="currency-btn">
                    <div class="dropdown">
                      <button class="btn btn-secondary dropdown-toggle" type="button" id="currencydropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> USD </button>
                      <div class="dropdown-menu" aria-labelledby="currencydropdown"> <a class="dropdown-item" href="#">USD</a> <a class="dropdown-item" href="#">Euro</a> <a class="dropdown-item" href="#">Pound</a> </div>
                    </div>
                  </li>
                  <li class="acctount-btn"> <a href="#">My Account</a> </li>
                  <li class="search-btn"> <a href="#"><i class="fas fa-search"></i></a> </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <!--topbar end--> 
        <!--Logo + Navbar Start-->
        <div class="logo-navbar">
          <div class="container">
            <div class="row">
              <div class="col-md-2 col-sm-5">
                <div class="logo"><a href="index.php"><img src="images/logo-dark.png" alt=""></a></div>
              </div>
              <div class="col-md-10 col-sm-7">
                <nav class="main-nav">
                  <ul>
                    <li class="nav-item drop-down">
                      <a href="index.php">Home</a>
                      <!-- <ul>
                        <li><a href="index.php">Home One</a></li>
                        <li><a href="index-two.php">Home Two</a></li>
						
                        
                      </ul> -->
                    </li>
                    <li class="nav-item drop-down">
                      <a href="">Matches</a>
                      <ul>
                        <li><a href="upcoming-match.php">Upcoming Match</a></li>
                        <li><a href="match-resut-layout-1.php">Match Result One</a></li>
                        <li><a href="match-resut-layout-2.php">Match Result Two</a></li>
                        <li><a href="match-resut-layout-3.php">Match Result Three</a></li>
                        <li><a href="match-details.php">Match Details</a></li>
                      </ul>
                    </li>
                    <li class="nav-item drop-down">
                      <a href="">Players</a>
                      <ul>
                        <li><a href="team-one.php">Team One</a></li>
                        <li><a href="team-two.php">Team Two</a></li>
                        <li><a href="team-three.php">Team Three</a></li>
                        <li><a href="team-four.php">Team Four</a></li>
                        <li><a href="team-details.php">Team Details</a></li>
                        <li><a href="staff-details.php">Staff Details</a></li>
                      </ul>
                    </li>
                    <li class="nav-item drop-down">
                      <a href="">Features</a>
                      <ul>
                        <li class="drop-down">
                          <a href="#">Shop</a>
                          <ul>
                            <li><a href="products-grid.php">Product Grid</a></li>
                            <li><a href="products-grid-two.php">Product Grid Two</a></li>
                            <li><a href="products-grid-three.php">Product Grid Three</a></li>
                            <li><a href="products-list.php">Product List</a></li>
                            <li><a href="shop-details.php">Shop Details</a></li>
                          </ul>
                        </li>
                        <li class="drop-down">
                          <a href="#">Gallery</a>
                          <ul>
                            <li><a href="gallery-2-col.php">Gallery Two Col</a></li>
                            <li><a href="gallery-3-col.php">Gallery Three Col</a></li>
                            <li><a href="gallery-clasic.php">Gallery Classic</a></li>
                            <li><a href="gallery-massonry.php">Gallery Massonry</a></li>
                            <li><a href="gallery-modern.php">Galery Modern</a></li>
                          </ul>
                        </li>
                        <li><a href="groups.php">Groups</a></li>
                        <li><a href="page-404.php">Page 404</a></li>
                        <li><a href="page-404-one.php">Page 404 Two</a></li>
                      </ul>
                    </li>
                    <li class="nav-item"> <a href="point-table.php">Point Table</a> </li>
                    <li class="nav-item drop-down">
                      <a href="">News</a>
                      <ul>
                        <li><a href="news-grid.php">News Grid</a></li>
                        <li><a href="news-large.php">News Large</a></li>
                        <li><a href="news-list.php">News List</a></li>
                        <li><a href="news-details.php">News Details</a></li>
                      </ul>
                    </li>
					<li class="nav-item drop-down">
                      <a href="">Fixtures</a>
                      <ul>
                        <li><a href="fixtures-layout-1.php">Fixtures One</a></li>
                        <li><a href="fixtures-layout-2.php">Fixtures Two</a></li>
                       
                      </ul>
                    </li>
                    
                    <li class="nav-item drop-down">
                      <a href="">Contact</a>
                      <ul>
                        <li><a href="contact.php">Contact One</a></li>
                        <li><a href="contact-two.php">Contact Two</a></li>
                      </ul>
                    </li>
                    <!-- <li class="nav-item buy-ticket"> <a href="#">Buy Tickets</a> </li> -->
                  </ul>
                </nav>
              </div>
            </div>
          </div>
        </div>
        <!--Logo + Navbar End--> 
      </header>
      <!--Header End--> 
      <!--Main Slider Start-->
      <div class="inner-banner-header wf100">
        <h1 data-generated="Staff Detail">Shop Detail</h1>
        <div class="gt-breadcrumbs">
          <ul>
            <li> <a href="#" class="active"> <i class="fas fa-home"></i> Home </a> </li>
            <li> <a href="#"> Shop </a> </li>
            <li> <a href="#"> Shop Detail </a> </li>
          </ul>
        </div>
      </div>
      <!--Main Slider Start--> 
      <!--Main Content Start-->
      <div class="main-content solidbg wf100">
        <!--Shop Detials Page Start-->
        <div class="shop-details wf100 p80">
          <div class="container">
            <div class="row">
              <div class="col-lg-6">
                <div class="shop-images">
                  <ul class="gallery">
                    <li> <a href="images/pro-large.jpg" data-rel="prettyPhoto[gallery1]"><i class="fas fa-search-plus"></i></a> <img src="images/pro-large.jpg" alt=""></li>
                    <li><img src="images/pro-large.jpg" alt=""></li>
                    <li><img src="images/pro-large.jpg" alt=""></li>
                    <li><img src="images/pro-large.jpg" alt=""></li>
                  </ul>
                </div>
              </div>
              <div class="col-lg-6">
                <div class="pro-summery">
                  <h1>Sports Team T-Shirt</h1>
                  <p class="price"><del>£20.00</del> <ins>£17.50</ins></p>
                  <p class="rating"><a href="#"><i class="fas fa-star"></i> <i class="fas fa-star"></i> <i class="fas fa-star"></i> <i class="fas fa-star"></i> <i class="fas fa-star"></i></a> 4.8/5.0</p>
                  <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip. </p>
                  <ul class="sizes radio-boxes">
                    <li><strong>Sizes:</strong></li>
                    <li>
                      <div class="radio custom">
                        <input name="donation" id="d1" type="radio" class="css-radio">
                        <label for="d1" class="css-label">S</label>
                      </div>
                    </li>
                    <li>
                      <div class="radio custom">
                        <input name="donation" id="d2" type="radio" class="css-radio">
                        <label for="d2" class="css-label">M</label>
                      </div>
                    </li>
                    <li>
                      <div class="radio custom">
                        <input name="donation" id="d3" type="radio" class="css-radio">
                        <label for="d3" class="css-label">L</label>
                      </div>
                    </li>
                    <li>
                      <div class="radio custom">
                        <input name="donation" id="d4" type="radio" class="css-radio">
                        <label for="d4" class="css-label">XL</label>
                      </div>
                    </li>
                    <li>
                      <div class="radio custom">
                        <input name="donation" id="d5" type="radio" class="css-radio">
                        <label for="d5" class="css-label">XXL</label>
                      </div>
                    </li>
                  </ul>
                  <ul class="colors">
                    <li><strong>Available Colors:</strong></li>
                    <li class="c1"><span></span></li>
                    <li class="c2"><span></span></li>
                    <li class="c3"><span></span></li>
                  </ul>
                  <p class="in-stock">Availability: <strong>In Stock</strong></p>
                  <ul class="cart-qty">
                    <li>Quantity:</li>
                    <li>
                      <input type="number">
                    </li>
                    <li>
                      <button class="add-2-cart">Add to Cart</button>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-12">
                <div class="product-tabs">
                  <nav>
                    <div class="nav nav-tabs" id="nav-tab" role="tablist"> <a class="nav-item nav-link active" id="nav-one-tab" data-toggle="tab" href="#nav-one" role="tab" aria-controls="nav-one" aria-selected="true">Description</a> <a class="nav-item nav-link" id="nav-two-tab" data-toggle="tab" href="#nav-two" role="tab" aria-controls="nav-two" aria-selected="false">Additional Information</a> <a class="nav-item nav-link" id="nav-three-tab" data-toggle="tab" href="#nav-three" role="tab" aria-controls="nav-three" aria-selected="false">Reviews</a> </div>
                  </nav>
                  <div class="tab-content" id="nav-tabContent">
                    <div class="tab-pane fade show active" id="nav-one" role="tabpanel" aria-labelledby="nav-one-tab">
                      <p> We are going to run a solid educational campaign for the orphan children study. There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words slightly believable. If you are going to use a passage of Lorem Ipsum.</p>
                      <p>You need to be sure there isn't anything embarrassing hidden in the middle of text. To take a trivial example, which of us ever undertakes laborious physical exercise, except to obtain some advantage. Etiam venenatis eleifend urna eget scelerisque. Aliquam in nunc quis dui sollicitudin ornare ac vitae lectus. Aliquam interdum dolor aliquet dolor sollicitudin fermentum. Donec congue lorem a molestie bibendum. </p>
                    </div>
                    <div class="tab-pane fade" id="nav-two" role="tabpanel" aria-labelledby="nav-two-tab">
                      <table>
                        <tr>
                          <td>Weight</td>
                          <td>130 gm</td>
                        </tr>
                        <tr>
                          <td>Dimensions</td>
                          <td>70 x 40 x 50 cm</td>
                        </tr>
                        <tr>
                          <td>Small</td>
                          <td>Mauris consequat odio turpis, sed ultricies libero tincidunt i</td>
                        </tr>
                        <tr>
                          <td>Large</td>
                          <td>Condimentum nisi vitae, consequat libero integer sit amet velit neque. </td>
                        </tr>
                      </table>
                    </div>
                    <div class="tab-pane fade" id="nav-three" role="tabpanel" aria-labelledby="nav-three-tab">
                      <ul class="comments">
                        <!--Comment Start-->
                        <li class="comment">
                          <div class="user-thumb"> <img src="images/auser.jpg" alt=""></div>
                          <div class="comment-txt">
                            <h6> Mason Gray </h6>
                            <p> Personally I think a combination of all these methods is most effective, but in today’s post I will be focusing specifically on how to use and style WordPress’ built-in sticky post feature and highlighting it’s best use case based on my own experience. </p>
                            <ul class="comment-time">
                              <li>Posted: 09 July, 2020 at 2:37 pm</li>
                              <li> <a href="#"><i class="fas fa-reply"></i> Reply</a> </li>
                            </ul>
                          </div>
                          <ul class="children">
                            <!--Comment Start-->
                            <li class="comment">
                              <div class="user-thumb"> <img src="images/auser.jpg" alt=""></div>
                              <div class="comment-txt">
                                <h6> Rog Kelly </h6>
                                <p> Personally I think a combination of all these methods is most effective, but in today’s post I will be focusing specifically on how to use and style WordPress’ built-in sticky post feature and highlighting it’s best use case based on my own experience. </p>
                                <ul class="comment-time">
                                  <li>Posted: 09 July, 2020 at 2:37 pm</li>
                                  <li> <a href="#"><i class="fas fa-reply"></i> Reply</a> </li>
                                </ul>
                              </div>
                            </li>
                            <!--Comment End-->
                          </ul>
                        </li>
                        <!--Comment End--> 
                        <!--Comment Start-->
                        <li class="comment">
                          <div class="user-thumb"> <img src="images/auser.jpg" alt=""></div>
                          <div class="comment-txt">
                            <h6> Harry Butler </h6>
                            <p> Personally I think a combination of all these methods is most effective, but in today’s post I will be focusing specifically on how to use and style WordPress’ built-in sticky post feature and highlighting it’s best use case based on my own experience. </p>
                            <ul class="comment-time">
                              <li>Posted: 09 July, 2020 at 2:37 pm</li>
                              <li> <a href="#"><i class="fas fa-reply"></i> Reply</a> </li>
                            </ul>
                          </div>
                        </li>
                        <!--Comment End-->
                      </ul>
                      <div class="wf100 comment-form">
                        <h4>Leave a Review</h4>
                        <p class="comment-notes"><span id="email-notes">Your email address will not be published.</span> Required fields are marked <span class="required">*</span></p>
                        <div class="comment-form-rating">
                          <label>Your rating</label>
                          <p class="stars"><span><a class="star-1" href="#">1</a><a class="star-2" href="#">2</a><a class="star-3" href="#">3</a><a class="star-4" href="#">4</a><a class="star-5" href="#">5</a></span></p>
                        </div>
                        <ul>
                          <li class="w3">
                            <input type="text" class="form-control" placeholder="Full Name">
                          </li>
                          <li class="w3">
                            <input type="text" class="form-control" placeholder="Email">
                          </li>
                          <li class="w3 np">
                            <input type="text" class="form-control" placeholder="Subject">
                          </li>
                          <li class="full">
                            <textarea class="form-control" placeholder="Write Comments"></textarea>
                          </li>
                          <li class="full">
                            <button class="post-btn">Post Your Review</button>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!--Shop Detials Page End-->
        <!--Related Products Start-->
        <section class="wf100 shop-products mb-80">
          <div class="container">
            <div class="row">
              <div class="col-md-12">
                <div class="section-title">
                  <h2>People Also Viewed</h2>
                </div>
              </div>
            </div>
            <div class="row">
              <!--Product Start-->
              <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="pro-box">
                  <div class="pro-thumb"> <a href="#"><i class="fas fa-link"></i></a> <img src="images/pro1.jpg" alt=""> </div>
                  <div class="pro-txt">
                    <h4> <a href="#">Sports Team T-Shirt</a> </h4>
                    <p class="price"> <del>£20.00</del> <strong>£17.50</strong> </p>
                    <a href="#" class="add2cart">Add to Cart</a> 
                  </div>
                </div>
              </div>
              <!--Product End--> 
              <!--Product Start-->
              <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="pro-box">
                  <div class="pro-thumb"> <a href="#"><i class="fas fa-link"></i></a> <img src="images/pro2.jpg" alt=""> </div>
                  <div class="pro-txt">
                    <h4> <a href="#">Soccer Gloves</a> </h4>
                    <p class="price"> <del>£20.00</del> <strong>£17.50</strong> </p>
                    <a href="#" class="add2cart">Add to Cart</a> 
                  </div>
                </div>
              </div>
              <!--Product End--> 
              <!--Product Start-->
              <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="pro-box">
                  <div class="pro-thumb"> <a href="#"><i class="fas fa-link"></i></a> <img src="images/pro3.jpg" alt=""> </div>
                  <div class="pro-txt">
                    <h4> <a href="#">Practice T-Shirt</a> </h4>
                    <p class="price"> <del>£20.00</del> <strong>£17.50</strong> </p>
                    <a href="#" class="add2cart">Add to Cart</a> 
                  </div>
                </div>
              </div>
              <!--Product End--> 
              <!--Product Start-->
              <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="pro-box">
                  <div class="pro-thumb"> <a href="#"><i class="fas fa-link"></i></a> <img src="images/pro4.jpg" alt=""> </div>
                  <div class="pro-txt">
                    <h4> <a href="#">Sports Shoes</a> </h4>
                    <p class="price"> <del>£20.00</del> <strong>£17.50</strong> </p>
                    <a href="#" class="add2cart">Add to Cart</a> 
                  </div>
                </div>
              </div>
              <!--Product End--> 
            </div>
          </div>
        </section>
        <!--Related Products End-->
      </div>
      <!--Main Content End--> 
      <!--Main Footer Start-->
      <footer class="wf100 main-footer">
        <div class="container">
          <div class="row">
            <!--Footer Widget Start-->
            <div class="col-lg-3 col-md-6">
              <div class="footer-widget about-widget">
                <img src="images/logo.png" alt="">
                <p> Fusce ac pharetra urna. Duis non lacus sit amet lacus interdum facilisis sed non est ut mi metus semper. </p>
                <address>
                  <ul>
                    <li><i class="fas fa-map-marker-alt"></i> 4700 Millenia Blvd # 175, Orlando, FL 32839, USA</li>
                    <li><i class="fas fa-phone"></i> +1 321 2345 678-7</li>
                    <li><i class="fas fa-envelope"></i> info@soccer.com
                      contact@soccer.com 
                    </li>
                  </ul>
                </address>
              </div>
            </div>
            <!--Footer Widget End--> 
            <!--Footer Widget Start-->
            <div class="col-lg-3 col-md-6">
              <div class="footer-widget">
                <h4>About Soccer</h4>
                <ul class="footer-links">
                  <li><a href="#"><i class="fas fa-angle-double-right"></i> About Club</a></li>
                  <li><a href="#"><i class="fas fa-angle-double-right"></i> Matche Schedules</a></li>
                  <li><a href="#"><i class="fas fa-angle-double-right"></i> Groups Table</a></li>
                  <li><a href="#"><i class="fas fa-angle-double-right"></i> Teams</a></li>
                  <li><a href="#"><i class="fas fa-angle-double-right"></i> Statistics</a></li>
                  <li><a href="#"><i class="fas fa-angle-double-right"></i> Qualifiers</a></li>
                  <li><a href="#"><i class="fas fa-angle-double-right"></i> Ticket Bookings</a></li>
                  <li><a href="#"><i class="fas fa-angle-double-right"></i> Shoes</a></li>
                  <li><a href="#"><i class="fas fa-angle-double-right"></i> T-Shirts</a></li>
                  <li><a href="#"><i class="fas fa-angle-double-right"></i> Sports Wear</a></li>
                  <li><a href="#"><i class="fas fa-angle-double-right"></i> Accessories</a></li>
                  <li><a href="#"><i class="fas fa-angle-double-right"></i> Shop</a></li>
                  <li><a href="#"><i class="fas fa-angle-double-right"></i> Contact us</a></li>
                  <li><a href="#"><i class="fas fa-angle-double-right"></i> Media Room</a></li>
                </ul>
              </div>
            </div>
            <!--Footer Widget End--> 
            <!--Footer Widget Start-->
            <div class="col-lg-3 col-md-6">
              <div class="footer-widget">
                <h4>Recent Instagram</h4>
                <ul class="instagram">
                  <li><img src="images/insta1.jpg" alt=""></li>
                  <li><img src="images/insta2.jpg" alt=""></li>
                  <li><img src="images/insta3.jpg" alt=""></li>
                  <li><img src="images/insta4.jpg" alt=""></li>
                  <li><img src="images/insta5.jpg" alt=""></li>
                  <li><img src="images/insta6.jpg" alt=""></li>
                </ul>
              </div>
            </div>
            <!--Footer Widget End--> 
            <!--Footer Widget Start-->
            <div class="col-lg-3 col-md-6">
              <div class="footer-widget">
                <h4>Get Updated</h4>
                <p> Sign up to Get Updated & latest offers with our Newsletter. </p>
                <ul class="newsletter">
                  <li>
                    <input type="text" class="form-control" placeholder="Your Name">
                  </li>
                  <li>
                    <input type="text" class="form-control" placeholder="Your Emaill Address">
                  </li>
                  <li> <strong>We respect your privacy</strong>
                    <button><span>Subscribe</span></button>
                  </li>
                </ul>
              </div>
            </div>
            <!--Footer Widget End--> 
          </div>
        </div>
        <div class="container brtop">
          <div class="row">
            <div class="col-lg-6 col-md-6">
              <p class="copyr"> All Rights Reserved of Sports © 2020, Design & Developed By: <a href="#">GramoTech</a> </p>
            </div>
            <div class="col-lg-6 col-md-6">
              <ul class="quick-links">
                <li><a href="#">Home</a></li>
                <li><a href="#">Players</a></li>
                <li><a href="#">Fixtures</a></li>
                <li><a href="#">Point Table</a></li>
                <li><a href="#">Tickets</a></li>
                <li><a href="#">Contact</a></li>
              </ul>
            </div>
          </div>
        </div>
      </footer>
      <!--Main Footer End--> 
    </div>
    <!--Wrapper End--> 
    <!-- Optional JavaScript --> 
    <script src="js/jquery-3.3.1.min.js"></script> 
    <script src="js/jquery-migrate-3.0.1.js"></script> 
    <script src="js/popper.min.js"></script> 
    <script src="js/bootstrap.min.js"></script> 
<script src="js/mobile-nav.js"></script>  
    <script src="js/owl.carousel.min.js"></script> 
    <script src="js/jquery.prettyPhoto.js"></script> 
    <script src="js/jquery.countdown.js"></script> 
    <script src="js/custom.js"></script>
  </body>
</html>