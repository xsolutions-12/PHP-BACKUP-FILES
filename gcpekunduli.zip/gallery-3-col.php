<!doctype html>
<html lang="en">
   <head>
   <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="images/logopic01.jpg" type="image/png">
    <!-- Bootstrap CSS -->
    <?php include('includeFiles/cssFiles.php') ?>
    <!--Rev Slider End-->
    <title>Government College of Physical Education, Kulundi, Sambalpur</title>
   </head>
   <body>
      <!--Wrapper Start-->
      <div class="wrapper">
    <!--Header Start-->
    <?php include('includeFiles/header.php') ?>
         <!--Header End--> 
         <!--Main Slider Start-->
         <div class="inner-banner-header wf100">
            <h1 data-generated="Image Gallery">Image Gallery</h1>
            <div class="gt-breadcrumbs">
               <ul>
                  <li> <a href="index.php" class="active"> <i class="fas fa-home"></i> Home </a> </li>
                  <li> <a href="#"> About </a> </li>
                  <li> <a href="gallery-3-col.php"> Gallery </a> </li>
               </ul>
            </div>
         </div>
         <!--Main Slider Start--> 
         <!--Main Content Start-->
         <div class="main-content innerpagebg wf100">
            <!--Image Gallery Start-->
            <div class="image-gallery gallery p80">
               <div class="container">
                  <div class="row">
                     <!--box start-->
                     <div class="col-sm-4">
                        <div class="gal-thumb"> <a href="images/college_pics/g01.jpg" data-rel="prettyPhoto[gallery1]"><i class="fas fa-link"></i></a> <img src="images/college_pics/g01.jpg" alt=""> </div>
                     </div>
                     <!--box end--> 
                     <!--box start-->
                     <div class="col-sm-4">
                        <div class="gal-thumb"> <a href="images/gallery/g2col-2.jpg" data-rel="prettyPhoto[gallery1]"><i class="fas fa-link"></i></a> <img src="images/college_pics/g02.jpg" alt=""> </div>
                     </div>
                     <!--box end--> 
                     <!--box start-->
                     <div class="col-sm-4">
                        <div class="gal-thumb"> <a href="images/gallery/g2col-3.jpg" data-rel="prettyPhoto[gallery1]"><i class="fas fa-link"></i></a> <img src="images/college_pics/g03.jpg" alt=""> </div>
                     </div>
                     <!--box end--> 
                     <!--box start-->
                     <div class="col-sm-4">
                        <div class="gal-thumb"> <a href="images/gallery/g2col-4.jpg" data-rel="prettyPhoto[gallery1]"><i class="fas fa-link"></i></a> <img src="images/college_pics/g04.jpg" alt=""> </div>
                     </div>
                     <!--box end--> 
                     <!--box start-->
                     <div class="col-sm-4">
                        <div class="gal-thumb"> <a href="images/gallery/g2col-5.jpg" data-rel="prettyPhoto[gallery1]"><i class="fas fa-link"></i></a> <img src="images/college_pics/g05.jpg" alt=""> </div>
                     </div>
                     <!--box end--> 
                     <!--box start-->
                     <div class="col-sm-4">
                        <div class="gal-thumb"> <a href="images/gallery/g2col-6.jpg" data-rel="prettyPhoto[gallery1]"><i class="fas fa-link"></i></a> <img src="images/college_pics/g06.jpg" alt=""> </div>
                     </div>
                     <!--box end--> 
                     <!--box start-->
                     <div class="col-sm-4">
                        <div class="gal-thumb"> <a href="images/gallery/g2col-7.jpg" data-rel="prettyPhoto[gallery1]"><i class="fas fa-link"></i></a> <img src="images/college_pics/g07.jpg" alt=""> </div>
                     </div>
                     <!--box end--> 
                     <!--box start-->
                     <div class="col-sm-4">
                        <div class="gal-thumb"> <a href="images/gallery/g2col-8.jpg" data-rel="prettyPhoto[gallery1]"><i class="fas fa-link"></i></a> <img src="images/college_pics/g08.jpg" alt=""> </div>
                     </div>
                     <!--box end--> 
                     <!--box start-->
                     <div class="col-sm-4">
                        <div class="gal-thumb"> <a href="images/gallery/g2col-9.jpg" data-rel="prettyPhoto[gallery1]"><i class="fas fa-link"></i></a> <img src="images/college_pics/g09.jpg" alt=""> </div>
                     </div>
                     <!--box end--> 
                     <!--box start-->
                     <div class="col-sm-4">
                        <div class="gal-thumb"> <a href="images/gallery/g2col-10.jpg" data-rel="prettyPhoto[gallery1]"><i class="fas fa-link"></i></a> <img src="images/college_pics/g10.jpg" alt=""> </div>
                     </div>
                     <!--box end--> 
                     <!--box start-->
                     <div class="col-sm-4">
                        <div class="gal-thumb"> <a href="images/gallery/g2col-11.jpg" data-rel="prettyPhoto[gallery1]"><i class="fas fa-link"></i></a> <img src="images/college_pics/g11.jpg" alt=""> </div>
                     </div>
                     <!--box end--> 
                     <!--box start-->
                     <div class="col-sm-4">
                        <div class="gal-thumb"> <a href="images/gallery/g2col-12.jpg" data-rel="prettyPhoto[gallery1]"><i class="fas fa-link"></i></a> <img src="images/college_pics/g12.jpg" alt=""> </div>
                     </div>
                     <!--box end--> 
                  </div>
                  <!-- <div class="row">
                     <div class="gt-pagination">
                        <nav aria-label="Page navigation example">
                           <ul class="pagination justify-content-center">
                              <li class="page-item"> <a class="page-link" href="#" tabindex="-1" aria-disabled="true"><i class="fas fa-angle-left"></i></a> </li>
                              <li class="page-item"><a class="page-link" href="#">1</a></li>
                              <li class="page-item active"><a class="page-link" href="#">2</a></li>
                              <li class="page-item"><a class="page-link" href="#">3</a></li>
                              <li class="page-item"> <a class="page-link" href="#"><i class="fas fa-angle-right"></i></a> </li>
                           </ul>
                        </nav>
                     </div>
                  </div> -->
               </div>
            </div>
            <!--Image Gallery End--> 
         </div>
         <!--Main Content End--> 
         <!--Main Footer Start-->
         <?php include('includeFiles/footer.php') ?>
         <!--Main Footer End--> 
      </div>
      <!--Wrapper End--> 
      <!-- Optional JavaScript --> 
      <?php include('includeFiles/scriptFile.php')?>
   </body>
</html>