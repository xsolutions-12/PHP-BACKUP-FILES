<!doctype html>
<html lang="en">
   <head>
   <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="images/logopic01.jpg" type="image/png">
    <!-- Bootstrap CSS -->
    <?php include('includeFiles/cssFiles.php') ?>
    <!--Rev Slider End-->
    <title>Government College of Physical Education, Kulundi, Sambalpur</title>
   </head>
   <body>
      <!--Wrapper Start-->
      <div class="wrapper">
         <!--Header Start-->
       <!--Header Start-->
    <?php include('includeFiles/header.php') ?>
         <!--Header End--> 
         <!--Main Slider Start-->
         <div class="inner-banner-header wf100">
            <h1 data-generated="Contact">Contact</h1>
            <div class="gt-breadcrumbs">
               <ul>
                  <li> <a href="index.php" class="active"> <i class="fas fa-home"></i> Home </a> </li>
                  <li> <a href="#"> Contact </a> </li>
               </ul>
            </div>
         </div>
         <!--Main Slider Start--> 
         <!--Main Content Start-->
         <div class="main-content p80 innerpagebg wf100">
            <!--Contact Page Start-->
            <div class="contact">
               <div class="container">
                  <div class="row">
                     <!--Form Start-->
                     <div class="col-md-6">
                        <div class="contact-form">
                           <h2>Feel Free to Contact us</h2>
                           <ul class="form-row">
                              <li class="half-col">
                                 <input type="text" class="form-control" placeholder="Your Name">
                              </li>
                              <li class="half-col">
                                 <input type="text" class="form-control" placeholder="Email">
                              </li>
                              <li class="half-col">
                                 <input type="text" class="form-control" placeholder="Contact">
                              </li>
                              <li class="half-col">
                                 <input type="text" class="form-control" placeholder="Subject">
                              </li>
                              <li class="full-col">
                                 <textarea  class="form-control" placeholder="Write Your Message"></textarea>
                              </li>
                              <li class="full-col">
                                 <button type="button">Contact us Now</button>
                              </li>
                           </ul>
                        </div>
                     </div>
                     <!--Form End--> 
                     <!--Map Start-->
                     <div class="col-md-6">
                        <div class="google-map">
                           <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d59407.23279657551!2d83.9728832!3d21.470397999999996!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a21167f047cd9b5%3A0x7660a40be684d655!2sSambalpur%2C%20Odisha!5e0!3m2!1sen!2sin!4v1693634759239!5m2!1sen!2sin"></iframe>
                        </div>
                     </div>
                     <!--Map End--> 
                  </div>
                  <div class="row mt-60">
                     <div class="col-md-12">
                        <h2>Contact Information</h2>
                     </div>
                     <!--Start-->
                     <div class="col-md-4">
                        <div class="contact-box">
                           <h5>Address:</h5>
                           <p> Sri Ganesh Chandra Bagh Address: Kulundi, Sambalpur, Pin:- 768112
                           </p>
                        </div>
                     </div>
                     <!--End--> 
                     <!--Start-->
                     <div class="col-md-4">
                        <div class="contact-box">
                           <h5>Contact:</h5>
                           <p><strong>Phone:</strong> +91 9938546949</p>
                           <p><strong>Fax: </strong> +91 9938546949 </p>
                        </div>
                     </div>
                     <!--End--> 
                     <!--Start-->
                     <div class="col-md-4">
                        <div class="contact-box">
                           <h5>For More Information:</h5>
                           <p> <strong>Email:</strong> gcpekulundi1993@gmail.com</p>
                           <p>contact@gcpekulundi.com</p>
                        </div>
                     </div>
                     <!--End--> 
                  </div>
               </div>
            </div>
            <!--Contact Page End--> 
         </div>
         <!--Main Content End--> 
         <!--Main Footer Start-->
         <?php include('includeFiles/footer.php') ?>
         <!--Main Footer End--> 
      </div>
      <!--Wrapper End--> 
      <!-- Optional JavaScript --> 
      <?php include('includeFiles/scriptFile.php')?>
   </body>
</html>