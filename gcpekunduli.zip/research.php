<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="images/logopic01.jpg" type="image/png">
    <!-- Bootstrap CSS -->
    <?php include('includeFiles/cssFiles.php') ?>
    <!--Rev Slider End-->
    <title>Government College of Physical Education, Bhubaneswar, Khordha</title>
</head>

<body>
    <!--Wrapper Start-->
    <div class="wrapper">
        <!--Header Start-->
        <!--Header Start-->
        <?php include('includeFiles/header.php') ?>
        <!--Header End-->
        <!--Main Slider Start-->
        <div class="inner-banner-header wf100">
            <h1 data-generated="Principal">Research Activities</h1>
            <div class="gt-breadcrumbs">
                <ul>
                    <li> <a href="index.php" class="active"> <i class="fas fa-home"></i> Home </a> </li>
                    <li> <a href="#">Academics</a> </li>
                    <li> <a href="research.php">Research Activities</a> </li>
                </ul>
            </div>
        </div>
        <!--Main Slider Start-->
        <!--Main Content Start-->
        <div class="main-content p80 innerpagebg wf100">
            <!--Contact Page Start-->
            <div class="contact">
                <div class="container">
                    <div class="row">
                        <!--Form Start-->

                        <div class="card" style="width: 70rem;">
                            <div class="card-body">
                                <div class="text-center pb-5" style="font-weight:600;font-size:50px;">Research Activities</div>
                              <div class="row">
                                <div class="col-md-3 col-sm-6 col-xs-12">
                                    <img src="images/activity.jpg" alt="">
                                </div>
                                    <div class="col-md-9 col-sm-3">
                                        <p>Staff and Master degree students of the college are carrying out research programmes on Physical Education & Sports Science for their fulfillment of games, sports, health, aspects and recreation through the research studies.</p> 
                                        <p>Near about 300 research findings conducted by staff & students have been reported to the University for future guidance. The college is also nominated as the nodal center for pre-doctorial course on physical education by the Utkal University.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--Contact Page End-->
        </div>
        <!--Main Content End-->
        <!--Main Footer Start-->
        <?php include('includeFiles/footer.php') ?>
        <!--Main Footer End-->
    </div>
    <!--Wrapper End-->
    <!-- Optional JavaScript -->
    <?php include('includeFiles/scriptFile.php')?>
</body>

</html>