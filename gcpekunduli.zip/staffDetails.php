<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="images/logopic01.jpg" type="image/png">
    <!-- Bootstrap CSS -->
    <?php include('includeFiles/cssFiles.php') ?>
    <!--Rev Slider End-->
    <title>Government College of Physical Education, Kulundi, Sambalpur</title>
</head>

<body>
    <!--Wrapper Start-->
    <div class="wrapper">
        <!--Header Start-->
        <!--Header Start-->
        <?php include('includeFiles/header.php') ?>
        <!--Header End-->
        <!--Main Slider Start-->
        <div class="inner-banner-header wf100">
            <h1 data-generated="Staff Details">Staff Details</h1>
            <div class="gt-breadcrumbs">
                <ul>
                    <li> <a href="index.php" class="active"> <i class="fas fa-home"></i> Home </a> </li>
                    <li> <a href="#"> About </a> </li>
                    <li> <a href="staffDetails.php"> Staff Details </a> </li>
                </ul>
            </div>
        </div>

        <!--Main Slider Start-->
        <!--Main Content Start-->
        <section class="wf100 featured-news p90">
            <div class="container">
                <div class="row">

                    <!--col start-->
                    <div class="col-lg-12">
                        <div class="h3-section-title">
                            <!-- <strong style="color:white">featured News</strong> -->
                            <h2 style="color:black;text-align: center;margin: 20px 0 0 0;">STAFF DETAILS</h2>
                        </div>

                        <!--news start-->
                        <div class="news-list-post">
                            <!-- <div class="post-thumb"> <a href="#"><i class="fas fa-link"></i></a> <img src="images/news-media-img1.jpg" alt=""></div> -->
                            <h2 style="color:black;padding: 25px;">GAZETTED SANCTIONED POST</h2>
                            <div class="post-txt" style="padding: 20px 70px 70px 70px;">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th scope="col">SL.NO</th>
                                            <th scope="col">NAME</th>
                                            <th scope="col">DESIGNATION</th>
                                            <th scope="col">IMAGES</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <th scope="row">1</th>
                                            <td>Dr. Suresh Kumar Mohapatra</td>
                                            <td>I/C PRINCIPAL</td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <th scope="row">2</th>
                                            <td>Sri. Samarpit Pradhan</td>
                                            <td>Thornton</td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <th scope="row">3</th>
                                            <td>Dr. Prabeen Kumar Sahu</td>
                                            <td>LECTURER</td>
                                            <td></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="news-list-post">
                            <!-- <div class="post-thumb"> <a href="#"><i class="fas fa-link"></i></a> <img src="images/news-media-img1.jpg" alt=""></div> -->
                            <h2 style="color:black;padding: 25px">NON - GAZETTED SANCTIONED POST</h2>
                            <div class="post-txt" style="padding: 20px 70px 70px 70px;">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th scope="col">SL.NO</th>
                                            <th scope="col">NAME</th>
                                            <th scope="col">DESIGNATION</th>
                                            <th scope="col">IMAGES</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <th scope="row">1</th>
                                            <td>Sri. Prakash Chandra Nayak</td>
                                            <td>DEMONSTATOR</td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <th scope="row">2</th>
                                            <td>Sri. Ganesh Chandra Bagh</td>
                                            <td>JR CLERK CUM TYPIST</td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <th scope="row">3</th>
                                            <td>Sri. Govindo Pradhan</td>
                                            <td>STOREKEPPER</td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <th scope="row">4</th>
                                            <td>Sri krushna Chandra Padhan</td>
                                            <td>PEON</td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <th scope="row">5</th>
                                            <td>Sri krushna Chandra Padhan</td>
                                            <td>PEON</td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <th scope="row">6</th>
                                            <td>Sri krushna Chandra Padhan</td>
                                            <td>GROUNDSMAN</td>
                                            <td></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="news-list-post">
                            <!-- <div class="post-thumb"> <a href="#"><i class="fas fa-link"></i></a> <img src="images/news-media-img1.jpg" alt=""></div> -->
                            <h2 style="color:black;padding: 25px">EMPLOYEE</h2>
                            <div class="post-txt" style="padding: 20px 70px 70px 70px;">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th scope="col">SL.NO</th>
                                            <th scope="col">NAME</th>
                                            <th scope="col">DESIGNATION</th>
                                            <th scope="col">IMAGES</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <th scope="row">1</th>
                                            <td>Harshabardan Sahu</td>
                                            <td>Instructor</td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <th scope="row">2</th>
                                            <td>Surendra kumar naik</td>
                                            <td>Trainer</td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <th scope="row">3</th>
                                            <td>Upendra satpathy</td>
                                            <td>Trainer</td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <th scope="row">4</th>
                                            <td>Debasish Behera</td>
                                            <td>Instructor</td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <th scope="row">5</th>
                                            <td>Amrendra Sarangi</td>
                                            <td>Yoga Trainer</td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <th scope="row">6</th>
                                            <td>Chetana Mayee Behera</td>
                                            <td>Music Teacher</td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <th scope="row">7</th>
                                            <td>Aliva Swain</td>
                                            <td>Dietician</td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <th scope="row">8</th>
                                            <td>Rabi Narayan Bhoi</td>
                                            <td>Librarian</td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <th scope="row">9</th>
                                            <td>Laxmikant Dansana</td>
                                            <td>Office Executive</td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <th scope="row">10</th>
                                            <td>Anjali Soni</td>
                                            <td>Office Executive</td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <th scope="row">11</th>
                                            <td>Office Executive</td>
                                            <td>Attendant</td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <th scope="row">12</th>
                                            <td>Latish Kumar Pradhan</td>
                                            <td>Ground Man</td>
                                            <td></td>
                                        </tr>
                                        <tr>
                                            <th scope="row">13</th>
                                            <td>Sudhir Kanda</td>
                                            <td>Washing Staff</td>
                                            <td></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>


                    </div>
                    <!--col end-->



                </div>
            </div>
        </section>
        <!--Main Content End-->
        <!--Main Footer Start-->
        <?php include('includeFiles/footer.php') ?>
        <!--Main Footer End-->
    </div>
    <!--Wrapper End-->
    <!-- Optional JavaScript -->
    <?php include('includeFiles/scriptFile.php') ?>
</body>

</html>