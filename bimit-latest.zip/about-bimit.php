<!DOCTYPE html>
<html>
<head>
	<title>About BIMIT</title>
	<?php include_once 'include/css.php'; ?>
</head>
<body class="about-page">
	<div class="container">
		<div class="main-wrap">
			<?php include_once 'include/header.php'; ?>
			<div class="row">
				<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="inner-page-sec">
						<h1 class="inner-title">About BIMIT</h1>
						<p>BIMIT, a premier Business School is an intellectual community rightly blended with spiritualism & strong traditions. It owes its inception to the Grace and Blessing of Beloved Bhagawan Sri Sathya Sai Baba. Drawing its precedence from the education, value & culture prophesised by Sri Sathya Sai Baba & His exemplary Institutes, it is committed to maintain a rare excellence both in educational experience and help making a profession out of business.</p>

						<p>Our confidence lies in the presence of the phenomenon of the Avatar in our midst,  which appears from time to time to inaugurate a new world by raising man by His example and through His teachings from the earthly plane to a higher status.</p>
						<p>
						<p>The combined fervour of an excellently designed academic curriculum by Biju Patnaik University of Technology (BPUT), and the conducive environment of BIMIT has added a new dimension to the educational system, academic excellence, scope of employment  and quality of life.</p>

						<p>Education at BIMIT means drawing out the best attribute which a human being has. The five fold aspects of the growth of human personality, namely physical, intellectual, emotional, psychic and spiritual.</p>

						<p>BIMIT is dedicated to inculcation of value-based education balanced with scientific and technological knowledge and high standard of teachings.</p>

						<p>The cultural richness of BIMIT campus community is the three H. Orchestrating Head, Heart and Hand is the objective of BIMIT are almost nearest to thoroughness and have been translated into action at BIMIT.</p>

						<p>Knowledge and skills are imparted in BIMIT in an atmosphere of tenderness and intense love.</p>

						<p>The single golden faith that runs through the gamut of all the activities of the institute curricular, co-curricular and extra curricular is that “Education is for life and not for a mere living”.</p>

						<p>It is observed by academicians, industrialists and government that :-</p>

						<p>BIMIT is unique in the sense that it has carved out a place of its own in the academic and education map of our country.</p>

						<p>It is a nobel experiment in the field of education and people all over the country looking upto it with great expectation</p>
						<p class="text-right inner-rm"><a href="about-bimit-2.php">More >></a></p>
					</div>
				</div>
				<?php include_once 'include/footer.php'; ?>
			</div>
		</div>
	</div>




	
	<?php include_once 'include/js.php'; ?>

</body>
</html>