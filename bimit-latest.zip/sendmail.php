<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/Exception.php';
require 'PHPMailer/PHPMailer.php';
require 'PHPMailer/SMTP.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name    = htmlspecialchars(trim($_POST['name']));
    $phone   = htmlspecialchars(trim($_POST['phone']));
    $email   = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $course  = htmlspecialchars(trim($_POST['course']));
    $message = htmlspecialchars(trim($_POST['message']));

    // Handle "Others" case for message
    if ($_POST['message'] === 'Others' && !empty($_POST['other_message'])) {
        $message = htmlspecialchars(trim($_POST['other_message']));
    } else {
        $message = htmlspecialchars(trim($_POST['message']));
    }
    
    // Create PHPMailer instance
    $mail = new PHPMailer(true);

    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com'; // Or your SMTP
        $mail->SMTPAuth   = true;
        $mail->Username   = 'puspanjali@chatbotsolutions.in'; // Your email
        $mail->Password   = 'suvs pbow uxmm fzpa';   // Use Gmail App Password
        $mail->SMTPSecure = 'tls';
        $mail->Port       = 587;

        // Recipients
        $mail->setFrom('puspanjali@chatbotsolutions.in', 'Website Inquiry');
        $mail->addAddress('contactusbimitisit@gmail.com'); // Who receives

        // Content
        $mail->isHTML(true);
        $mail->Subject = 'New Inquiry from Website';
        $mail->Body    = "
            <h2>New Inquiry Received</h2>
            <p><strong>Name:</strong> $name</p>
            <p><strong>Phone:</strong> $phone</p>
            <p><strong>Email:</strong> $email</p>
            <p><strong>Course:</strong> $course</p>
            <p><strong>Message:</strong> $message</p>
        ";

        $mail->send();
        header("Location: index.php?status=success");
        exit;
    } catch (Exception $e) {
        header("Location: index.php?status=failed");
        exit;
    }
}
