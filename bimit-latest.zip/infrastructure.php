<!DOCTYPE html>
<html>
<head>
	<title>Infrastructure</title>
	<?php include_once 'include/css.php'; ?>
</head>
<body class="about-page">
	<div class="container">
		<div class="main-wrap">
			<?php include_once 'include/header.php'; ?>
			<div class="row">
				<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="inner-page-sec faciliti">
						<h1 class="inner-title">Infrastructure</h1>
						<div class="row">
							<div class="col-xl-3 col-lg-3 col-smd-3 col-sm-4 col-xs-12">
								<img src="images/comp_lab.png" class="img-fluid">
							</div>
							<div class="col-xl-9 col-lg-9 col-smd-9 col-sm-8 col-xs-12">
								<h4 class="inner-title2">Computer Lab</h4>
								<p>The computing facilities include the most modern up-to-date equipments including the latest PCs. There are currently two laboratories for use by the students with Wi-Fi Facility.</p>
								<p>One lab operates in the LAN environment while the other facilitates advanced computing which consists of all the advanced software's. The latter i.e. the second laboratory houses activities like computer training and software development.</p>
								<p>The computer centre can accommodate 180 students at a time, with all latest software used in Financial Analysis, Computer Graphics, World Processing, Data Processing, Data Base, Business Simulation and Multimedia. The computers are also linked with 1 MBPS INTERNET Connectivity and plans to have International Educational Network</p>
							</div>
							<div class="col-lg-12 col-md-12">
								<p><strong>(IEN) facilities.</strong></p>
								<p>No of machines:- 180</p>
								<p>MCA students make use of the labs with the help of faculty members as per the schedule.</p>
								<p>For the MCA students, we offer the following courses: </p>
								<p>DOS, Windows, C, C++, Visual Basic, Linux, SQL, MS Office, Java (Core / Advance).</p>
							</div>
						</div>
						<div class="row">
							<div class="col-xl-9 col-lg-9 col-smd-9 col-sm-8 col-xs-12">
								<h5 class="sm-head">We have 3 servers</h5>
								<p><strong>labLinux Server (HCL)</strong></p>
								<p>Configuration- Red hat 9.0, Hard disk – 80 GB, RAM – 512 MB, Processor – P-IV

								<p><strong>Proxy Server (HCL)</strong></p>
								<p>Configuration- Windows XP, Hard disk – 80 GB, RAM – 512 MB, Processor – P-IV

								<p><strong>Windows 2003 Server (IBM)</strong></p>
								<p>Configuration- Windows 2003, Hard disk – 160 GB, RAM – 1 GB, Processor – P-IV</p>
							</div>
							<div class="col-xl-3 col-lg-3 col-smd-3 col-sm-4 col-xs-12">
								<img src="images/comp_lab2.png" class="img-fluid">
							</div>
						</div>
						<div class="row">
							<div class="col-lg-12">
								<h4 class="inner-title2">Classroom</h4>
							</div>
							<div class="col-xl-3 col-lg-3 col-smd-3 col-sm-4 col-xs-12">
								<img src="images/classroom.png" class="img-fluid">
							</div>
							<div class="col-xl-9 col-lg-9 col-smd-9 col-sm-8 col-xs-12">
								<p><i><strong>No. of classrooms : 10 Student strength in each class : 60</strong></i></p>
								<table style="background-color: #ffffff; border-color: #777777; border-width: 1px; border-style: solid; width: 600px;" border="1" cellspacing="1" cellpadding="5" align="left">
									<tbody>
									<tr>
									<td class="style1" style="background-color: #99ffcc; height: 20px;" align="center" valign="middle"><span style="font-size: small;"><strong>Number of Classrooms <span style="font-size: small;">&nbsp;</span><br></strong></span></td>
									<td class="style1" style="background-color: #99ffcc; width: 272px; height: 20px;" align="center" valign="middle"><strong><span style="font-size: small;">Facilities</span></strong></td>
									</tr>
									<tr>
									<td class="style1" style="background-color: #ffffff; width: 149px;" align="center" valign="middle"><span style="font-size: small;">2</span></td>
									<td class="style1" style="background-color: #ffffff; width: 149px;" align="left" valign="middle"><span style="font-size: small;">English Communication Labs</span></td>
									</tr>
									<tr>
									<td class="style1" style="background-color: #ffffff; width: 149px;" align="center" valign="middle"><span style="font-size: small;">4</span></td>
									<td style="background-color: #ffffff; width: 149px;" align="left" valign="middle"><span style="font-size: small;">LCD and OHP for classroom teaching</span></td>
									</tr>
									<tr>
									<td class="style1" style="background-color: #ffffff; width: 149px;" align="center" valign="middle"><span style="font-size: small;">4</span></td>
									<td class="style1" style="background-color: #ffffff; width: 149px;" align="left" valign="middle"><span style="font-size: small;">Tutorial Classes with Laptops having Wi-Fi Connectivity</span></td>
									</tr>
									</tbody>
									</table>
							</div>
						</div>
						<div class="row">
							<div class="col-xl-9 col-lg-9 col-smd-9 col-sm-8 col-xs-12">
								<h4 class="inner-title2">Library</h4>
								<p>The library is automated having around 25000 books, periodicals on Management and Information Technology and other general matters.</p>
								<p>It also subscribes to various magazines, journals & newspapers. The library staff works closely with students and faculty, offering both individual and group assistance.</p>
								<p>The library is also a storehouse of a large number of videotapes and CDs covering the course materials.</p>
							</div>
							<div class="col-xl-3 col-lg-3 col-smd-3 col-sm-4 col-xs-12">
								<img src="images/livrary_new.png" class="img-fluid">
							</div>
						</div>
						<div class="row">
							<div class="col-xl-3 col-lg-3 col-smd-3 col-sm-4 col-xs-12">
								<img src="images/seminar.png" class="img-fluid">
							</div>
							<div class="col-xl-9 col-lg-9 col-smd-9 col-sm-8 col-xs-12">
								<h4 class="inner-title2">Seminar Hall</h4>
								<p>Our seminar hall hour's national & international seminars organized every year by the institute. Equipped with LCD projector, pleasant sound system and serene environment the seminar hall can accommodate 250 persons.</p>

								<p>Different industries coming for On-campus recruitment have conducted their PPT's in this hall. Eminent personality, dignitaries from industries, and other IT professionals including academicians have addressed the faculty and students here. Yoga practice classes, classes on Human Values, Ethics and Spirituality are also conducted in the seminar hall besides the daily weekly 'Bhajans of the Institute'. In short our seminar hall is a well-equipped ambience of an  ideal meeting place.</p>
							</div>
						</div>
					</div>
				</div>
				<?php include_once 'include/footer.php'; ?>
			</div>
		</div>
	</div>




	
	<?php include_once 'include/js.php'; ?>

</body>
</html>