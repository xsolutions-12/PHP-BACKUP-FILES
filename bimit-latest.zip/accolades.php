<!DOCTYPE html>
<html>
<head>
	<title>Shared Observation</title>
	<?php include_once 'include/css.php'; ?>
</head>
<body class="about-page">
	<div class="container">
		<div class="main-wrap">
			<?php include_once 'include/header.php'; ?>
			<div class="row">
				<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="inner-page-sec">
						<h1 class="inner-title">Shared Observation</h1>
						<img src="images/shard_observation.jpg" class="img-fluid">
					</div>
				</div>
				<?php include_once 'include/footer.php'; ?>
			</div>
		</div>
	</div>




	
	<?php include_once 'include/js.php'; ?>

</body>
</html>