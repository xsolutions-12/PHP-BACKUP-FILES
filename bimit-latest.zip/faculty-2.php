<!DOCTYPE html>
<html>
<head>
	<title>Faculty</title>
	<?php include_once 'include/css.php'; ?>
</head>
<body class="about-page">
	<div class="container">
		<div class="main-wrap">
			<?php include_once 'include/header.php'; ?>
			<div class="inner-page-sec">
				<div class="row">
					<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<h1 class="inner-title">Faculty Members </h1>
						<div style="">
							
							<table style="margin-top: 10px; height: 242px; width: 900px;" border="0" cellspacing="0" width="900" height="1041">
								<thead>
								<tr style="height: 40px; background-color: #ffffcc;" align="center" valign="middle">
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">
								<p><strong>Faculty</strong></p>
								</td>
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">
								<p>
								<strong>Name
								</strong></p>
								</td>
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">
								<p>
								<strong>Designation</strong></p>
								</td>
								<!--<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">-->
								<!--<p><strong>No. of Publications</strong></p>-->
								<!--</td>-->
								<!--<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">-->
								<!--<p><strong>Experience</strong></p>-->
								<!--</td>-->
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">
								<p><strong>Year Joined</strong></p>
								</td>
								</tr>
								</thead>
								<tbody>
								<tr>
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">
								<p><img src="images/faculty/qursid.png" alt="B M Das"></p>
								<!--<p><strong>Shri B.M Das</strong></p>-->
								</td>
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">
								<p><strong>Mrs. QURSHID  ARA</strong></p>
								</td>
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px; text-align: center;" scope="col">
								<p><strong> Assistant Professor</strong></p>
								<!--<p><strong>&nbsp;PG</strong> - PGD(NPC)(HRM) </p>-->
								</td>
								<!--<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">-->
								<!--<p>&nbsp;<strong>Books</strong> - 01</p>-->
								<!--<p>&nbsp;<strong>Nat. Journal</strong> - 01</p>-->
								<!--<p>&nbsp;<strong>Isem &amp; Conf</strong> - 02</p>-->
								<!--</td>-->
								<!--<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">-->
								<!--<p>&nbsp;<strong>Teaching</strong> - 10</p>-->
								<!--<p>&nbsp;<strong>Industry</strong> - 35</p>-->
								<!--</td>-->
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px; text-align: center;" scope="col">03-04-2023</td>
								</tr>
								<tr>
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">
								<p><img src="images/faculty/jeevan.png" alt="anshuman sahoo"></p>
								</td>
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col"><strong>Mr. JEEVAN JYOTI SARANGI</strong> <br></td>
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px; text-align: center;" scope="col">
								<p><strong> Assistant Professor</strong></p>
								</td>
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px; text-align: center;" scope="col">01-11-2024</td>
								</tr>
								<tr>
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">
								<p><img src="images/faculty/sunil.png" alt="sachi panda"></p>
								</td>
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">&nbsp;<strong>Mr. SUNIL KUMAR MOHAPATRA</strong> <br></td>
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px; text-align: center;" scope="col">
								<p><strong> Assistant Professor</strong></p>
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px; text-align: center;" scope="col">11-04-2025</td>
								</tr>
								<!--<tr>-->
								<!--<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">-->
								<!--<p><img src="images/faculty/user.png" alt="manoj kumar behera"></p>-->
								<!--</td>-->
								<!--<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">&nbsp;<strong>Mrs.LAXMI  BEURA</strong></td>-->
								<!--<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">-->
								<!--<p><span>&nbsp;<strong> Assistant Professor</strong> </span></p>-->
								<!--</td>-->
								<!--<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">&nbsp;<span>26/12/2007</span></td>-->
								<!--</tr>-->
								<!--<tr>-->
								<!--<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">-->
								<!--<p><img src="images/faculty/user.png" alt="chandrakanta sahoo"></p>-->
								<!--</td>-->
								<!--<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col"><strong>Mr.SANGRAM  SARANGI</strong>&nbsp;</td>-->
								<!--<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">&nbsp;-->
								<!--<p><span>&nbsp;<strong> Assistant Professor</strong></span></p>-->
								<!--</td>-->
								<!--<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">&nbsp;<span>12/08/2009</span></td>-->
								<!--</tr>-->
								<!--<tr>-->
								<!--<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">-->
								<!--<p><img src="images/faculty/user.png" alt="laxmi beura"></p>-->
								<!--<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col"><strong>Mr.SARTHAK SHANKAR BHAGAT</strong></td>-->
								<!--<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">&nbsp;-->
								<!--<p><span>&nbsp;<strong> Assistant Professor</strong></span></p>-->
								<!--</td>-->
								<!--<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">&nbsp;12/09/2012</td>-->
								<!--</tr>-->
								</tbody>
								</table>

						<p>&nbsp;</p>
						<table style="height: 40px; width: 86px;" border="0" width="86" height="40" align="center">
								<tbody>
								<tr>
								<td style="background-color: #107dc2;" align="center"><strong><a title="next page" href="faculty-1.php"><span style="color: #ffffff;">« Previous</span></a></strong></td>
								</tr>
							</tbody>
						</table>

						</div>
						
					<?php include_once 'include/footer.php'; ?>
				</div>
			</div>
		</div>
	</div>




	
	<?php include_once 'include/js.php'; ?>

</body>
</html>