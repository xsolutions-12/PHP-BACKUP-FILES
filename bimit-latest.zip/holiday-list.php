<!DOCTYPE html>
<html>
<head>
	<title>Holiday List</title>
	<?php include_once 'include/css.php'; ?>
</head>
<body class="about-page">
	<div class="container">
		<div class="main-wrap">
			<?php include_once 'include/header.php'; ?>
			<div class="inner-page-sec">
				<div class="row">
					<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<h1 class="inner-title">Holiday List</h1>
						<h1 style="text-align: center;">COMING SOON !!</h1>

						<!--<table style="width: 900px; border-color: #dddddd; border-width: 1px; border-style: solid;" border="1" cellspacing="0" cellpadding="5" align="center">-->
						<!--	<tbody>-->
						<!--	<tr>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p><strong>Sl.-->
						<!--	  No. </strong></p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p><strong>Date</strong></p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p><strong>Week-->
						<!--	  Days</strong></p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p><strong>Name-->
						<!--	  of Holidays </strong></p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p><strong>No.-->
						<!--	  of Days</strong></p>-->
						<!--	</td>-->
						<!--	</tr>-->
						<!--	<tr style="background-color: #f5f5f5;">-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>01</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>15.06.2011</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>Wednesday</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>Raja Sankarnti</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>01</p>-->
						<!--	</td>-->
						<!--	</tr>-->
						<!--	<tr>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>02</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>15.08.2011</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>Monday</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>Independence Day</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>01</p>-->
						<!--	</td>-->
						<!--	</tr>-->
						<!--	<tr style="background-color: #f5f5f5;">-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>03</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>31.08.2011</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>Wednesday</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>Id-ul-Fitre</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>01</p>-->
						<!--	</td>-->
						<!--	</tr>-->
						<!--	<tr>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>04</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>01.09.2011</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>Thursday</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>Ganesh Chaturthi</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>01</p>-->
						<!--	</td>-->
						<!--	</tr>-->
						<!--	<tr style="background-color: #f5f5f5;">-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>05</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>02.09.2011</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>Friday</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>Nuakhai</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>01</p>-->
						<!--	</td>-->
						<!--	</tr>-->
						<!--	<tr>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>06</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>27.09.2011</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>Tuesday</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>Mahalaya</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>01</p>-->
						<!--	</td>-->
						<!--	</tr>-->
						<!--	<tr style="background-color: #f5f5f5;">-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>07</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>03.10.2011 To 12.10.2011</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>Monday To Wednesday</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>Durga Puja</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>10</p>-->
						<!--	</td>-->
						<!--	</tr>-->
						<!--	<tr>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>08</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>26.10.2011</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>Wednesday</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>Kali Puja</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>01</p>-->
						<!--	</td>-->
						<!--	</tr>-->
						<!--	<tr style="background-color: #f5f5f5;">-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>09</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>07.11.2011</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>Monday</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>Id-ul-Zuha</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>01</p>-->
						<!--	</td>-->
						<!--	</tr>-->
						<!--	<tr>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>10</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>10.11.2011</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>Thursday</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>Kartika Purnima</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>01</p>-->
						<!--	</td>-->
						<!--	</tr>-->
						<!--	<tr style="background-color: #f5f5f5;">-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>11</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>21.11.2011</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>Monday</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>University Foundation Day</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>01</p>-->
						<!--	</td>-->
						<!--	</tr>-->
						<!--	<tr>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>12</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>06.12.2011</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>Tuesday</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>Moharrum</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>01</p>-->
						<!--	</td>-->
						<!--	</tr>-->
						<!--	<tr style="background-color: #f5f5f5;">-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>13</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>26.01.2012</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>Thursday</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>Republic Day</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>01</p>-->
						<!--	</td>-->
						<!--	</tr>-->
						<!--	<tr>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>14</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>28.01.2012</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>Saturday</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>Saraswati Puja</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>01</p>-->
						<!--	</td>-->
						<!--	</tr>-->
						<!--	<tr style="background-color: #f5f5f5;">-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>15</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>20.02.2012</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>Monday</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>Maha Sivaratri</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>01</p>-->
						<!--	</td>-->
						<!--	</tr>-->
						<!--	<tr>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>16</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>09.03.2012</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>Friday</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>Holi</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>01</p>-->
						<!--	</td>-->
						<!--	</tr>-->
						<!--	<tr style="background-color: #f5f5f5;">-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>17</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>06.04.2012</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>Friday</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>Good Friday</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>01</p>-->
						<!--	</td>-->
						<!--	</tr>-->
						<!--	<tr>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>&nbsp;</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>&nbsp;</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p>&nbsp;</p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p><strong>Total</strong></p>-->
						<!--	</td>-->
						<!--	<td style="width: 22%; border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">-->
						<!--	<p><strong>26</strong></p>-->
						<!--	</td>-->
						<!--	</tr>-->
						<!--	</tbody>-->
						<!--</table>-->
						<!--<div style="padding: 0 15px; margin-top: 10px;">-->
						<!--	<p><strong>Note :</strong> Summer Vacation shall be notified in due course.</p>-->
						<!--	<p>In addition to the above 26 days of holidays, the institute may at its discretion grant 4 days (Four Days) holidays for other occasions during the academic year 2011-12.</p>-->
						<!--</div>-->
					<?php include_once 'include/footer.php'; ?>
				</div>
			</div>
		</div>
	</div>




	
	<?php include_once 'include/js.php'; ?>

</body>
</html>