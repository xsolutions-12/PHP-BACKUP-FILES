<!DOCTYPE html>
<html>
<head>
	<title>Vision & Mission</title>
	<?php include_once 'include/css.php'; ?>
</head>
<body class="about-page">
	<div class="container">
		<div class="main-wrap">
			<?php include_once 'include/header.php'; ?>
			<div class="row">
				<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="inner-page-sec">
						<h1 class="inner-title">Vision & Mission</h1>
						<img src="images/integral_education.jpg" class="img-fluid">
						<p class="text-right inner-rm"><a href="vision-mission.php"> << previous</a></p>
					</div>
				</div>
				<?php include_once 'include/footer.php'; ?>
			</div>
		</div>
	</div>




	
	<?php include_once 'include/js.php'; ?>

</body>
</html>