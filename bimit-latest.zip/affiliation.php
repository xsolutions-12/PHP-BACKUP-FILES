<!DOCTYPE html>
<html>
<head>
	<title>Affiliation</title>
	<?php include_once 'include/css.php'; ?>
</head>
<body class="about-page">
	<div class="container">
		<div class="main-wrap">
			<?php include_once 'include/header.php'; ?>
			<div class="row">
				<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="inner-page-sec">
						<h1 class="inner-title">Affiliation</h1>
						<p><strong>Bhubaneswar Institute of Management and Information Technology (BIMIT)</strong>,&nbsp;Bhubaneswar has got its first conditional approval from&nbsp;<strong>All India Council for Technical Education (AICTE)</strong>, New Delhi vide letter No. F.36-7/B-II/BOS(M)/94/20094, dated 15th April 1994 to run&nbsp;<strong>Master of Business Administration (MBA)</strong>&nbsp;programme (2 Years Full Time) with an in take of 60 seats for the academic session 1995-1996.</p>
						<p style="text-align: justify;">BIMIT&nbsp;has got its first proviosonal affiliation from&nbsp;<strong>Utkal&nbsp;University</strong>&nbsp;Vanivihar, Bhubaneswar vide notification No. AFF.579/44499/97, dated 18.12.1997 to run MBA programme (2 Years Full Time) with an in take of 60 seats for the academic session 1995-1996.</p>
						<p style="text-align: justify;">From 1995-96 onwards, upto 2001-2002,&nbsp;BIMIT,&nbsp;continues to be affiliated from both&nbsp;AICTE&nbsp;and&nbsp;Utkal&nbsp;University.</p>
						<p style="text-align: justify;">But from 2002-2003, with the inception of&nbsp;BPUT&nbsp;Orissa&nbsp;BIMIT&nbsp;is coming within its purview.</p>
						<p style="text-align: justify;">During the year 2002-2003,&nbsp;BIMIT&nbsp;has again got its conditional approval from&nbsp;AICTE, vide letter No. F.NO-431/36-7/MCP(M)/94, dated 03.06.2002 to run MBA programme (2 Years Full Time).</p>
						<p style="text-align: justify;">Again during the year 2002-03,&nbsp;BIMIT&nbsp;has got its provisional affiliation form&nbsp;BPUT, Orissa vide notification No. BPUT/198, dated 16.03.2004 to run MBA programme (2 Years Full Time).</p>
						<p style="text-align: justify;">In the year 2006-2007,&nbsp;BIMIT&nbsp;has got its extension of&nbsp;AICTE&nbsp;approval vide letter No. F.NO.431/36-7/MCP(M)/94 dated 23.06.2006 to run MBA (2 Years Full Time) programme with an intake of 120 seats for the academic session 2006-2007.</p>
						<p style="text-align: justify;">In the year 2006-2007,&nbsp;BIMIT&nbsp;has also got its provisional affiliation from&nbsp;BPUT, Orissa vide letter No. BPUT/2590(2) dated 20.07.2006 to run MBA programme (2 Years Full Time) with an intake of 120 seats.</p>
						<p style="text-align: justify;">Now for the ongoing academic session 2007-08&nbsp;BIMIT&nbsp;has already got its conditional approval from&nbsp;AICTE, vide letter No. F.NO.431/36-7/MCP(M)/94, dated 10.05.2007 to run MBA programme (2 Years Full Time) with an intake of 120 seats for the academic session 2025-2026</p>
					</div>
				</div>
				<?php include_once 'include/footer.php'; ?>
			</div>
		</div>
	</div>




	
	<?php include_once 'include/js.php'; ?>

</body>
</html>