<!DOCTYPE html>
<html>
<head>
	<title>About BIMIT</title>
	<?php include_once 'include/css.php'; ?>
</head>
<body class="about-page">
	<div class="container">
		<div class="main-wrap">
			<?php include_once 'include/header.php'; ?>
			<div class="row">
				<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="inner-page-sec">
						<h1 class="inner-title">About BIMIT</h1>
						<p>The end of Education is Character and that the true meaning of education is not merely acquisition of knowledge, but knowledge in action.</p>

							<div class="no-mar-p">
								<p class="text-center">Perhaps ISIT and all the Institutions</p>
								<p class="text-center">Under the aegis of Orissa Trust of Technical</p>
								<p class="text-center">Education and Training (OTTET)</p>
								<p class="text-center">are the only institutions in the world,</p>
								<p class="text-center">which neither accept any donation</p>
								<p class="text-center">nor any capitation fee.</p>

								<p class="text-center">ISIT is dedicated to</p>
								<p class="text-center">Man-Making & not Money-Making</p>

								<p class="text-center">ISIT believes that</p>
								<p class="text-center">its students are its properties</p>
								<p class="text-center">not the land & buildings.</p>

								<p class="text-center">And with full faith and confidence that,</p>

								<p class="text-center">“When good students get good Gurus,</p>
								<p class="text-center">they succeed not only in attaining Bliss</p>
								<p class="text-center">but also in conferring peace, prosperity and joy</p>
								<p class="text-center">upon the entire world” </p>
							</div>
							<h6>BIMIT believes in quality & not quantity.</h6>
							<p>The Institute not only prepares students but also teachers. In pursuance of their continued excellence in academics, it encourages R & D to suit their interest.</p>

							<p>The programme of BIMIT, ever since its inception in 1995, has been observing a distinct feature of successful completion of eleven batches of its students. The Institute has to its credit the pride of consistently producing and experiencing 1st Class Degree holders, Toppers and Rank holders of the University. It continues to maintain this academic excellence.</p>

							<p>The students who have so far completed their MBA Degrees here are suitably absorbed in various prestigious organizations in India and abroad. Hardly one can find any company of repute where a BIMITIAN is not there. The Institute receives communication from all these old students regularly.</p>

							<p>Employers' outstanding report about the Institute's Alumni, their work ethos, commitment and over-all behaviour and competence support the validity of the design of the Institute's curriculum. It has been found that excellently managed companies have the pride of these areas of competence and strong value systems.</p>

							<p>Above all, BIMIT is successfully spiritualizing the modern teaching of sciences and humanities with a view to forging a synthesis of Western civilization and Indian culture from which both stand to benefit. The Institute is well on its way to becoming the model for tomorrow's educational institutions in India and elsewhere.</p>

							<p>BIMIT is fortunate in having the Grace. The guidance is sublime. The goal is steady. The vision is constant. The boundaries are well-defined. The message is vibrant and inspiring. Pace has been set. Hurdles are overcome. The march is on.</p>
						<p class="text-right inner-rm"><a href="about-bimit.php"> << previous</a></p>
					</div>
				</div>
				<?php include_once 'include/footer.php'; ?>
			</div>
		</div>
	</div>




	
	<?php include_once 'include/js.php'; ?>

</body>
</html>