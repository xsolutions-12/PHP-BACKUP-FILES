<!DOCTYPE html>
<html>
<head>
	<title>Academic Calendar</title>
	<?php include_once 'include/css.php'; ?>
</head>
<body class="about-page">
	<div class="container">
		<div class="main-wrap">
			<?php include_once 'include/header.php'; ?>
			<div class="inner-page-sec">
				<div class="row">
					<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<h1 class="inner-title">Academic Calendar</h1>
						<!--<h5 class="sm-head">Provisional Academic Calendar for MBA Programme for the session 2011-12</h5>-->
						<h1 style="text-align: center;">COMING SOON !!</h5>
<!--						<div class="">-->
<!--						<table style="line-height: 150%; background-color: #cccccc; margin-top: 10px; font-size: 13px;" border="0" cellspacing="1" cellpadding="5" width="930" height="833">-->
<!--<tbody>-->
<!--<tr>-->
<!--<td width="7%" align="center" valign="middle" bgcolor="#CCCCCC"><strong>Sl. -->
<!--                              No. </strong></td>-->
<!--<td width="23%" align="center" valign="middle" bgcolor="#CCCCCC"><strong>Events</strong></td>-->
<!--<td width="17%" align="center" valign="middle" bgcolor="#CCCCCC"><strong>1st Semester</strong></td>-->
<!--<td width="18%" align="center" valign="middle" bgcolor="#CCCCCC"><strong>2nd Semester</strong><br></td>-->
<!--<td width="18%" align="center" valign="middle" bgcolor="#CCCCCC"><strong>3rh Semester</strong></td>-->
<!--<td width="17%" align="center" valign="middle" bgcolor="#CCCCCC"><strong>4th Semester</strong></td>-->
<!--</tr>-->
<!--<tr valign="top">-->
<!--<td align="center" valign="middle" bgcolor="#F4F4F4"><strong>01</strong></td>-->
<!--<td valign="middle" bgcolor="#F4F4F4"><strong>Registration <br>-->
<!--                            </strong></td>-->
<!--<td align="center" valign="middle" bgcolor="#F4F4F4">05.09.2011 - 12.09.2011</td>-->
<!--<td align="center" valign="middle" bgcolor="#F4F4F4">24.01.2012 - 31.01.2012</td>-->
<!--<td align="center" valign="middle" bgcolor="#F4F4F4">05.09.2011 - 12.09.2011</td>-->
<!--<td align="center" valign="middle" bgcolor="#F4F4F4">13.02.2012 - 21.02.2012</td>-->
<!--</tr>-->
<!--<tr valign="top" bgcolor="#E4E4E4">-->
<!--<td align="center" valign="middle" bgcolor="#E4E4E4"><strong>02</strong></td>-->
<!--<td valign="middle"><strong>Registration With Fine Rs.500/-</strong></td>-->
<!--<td align="center" valign="middle" bgcolor="#E4E4E4">-</td>-->
<!--<td align="center" valign="middle" bgcolor="#E4E4E4">09.02.2012 - 16.02.2012 </td>-->
<!--<td align="center" valign="middle" bgcolor="#E4E4E4">13.09.2011 - 20.09.2011</td>-->
<!--<td align="center" valign="middle" bgcolor="#E4E4E4">22.02.2012 - 29.02.2012</td>-->
<!--</tr>-->
<!--<tr valign="top" bgcolor="#E4E4E4">-->
<!--<td align="center" valign="middle" bgcolor="#F4F4F4"><strong>03</strong></td>-->
<!--<td valign="middle" bgcolor="#F4F4F4"><strong>Registration With Fine Rs.1000/-</strong></td>-->
<!--<td align="center" valign="middle" bgcolor="#F4F4F4">-</td>-->
<!--<td align="center" valign="middle" bgcolor="#F4F4F4">06.02.2012-13.02.2012</td>-->
<!--<td align="center" valign="middle" bgcolor="#F4F4F4">21.09.2011-28.09.2011</td>-->
<!--<td align="center" valign="middle" bgcolor="#F4F4F4">01.03.2012-08.03.2012</td>-->
<!--</tr>-->
<!--<tr bgcolor="#E4E4E4">-->
<!--<td align="center" valign="middle" bgcolor="#E4E4E4"><strong>04</strong></td>-->
<!--<td valign="middle"><strong>Starting Date of Instruction</strong></td>-->
<!--<td align="center" valign="middle" bgcolor="#E4E4E4">03.09.2011</td>-->
<!--<td align="center" valign="middle" bgcolor="#E4E4E4">24.01.2012</td>-->
<!--<td align="center" valign="middle" bgcolor="#E4E4E4">03.09.2011</td>-->
<!--<td align="center" valign="middle" bgcolor="#E4E4E4">13.02.2012</td>-->
<!--</tr>-->
<!--<tr bgcolor="#E4E4E4">-->
<!--<td align="center" valign="middle" bgcolor="#F4F4F4"><strong>05</strong></td>-->
<!--<td valign="middle" bgcolor="#F4F4F4"><strong>Class Test - I</strong></td>-->
<!--<td align="center" valign="middle" bgcolor="#F4F4F4">13.10.2011 - 19.10.2011</td>-->
<!--<td align="center" valign="middle" bgcolor="#F4F4F4">16.02.2012 - 24.02.2012</td>-->
<!--<td align="center" valign="middle" bgcolor="#F4F4F4">13.10.2011 - 19.10.2011</td>-->
<!--<td align="center" valign="middle" bgcolor="#F4F4F4">13.03.2012 - 20.03.2012</td>-->
<!--</tr>-->
<!--<tr valign="top">-->
<!--<td align="center" valign="middle" bgcolor="#E4E4E4"><strong>06</strong></td>-->
<!--<td valign="middle" bgcolor="#E4E4E4"><strong>Online Mark Entry <br>(by the Colleges)</strong></td>-->
<!--<td align="center" valign="middle" bgcolor="#E4E4E4">28.10.2011 - 05.11.2011</td>-->
<!--<td align="center" valign="middle" bgcolor="#E4E4E4">05.03.2012 - 10.03.2012</td>-->
<!--<td align="center" valign="middle" bgcolor="#E4E4E4">28.10.2011 - 05.11.2011</td>-->
<!--<td align="center" valign="middle" bgcolor="#E4E4E4">27.03.2012-03.04.2012</td>-->
<!--</tr>-->
<!--<tr valign="top">-->
<!--<td align="center" valign="middle" bgcolor="#F4F4F4"><strong>07</strong></td>-->
<!--<td valign="middle" bgcolor="#F4F4F4"><strong>Class Test -II</strong></td>-->
<!--<td align="center" valign="middle" bgcolor="#F4F4F4">14.11.2011 - 19.11.2011</td>-->
<!--<td align="center" valign="middle" bgcolor="#F4F4F4">19.03.2012 - 26.03.2012</td>-->
<!--<td align="center" valign="middle" bgcolor="#F4F4F4">14.11.2011 - 19.11.2011</td>-->
<!--<td align="center" valign="middle" bgcolor="#F4F4F4">16.04.2012 - 24.04.2012</td>-->
<!--</tr>-->
<!--<tr valign="top">-->
<!--<td align="center" valign="middle" bgcolor="#E4E4E4"><strong>08</strong></td>-->
<!--<td valign="middle" bgcolor="#E4E4E4"><strong>Online Mark Entry <br>(by the Colleges)</strong></td>-->
<!--<td align="center" valign="middle" bgcolor="#E4E4E4">25.11.2011 - 01.12.2011</td>-->
<!--<td align="center" valign="middle" bgcolor="#E4E4E4">04.04.2012 - 11.04.2012</td>-->
<!--<td align="center" valign="middle" bgcolor="#E4E4E4">25.11.2011 - 01.12.2011</td>-->
<!--<td align="center" valign="middle" bgcolor="#E4E4E4">01.05.2012 - 09.05.2012</td>-->
<!--</tr>-->
<!--<tr valign="top">-->
<!--<td align="center" valign="middle" bgcolor="#F4F4F4"><strong>09</strong></td>-->
<!--<td valign="middle" bgcolor="#F4F4F4"><strong>Class Test -III</strong></td>-->
<!--<td align="center" valign="middle" bgcolor="#F4F4F4">12.12.2011 - 17.12.2011</td>-->
<!--<td align="center" valign="middle" bgcolor="#F4F4F4">16.04.2012 - 23.04.2012</td>-->
<!--<td align="center" valign="middle" bgcolor="#F4F4F4">12.12.2011 - 17.12.2011</td>-->
<!--<td align="center" valign="middle" bgcolor="#F4F4F4">14.05.2012 - 22.05.2012</td>-->
<!--</tr>-->
<!--<tr valign="top">-->
<!--<td align="center" valign="middle" bgcolor="#E4E4E4"><strong>10</strong></td>-->
<!--<td valign="middle" bgcolor="#E4E4E4"><strong>Online Mark Entry <br>(by the Colleges)</strong></td>-->
<!--<td align="center" valign="middle" bgcolor="#E4E4E4">24.12.2011 - 31.12.2011</td>-->
<!--<td align="center" valign="middle" bgcolor="#E4E4E4">01.05.2012 - 08.05.2012</td>-->
<!--<td align="center" valign="middle" bgcolor="#E4E4E4">24.12.2011 - 31.12.2011</td>-->
<!--<td align="center" valign="middle" bgcolor="#E4E4E4">29.05.2012 - 05.06.2012</td>-->
<!--</tr>-->
<!--<tr valign="top">-->
<!--<td align="center" valign="middle" bgcolor="#F4F4F4"><strong>11</strong></td>-->
<!--<td valign="middle" bgcolor="#F4F4F4"><strong>Closing Date of Instruction</strong></td>-->
<!--<td align="center" valign="middle" bgcolor="#F4F4F4">24.12.2011</td>-->
<!--<td align="center" valign="middle" bgcolor="#F4F4F4">05.05.2012</td>-->
<!--<td align="center" valign="middle" bgcolor="#F4F4F4">05.01.2012</td>-->
<!--<td align="center" valign="middle" bgcolor="#F4F4F4">25.05.2012</td>-->
<!--</tr>-->
<!--<tr valign="top">-->
<!--<td align="center" valign="middle" bgcolor="#E4E4E4"><strong>12</strong></td>-->
<!--<td valign="middle" bgcolor="#E4E4E4"><strong>End Semester Examiantion</strong></td>-->
<!--<td align="center" valign="middle" bgcolor="#E4E4E4">02.01.2012 - 14.01.2012</td>-->
<!--<td align="center" valign="middle" bgcolor="#E4E4E4">08.05.2012 - 24.05.2012</td>-->
<!--<td align="center" valign="middle" bgcolor="#E4E4E4">08.01.2012 - 22.01.2012</td>-->
<!--<td align="center" valign="middle" bgcolor="#E4E4E4">29.05.2012 - 17.06.2012</td>-->
<!--</tr>-->
<!--<tr valign="top">-->
<!--<td align="center" valign="middle" bgcolor="#F4F4F4"><strong>&nbsp;</strong><br></td>-->
<!--<td valign="middle" bgcolor="#F4F4F4"><strong>Summer Training </strong></td>-->
<!--<td align="center" valign="middle" bgcolor="#F4F4F4"> - </td>-->
<!--<td align="center" valign="middle" bgcolor="#F4F4F4">01.06.2012 - 15.07.2012</td>-->
<!--<td align="center" valign="middle" bgcolor="#F4F4F4"> - </td>-->
<!--<td align="center" valign="middle" bgcolor="#F4F4F4"> - </td>-->
<!--</tr>-->
<!--</tbody>-->
<!--</table>-->
<!--					</div>-->
					<?php include_once 'include/footer.php'; ?>
				</div>
			</div>
		</div>
	</div>




	
	<?php include_once 'include/js.php'; ?>

</body>
</html>