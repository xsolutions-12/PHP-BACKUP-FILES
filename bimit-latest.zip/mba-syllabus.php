<!DOCTYPE html>
<html>
<head>
	<title>MBA Syllabus</title>
	<?php include_once 'include/css.php'; ?>
</head>
<body class="about-page">
	<div class="container">
		<div class="main-wrap">
			<?php include_once 'include/header.php'; ?>
			<div class="inner-page-sec">
				<div class="row">
					<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<h1 class="inner-title">MBA Syllabus</h1>
						<a href="images/new_mba_sem_syllabus_2010.pdf" target="_blank">
							<img src="images/pdf.gif" class="img-fluid d-block mx-auto">
							<p class="text-center"><b>MBA</b><br>(Regular 2 years Semester System Programme)</p>
						</a>
					</div>
					<?php include_once 'include/footer.php'; ?>
				</div>
			</div>
		</div>
	</div>




	
	<?php include_once 'include/js.php'; ?>

</body>
</html>