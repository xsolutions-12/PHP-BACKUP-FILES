<!DOCTYPE html>
<html>
<head>
	<title>Training</title>
	<?php include_once 'include/css.php'; ?>
	<style type="text/css">
		ul, p, li {
			float: left;
			width: 100%;
		}
	</style>
</head>
<body class="about-page">
	<div class="container">
		<div class="main-wrap">
			<?php include_once 'include/header.php'; ?>
			<div class="inner-page-sec">
				<div class="row">
					<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<h1 class="inner-title">Training</h1>
<div>
<h2 style="text-align: center;">SOFT SKILLS AND COMMUNICATION</h2>
</div>
<p style="text-align: center;"><em>TOTAL HOURS: 35 SESSIONS: 25</em> </p>
<p style="text-align: center;"><span style="text-decoration: underline;"><br></span></p>
<p>&nbsp;</p>
<p>MODULE-I:  Objective = need analysis and competency
mapping </p>
<p>Session-1&amp;2:  one
to one interview for 5-7mts</p>
<p>Session 3:  a talk
on communication models like AIDA and SMCR.</p>
<p>Fundamentals </p>
<ul>
<li>Grammar
and uses (modal ,preposition , connotation ) </li>
<li>Avoidance
of redundancy, clichés, verbose, hyperboles. </li>
</ul>
<p>Session 4&amp;5: 
individual presentations for 7 mts</p>
<ul>
<li><em>Case study analysis</em> </li>
<li><em>Current&nbsp; business trends</em> </li>
<li><em>Presentation on advertisements
and effects</em> </li>
<li><em>Promoting a product(etc)</em> </li>
</ul>
<p>&nbsp;</p>
<p>MODULE-II: Objective=
Learning to relate verbal with non verbal communication and creativity
&amp;effective communication </p>
<p>Session-6:  a talk
on non verbal communication along with demonstration</p>
<ul>
<li><em>Tough questions and tricky
answers in the interview</em> </li>
<li><em>Reading the interviewer body
language</em> </li>
<li><em>Questions to avoid in an
interview</em> </li>
<li><em>Appropriate body language to
handle a stress interview</em> </li>
<li><em>Wear ,entry and exit mannerism</em> </li>
<li><em>Eye behavior in an interview</em> </li>
<li><em>How to handle embarrassments/
polite denial of unknown answers to questions</em> </li>
</ul>
<p>Session 7: 
grooming an integral part of non verbal communication</p>
<ul>
<li><em>Psychographic grooming</em> </li>
<li><em>Guess ,inference, predict</em> </li>
</ul>
<p>Session 8, 9 &amp;10: 
Application of verbal and non verbal skills in New Product Development </p>
<p><span style="text-decoration: underline; text-align: center;"> Group size:
5, mode: presentation</span></p>
<ul>
<li><em>Tone and style of presentation</em> </li>
<li><em>Audience demographic features</em> </li>
<li><em>Tools ,types , and tricks to
handle audience expectations</em> </li>
<li><em>Informative and evaluative
business presentation</em> </li>
<li><em>Features of effective
presentation in business contexts</em> </li>
</ul>
<p>&nbsp;</p>
<p>MODULE- III:  Objective= Listening and empathy and
essential aid in communication </p>
<p>Session- 11:&nbsp;  listening an aid to effective
communication (mode: activity)</p>
</div>
<div class="Section2">

<ul>
<li><em>Emphatic listening</em> </li>
<li><em>Listening with a purpose</em> </li>
<li><em>Intensive listening</em> </li>
<li><em>Critical listening</em> </li>
<li><em>Appreciative listening</em> </li>
<li><em>Listening against noise</em> </li>
<li><em>The listeners mental process</em> </li>
</ul>
</div>
<p>Session-12: &nbsp; conducting meetings and reaching conclusions
(role plays)</p>
<ul>
<li><em>Organizing a meeting</em> </li>
<li><em>Brain storming</em> </li>
<li><em>Preparing a minute of a mock
meeting</em> </li>
<li><em>Handling a conflict/clash of
opinion/ego</em> </li>
</ul>
<p>Session -13 : organizational
etiquettes and communication</p>
<p>Session-14:  basics
in written business communication.  <em>‘Keep it
short and simple’ (KISS)</em> </p>
<p>&nbsp;</p>
<p>MODULE-IV: Persuasive
communication </p>
<p>Session-15:  Talk
on GD, demonstration and feedback</p>
<p>Session-16 to 20: GD(
group size 8, so that each individual is exposed to the discussion at least 3
times) </p>
<ul>
<li>Topic
that relate to both business ,technical, abstract elements </li>
</ul>
<p>Session 21-24: 
individual interviews( feedback)</p>
<p><span style="text-decoration: underline; text-align: center;">
First round CV based</span></p>
<p><span style="text-decoration: underline; text-align: center;">
Second round competency based</span></p>
<ul>
<li>
	<em>POSSIBLE
QUESTIONS( Commonly Asked Questions And Their Possible Answers)</em></li>
</ul>
<p>Session-25:
recapitulation </p>
<ul>
<li><em>FEED-FORWARD</em> </li>
</ul>
</div>
						
						
					<?php include_once 'include/footer.php'; ?>
				</div>
			</div>
		</div>
	</div>




	
	<?php include_once 'include/js.php'; ?>

</body>
</html>