<!DOCTYPE html>
<html>
<head>
	<title>Contact Us</title>
	<?php include_once 'include/css.php'; ?>
	   <script>
        function toggleOtherMessage(select) {
            const otherBox = document.getElementById('otherMessageBox');
            if (select.value === 'Others') {
                otherBox.style.display = 'block';
            } else {
                otherBox.style.display = 'none';
            }
        }
    </script>
</head>
<body class="about-page">
	<div class="container">
		<div class="main-wrap">
			<?php include_once 'include/header.php'; ?>
			<div class="inner-page-sec">
				<div class="row">
					<div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-xs-12">
						<h1 class="inner-title">Contact Us</h1>
						<img src="images/iisit_locationmap.gif" class="img-fluid mx-auto d-block">
						<p class="text-center">Prasnagarbha, Plot. No-S-3/68, 69, & 83, Sec. A, Zone B</p>
						<p class="text-center">MancheswarInd.Estate, Bhubaneswar – 751010</p>
						<p class="text-center">Mob : 9938836335 / 9937573144</p>
						<!--<p class="text-center">Phone: 0674 - 600666666 / 600333333</p>-->
						<!--<p class="text-center">Fax : 0674-2582001</p>-->
						<p class="text-center">Web site: www.bimit.in</p>
						<p class="text-center">Email Id : bimit@bimit.in</p>	
				    </div>
				    <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-xs-12" style="border-left: 1px solid #e1e1e1;">
						<h1 class="inner-title">Inquiry Us</h1>
						<?php if (isset($_GET['status'])): ?>
            <div class="alert alert-<?= $_GET['status'] == 'success' ? 'success' : 'danger' ?>">
                <?= $_GET['status'] == 'success' ? 'Message Sent Successfully!' : 'Failed to Send Message.' ?>
            </div>
        <?php endif; ?>
                        <form action="sendmail.php" method="post">
  <label style="font-size: 13px;">Name:</label>
  <input type="text" name="name" required class="form-control" style="margin-bottom: -15px;"><br>

  <label style="font-size: 13px;">Phone No:</label>
  <input type="text" name="phone" required class="form-control" style="margin-bottom: -15px;"><br>

  <label style="font-size: 13px;">Email:</label>
  <input type="email" name="email" required class="form-control" style="margin-bottom: -15px;"><br>

  <label style="font-size: 13px;">Course:</label>
  <input type="text" name="course" value="MBA" readonly class="form-control" style="margin-bottom: -15px;"><br>

  <label style="font-size: 13px;">Message:</label>
            <select name="message" required class="form-control mb-2" onchange="toggleOtherMessage(this)">
                <option value="" disabled selected>-- Select a message --</option>
                <option value="What documents are required for admission?">What documents are required for admission?</option>
                <option value="Can I get an extension on the application deadline?">Can I get an extension on the application deadline?</option>
                <option value="Can you provide information on available scholarships?">Can you provide information on available scholarships?</option>
                <option value="Can I pursue this course through distance learning?">Can I pursue this course through distance learning?</option>
                <option value="Others">Others</option>
            </select>

            <!-- Hidden textarea shown only if "Others" is selected -->
            <div id="otherMessageBox" style="display: none;">
                <label>Enter your message:</label>
                <textarea name="other_message" class="form-control mb-3"></textarea>
            </div>

  <button type="submit" class="btn btn-primary" style="margin-top: 15px;">Submit</button>
</form>
				    </div>
			<?php include_once 'include/footer.php'; ?>
			</div>
		</div>
	</div>




	
	<?php include_once 'include/js.php'; ?>

</body>
</html>