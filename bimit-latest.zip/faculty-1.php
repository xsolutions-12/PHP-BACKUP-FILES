<!DOCTYPE html>
<html>
<head>
	<title>Faculty</title>
	<?php include_once 'include/css.php'; ?>
</head>
<body class="about-page">
	<div class="container">
		<div class="main-wrap">
			<?php include_once 'include/header.php'; ?>
			<div class="inner-page-sec">
				<div class="row">
					<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<h1 class="inner-title">Faculty Members </h1>
						<div style="">
							
							<table style="margin-top: 10px; height: 242px; width: 900px;" border="0" cellspacing="0" width="900" height="1041">
								<thead>
								<tr style="height: 40px; background-color: #ffffcc;" align="center" valign="middle">
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">
								<p><strong>Faculty</strong></p>
								</td>
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">
								<p>
								<strong>Name
								</strong></p>
								</td>
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">
								<p>
								<strong>Designation</strong></p>
								</td>
								<!--<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">-->
								<!--<p><strong>No. of Publications</strong></p>-->
								<!--</td>-->
								<!--<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">-->
								<!--<p><strong>Experience</strong></p>-->
								<!--</td>-->
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">
								<p><strong>Year Joined</strong></p>
								</td>
								</tr>
								</thead>
								<tbody>
								<tr>
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">
								<p><img src="images/faculty/tapan.png" alt="faculty"></p>
								<!--<p><strong>Prof.(Dr.) P.K Tripathy</strong></p>-->
								</td>
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">
								<p><strong>Prof (Dr) TAPAN KUMAR PANDA</strong></p>
								</td>
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px; text-align: center;" scope="col">
								<p><strong>Director Academics</strong></p>
								<!--<p><strong>&nbsp; PG</strong> - PGDM,XIM</p>-->
								<!--<p><strong>&nbsp; Doctorate</strong> - PGDEM, DBA</p>-->
								</td>
								<!--<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">-->
								<!--<p>&nbsp;<strong>Books</strong> - 03</p>-->
								<!--<p><strong>&nbsp; Nat.Journal</strong> - 05</p>-->
								<!--</td>-->
								<!--<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">-->
								<!--<p><strong>&nbsp;</strong><strong>Teaching</strong> - 08</p>-->
								<!--<p>&nbsp;<strong>Industry</strong> - 03</p>-->
								<!--<p>&nbsp;<strong>Research</strong> - 03</p>-->
								<!--<p>&nbsp;</p>-->
								<!--</td>-->
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px; text-align: center;" scope="col">13-03-2025</td>
								</td>
								</tr>
								<tr>
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">
								<p><img src="images/faculty/trupti.png" alt="B M Das"></p>
								<!--<p><strong>Shri B.M Das</strong></p>-->
								</td>
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">
								<p><strong>Dr. TRUPTIMAYEE  MAHARANA</strong></p>
								</td>
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px; text-align: center;" scope="col">
								<p><strong>Principal</strong></p>
								<!--<p><strong>&nbsp;PG</strong> - PGD(NPC)(HRM) </p>-->
								</td>
								<!--<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">-->
								<!--<p>&nbsp;<strong>Books</strong> - 01</p>-->
								<!--<p>&nbsp;<strong>Nat. Journal</strong> - 01</p>-->
								<!--<p>&nbsp;<strong>Isem &amp; Conf</strong> - 02</p>-->
								<!--</td>-->
								<!--<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">-->
								<!--<p>&nbsp;<strong>Teaching</strong> - 10</p>-->
								<!--<p>&nbsp;<strong>Industry</strong> - 35</p>-->
								<!--</td>-->
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px; text-align: center;" scope="col">18-02-2020</td>
								</tr>
								
								<tr>
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">
								<p><img src="images/faculty/user.png" alt="anshuman sahoo"></p>
								</td>
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col"><strong>Mrs.ARCHANA  BHAGAT</strong> <br></td>
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px; text-align: center;" scope="col">
								<p><strong> Professor</strong></p>
								</td>
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px; text-align: center;" scope="col">01-07-2021</td>
								</tr>
								
								<tr>
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">
								<p><img src="images/faculty/shravani.png" alt="sachi panda"></p>
								</td>
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">&nbsp;<strong>Miss. SHRABANI  SHUBHADARSHINI</strong> <br></td>
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px; text-align: center;" scope="col">&nbsp;
								<p><strong> Assistant Professor</strong></p>
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px; text-align: center;" scope="col">03-04-2019</td>
								</tr>
								
								<tr>
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">
								<p><img src="images/faculty/laxmi.png" alt="manoj kumar behera"></p>
								</td>
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col"><strong>Mrs. LAXMI  BEURA</strong></td>
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px; text-align: center;" scope="col">
								<p><span><strong> Assistant Professor</strong> </span></p>
								</td>
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px; text-align: center;" scope="col"><span>26-12-2007</span></td>
								</tr>
								
								<tr>
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">
								<p><img src="images/faculty/sangram.png" alt="chandrakanta sahoo"></p>
								</td>
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col"><strong>Mr. SANGRAM  SARANGI</strong>&nbsp;</td>
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px; text-align: center;" scope="col">
								<p><span><strong> Assistant Professor</strong></span></p>
								</td>
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px; text-align: center;" scope="col"><span>12-08-2009</span></td>
								</tr>
								
								<tr>
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">
								<p><img src="images/faculty/user.png" alt="laxmi beura"></p>
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col"><strong>Mr.SARTHAK SHANKAR BHAGAT</strong></td>
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px; text-align: center;" scope="col">
								<p><span><strong> Assistant Professor</strong></span></p>
								</td>
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px; text-align: center;" scope="col">12-09-2012</td>
								</tr>
								
								<tr>
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">
								<p><img src="images/faculty/munmun.png" alt="anil kumar mishra"></p>
								</td>
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col"><strong>Mrs. MOONMOON  BRAHMA</strong></td>
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px; text-align: center;" scope="col">
								<p><span><strong> Assistant Professor</strong></span></p>
								</td>
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px; text-align: center;" scope="col"><span>01-07-2021</span></td>
								</tr>
								
								<tr>
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">
								<p><img src="images/snigdha.png" alt="smita dash"></p>
								</td>
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col"><strong>Mrs. SNIGDHA  BHAGAT</strong></td>
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px; text-align: center;" scope="col">
								<p><span><strong> Assistant Professor</strong></span></p>
								</td>
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px; text-align: center;" scope="col"><span>03-07-2017</span></td>
								</tr>
								
								<tr>
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">
								<p><img src="images/shiv-narayan.png" alt="tania mishra"></p>
								</td>
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col"><strong>Mr. SHIV NARAYAN PATRI</strong></td>
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px; text-align: center;" scope="col">
								<p><span><strong> Assistant Professor</strong></span></p>
								</td>
								<td style="border-color: #dddddd; border-style: solid; border-width: 1px; text-align: center;" scope="col"><span>15-04-2009</span></td>
								</tr>
								</tbody>
								</table>

						<p>&nbsp;</p>
						<table style="height: 40px; width: 86px;" border="0" width="86" height="40" align="center">
								<tbody>
								<tr>
								<td style="background-color: #107dc2;" align="center"><strong><a title="next page" href="faculty-2.php"><span style="color: #ffffff;">Next »</span></a></strong></td>
								</tr>
							</tbody>
						</table>

						</div>
						
					<?php include_once 'include/footer.php'; ?>
				</div>
			</div>
		</div>
	</div>




	
	<?php include_once 'include/js.php'; ?>

</body>
</html>