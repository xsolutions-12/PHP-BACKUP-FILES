<!DOCTYPE html>
<html>
<head>
	<title>Advisors</title>
	<?php include_once 'include/css.php'; ?>
</head>
<body class="about-page">
	<div class="container">
		<div class="main-wrap">
			<?php include_once 'include/header.php'; ?>
			<div class="inner-page-sec">
				<div class="row">
					<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<div class="inner-page-sec">
							<h1 class="inner-title">Board of Advisors - Our Planners and Implementers</h1>
						</div>
						<table style="width: 564px; height: 421px; border-color: #dddddd; border-width: 1px; border-style: solid;" border="1" cellspacing="0" align="center">
						   <tbody>
						      <tr align="center" valign="middle">
						         <td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle"><img title="Justice P.N Bhagwati" src="images/p.n.bhagwati.gif" alt="Justice P.N Bhagwati" width="64" height="63"></td>
						         <td style="padding-left: 5px; border-color: #dddddd; border-style: solid; border-width: 1px;" align="left" valign="middle">
						            <p>CHAIRMAN, ADVISORS BOARD<br>
						               <strong>JUSTICE SRI P.N. BHAGWATI</strong><br>
						               Former Chief Justice of India<br>
						               Member UN Human Rights Commission<br>
						               Trustee, Sri Sathya Sai Central Trust<br>
						               Trustee, Sri Sathya Sai Educational Trust<br>
						               Chancellor, Sri Lal Bahadur Shastri Sanskrit  Vidhyapeeth
						            </p>
						         </td>
						      </tr>
						      <tr style="background-color: #f5f5f5;" align="center" valign="middle">
						         <td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle"><img title="Prof. S.K Khanna" src="images/skkhanna.png" alt="Prof. S.K Khanna" width="64" height="64"></td>
						         <td style="padding-left: 5px; border-color: #dddddd; border-style: solid; border-width: 1px;" align="left" valign="middle">
						            <p><span class="style1">
						               <strong>PROF S.K.KHANNA</strong>, FNAE, FNASc, FIE<br>
						               Former Chairman of AICTE.<br>
						               Vice-Chairemen UGC<br>
						               Chairman Research Council CSIR<br>
						               Chairman Board of Governors IIM(Ahmedabad)</span>
						            </p>
						         </td>
						      </tr>
						      <tr>
						         <td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">&nbsp;<img title="M K Kaw" src="images/m.k.kaw.jpg" alt="M K Kaw" width="59" height="56"></td>
						         <td style="padding-left: 5px; border-color: #dddddd; border-style: solid; border-width: 1px;" align="left" valign="middle">
						            <p><strong>MR. M. K. KAW</strong><br>Former Secretary HRD Govt. of India.<br>Dean, Sri   Sathya Sai   International School  of Human Values</p>
						         </td>
						      </tr>
						      <tr style="background-color: #f5f5f5;" align="center" valign="middle">
						         <td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">&nbsp;<img title="Prof. Subir Chowdhury" src="images/subir.chowdhury.gif" alt="Prof. Subir Chowdhury" width="64" height="63"></td>
						         <td style="padding-left: 5px; border-color: #dddddd; border-style: solid; border-width: 1px;" align="left" valign="middle">
						            <p><strong>PROF. SUBIR CHOWDHURY</strong><br>Former Director of IISW &amp; Business Management, Kolkata<br>Former Director, IIM (C)<br>Vice-Chairman of Indian Institute of Bank Management<br>Former Member, Board of Governors, XLRI, Jamshedpur</p>
						         </td>
						      </tr>
						      <tr>
						         <td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">&nbsp;<img title="Prof. Vachaspati Upadhyaya" src="images/vachaspati.upadhyaya.jpg" alt="Prof. Vachaspati Upadhyaya" width="64" height="71"></td>
						         <td style="padding-left: 5px; border-color: #dddddd; border-style: solid; border-width: 1px;" align="left" valign="middle">
						            <p><strong>PROF. VACHASPATI UPADHYAYA</strong><br>President, Association of Indian University &amp;<br>Vice-Chancellor, Shri Lal Bahadur Shastri Rashtriya <br>Sanskrit Vidyapeeth (Deemed University)</p>
						         </td>
						      </tr>
						      <tr style="background-color: #f5f5f5;" align="center" valign="middle">
						         <td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle"><img title="Sajjan Kumar Tulsiyan" src="images/sajjan.png" alt="Sajjan Kumar Tulsiyan" width="64" height="64">&nbsp;</td>
						         <td style="padding-left: 5px; border-color: #dddddd; border-style: solid; border-width: 1px;" align="left" valign="middle">
						            <p><strong>SRI SAJJAN KUMAR TULSIYAN</strong><br>(sr.advocate)<br>Taxation Consultants</p>
						         </td>
						      </tr>
						      <tr>
						         <td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle"><img title="Prof. M.M Pant" src="images/m.m.pant.png" alt="Prof. M.M Pant" width="64" height="64">&nbsp;</td>
						         <td style="padding-left: 5px; border-color: #dddddd; border-style: solid; border-width: 1px;" align="left" valign="middle">
						            <p><strong>PROF. M.M.PANT</strong><br>Member, Board of Management, IIT-Delhi,<br>Former Pro-Vice-Chancellor , IGNOU</p>
						         </td>
						      </tr>
						      <tr style="background-color: #f5f5f5;" align="center" valign="middle">
						         <td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle"><img title="Prof. Premananda Das" src="images/premananda.das.jpg" alt="Prof. Premananda Das" width="64" height="64">&nbsp;</td>
						         <td style="padding-left: 5px; border-color: #dddddd; border-style: solid; border-width: 1px;" align="left" valign="middle">
						            <p><strong>PROF. PREMANANDA DAS</strong>, FNA, FNA Sc. FNAAS,<br>INSA Senior Scientist <br>Department of Biotechnology<br>IIT, Kharagpur</p>
						         </td>
						      </tr>
						      <tr>
						         <td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle">&nbsp;<img title="Prof. S.K Chakraborty" src="images/s.k.chakraborty.gif" alt="Prof. S.K Chakraborty" width="64" height="59"></td>
						         <td style="padding-left: 5px; border-color: #dddddd; border-style: solid; border-width: 1px;" align="left" valign="middle">
						            <p><strong>PROF. S. K. CHAKRABORTY</strong><br>Prof. &amp; Founder Convenor,<br>Management Centre Human Values, IIM (C)</p>
						         </td>
						      </tr>
						   </tbody>
						</table>
					</div>
					<?php include_once 'include/footer.php'; ?>
				</div>
			</div>
		</div>
	</div>




	
	<?php include_once 'include/js.php'; ?>

</body>
</html>