<!DOCTYPE html>
<html>
<head>
	<title>Mandatory Disclosure</title>
	<?php include_once 'include/css.php'; ?>
</head>
<body class="about-page">
	<div class="container">
		<div class="main-wrap">
			<?php include_once 'include/header.php'; ?>
			<div class="row">
				<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="inner-page-sec">
						<h1 class="inner-title">Mandatory Disclosure</h1>
					</div>
					<div class="editor-content" style="    width: 100%;
    display: flex;
    flex-direction: column;">
						<p style="text-align: center;"><strong>BHUBANESWAR INSTITUTE OF MANAGEMENT &amp; INFORMATION TECHNOLOGY (BIMIT)</strong><br><strong>
Extension of Approval 2025-2026, MBA</strong></p>
<table border="0" cellspacing="0" cellpadding="0" width="100%" align="left">
<tbody>
<tr>
<td class="color" width="194" height="35" align="left" valign="top">Mandatory  Disclosure</td>
<td class="style3" width="14" align="center" valign="top">:</td>
<td class="color" colspan="2" align="left" valign="top">updated  on 10.02.2010</td>
</tr>
<tr>
<td class="color" height="20" align="left" valign="top">AICTE  File No</td>
<td class="style3" align="center" valign="top">:</td>
<td class="style4" colspan="2" height="30" align="left" valign="top">431/36-7/MCP(M)/94</td>
</tr>
<tr>
<td class="color" height="20" align="left" valign="top">Date  &amp; Period of last approval</td>
<td class="style3" align="center" valign="top">:</td>
<td class="style4" colspan="2" height="35" align="left" valign="top">June  6, (2009-2010)</td>
</tr>
<tr>
<td class="color" height="20" align="left" valign="top">Name  of the Institution</td>
<td class="style3" align="center" valign="top">:</td>
<td class="style4" colspan="2" height="38" align="left" valign="top">BHUBANESWAR INSTITUTE OF MANAGEMENT &amp; INFORMATION 
				TECHNOLOGY (BIMIT)</td>
</tr>
<tr>
<td class="color" height="20" align="left" valign="top">Address of the Institution</td>
<td class="style3" align="center" valign="top">:</td>
<td class="style4" colspan="2" height="75" align="left" valign="top">Prasnagarbha<br> 
                              Plot. No-S-3/68, 69, &amp; 83,<br> 
				Sector A, Zone-B,<br> 
				Mancheswar Industrial Estate,<br>
				Bhubaneswar</td>
</tr>
<tr>
<td class="color" height="20" align="left" valign="top">City &amp; Pin Code</td>
<td class="style3" align="center" valign="top">:</td>
<td class="style4" width="162" height="30" align="left" valign="top">Bhubaneswar-751010</td>
<td class="style4" rowspan="7" width="299" height="35" align="center" valign="top"><img src="images/map.png" alt="map" width="199" height="167"><br></td>
</tr>
<tr>
<td class="color" height="20" align="left" valign="top">State / UT</td>
<td class="style3" align="center" valign="top">:</td>
<td class="style4" height="30" align="left" valign="top">Orissa</td>
</tr>
<tr>
<td class="color" height="15" align="left" valign="top">Longitude &amp; Latitude</td>
<td class="style3" align="center" valign="top">:</td>
<td class="style4" height="30" align="left" valign="top">85 East, 21 North</td>
</tr>
<tr>
<td class="color" height="20" align="left" valign="top">Phone number with STD code</td>
<td class="style3" align="center" valign="top">:</td>
<td class="style4" height="30" align="left" valign="top">Phone:&nbsp;  0674-2580771</td>
</tr>
<tr>
<td class="color" height="20" align="left" valign="top">FAX number with STD code</td>
<td class="style3" align="center" valign="top">:</td>
<td class="style4" height="30" align="left" valign="top">Fax:&nbsp;  0674-2582001</td>
</tr>
<tr>
<td class="color" height="20" align="left" valign="top">Office hours at the Institution</td>
<td class="style3" align="center" valign="top">:</td>
<td class="style4" height="30" align="left" valign="top">9 AM – 5.00 PM</td>
</tr>
<tr>
<td class="color" align="left" valign="top">Academic hours at the Institution</td>
<td class="style3" align="center" valign="top">:</td>
<td class="style4" height="40" align="left" valign="top">07hrs</td>
</tr>
<tr>
<td class="color" height="25" align="left" valign="top">Email</td>
<td class="style3" align="center" valign="top">:</td>
<td align="left" valign="top"><a class="style4" href="mailto:bimit@bimit.in">bimit@bimit.in</a></td>
<td>&nbsp;</td>
</tr>
<tr>
<td class="color" height="25" align="left" valign="top">Website</td>
<td class="style3" align="center" valign="top">:</td>
<td class="style4" align="left" valign="top"><a class="style4" href="http://www.bimit.in/">www.bimit.in</a></td>
<td>&nbsp;</td>
</tr>
<tr>
<td class="color" height="25" align="left" valign="top">Nearest Railway Station (dist in Km)</td>
<td class="style3" align="center" valign="top">:</td>
<td class="style4" align="left" valign="top">6 km</td>
<td>&nbsp;</td>
</tr>
<tr>
<td class="color" height="25" align="left" valign="top">Nearest Airport (dist in Km)</td>
<td class="style3" align="center" valign="top">:</td>
<td class="style4" align="left" valign="top">10km</td>
<td>&nbsp;</td>
</tr>
<tr>
<td class="color" height="25" align="left" valign="top">Type of Institution</td>
<td class="style3" align="center" valign="top">:</td>
<td class="style4" align="left" valign="top">Private-Self Financed</td>
<td>&nbsp;</td>
</tr>
<tr>
<td class="color" height="35" align="left" valign="top">Category (1) of the Institution</td>
<td class="style3" align="center" valign="top">:</td>
<td class="style4" align="left" valign="top">Non Minority</td>
<td>&nbsp;</td>
</tr>
<tr>
<td class="color" height="35" align="left" valign="top">Category (2) of the Institution</td>
<td class="style3" align="center" valign="top">:</td>
<td class="style4" align="left" valign="top">Co-Ed </td>
<td>&nbsp;</td>
</tr>
<tr>
<td class="color" height="35" align="left" valign="top">Name of the organization running	
                              the Institution</td>
<td class="style3" align="center" valign="top">:</td>
<td class="style4" colspan="2" align="left" valign="top">Orissa Trust of Technical Education &amp; Training  (OTTET)</td>
</tr>
<tr>
<td class="color" height="25" align="left" valign="top">Type of organization</td>
<td class="style3" align="center" valign="top">:</td>
<td class="style4" align="left" valign="top">Trust</td>
<td>&nbsp;</td>
</tr>
<tr>
<td class="color" height="25" align="left" valign="top">Address of the organization</td>
<td class="style3" align="center" valign="top">:</td>
<td class="style4" colspan="2" align="left" valign="top">Prasnagarbha, Plot. No-S-3/68, 69, &amp; 83, <br>
                              Sector A, Zone-B, <br>
                              Mancheswar Industrial., 
                              Estate<br>
                              Bhubaneswar<br></td>
</tr>
<tr>
<td class="color" height="25" align="left" valign="top">Registered with</td>
<td class="style3" align="center" valign="top">:</td>
<td class="style4" colspan="2" align="left" valign="top">District Sub-Registrar, Bhubaneswar</td>
</tr>
<tr>
<td class="color" height="25" align="left" valign="top">Registration date</td>
<td class="style3" align="center" valign="top">:</td>
<td class="style4" colspan="2" align="left" valign="top">18-May, 1998 (No. 1165)</td>
</tr>
<tr>
<td class="color" height="25" align="left" valign="top">Website of the organization</td>
<td class="style3" align="center" valign="top">:</td>
<td class="style4" align="left" valign="top"><a href="http://www.ottet.in/">www.ottet.in</a></td>
<td>&nbsp;</td>
</tr>
<tr>
<td class="color" height="25" align="left" valign="top">Name of the affiliating University</td>
<td class="style3" align="center" valign="top">:</td>
<td class="style4" colspan="2" align="left" valign="top"><a href="http://www.bput.ac.in/">Biju Patnaik University of Technology (BPUT)</a></td>
</tr>
</tbody>
</table>
</div>
				<?php include_once 'include/footer.php'; ?>
			</div>
		</div>
	</div>




	
	<?php include_once 'include/js.php'; ?>

</body>
</html>