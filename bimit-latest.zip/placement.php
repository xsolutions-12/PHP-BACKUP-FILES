<!DOCTYPE html>
<html>
<head>
	<title>Placement</title>
	<?php include_once 'include/css.php'; ?>
</head>
<body class="about-page">
	<div class="container">
		<div class="main-wrap">
			<?php include_once 'include/header.php'; ?>
			<div class="inner-page-sec">
				<div class="row">
					<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<h1 class="inner-title">BIMIT Placement Details</h1>
						<table border="0" cellspacing="0" cellpadding="0" width="826" height="1638">
							<tbody>
							<tr>
							<td class="style1" colspan="3" height="115" align="left" valign="top">
							<table border="1" cellspacing="0" cellpadding="0" width="598" height="278" align="center">
							<tbody>
							<tr>
							<td style="width: 175px;" align="center" valign="middle">
							<p><strong>Year</strong></p>
							</td>
							<td style="width: 218px;" align="center" valign="middle">
							<p><strong>No. of Students on the Roll</strong></p>
							</td>
							<td style="width: 197px;" align="center" valign="middle">
							<p><strong>No. of Students Placed</strong></p>
							</td>
							</tr>
							<tr>
							<td align="center" valign="middle">
							<p>2016-15</p>
							</td>
							<td align="center" valign="middle">
							<p>60</p>
							</td>
							<td align="center" valign="middle">
							<p>52</p>
							</td>
							</tr>
							<tr>
							<td align="center" valign="middle">
							<p>2017-16</p>
							</td>
							<td align="center" valign="middle">
							<p>60</p>
							</td>
							<td align="center" valign="middle">
							<p>42</p>
							</td>
							</tr>
							<tr>
							<td align="center" valign="middle">
							<p>2018-19</p>
							</td>
							<td align="center" valign="middle">
							<p>120</p>
							</td>
							<td align="center" valign="middle">
							<p>75</p>
							</td>
							</tr>
							<tr>
							<td align="center" valign="middle">
							<p>2019-20</p>
							</td>
							<td align="center" valign="middle">
							<p>120</p>
							</td>
							<td align="center" valign="middle">
							<p>47</p>
							</td>
							</tr>
							<tr>
							<td align="center" valign="middle">
							<p>2020-21</p>
							</td>
							<td align="center" valign="middle">
							<p>120</p>
							</td>
							<td align="center" valign="middle">
							<p>25</p>
							</td>
							</tr>
							<tr>
							<td align="center" valign="middle">
							<p>2021-22</p>
							</td>
							<td align="center" valign="middle">
							<p>120</p>
							</td>
							<td align="center" valign="middle">
							<p>78</p>
							</td>
							</tr>
							<tr>
							<td align="center" valign="middle">
							<p>2022-23</p>
							</td>
							<td align="center" valign="middle">120</td>
							<td align="center" valign="middle">
							<p>Continuing……</p>
							</td>
							</tr>
							</tbody>
							</table>
							</td>
							</tr>
							<tr style="height: 40px;">
							<td class="style1" width="55" height="16" align="left" valign="top">
							<p>&nbsp;</p>
							</td>
							<td colspan="2" align="left" valign="middle">
							<p>&nbsp;</p>
							<p><strong>Major corporate participates in the campus drive</strong></p>
							<table border="0" cellspacing="0" cellpadding="0" width="100%" align="center">
							<tbody>
							<tr>
							<td width="52%" valign="top"><ol>
							<li>Vangelz Technologies Pvt. Ltd., Noida</li>
							<li>Linx Smart Technology, Delhi</li>
							<li>Destimoney (MNC), Bhubaneswar</li>
							<li>Helix Technology Solutions, Hyderabad</li>
							<li>GlaxoSmithKline Consumer Health Care Ltd., FMCG</li>
							<li>Capital IQ, Hyderabad</li>
							<li>Britt World Wide</li>
							<li>Wipro Spectramind</li>
							<li>ICICI Bank Ltd.</li>
							<li>ICICI Prudential</li>
							<li>Kotak Services Ltd.</li>
							<li>Reliance Infocom</li>
							</ol></td>
							<td width="48%" valign="top"><ol>
							<li>CITI Bank</li>
							<li>India Bulls Securities Ltd.</li>
							<li>Franklin Templeton Ltd.</li>
							<li>Ceasefire Industries Ltd.</li>
							<li>WIPRO BPO Solution Ltd.</li>
							<li>Standard Chartered Bank</li>
							<li>SBI Life Insurance</li>
							<li>HDFC Bank</li>
							<li>UTI Bank</li>
							<li>Airtel, Bangalore</li>
							<li>IDBI Bank, Delhi</li>
							<li>Shiva Shakti Group of Companies, Hyderabad</li>
							</ol></td>
							</tr>
							</tbody>
							</table>
							<p>&nbsp;</p>
							</td>
							</tr>
							<tr>
							<td class="style1" height="16" align="left" valign="top">&nbsp;</td>
							<td class="style1" colspan="2" align="left" valign="top">
							<p><strong>Major Companies where our students have undergone 2 months Job Training during July – August, 2010</strong></p>
							<table border="0" cellspacing="0" cellpadding="0" width="95%">
							<tbody>
							<tr>
							<td width="50%"><ol>
							<li>Kurlon Ltd.</li>
							<li>OMFED, Cuttack</li>
							<li>Mamata Agro Foods</li>
							<li>Tripti Drinks Pvt. Ltd.</li>
							<li>Nestle India Ltd.</li>
							<li>Birla Tires Ltd.</li>
							<li>Tata Tele Service Ltd.</li>
							<li>Gujurat Co-operative Milk Marketing Fed. Ltd</li>
							<li>Max New York Life Insurance Co. Ltd.</li>
							<li>Kotak Securities Ltd.</li>
							<li>Om Oil and Flour Mills Ltd.</li>
							<li>Ultra Tech Cement Ltd.</li>
							<li>Hindustan Copper Ltd.</li>
							<li>J. K. Paper Mills</li>
							<li>Karvey Stock Broking Ltd</li>
							<li>Indus Ind Bank Ltd</li>
							</ol></td>
							<td valign="top"><ol>
							<li>International Auto Ltd</li>
							<li>Indian Auto Ltd.</li>
							<li>Indian Oil Corporation</li>
							<li>Punjab National Bank</li>
							<li>NALCO</li>
							<li>Orissa Spong Iron Ltd.</li>
							<li>Hindustan Coca-Cola Beverages Pvt. Ltd.</li>
							<li>NALCO Smelter Plant, Angul</li>
							<li>Orissa Power Transmission Corporation Ltd.</li>
							<li>Nagarjuna Agrichem Ltd.</li>
							<li>Orisssa Cement Ltd</li>
							<li>NTPC, Simhadiri</li>
							<li>HAL, Sunabeda</li>
							<li>ARSS Infrastructure Project Ltd.</li>
							<li>ITC Ltd.</li>
							<li>UAL Industries Ltd.</li>
							</ol></td>
							</tr>
							</tbody>
							</table>
							<br></td>
							</tr>
							<tr>
							<td class="style1" height="16" align="left" valign="top">&nbsp;</td>
							<td class="style1" colspan="2" align="left" valign="top">
							<p><strong>Major companies where our students have undergone 2 months Job training during June &amp; July 2006 &amp; 2007.</strong></p>
							<table border="0" cellspacing="0" cellpadding="0" width="95%">
							<tbody>
							<tr>
							<td width="50%"><ol>
							<li>NALCO</li>
							<li>RSP</li>
							<li>UTI Bank</li>
							<li>SBI Life</li>
							<li>IMFA</li>
							<li>SBI (Trg. &amp; Dev.)</li>
							<li>Cocacola Beverage</li>
							</ol></td>
							<td valign="top"><ol>
							<li>Reliance Money</li>
							<li>OMFED</li>
							<li>OPGC</li>
							<li>ICICI Prudential</li>
							<li>Lamour Cosmetics (I) Pvt. Ltd.</li>
							<li>LIC of India</li>
							<li>CESC, Kolkata</li>
							</ol></td>
							</tr>
							</tbody>
							</table>
							<br></td>
							</tr>
							<tr>
							<td class="style1" height="16" align="left" valign="top">&nbsp;</td>
							<td class="style1" colspan="2" align="center" valign="top">
							<p style="text-align: left;"><strong>List of Companies/Organisation where MBA 1st Year (2007-09) Batch Took their SIP</strong></p>
							</td>
							</tr>
							<tr>
							<td class="style1" height="16" align="left" valign="top">&nbsp;</td>
							<td class="style1" width="237" align="left" valign="top"><ol>
							<li>Max New York Life</li>
							<li>Ortel</li>
							<li>Reliance Life</li>
							<li>HDFC Std. Life</li>
							<li>NALCO</li>
							<li>RBI</li>
							<li>HINDALCO</li>
							<li>Pepsico</li>
							<li>Reliance Money</li>
							<li>Axis Bank</li>
							<li>AFL Pvt. Ltd.</li>
							<li>IDBI Capital</li>
							<li>Frostee</li>
							<li>ICICI Bank</li>
							<li>IOB</li>
							<li>Ruchi</li>
							<li>Celesty</li>
							<li>Bolani Ore Mines</li>
							<li>2Coms</li>
							<li>Coca Cola</li>
							<li>Syndicate Bank</li>
							<li>RRTC</li>
							<li>DTFL</li>
							</ol></td>
							<td class="style1" width="418" align="left" valign="top"><ol>
							<li>Bajaj Allianz</li>
							<li>PNB</li>
							<li>IMFA</li>
							<li>Onida</li>
							<li>LG Electronics</li>
							<li>Std. Chartered</li>
							<li>SANSUI</li>
							<li>HDFC Bank</li>
							<li>UTI MF</li>
							<li>IFFCU</li>
							<li>SBI</li>
							<li>Indian Bank</li>
							<li>MIRC Electronic</li>
							<li>HAL</li>
							<li>OMC</li>
							<li>OPGC</li>
							<li>Jindal</li>
							<li>E. Co Rly</li>
							<li>Vijaj Steel Plant</li>
							<li>Paradeep Port Trust</li>
							</ol></td>
							</tr>
							</tbody>
						</table>
							<p class="text-right"><strong><a href="placement-2.php">Next >></a></strong></p>
						
					<?php include_once 'include/footer.php'; ?>
				</div>
			</div>
		</div>
	</div>




	
	<?php include_once 'include/js.php'; ?>

</body>
</html>