<!DOCTYPE html>
<html>
<head>
	<title>Dean</title>
	<?php include_once 'include/css.php'; ?>
</head>
<body class="about-page">
	<div class="container">
		<div class="main-wrap">
			<?php include_once 'include/header.php'; ?>
			<div class="inner-page-sec">
				<div class="row">
					<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<div class="inner-page-sec">
							<h1 class="inner-title">Dean</h1>
						</div>
						<div class="row">
							<div class="col-lg-12 col-md-12">
								<div class="img-box" style="display: block;margin: 0 auto;">
									<img src="images/dean.jpg" class="img-fluid mx-auto d-block">
									<p class="text-center"><strong>Prof. (Dr.) P. K. Tripathy <br>  B.Sc. Engg, PGDM (XIMB) PGDEM, DBA (UK)</strong></p>
								</div>
							</div>
							<div class="col-lg-12 col-md-12">
								<p>It is strange to notice that the present model of Management education in many institutions in India is outdated. It is the need of the hour to produce value enriched Managers, not degree holders.</p>

								<p>With the change of Generation business operation and global competition has taken a new shape with which our managers or leaders has to cope with.</p>
								<p>We at BIMIT prepare future Indian professionals with value, morale and integrity. We integrate academic wisdom with human values crafting new thoughts like spiritualism, ethics, corporate transparency and value based management processes.</p>
								<p class="text-center"><strong>"Only a man of steady character and wisdom can carry out the task of leading and administering a kingdom effectively".</strong></p>
							</div>
						</div>
					</div>
					<?php include_once 'include/footer.php'; ?>
				</div>
			</div>
		</div>
	</div>




	
	<?php include_once 'include/js.php'; ?>

</body>
</html>