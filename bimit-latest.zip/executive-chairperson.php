<!DOCTYPE html>
<html>
<head>
	<title>Executive Chairperson</title>
	<?php include_once 'include/css.php'; ?>
</head>
<body class="about-page">
	<div class="container">
		<div class="main-wrap">
			<?php include_once 'include/header.php'; ?>
			<div class="inner-page-sec">
				<div class="row">
					<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<div class="inner-page-sec">
							<h1 class="inner-title">Executive Chairperson</h1>
						</div>
						<div class="row">
							<div class="col-lg-12 col-md-12">
								<div class="img-box" style="display: block;margin: 0 auto;">
									<img src="images/chairperson.png" class="img-fluid mx-auto d-block">
									<p class="text-center"><strong>Atreyee Panda <br>Executive Chairperson</strong></p>
								</div>
							</div>
							<div class="col-lg-12 col-md-12">
								<p>The Bhubaneswar Institute of Management and Information Technology (BIMIT), a premier Business School is an intellectual community rightly blended with spiritualism & strong traditions. It owes its inception to the Grace and Blessing of Beloved Bhagawan Sri Sathya Sai Baba. Drawing its precedence from the education, value & culture prophesized by Sri Sathya Sai Baba & His exemplary Institutes, it is committed to maintain a rare excellence both in educational experience and help making a profession out of business.</p>

								<p>BIMIT prepares students to shoulder leadership and responsibilities as executive, managers, teachers and officers in various fields and become warriors of the twenty first century to unite humanity with the bond of Love.</p>
							</div>
						</div>
					</div>
					<?php include_once 'include/footer.php'; ?>
				</div>
			</div>
		</div>
	</div>




	
	<?php include_once 'include/js.php'; ?>

</body>
</html>