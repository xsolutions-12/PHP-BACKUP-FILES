<!DOCTYPE html>
<html>
<head>
	<title>Welcome BIMIT</title>
	<?php include_once 'include/css.php'; ?>
</head>
<body class="home-page">
	<div class="container">
		<div class="main-wrap">
			<?php include_once 'include/header.php'; ?>

			<div class="owl-carousel banner-slider">
				<div class="slider-item">
					<img src="images/slider1.jpg" class="img-fluid">
					<div class="caption">
						<p>A world where man loves man.</p>
						<h4>RECEIVING THE SOURCE OF BENEDICTION</h4>
					</div>
				</div>
				<div class="slider-item">
					<img src="images/slider2.jpg" class="img-fluid">
				</div>
				<div class="slider-item">
					<img src="images/slider3.jpg" class="img-fluid">
					<div class="caption">
						<h4>Library</h4>
					</div>
				</div>
				<div class="slider-item">
					<img src="images/slider4.jpg" class="img-fluid">
				</div>
				<div class="slider-item">
					<img src="images/slider5.jpg" class="img-fluid">
					<div class="caption">
						<h4>Computer Lab</h4>
					</div>
				</div>
				<div class="slider-item">
					<img src="images/slider6.jpg" class="img-fluid">
				</div>
			</div>

			<div class="notice-sec">
				<p><marquee onmouseover="this.stop()" onmouseout="this.start()">Congratulations to all our students for being placed so far !</marquee></p>
			</div>

			<div class="row">
				<div class="col-xl-8 col-lg-8 col-md-8 col-sm-12 col-xs-12">
					<div class="row">
						<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 pad-r-5">
							<div class="wel-sec">
								<h4 class="head-bg">Welcome to BIMIT</h4>
								<p><strong>BIMIT,</strong> a premier Business School is an intellectual community rightly blended with spiritualism & strong traditions. It owes its inception to the Grace and Blessing of Beloved Bhagawan Sri Sathya Sai Baba. Drawing its precedence from the education, value & culture prophesised by Sri Sathya Sai Baba & His exemplary Institutes, it is committed to maintain a rare excellence both in educational experience and help making a profession out of business.</p>
								<p>Our confidence lies in the presence of the phenomenon of the Avatar in our midst, which appears from time to time to inaugurate a new world by raising man by His example and through his teachings from the earthly plane to a higher status.</p>
								<p>The combined fervour of an excellently designed academic curriculum by Biju Patnaik University of Technology (BPUT), and the conducive environment of <strong>BIMIT</strong> has added a new dimension to the educational system, academic excellence, scope of employment  and quality of life.</p>
								<a class="read-more" href="#"><img src="images/more.jpg" title="read more"></a>
							</div>
						</div>
						<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 pad-r-5">
							<div class="full-sec">
								<h4 class="head-bg">Education for Life - The need of the Hour</h4>
								<div class="full">
									<img src="images/wel.png" class="img-fluid pp-img">
									<p>"Education without character, commerce without morality, politics without principles, science without humanity, religion without love, culture without unity, administration without justice, knowledge without application, and patriotism without sacrifice are not only useless but positively dangerous".</p>
									<a class="read-more" href="#"><img src="images/more.jpg" title="read more"></a>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-xs-12 pad-l-0">
					<div class="full-sec">
						<h4 class="head-bg2">Campus Placements 2022-23 batch</h4>
						<div class="nt">
							<ul class="list-news" id="nt-example">
							   <li>
							      <h4>Bikash Kumar Behera</h4>
							      <p>Spandana Sphoorty Financial Limited</p>
							      <span> lacs.</span>
							   </li>
							   <li>
							      <h4>Soumya Ranjan Rana</h4>
							      <p>Spandana Sphoorty Financial Limited</p>
							      <span> lacs.</span>
							   </li>
							   <li>
							      <h4>Ankita Kumari</h4>
							      <p>Spandana Sphoorty Financial Limited</p>
							      <span> lacs.</span>
							   </li>
							   <li>
							      <h4>Ellora Bhuyan</h4>
							      <p>Spandana Sphoorty Financial Limited</p>
							      <span> lacs.</span>
							   </li>
							   <li>
							      <h4>Suchana Swastik Mishra</h4>
							      <p>Spandana Sphoorty Financial Limited</p>
							      <span> lacs.</span>
							   </li>
							   <li>
							      <h4>Rashmi Jena</h4>
							      <p>Spandana Sphoorty Financial Limited</p>
							      <span> lacs.</span>
							   </li>
							   <li>
							      <h4>Ashish Bhagat </h4>
							      <p>SBI LIFE </p>
							      <span>nbsp;2.5 lacs.</span>
							   </li>
							   <li>
							      <h4>Satyanarayan Satapathy </h4>
							      <p>SBI LIFE </p>
							      <span>.5 lacs. </span>
							   </li>
							   <li>
							      <h4>Debasis Mohanty </h4>
							      <p>CEASEFIRE </p>
							      <span>.86 to 2.5 lacs.</span>
							   </li>
							   <li>
							      <h4>Biswabibhu Satrusallya </h4>
							      <p> CEASEFIRE </p>
							      <span>.86 to 2.5 lacs.</span>
							   </li>
							   <li>
							      <h4>Jyoti Prakash Pradhan </h4>
							      <p>CEASEFIRE </p>
							      <span>.86 to 2.5 lacs.</span>
							   </li>
							   <li>
							      <h4>Ramanaranjan Sahoo </h4>
							      <p>CEASEFIRE </p>
							      <span>1.86 to 2.5 lacs.</span>
							   </li>
							   <li>
							   	   <h4>Mansingh Biswajit Aech</h4>
								   <p>CEASEFIRE</p>
								   <span>.86 to 2.5 lacs.</span>
							   </li>
							   <li>
							      <h4>Soumya Ranjan Pattnaik</h4>
							      <p>CEASEFIRE</p>
							      <span>1.86 to 2.5 lacs.</span>
							   </li>
							   <li>
							      <h4>Devidutta Mohanty</h4>
							      <p>EXIMUS INFOTECH PVT. LTD.</p>
							      <span>.2 lacs.+</span>
							   </li>
							   <li>
							      <h4>Srija Subhadarsini Lenka</h4>
							      <p>GOURANGA SOFT TECH PVT. LTD.</p>
							      <span>.2 lacs.+</span>
							   </li>
							</ul>
							<div class="news-ctrl">
								<a href="javascript:void(0)" id="nt-example1-prev"><img src="images/left.png"></a>
								<a href="javascript:void(0)" id="nt-example1-next"><img src="images/right.png"></a>
							</div>
						</div>
					</div>
					<div class="full-sec">
						<h4 class="head-bg">Our Recruiters</h4>
						<div class="owl-carousel logo-slider">
							<div><img src="images/1.jpg" class="img-fluid"></div>
							<div><img src="images/2.jpg" class="img-fluid"></div>
							<div><img src="images/3.jpg" class="img-fluid"></div>
							<div><img src="images/4.jpg" class="img-fluid"></div>
							<div><img src="images/5.jpg" class="img-fluid"></div>
							<div><img src="images/6.jpg" class="img-fluid"></div>
							<div><img src="images/7.jpg" class="img-fluid"></div>
							<div><img src="images/8.jpg" class="img-fluid"></div>
							<div><img src="images/9.jpg" class="img-fluid"></div>
							<div><img src="images/10.jpg" class="img-fluid"></div>
							<div><img src="images/11.jpg" class="img-fluid"></div>
							<div><img src="images/12.jpg" class="img-fluid"></div>
							<div><img src="images/13.jpg" class="img-fluid"></div>
							<div><img src="images/14.jpg" class="img-fluid"></div>
							<div><img src="images/15.jpg" class="img-fluid"></div>
							<div><img src="images/16.jpg" class="img-fluid"></div>
							<div><img src="images/17.jpg" class="img-fluid"></div>
							<div><img src="images/18.jpg" class="img-fluid"></div>
						</div>
						<a class="read-more" href="#" style="    margin-top: 25px;"><img src="images/more.jpg" title="read more"></a>
					</div>
				</div>
				<?php include_once 'include/footer.php'; ?>
			</div>
		</div>
	</div>



<!-- Admission Popup -->
<div id="popupBox" style="display:none; position: fixed; top: 0; left: 0; width: 100%; height: 100%;
     background-color: rgba(0,0,0,0.6); z-index: 9999; justify-content: center; align-items: center;">
    <div style="position: relative; left: 23%;">
        <img src="images/popup/mba.png" alt="Admission Open" style="width: 40%; border-radius: 10px;">
        <button onclick="closePopup()" style="position: absolute; top: 10px; left: 35%; background: #fff; 
            border: none; font-size: 20px; padding: 5px 10px; cursor: pointer; border-radius: 50%;">&times;</button>
    </div>
</div>

<script>
    // Show popup on page load
    window.onload = function() {
        document.getElementById('popupBox').style.display = 'flex';
    };

    // Close popup
    function closePopup() {
        document.getElementById('popupBox').style.display = 'none';
    }
</script>

	
	<?php include_once 'include/js.php'; ?>

</body>
</html>