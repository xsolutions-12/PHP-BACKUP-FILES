<!DOCTYPE html>
<html>
<head>
	<title>Faculty</title>
	<?php include_once 'include/css.php'; ?>
</head>
<body class="about-page">
	<div class="container">
		<div class="main-wrap">
			<?php include_once 'include/header.php'; ?>
			<div class="inner-page-sec">
				<div class="row">
					<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<h1 class="inner-title">Faculty Overview</h1>
						<p>The faculty comprises of commited, proficient and
						inter-active professionals each excelling in his respective field. Each of them
						spend their time not only in teaching but also assist in development and research.</p>
						<p>Developing academic excellence amongst
						its students has been the prime concern of the faculty. A student evaluation
						committee reviews affairs concerning academic performance and other aspect of
						every student. The evaluation process includes assignment, formative and
						summative exams held at the end of the year. </p>
						<p>The <strong>BIMIT </strong>faculty members are
						committed to the personal &amp; professional development of their students.
						This commitment is experienced not only by the hours spent in the classroom,
						but also by the time devoted to class preparation &amp; student counseling. </p>
						<p>The Faculty take personal care in
						building a student’s competence in academics and the self. They also act as
						mentors in guiding a student’s all-round development. They influence the
						student’s behaviour in the improvement of knowledge, attitude &amp; skill. </p>
						<p>The Faculty of <strong>BIMIT</strong> comprises
						of both the Core Faculties and Visiting Faculties drawn from various
						Institutes, Organizations and Industries of repute. </p>
						<p>The Faculties orchestrate classroom
						instruction, case study method, discussions etc. urging students to stretch
						their imaginations &amp; analytical skills to reach creative solution &amp;
						broaden their understanding of issues. Faculties are accessible to students
						beyond classroom &amp; many serve as advisers to field study groups &amp; to
						students conducting individual research projects since curriculum development,
						case writing and research are inseparable elements of the Institute’s mission.
						Faculty continuously write new cases updating and revising existing ones. The
						faculty’s ongoing involvement with practicing managers ensures that the
						curriculum is current &amp; focuses on both contemporary and future issues. </p>
						<p>It has been acknowledge by students
						and Alumni of <strong>BIMIT</strong> that the faculties of <strong>BIMIT</strong> are ideal teachers. Many
						alumni and students have identified a few qualities, analysed and synthesized
						these and have shown as to how these illustrate, illumine, instill, inspire and
						impart to the students, the true traits of an ideal teacher, who have
						confidence, selflessness, equanimity, compassion, motivation, gratitude,
						communication, leading by example, concern for students and love. The faculty
						at <strong>BIMIT</strong> are not only ideal teachers but also are helping. Through their
						educational experiment, which is now well known, the faculty’s objective at
						BIMIT is to make their students ideal leaders, good and great.</p>

						<p>&nbsp;</p>
						<table style="" border="0" align="center">
								<tbody>
								<tr>
								<td style="" align="center"><strong><a title="next page" href="faculty-1.php"><span style="color: #107dc2;">List of our Faculty Members »</span></a></strong></td>
								</tr>
							</tbody>
						</table>
						
					<?php include_once 'include/footer.php'; ?>
				</div>
			</div>
		</div>
	</div>




	
	<?php include_once 'include/js.php'; ?>

</body>
</html>