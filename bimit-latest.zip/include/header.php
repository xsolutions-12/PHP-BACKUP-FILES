<header>
	<div class="row align-items-center">
		<div class="col-xl-2 col-lg-2 col-md-2">
			<a href="index.php" style="display: block;"><img src="images/logo.png" class="img-fluid"></a>
		</div>
		<div class="col-xl-10 col-lg-10 col-md-10">
			<h4>Bhubaneswar Institute of Management and Information Technology (BIMIT)</h4>
			<p>(approved by AICTE, affiliated to Biju Patnaik University of Technology)</p> 
      <p style="text-align: right; padding-right: 15px; font-style: italic;">JEE code : BIM <br>Established : 1995</p>
		</div>
	</div>
</header>
<nav class="navbar navbar-expand-sm navbar-light bg-light">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="javascript:void(0)" id="navbarDropdown" role="button" data-hover="dropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          About Us
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="about-bimit.php">BIMIT - an insight</a>
          <a class="dropdown-item" href="vision-mission.php">Vision &amp; Mission</a>
          <a class="dropdown-item" href="affiliation.php">Affiliation</a>
          <a class="dropdown-item" href="facilities.php">Facilities</a>
          <a class="dropdown-item" href="infrastructure.php">Infrastructure</a>
          <a class="dropdown-item" href="accolades.php">Accolades</a>
        </div>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="javascript:void(0)" id="navbarDropdown" role="button" data-hover="dropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Foreward
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="managing-trustee.php">Managing Trustee</a>
        </div>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="javascript:void(0)" id="navbarDropdown" role="button" data-hover="dropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Administration
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="executive-chairperson.php">Executive Chairperson</a>
          <a class="dropdown-item" href="advisors.php"> Advisors</a>
          <a class="dropdown-item" href="dean.php">Dean</a>
          <a class="dropdown-item" href="directors.php">Directors</a>
        </div>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="javascript:void(0)" id="navbarDropdown" role="button" data-hover="dropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Academics
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="admission-procedure.php">Admission Procedure </a>
          <a class="dropdown-item" href="mba-syllabus.php">MBA Syllabus</a>
          <a class="dropdown-item" href="academic-calendar.php">Academic Calendar  </a>
          <a class="dropdown-item" href="holiday-list.php">Holiday List </a>
          <a class="dropdown-item" href="jee.php">JEE</a>
        </div>
      </li>
      
      <li class="nav-item">
        <a class="nav-link" href="faculty.php">Faculty</a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="javascript:void(0)" id="navbarDropdown" role="button" data-hover="dropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Placement
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="placement.php">Placements at a glance</a>
          <a class="dropdown-item" href="training.php">Training</a>
          <a class="dropdown-item" href="alumni.php">Alumni</a>
        </div>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="javascript:void(0)" id="navbarDropdown" role="button" data-hover="dropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Activities
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="seminar.php">Seminar </a>
          <a class="dropdown-item" href="spiritual-activities.php">Spiritual Activities</a>
          <a class="dropdown-item" href="cultural-activities.php">Cultural Activities </a>
          <a class="dropdown-item" href="service-activities.php">Services Activities</a>
          <a class="dropdown-item" href="study-tour.php">Study Tour  </a>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="mandatory-disclosure.php">Mandatory Disclosure</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="contact-us.php">Contact Us</a>
      </li>
    </ul>
  </div>
</nav>