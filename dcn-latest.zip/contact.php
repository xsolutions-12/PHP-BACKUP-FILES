<!DOCTYPE html>
<html lang="en">
<head>
      <title>DC NORTHINDIA</title>
      <meta charset="utf-8">
      <?php
	  	include("external.php");
	  ?>
   </head>
   <body>
      <?php
	  	include("header.php");
	  ?>
      <div class="head-box" style="height:360px;">
         <div class="container">
            <div class="row">
               <div class="col-sm-12">
                  <h3 class="text-uppercase last">Contact Us</h3>
                  <h4>Daughters Of Charity  of St Vincent De Paul Society</h4>
                  <p>
                  	President: Sr. Martha Pradhan<br> <!--Sr. Kristo Kumari Singh-->
                  	St.Vincents Provincial House,<br>
                    Panda Colony, At/PO-Berhampur<br>
                    Dist-Ganjam,Pin-760 010, Odisha
                  </p>
                  <br>
                  <p>
                  	Phone: 0680-2291806<br>
                    Emal: <a href="mailto:nieconoma@yahoo.in">nieconoma@yahoo.in</a><br>
                    Website: <a href="http://www.dcnindia.org">http://www.dcnindia.org</a>
                  </p>
               </div>
            </div>
         </div>
      </div>
      <?php
	  	include("footer.php");
	  ?>
   </body>
</html>