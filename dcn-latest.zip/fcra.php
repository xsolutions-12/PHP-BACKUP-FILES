<!DOCTYPE html>
<html lang="en">
<head>
      <title>DC NORTHINDIA</title>
      <meta charset="utf-8">
      <?php
	  	include("external.php");
	  ?>
   </head>
   <body>
      <?php
	  	include("header.php");
	  ?>
      <div class="head-box" style="height:360px;">
         <div class="container">
            <div class="row">
               <div class="col-sm-12">
                  <h3 class="text-uppercase last">FCRA</h3>
                  <p><a target="_blank" href="data/fcra/Audited Accounts for the Financial Year 2014-15.pdf">Audited Accounts for the Financial Year 2014-15</a> </p>
                  <p><a target="_blank" href="data/fcra/Audited Accounts for the Financial Year 2015-16.pdf">Audited Accounts for the Financial Year 2015-16</a> </p>
                  <p><a target="_blank" href="data/fcra/Accounts for 2016-2017.pdf">Audited Accounts for the Financial Year 2016-17</a> </p>
                  <p><a target="_blank" href="data/fcra/Report And Accounts-31.03.2018.pdf">Audited Accounts for the Financial Year 2017-18</a> </p>
                  <p><a target="_blank" href="data/fcra/FC report for 2018-2019.pdf">Audited Accounts for the Financial Year 2018-19</a> </p>
               </div>
            </div>
         </div>
      </div>
      <?php
	  	include("footer.php");
	  ?>
   </body>
</html>