<?php
	$url=basename($_SERVER["PHP_SELF"]);
?>
<div id="header-top">
 <div class="container">
    <div class="row">
       <div class="col-md-6">
          <div class="text">
             <p>Contact : 0680-2291806</p>
          </div>
       </div>
       <div class="col-md-6">
          <div class="text pull-right">
             <p><a href="mailto:nieconoma@yahoo.in">nieconoma@yahoo.in</a></p>
          </div>
       </div>
    </div>
 </div>
</div>
<div class="topbar">
    <div class="container">
        <div class="row">
            <div class="col-md-2">
                <img src="assets/images/logo.png" style="width:120px;">
            </div>
            <div class="col-md-10">
                <h2>DC NORTHINDIA</h2>
                <h4>( Daughters of Charity of St. Vincent De Paul Society )</h4>
            </div>
            <!--<div class="col-md-3">
                <div class="search">
                    <input type="text" class="form-control" placeholder="Search">
                </div>
            </div>
            <div class="col-md-1">
                <div class="search">
                    <button type="submit" class="btn btn-primary"><i class=" fa fa-search"></i></button>
                </div>
            </div>-->
        </div>
    </div>
</div>
<div class="navbar navbar-inverse">
 <div class="container">
    <div class="navbar-header">
       <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
    </div>
    <div class="navbar-collapse collapse" align="center">
       <ul class="nav navbar-nav mainNav">
          <li <?php if($url=='index.php'){echo "class='active'"; } ?>><a href="index.php">Home</a></li>
          <li <?php if($url=='about.php'){echo "class='active'"; } ?>><a href="about.php">About Us</a></li>
          <li <?php if($url=='fcra.php'){echo "class='active'"; } ?>><a href="fcra.php">FCRA</a></li>
          <li <?php if($url=='donations.php'){echo "class='active'"; } ?>><a href="donations.php">Donations</a></li>
          <!--<li class="dropdown">
             <a href="#" class="dropdown-toggle" data-toggle="dropdown">Pages <b class="caret"></b></a>
             <ul class="dropdown-menu">
                <li><a href="sidebar-right.html">Right Sidebar</a></li>
                <li><a href="#">Dummy Link1</a></li>
                <li><a href="#">Dummy Link2</a></li>
                <li><a href="#">Dummy Link3</a></li>
             </ul>
          </li>-->
          <li <?php if($url=='contact.php'){echo "class='active'"; } ?>><a href="contact.php">Contact Us</a></li>
       </ul>
    </div>
 </div>
</div>