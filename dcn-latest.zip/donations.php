<!DOCTYPE html>
<html lang="en">
<head>
      <title>DC NORTHINDIA</title>
      <meta charset="utf-8">
      <?php
	  	include("external.php");
	  ?>
   </head>
   <body>
      <?php
	  	include("header.php");
	  ?>
      <div class="head-box" style="min-height:360px;">
         <div class="container">
            <div class="row">
            	<div class="col-md-12">
                	<h3 class="text-uppercase last" style="padding-inline: 45%;">Donations</h3>
                	<hr style="border-top: 1px solid grey;">
                </div>
                <div class="col-md-12">
                    <div class="col-md-3"> 
                      <h4><strong>Financial Year 2024-2025</strong></h4>
                      <p><a target="_blank" href="data/donations/FCRA Donation 1 st qtr -2024.pdf">FCRA Donation 1st Qtr 2024-25</a>
                      <p><a target="_blank" href="data/donations/FCRA Donation 2nd quarter.png">FCRA Donation 2nd Qtr 2024-25</a>
                      <p><a target="_blank" href="data/donations/FCRA Donation 3rd qtr 2024-2025.pdf">FCRA Donation 3rd Qtr 2024-25</a>
                      <p><a target="_blank" href="data/donations/FCRA Donation List-4th Qtr-2024-25.pdf">FCRA Donation 4th Qtr 2024-25</a>
                   </div>
                    <div class="col-md-3"> 
                      <h4><strong>Financial Year 2023-2024</strong></h4>
                      <p><a target="_blank" href="data/donations/FCRA Donation 1st Qtr 2023-2024.pdf">FCRA Donation 1st Qtr 2023-2024</a>
                      <p><a target="_blank" href="data/donations/2nd Qtr FC Donation Detail2023.pdf">FCRA Donation 2nd Qtr 2023-2024</a>
                      <p><a target="_blank" href="data/donations/FCRA Donation Detail 13.01.2024.pdf">FCRA Donation 3rd Qtr 2023-2024</a>
                      <p><a target="_blank" href="data/donations/FCRA Donation Detail -12.04.2024.pdf">FCRA Donation 4th Qtr 2023-2024</a>
                    </div>
                   <!--<div class="col-md-3"> -->
                   <!--   <h4><strong>Financial Year 2020-2021</strong></h4>-->
                   <!--   <p><a target="_blank" href="data/donations/fc-donation-detail1st-qtr.2020.pdf">FCRA Donation 1st Qtr 2020-21</a>-->
                   <!--   <p><a target="_blank" href="data/donations/fc-donation-detail2ndqtr.2020.pdf">FCRA Donation 2nd Qtr 2020-21</a>-->
                   <!--   <p><a target="_blank" href="data/donations/fc-donation-detail3rd-qtr.2021.pdf">FCRA Donation 3rd Qtr 2020-21</a>-->
                   <!--   </p>-->
                   <!--   <p><a target="_blank" href="data/fcra/fcra-donation-4rd-qtr-2020-21.pdf">FCRA Donation 4rd Qtr 2020-21</a>-->
                   <!--   </p>-->
                   <!--</div>-->
                   <!-- <div class="col-md-3"> -->
                   <!--   <h4><strong>Financial Year 2019-2020</strong></h4>-->
                   <!--   <p><a target="_blank" href="data/donations/FCRA Donation 1st Qtr 2019-20.pdf">FCRA Donation 1st Qtr 2019-20</a> </p>-->
                   <!--   <p><a target="_blank" href="data/donations/FCRA Donation Detail 2nd Qtr- 2019.pdf">FCRA Donation 2nd Qtr 2019-20</a> </p>-->
                   <!--   <p><a target="_blank" href="data/donations/FCRA Donation 3 rd Qtr 2019-20.pdf">FCRA Donation 3rd Qtr 2019-20</a> </p>-->
                   <!--   <p><a target="_blank" href="data/donations/fcra-donation-4th-qtr-2020.pdf">FCRA Donation 4th Qtr 2019-20</a> </p>-->
                   <!--</div>-->
                </div>
                <div class="col-md-12">
                    <div class="col-md-3"> 
                       <h4><strong>Financial Year 2022-2023</strong></h4>
                       <p><a target="_blank" href="data/donations/FCRA Donation 1st Qtr 2022-2023.pdf">FCRA Donation 1st Qtr 2022-2023</a>
                       <p><a target="_blank" href="data/donations/FCRA Donation 2nd Qtr 2022-2023.pdf">FCRA Donation 2nd Qtr 2022-2023</a>
                       <p><a target="_blank" href="data/donations/FCRA Donation 3rd Qtr 2022-2023.pdf">FCRA Donation 3rd Qtr 2022-2023</a>
                       <p><a target="_blank" href="data/donations/FCRA Donation 4th Qtr 2022-2023.pdf">FCRA Donation 4th Qtr 2022-2023</a>
                    </div>
                    <div class="col-md-3"> 
                      <h4><strong>Financial Year 2021-2022</strong></h4>
                      <p><a target="_blank" href="data/donations/1st-qtr-fc-donation-21-22.pdf">FCRA Donation 1st Qtr 2021-22</a> </p>
                      <p><a target="_blank" href="data/donations/FC List 2nd Qtr-2021-2022-Berhampur.pdf">FCRA Donation 2nd Qtr 2021-22</a> </p>
                      <p><a target="_blank" href="data/donations/FCRA Donation Detail 3rd qtr .pdf">FCRA Donation 3rd Qtr 2021-22</a> </p>
                      <p><a target="_blank" href="data/donations/FCRA Donation Detail 4th qtr.pdf">FCRA Donation 4th Qtr 2021-22</a> </p>
                    </div>
                    <div class="col-md-3"> 
                      <h4><strong>Financial Year 2020-2021</strong></h4>
                      <p><a target="_blank" href="data/donations/fc-donation-detail1st-qtr.2020.pdf">FCRA Donation 1st Qtr 2020-21</a> </p>
                      <p><a target="_blank" href="data/donations/fc-donation-detail2ndqtr.2020.pdf">FCRA Donation 2nd Qtr 2020-21</a> </p>
                      <p><a target="_blank" href="data/donations/fc-donation-detail3rd-qtr.2021.pdf">FCRA Donation 3rd Qtr 2020-21</a> </p>
                      <p><a target="_blank" href="data/fcra/fcra-donation-4rd-qtr-2020-21.pdf">FCRA Donation 4rd Qtr 2020-21</a> </p>
                    </div>
                    <div class="col-md-3"> 
                      <h4><strong>Financial Year 2019-2020</strong></h4>
                      <p><a target="_blank" href="data/donations/FCRA Donation 1st Qtr 2019-20.pdf">FCRA Donation 1st Qtr 2019-20</a> </p>
                      <p><a target="_blank" href="data/donations/FCRA Donation Detail 2nd Qtr- 2019.pdf">FCRA Donation 2nd Qtr 2019-20</a> </p>
                      <p><a target="_blank" href="data/donations/FCRA Donation 3 rd Qtr 2019-20.pdf">FCRA Donation 3rd Qtr 2019-20</a> </p>
                      <p><a target="_blank" href="data/donations/fcra-donation-4th-qtr-2020.pdf">FCRA Donation 4th Qtr 2019-20</a> </p>
                    </div>
                </div>
                <div class="col-md-12">
                      <div class="col-md-3"> 
                      <h4><strong>Financial Year 2018-2019</strong></h4>
                      <p><a target="_blank" href="data/fcra/FCRA_1st_Qtr_2018_19.pdf">FC Donation-1st Qtr-2018</a> </p>
                      <p><a target="_blank" href="data/fcra/FC List 2nd Qtr-2018-19.pdf">FC Donation-2nd Qtr-2018</a> </p>
                      <p><a target="_blank" href="data/fcra/FCRA Donation Detail 3rd quater 2018-19.pdf">FC Donation-3rd Qtr-2018</a> </p>
                      <p><a target="_blank" href="data/fcra/4th Qtr FCRA Details.pdf">FC Donation-4th Qtr-2018</a> </p>
                   </div>
                   <div class="col-md-3"> 
                      <h4><strong>Financial Year 2017-2018</strong></h4>
                      <p><a target="_blank" href="data/donations/Financial Year 2017-2018/FC Donation-1st Qtr-2017-18.pdf">FC Donation-1st Qtr-2017</a> </p>
                      <p><a target="_blank" href="data/donations/Financial Year 2017-2018/FC Donation 2nd Qtr-2017-18.pdf">FC Donation-2nd Qtr-2017</a> </p>
                      <p><a target="_blank" href="data/fcra/FCRA Quarterly donation Q3 Berhampur.pdf">FC Donation-3rd Qtr-2017</a> </p>
                      <p><a target="_blank" href="data/fcra/FC Donation 4th Qtr-2017-18.pdf">FC Donation-4th Qtr-2017</a> </p>
                   </div>
                   <div class="col-md-3"> 
                      <h4><strong>Financial Year 2016-2017</strong></h4>
                      <p><a target="_blank" href="data/donations/Financial Year 2016-2017/Foreign Donation-1st Qtr 2016.pdf">Foreign Donation-1st Qtr 2016</a> </p>
                      <p><a target="_blank" href="data/donations/Financial Year 2016-2017/Foreign Donation-2nd Qtr 2016.pdf">Foreign Donation-2nd Qtr 2016</a> </p>
                      <p><a target="_blank" href="data/donations/Financial Year 2016-2017/Foreign Donation-3rd Qtr 2016.pdf">Foreign Donation-3rd Qtr 2016</a> </p>
                      <p><a target="_blank" href="data/fcra/4th Qtr FCRA Donation detail.pdf">Foreign Donation-4th Qtr 2016</a> </p>
                   </div>
                    <div class="col-md-3">
                      <h4><strong>Financial Year 2015-2016</strong></h4>
                      <p><a target="_blank" href="data/donations/Financial Year 2015-2016/Foreign Donation-1st Qtr-2015-16.pdf">Foreign Donation-1st Qtr-2015-16</a> </p>
                      <p><a target="_blank" href="data/donations/Financial Year 2015-2016/Foreign Donation-2nd Qtr-2015-16.pdf">Foreign Donation-2nd Qtr-2015-16</a> </p>
                      <p><a target="_blank" href="data/donations/Financial Year 2015-2016/Foreign Donation-3rd Qtr-2015-16.pdf">Foreign Donation-3rd Qtr-2015-16</a> </p>
                      <p><a target="_blank" href="data/donations/Financial Year 2015-2016/Foreign Donation-4th Qtr-2015-16.pdf">Foreign Donation-4th Qtr-2015-16</a> </p>
                   </div>
                </div>
            </div>
         </div>
      </div>
      <?php
	  	include("footer.php");
	  ?>
   </body>
</html>