<!DOCTYPE html>
<html lang="en">
<head>
      <title>DC NORTHINDIA</title>
      <meta charset="utf-8">
      <?php
	  	include("external.php");
	  ?>
   </head>
   <body>
      <?php
	  	include("header.php");
	  ?>
      <header id="head">
         <div class="container">
            <div class="row">
            	<div class="col-md-4">
                	<img src="assets/images/side-banner.png" width="100%">
                </div>
                <div class="col-md-8">
                    <div id="myCarousel" class="carousel slide" data-ride="carousel">
                       <div class="carousel-inner" role="listbox">
                          <div class="item active">
                             <img src="assets/images/slides/bana1.jpg" width="100%" alt="">
                          </div>
                          <div class="item">
                             <img src="assets/images/slides/bana2.jpg" width="100%" alt="">
                          </div>
                          <div class="item">
                             <img src="assets/images/slides/bana3.jpg" width="100%" alt="">
                          </div>
                       </div>
                       <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
                       		&larr;
                       </a>
                       <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
                       		&rarr;
                       </a>
                    </div>
                </div>
            </div>
         </div>
      </header>
      <div class="head-box">
         <div class="container">
            <div class="row">

               <div class="col-sm-12">
                  <h4 class="text-center text-uppercase last">Welcome to</h4>
                  <h2 class="text-center last">Daughters of Charity of St. Vincent De Paul Society.</h2>
               </div>
            </div>
         </div>
      </div>
      <?php
	  	include("footer.php");
	  ?>
   </body>
</html>