<footer id="footer">
 <div class="footer2">
    <div class="container">
       <div class="row">
          <div class="col-md-6 panel">
             <div class="panel-body">
                <p>
                   Copyright &copy; 2017 DC NORTHINDIA
                </p>
             </div>
          </div>
          <div class="col-md-6 panel">
             <div class="panel-body">
                <p class="text-right">
                   Developed By <a href="http://www.xprosolutions.co.in">XPRO</a>
                </p>
             </div>
          </div>
       </div>
    </div>
 </div>
</footer>
<script src="assets/js/modernizr-latest.js"></script> 
<script type='text/javascript' src='assets/js/jquery.min.js'></script>
<script type='text/javascript' src='assets/js/fancybox/jquery.fancybox.pack.js'></script>
<script type='text/javascript' src='assets/js/jquery.mobile.customized.min.js'></script>
<script type='text/javascript' src='assets/js/jquery.easing.1.3.js'></script> 
<script type='text/javascript' src='assets/js/camera.min.js'></script> 
<script src="assets/js/bootstrap.min.js"></script> 
<script src="assets/js/custom.js"></script>
<script>
 jQuery(function(){
    
    jQuery('#camera_wrap_4').camera({
        height: '600',
        loader: 'bar',
        pagination: false,
        thumbnails: false,
        hover: false,
        opacityOnGrid: false,
        imagePath: 'assets/images/'
    });
 
 });
</script>