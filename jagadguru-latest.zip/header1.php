	<div class="bar">
		<div style="width:900px; margin:0px auto; text-align:left">
		<div  class="top_menu" style="float:left"><a href="index.php" style="color:#FFFF00;">Home</a> <a href="about.php" style="color:#FFFF00;">About Us</a> </div>
		<div style="width:300px; float:right; text-align:right; padding-top:3px;"><a href="#"><img src="image/icon/f.png" alt="" width="28" height="28" border="0" /></a>&nbsp;&nbsp;<a href="#"><img src="image/icon/t.png" alt="" width="28" height="28" border="0" /></a>&nbsp;&nbsp;<a href="#"><img src="image/instagram.png" alt="" width="28" height="28" border="0" /></a>&nbsp;&nbsp;<a href="#"><img src="image/icon/yt.png" alt="" width="28" height="28" border="0" /></a></div>
		</div>
    </div>
	
	<a href="Balsanskar.php"><div class="bsk"></div></a>
	
	<div class="spacer">
    	<div class="logo">
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="44%"><a href="index.php"><img src="image/logo.png" alt="Jagadguru Yoga Foundation" /></a></td>
    <td width="56%" align="right" valign="middle">
		<img src="images/arising.png" alt="" />	</td>
  </tr>
</table>

		
		</div>
	    <div class="nav">
		    <!--<div class="sf-menu">
                <ul>
                    <li><a href="index.php">home</a></li>
                    <li><a href="about.php">about us</a></li>
                    <li><a href="youth.php">youth & yoga</a></li>
                    <li><a href="gallery.php">gallery</a></li>
                    <li><a href="contact.php">contact us</a></li>
                </ul>
        	</div> -->
			<div class="menu">
			 <a href="youth.php">Youth & Yoga</a>        <a href="DevSanskriti.php">Devsanskriti Yoga Vidyalaya</a>         <a href="Yoga_professionals.php">Yoga Professionals Association of Odisha</a>        <a href="course_structure.php">Yoga Course Structure</a>        <a href="creative_camp.php">Creative Camp for Students</a>         <a href="gallery.php">Gallery</a> 
			</div>
		</div>
    </div>