<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Jagad Guru Yoga Bharat Foundation</title>
    <link rel="stylesheet" href="yoga_style.css" />
     <link href="tab/style1.css" rel="stylesheet" type="text/css">
</head>

<body>

	<?php include("header1.php"); ?>
	    
		<div class="main"  >
    	<div class="content_wrap">
            <div style="width:100%; height:30px;"></div>
            <div class="main_wrap"  >
                <div class="wrapper1">                	
     
    <div>
      <div class="tabpage"  style="text-align:center">
      <h2>BENEFITS OF YOGA FOR ALL AGE </h2>
      <h4 style="float:right; text-align:right; color:#666">Yogacharya Dr. Biswaranjan Rath,<br />
Faculty, P.G. Department of Yoga, Utkal University 
</h4><br /><br /><br />

<br />
<p style="text-align:justify; font-size:18px;"><br /><br />
<strong>Sorry for inconvenience.<br /><br />We're updating the fresh contents to guide you the "Benifits of Yoga" and will mention for you in this place very sooner.</strong><br /><br />
</p>
      </div>
      
	  
      
    </div>
  </div>
                    
                </div>
            </div>
        </div>
		
    <?php include("footer.php"); ?>
	
</body>
</html>
