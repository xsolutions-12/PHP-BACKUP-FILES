<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Jagad Guru Yoga Bharat Foundation</title>
    <link rel="stylesheet" href="yoga_style.css" />
     <link href="tab/style1.css" rel="stylesheet" type="text/css">
</head>

<body>

	<?php include("header1.php"); ?>

		<div class="main" >
    	<div class="content_wrap">
            <div style="width:100%; height:30px;"></div>
            <div class="main_wrap" style=" ">
                <div class="wrapper1">                	
     
    <div>
      <div class="tabpage" id="tabpage_1">
      <img src="images/founder.png" width="226" height="255" alt="" style="float:right; margin-top:45px; margin-right:25px;" />
<h3>Contact Us</h3><br />
<p>R.M.P. Alternative Therapy, B. Pharma, M.Sc. DFSM,<br />
M.D. Yoga Therapy, DMLT, CNCC, CCAM, YIC<br />
Founder, Jagadguru Yoga Bharat Foundation<br />
Faculty, P.G. Dept. of Yoga, Utkal University <br />
Guest Faculty, Dept. of Yoga, DevsanskritiVishwaVidyalaya<br />
Master trainer in Yoga, C.H.S.E. Govt. of Odisha<br />
Co-ordinator, divine India Youth Association (DIYA), Bhubaneswar, Odisha<br />
President, Yoga Professionals association of India<br />
Director & Research Head, Divya Yuga Nirman Educational and clinical research centre.<br />
Principal Devsanskriti Yoga Vidyalaya<br />
Chairman, YuganirmanVidyapitham<br />
National Secretary, Arising India Youth Association (ARYAN)<br />
Sanjojaka, Yuga Rishi PanditShri Ram Sharma Vichar Mancha.</p>


      </div>
      
	  
      
    </div>
  </div>
                    
                </div>
            </div>
        </div>
		
    <?php include("footer.php"); ?>
	
</body>
</html>
