<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Jagad Guru Yoga Bharat Foundation</title>
    <link rel="stylesheet" href="yoga_style.css" />
     <link href="tab/style1.css" rel="stylesheet" type="text/css">
     <link href="SpryAssets/SpryAccordion.css" rel="stylesheet" type="text/css" />
<script src="SpryAssets/SpryAccordion.js" type="text/javascript"></script>
</head>

<body>

	<?php include("header1.php"); ?>

		<div class="main"  >
    	<div class="content_wrap">
            <div style="width:100%; height:30px;"></div>
            <div class="main_wrap"  >
                <div class="wrapper1">                	
     
    <div>
      <div class="tabpage" id="tabpage_1">
     
<h3>Humanitarian activity and social Reconstruction</h3><br />

<div id="Accordion1" class="Accordion" tabindex="0">
  <div class="AccordionPanel">
    <div class="AccordionPanelTab">
      <h4>(a)	De-addiction Programme (Free yourself from the habit)</h4>
    </div>
    <div class="AccordionPanelContent cnt">
     
    	<p style="color:#333; font-size:14px;">
<strong>Preventive and treatment of Drugs and Alcohol Abuse</strong>.
<br />
Consumption of alcoholic drinks/narcotic drugs or other intoxicating substances is a prominent cause that makes one mindless and trigger/ boosts beastly instincts. In most cases of rape and/or violence, the culprits/ accused are reported to have consumed wine/liquor/charas or other kinds of “nasha”. Intoxication will continue to catalyze the evil instincts inspite of harsh laws and punishments against the heinous crimes like rape.<br />
<br />
Studies on Alcohol abuse in India indicate that more than 30 percent of males and 5% of females are alcohol dependant.<br />
Study towards end of 20th century showed in Mumbai alcoholism in women is around 67%, where as in Kolkata it is almost 50% alcoholism and 50% Bis (mostly) amongst women.<br /><br />
Alcohol and Drug Abuse breed hatred, jealousy and violence, lowers self-image, causes financial stresses, and tears families apart. These manifest further by destabilizing peace and harmony in the society and nation at large.<br />
<br />
Recent studies also reveal that drug addiction on the streets of Kolkata and surrounding areas alone has afflicted more than 40,000 individuals.<br />
<br />
In India, the problem of addiction is further aggravated by the lack of treatment and rehabilitation facilities. The JYB Foundation Research Centre was formed in this light to fight against the problems of addiction by :<br />
<br />
•&nbsp;&nbsp;&nbsp;Creating awareness.<br />
•&nbsp;&nbsp;&nbsp;Providing effective treatment and adopting measures against relapse.<br />
•&nbsp;&nbsp;&nbsp;Counseling addicts and their family members.<br />
•&nbsp;&nbsp;&nbsp;Instilling a sense of spirituality through daily practice of Yoga<br />
•&nbsp;&nbsp;&nbsp;Devising means of social integration and finding gainful employment for recovered addicts.<br />
•&nbsp;&nbsp;&nbsp;Widening scope to help victims of chemical Abuse through larger activity and also by increasing capacity to provid helps to more people.<br />
•&nbsp;&nbsp;&nbsp;Campaigning against spread of HIV/AIDS.<br /><br />
The objective of this coalition was to facilitate coordination among civil society and enable a shared platform in terms of resources, expertise and skills for establishing a better alcohol and drug free society.<br />
<br />
The treatment programme is a residential multidisciplinary therapeutic programme and spiritual treatment conducted by a team of psychiatrist, physician, psychologist, social workers, councelor, Nursing staff and spiritual yoga teacher.
</p>
	 
    </div>
  </div>
  <div class="AccordionPanel">
    <div class="AccordionPanelTab">
      <h4>(b)	Anti Tobacco campaign (Tobacco free youth, tobacco free India)</h4>
    </div>
    <div class="AccordionPanelContent cnt">
    	<p style="color:#333; font-size:14px;"><strong>Anti Tobacco campaign (Tobacco free youth, tobacco free India) stop smoking start living. – Tobacco free initiative</strong><br />
In an ongoing effort to improve the life of every individual, the JYB foundation has taken up the initiative to help people comeout of the fatal habit of smoking. According to WHO every year 7,00,000 people die due to smoking related disorders. Smoking is the biggest cause of cardiac problems, cancer and various other disease in youth today. Further, people who have developed the habit of smoking are not able to quit even if they wish to do so. In most cases it is the influence of the mind that takes people into various habits.<br />
<br />
So through “<strong>Healing Breath Workshops</strong>” a yoga Holistic Health Workshop youth took a pledge to not use and not promote the use of smoking and tobacco.
<br />
<br />
We therefore appeal that apart from making stringent laws against such crimes, there should be an effective law prohibiting the production, distribution/sales and consumption of wine/liquor/narcotic drugs and other intoxicating substances.</p>

    
    </div>
  </div>
  
   <div class="AccordionPanel">
    <div class="AccordionPanelTab"><h4>(c)	Suicide prevention through project Hope</h4></div>
    <div class="AccordionPanelContent cnt">
     
    	<p style="color:#333; font-size:14px;">
JYB Foundation developed a programme to provide sustainable tools and techniques for youth to physically, emotionally,spiritually and economically empower them in the face of increasing suicide statistics in India. The programme also aimed to educate different sections of society about the problems faced by youth and to provide them with skills to tackle them.<br />
<br />
To learn life skills and tools to prevent them- from getting depressed and anxious. This was conducted in the month of march and april as these are the peak examination months in India.<br /><br />
Following the programme, the following stress elimination benefits were noted amongst the participants :-
<br />
<br />
<li type="disc" style="font-size:14px">Reduction in incidence of suicides among students.</li><br />
<li type="disc" style="font-size:14px">Reducation in suicidal tendencies.</li><br />
<li type="disc" style="font-size:14px">De-addiction from dependencies like drugs, smoking and alcohol.</li><br />
<li type="disc" style="font-size:14px">Enhanced energy levels and academic performane.</li><br />
<li type="disc" style="font-size:14px">Increased creativity and focus.</li><br />
<li type="disc" style="font-size:14px">Increased sense of social responsibility.</li>

	 
    </div>
  </div>
  <div class="AccordionPanel">
    <div class="AccordionPanelTab"><h4>(d)	Smart prison program through yoga (Inner freedom for the imprisoned).</h4></div>
    <div class="AccordionPanelContent cnt">
    	<p style="color:#333; font-size:14px;">
        <strong>Yoga in prisons : Transforming the criminal</strong><br /><br />
Prisoner –welfare project in the India provide solace for prison inmates.<br />
If a person commits crime knowingly or unknowingly he or she is imprisoned subsequently, if the person’s inner consciousness motivates him to do some good work for the society, humanity or the nation then probably this would be the greatest gift for the mankind. The main objective of punishment is to bring about improvement. If this process takes plae through self-realization then it would transform a person’s life.<br />
<br />
<strong>Yogacharya Biswa Ranjan</strong> has made a begining in this direction. When a criminal will look within in the light of yoga, it is sure to bring about positive change in their attitude towards life. Yogacharyaji believes that it is necessary to look at negative aspects of a criminal humanely in order to establish peaceful society. When the society and individual will be free from criminal attitude then problems like terrorism, robbery, dacoity, murders, kidnapping will reduce.<br />
<br />
<strong>Yogacharya Biswa Ranjan</strong> has organised yoga camp in different prisons including <strong>Jharpada Jail, Bhubaneswar</strong>. He has brought terrorists and criminals on the platform of yoga and aroused the feeling of patriotism in their hearts.<br />
<br />
Young prison inmates to teach skills that reduce stress, heal trauma and provide practical knowledge of how to handle negative emotions. By undergoing the transformational youth empowerment programme, the inmates were given the opportunity to live to their highest potential and contribute to society in a positive way.<br /><br />
Following the programme, they recorded better sleep pattern, increased energy and clarity of mind, reduced aggressive tendencies, decreased interpersonal conflit, greater positive outlook on the future, and freedom from traumatic scars of the past.<br />
<br />
The result being that today the prisoners are giving yoga training to their fellow inmates.

        </p>
    </div>
  </div>
  
   <div class="AccordionPanel">
    <div class="AccordionPanelTab">
      <h4>(e)	Yoga for Defence personnel</h4>
    </div>
    <div class="AccordionPanelContent cnt">
     
    	<p style="color:#333; font-size:14px;">Soldiers guard the borders of our nation and work for more than 16 hours a day. They are supposed to be alert and vigilant all the time and have to brave tough weather conditions. Moreover, they do not see their families for several months together and yet they are committed to protect the motherland. They are indeed fortunate as they have the chance to serve the motherland. But it is also true that incidences of irresponsibility are inreasing in police, defence force or any other system associated with security of the nation. They are breaking down under intense stress and driven to suicide making their families helpless. Those who are supposed to make the society free of terror and war, are themselves plagued by, insecurity and depression. The only resource to change the heart, attitude of these people is yoga.<br />
    	  <br />
<strong>Yogacharya Biswa Ranjan</strong> has organised “Yoga camps” in different institutions associated with Police and Defence. He has aroused the feeling of patriotism and tried to relieve defence personnel from mental tension and physical ailments. JYB foundation has not accepted any remuneration for its work with the soldiers.<br />
<br />
<strong>Future project :</strong><br />
Massive project of teaching the yogic technique to India’s 1.3 million (13 lakh) paramilitary personnel. Classes have been given to the BSF-Border Security Force (next to Pakistan, Afghanistan, Tibet, China, Nepal, Bhutan, Bangladesh and Myanmar).<br />
The central Industrial Security Force<br /><br />
Sashastra seema Bal, the CRPF – Central Reserve Police Force and the Indo-Ttibetan Border Police. Indian Army, Air Force & Navy.


</p>
	 
    </div>
  </div>
  
  <div class="AccordionPanel">
    <div class="AccordionPanelTab">
      <h4>(f)	Safe driving awareness through project “Yoga Sarathi”.</h4>
    </div>
    <div class="AccordionPanelContent cnt">
     
    	<p style="color:#333; font-size:14px;">Texts will be added soon.</p>
	 
    </div>
  </div>
  <div class="AccordionPanel">
    <div class="AccordionPanelTab">
      <h4>(g)	Orphanage activities</h4>
    </div>
    <div class="AccordionPanelContent cnt">
     
    	<p style="color:#333; font-size:14px;">Texts will be added soon.</p>
	 
    </div>
  </div>
  <div class="AccordionPanel">
    <div class="AccordionPanelTab">
      <h4>(h)	Issue Based satsangs. (Not Prabachan but Svavachan)</h4>
    </div>
    <div class="AccordionPanelContent cnt">
     
    	<p style="color:#333; font-size:14px;">During the Satsang Yogacharya Biswa Ranjanji disseminates the message on a particular issue such as Female Foeticide, HIV/AIDS and Poverty related concerns in the context of the Indian scriptures to allow the message to reach out to a broader audience.<br />
</p>
	 
    </div>
  </div>
  <div class="AccordionPanel">
    <div class="AccordionPanelTab">
      <h4>(i)	Tribal welfare project.</h4>
    </div>
    <div class="AccordionPanelContent cnt">
     
    	<p style="color:#333; font-size:14px;">Poverty, malnutrition and disease amongst tribal families, in India continue today due to lack of development in tribal areas. A lack of education has in some cases led to the exploitation of such families by vested interests and the loss of heir identity, JYB foundation has been working to help tribal groups in a destitute condition improve their socio-economic standard of living in the tribal belts of India. JYBF’s work in these regions has also extended to create awareness amongst tribal groups about the richness of their own culture, to guide them to live a balanced life incorporating relevant aspects of modern societies and to aid in preserving the rich biodiversity that is present in tribal areas.<br />
    	  <br />
JYB Foundation, with support from the Government of Odisha, worked with the Ekalavya model Residential Schools (EMRS), set up in odisha to provide quality middle and high level education to scheduled tribe (ST) students in remote areas. JYBF’s programme was aimed at providing comprehensive physical, mental, emotional, and spiritual development of all students. So that they become “Agents of change” in their home, villages and finally in the country.<br />
<br />
Also Tribal children are not supported at home by their illiterate parents, and the dropout rate is high after the 3rd standard. At JYBF’s centres they are given supplementary tutoring to ensure they get the support they need.
</p>
	 
    </div>
  </div>
  
  <div class="AccordionPanel">
    <div class="AccordionPanelTab">
      <h4>(j)	March against terrorism and corruption. (Standup take action)</h4>
    </div>
    <div class="AccordionPanelContent cnt">
     
    	<p style="color:#333; font-size:14px;">Today, people are spending their hard earned money on medicines which they can save by practising yoga. They will also be free from corruption, crime and other negative tendencies. A person who adopts yoga in life becomes stress-free, gains mental peace, becomes tolerant and adopts ethical behavior. As the number of ethical minded people increases, corruption and injustice will decrease automatically.<br />
    	  <br />
This clearly shows that today yoga, family values and culture are becoming important for indians. They are becoming increasingly aware of national pride, self-respect, disease free life and humanity.<br />
<br />
So JYB Foundation takes a programme “Stand up Take Action” against terrorism & corruption by Yoga programme, Rally, Dharana, Human line.<br />
<br />
Amount equivalent to bribes paid over a year could feed 400 million starving people for the next 27 years.
</p>
	 
    </div>
  </div>
  
  <div class="AccordionPanel">
    <div class="AccordionPanelTab">
      <h4>(k)	Mission green earth (Plant for Planet)</h4>
    </div>
    <div class="AccordionPanelContent cnt">
     
    	<p style="color:#333; font-size:14px;">The Project green friend, the environmental branch of JYB foundation, is a rapidly growing international movement to foster lifestyle that respects nature.Green friend encourages us to reawaken our awareness of the unity between nature and humanity, and to cultivate love and reverence for nature.<br />
    	  <br />
Project green friend is an ecological initiative of JYB Foundation to prevent and reverse environmental degradation and enable sustainable living. This large-scale tree planting project will enhance biodiversity, protect the soil, restore ecological balance and provide livelihood opportunities for thousands across the state.<br />
<br />
The <strong>“My tree campaign”</strong> will be supported by large scale events and nature awareness programs to establish a culture of care for the environment.<br />
<br />
<strong>Trees and humans are in an intimate relationship. What they exhale, we inhale, what we exhale, they inhale. This is a constant relationship that no body can afford to break or live without.</strong><br />
<br />
<strong>Project Green Hands: -</strong> An Ecological initiative to Heal the planet. No green cover means no water, no oxygen… No Life! The diminishing tree cover on our planet is putting our very survival in question.
Project green hands: - Mass tree planting through people’s participation is the immediate need.<br />
<br />
<strong>Reducing Deforestation:-</strong><br />
The combined effect of Commercial farming methods, industrial growth and the use of trees to meet the fuel and housing needs of a growing population threatens remaining tree cover. Poverty caused by commercial agriculture is a prime driving force of continued deforestation. Project green hands is a means for awakening people to the reality of human and environmental suffering caused by industrialized agriculture. It is a profound tool for immediate logical action that can be taken enmasses at the grass roots level to avoid soil erosion, desertification and, eventually, widespread famine.<br />
<br />
<strong>Why plant tree?</strong><br />
<em>This is because Trees</em><br />

i.  Reduce global warming and adverse climate change by absorbing carbon dioxide and releasing oxygen to the atmosphere.<br />

ii. Are essential for seeding the clouds, rain harvesting, ground water recharge and to maintain a healthy hydrological regime.<br />

iii.Are an effective means of soil regeneration and prevention of soil erosion.<br />

iv. Provide home and habitat to different species of plants and animals, enhancing bio-diversity.<br />

v.  Mitigate poverty and malnutrition by serving as a source of income generation and nutritious food.
<br />
<br />
<strong>Believe it or not !</strong><br />

1.	A single mature tree can produce enough oxygen for the survival of two human beings.<br />

2.	Trees also reduce the green house effect by providing cooling and shading homes and offices and thereby reducing our air-conditioning needs by 30%.<br />

3.	Trees also remove other gaseous pollutants such as sulfur dioxide (SO2). There is upto a 60% decrease in street level particulates because of trees.<br />

4.	According to an American research (wonder how they did it) over a 50- year life time, a tree generates $31,250 worth of oxygen, provides $62,00 worth of air pollution control, recycles $ 37,500 dollars worth of water, and controls $31,250 dollars worth of soil erosion.<br />

5.	Rain forests are being cut down at the rate of 100 acres per minute. At this rate, it would cover the size of Bhubaneswar in 42 hours.
<br />
<br />
<strong>Current scenario:-</strong><br />

Over-exploitation of natural resources has led to massive degradation of ecological systems and to global warming. Unless serious corrective measures like restoration of tree cover, ground water and soil health are put in place, human habitation will be seriously affected.<br />
<br />

The situation in the state of Odisha, India is a case point. The forest of tree cover in Odisha is only 17.58%, against the national ideal of 33%. Odisha receives heavy rains for short period from June to October, resulting in heavy floods and soil erosion, where almost 50% of rainfall runs off to the sea, carrying life sustaining soil with it. In the absence of green cover, a severe drinking water scarcity has also arisen. An increasing population in the next 35-50 years will lead to prime agricultural lands being lost to fulfill the basic needs of the people. Due to uncertainty in the monsoons and adverse climate changes, food production will become a matter of chance.<br /><br />


With the current rate of land degradation, experts predict that by 2025, 60% of Odisha will be desert, unsuitable for food production. This situation, if unchecked will result in loss of ecological balance, poverty and social instability.<br />
<br />

“Every Society needs individuals who will go on planting mango trees, without thinking whether they will get to eat the fruits or not.”<br />
<br />

The <strong>My Tree Campaign</strong> aims to go beyond events of tree plantation to create a sub-culture around tree plantation, where trees form part of the everyday lives of people. For instance, JYB Foundation has been encouraging individuals to give saplings in lieu of or in addition to other gifts on occasions such as Birthdays, wedding and childbirth. Similarly on Raksha Bandhan, We had Rakhis for saplings and saplings for Rakhis, where we gifted saplings to the sisters who tied rakhis, and also tied rakhis to the saplings. We planted, to protect us.<br />
<br />

<strong>What is project Green Hands!</strong><br />

Project Green hands is an ecological initiative of JYB foundation to prevent and reverse environmental degradation and enable sustainable living. Additionally, nature awareness campaigns are conducted to establish a culture care for the environment. Starting from the geographical land area of Odisha, project green hands seeks to inspire people around the world to keep this planet livable for future generations.<br />
<br />

Today’s contribution will reach future generations.
<strong>-	Join us now!</strong><br />
<br />

Ask yourself, “How can I beautiful to those around me and to the whole world.”
“Planet ke Rakhwale” campaign to planet trees.<br />
<br />

Saplings have been planted on both sides of long connecting roads, so as to provide shade for visitors and locals. Plantation has also been done in school campuses and individual houses, in front of the temple, on path ways and approaching roadsides.
Green initiatives, Go Green mission.
</p>
	 
    </div>
  </div>
  
  <div class="AccordionPanel">
    <div class="AccordionPanelTab">
      <h4>(l) Mission Healthy India Healthy world.</h4>
    </div>
    <div class="AccordionPanelContent cnt">
     
    	<p style="color:#333; font-size:14px;">Texts will be added soon.</p>
	 
    </div>
  </div>
  
  <div class="AccordionPanel">
    <div class="AccordionPanelTab">
    <h4>(m)	Clean India – Beautiful India Programme (Clean Inside-Clean Outside)</h4>
    </div>
    <div class="AccordionPanelContent cnt">
    
    <p style="color:#333; font-size:14px;">The JYB foundation taken clean India-Beautiful India program aimed at improving public health and at restoring India’s physical beauty. Through this campaign, JYBF call all citizens of India to embrace practical new Initiatives to clean India’s public space, promote health through hygiene, sort garbage, recycle and properly dispose of waste. The campaign is also working to make people more aware of the need to avoid littering, spitting and urinating in public and to maintain environmental cleanliness. The awareness campaign is ongoing in every languages and every stae in India, and has already reached millions of people nationwide.<br />
      <br />
    Through JYB Foundation, volunteers are cleaning public areas, constructing public toilets and spreading awareness in schools regarding the proper way to dispose of trash. Also educated people living in that area about garbage separation, rain water harvesting, tree plantation and hazards of littering, spitting and using plastics.<br />
    <br />
    In Odisha, where the campaign was first launched clean-up drives have been conducted in every major town and city. Founder is also calling upon all citizens of India to take to recognize in principle that the earth is the mother of humanity and that cleanliness is godliness, and to pledge to work with dedication for the realization of environmental cleanliness and hygiene.<br />
    <br />
    The initiative also included cleaning the sacred river Prachi, Daya, Kuakhai, Bindusagar and its surrounding Ghats that have been polluted for several decades through industrial waste, dumping and negligence.<br />
    <br />
<em>    Over 40% of the world’s populations do not have access to basic sanitation.</em>
    </p>
    
    </div>
    </div>
    
  <div class="AccordionPanel">
    <div class="AccordionPanelTab">
    <h4>(n)	HIV – AIDS Awareness among Rural and Slum Adolescents.</h4>
    </div>
    <div class="AccordionPanelContent cnt">
    
    <p style="color:#333; font-size:14px;">It is estimated that around 2.27 million people are currently living with HIV in India, which makes the country third in the world in terms of the greatest number of people living with disease. HIV and AIDS poses enormous spiritual, social, economical and political challenges and increasingly. It is a problem facing youth. Young people represent half of all new HIV infections worldwide.<br />
      <br />
    So JYB foundation, working 1st in Odisha of India, has been delivering programmes to create awareness on and prevent the spread of HIV-AIDS. The programmes aim to train volunteers from the local communities (Yuvacharayas), with the expectation that they will reach out to the masses with the message of HIV prevention. Target groups include injecting drug users (IDUS) female sex workers, men who have sex with men (MSM), and STD Clinic attendees.<br />
    <br />
    On world AIDS day on 1st Dec, every year we arranged a rally in Bhubaneswar, Odisha on reducing stigma and discrimination against HIV AIDS affected patients. The rally and its participants expressed solidarity for the prevention of AIDS and against the discrimination of HIV positive people.
    </p>
    
    </div>
    </div>  
    
  <div class="AccordionPanel">
    <div class="AccordionPanelTab">
    <h4>(o)	Blood donation camp. (Give Red Live Green).</h4>
    </div>
    <div class="AccordionPanelContent cnt">
    
    <p style="color:#333; font-size:14px;">You don’t have to be a doctor<br />
      <br />
    Blood ! A gift from the heart To save a life.<br />
<br />
	Donate blood.Together we can save lives.
<br />
    <br />
Giving = Living.<br />
<br />
Donate your blood And make a difference.<br />
<br />
It’s Safe, its simple…. To save lives.<br />
<br />
Every Blood Donor is the hero.
    </p>
    
    </div>
    </div>  
    
  <div class="AccordionPanel">
    <div class="AccordionPanelTab">
    <h4>(p)	Action for rural rejuvenation. (Gramayan)</h4>
    </div>
    <div class="AccordionPanelContent cnt">
    
    <p style="color:#333; font-size:14px;">In India, over 750 million people live in rural communities, most of them in hopeless socioeconomic situations, prevalent with disease, apathy, isolation, and despair.<br />
      <br />
    “Action for Rural Rejuvenation” (ARR) is a multi pronged, multi-phased, holistic outreach program initiated by JYB foundation. The Projects primary objective is to improve the overall health and quality of life of the rural poor. In a unique philanthropic effort, JYB enhances conventional development schemes by supporting indigenous model of health and prevention.<br />
<br />
	So medical camps and health awareness programs are conducted especially in villages and slum areas of Odisha to provide medical support to understand communities and raise their standard of health. the multi-pronged project offers integrated, preventive health are as well as access to health-promoting and life-saving interventions. Partly in association with reputed specially hospitals. the project is geared to offer immediate relief in the case of epidemics and natural disasters.
<br />
    <br />
The aim of “Gramayan” is to create a sense of pride in the society about village life. to involve 6 lakh villages in the celebrations, village committees will be formed. They will organize programmes in tune with the local customs and traditions, such as Bharat matapujan, Kath kirtanmela. by motivating the urban youth to devote time in the villages, long term service projects to develop “vivek gram” village free of untouchability; conversion, addiction, police/courts and depends on chemical fertilizers. The semi rural clusters in the urban area will also be developed into “vivekbasti”.<br />
<br />
This project is not just aimed at improving the economic condition of people.  It is a way of inspiring a human being to stand up for him to raise the human spirit.
    </p>
    
    </div>
    </div> 
    
  <div class="AccordionPanel">
    <div class="AccordionPanelTab">
    <h4>(q)	Village olympics</h4>
    </div>
    <div class="AccordionPanelContent cnt">
    
    <p style="color:#333; font-size:14px;">Through this initiative, JYB aims to rekindle the villager’s involvement in communities, reduce addictions and promote social bonding beyond caste, creed, religion of economic status, by organizing village Olympic sports events and inter village tournaments as well as Gramotsakam, a large scale rural festival which features the Rural Olympics, for talent search to promote Bharat to win more medal in world Olympic games.
    </p>
    
    </div>
    </div>  
        
  <div class="AccordionPanel">
    <div class="AccordionPanelTab">
    <h4>(r)	Annapurna Project. Akshayapatra facts. (A meal today, a life tomorrow).</h4>
    </div>
    <div class="AccordionPanelContent cnt">
    
    <p style="color:#333; font-size:14px;"><strong>Some facts about Global poverty:</strong>
	i.  A child dies of extreme poverty every 3-6 seconds.
	ii. 114 million children do not have a basic education.
	iii.More than 800 million people go to bed hungry every day. 300 million are children.<br />
<br />
There will come a day, when not a single Indian child will go hungry.<br />
<br />
Annapurna project, a public-private partnership, is among the world’s largest school meal programs. This addresses two of India’s most immediate challenges, hunger and education.<br />
<br />

Our vision is to empower every under privileged Indian child with food and education and thus, empower generations to follow.
The program is a pioneering effort in public-private partnership for social development and has produced dramatic results in school enrollment and attendance.


    </p>
    
    </div>
    </div>    
    
  <div class="AccordionPanel">
    <div class="AccordionPanelTab">
      <h4>(s)	Swavalamban campus (Job oriented program)</h4>
    </div>
    <div class="AccordionPanelContent cnt">
     
    	<p style="color:#333; font-size:14px;">Texts will be added soon.</p>
	 
    </div>
  </div>
  
  <div class="AccordionPanel">
    <div class="AccordionPanelTab">
      <h4>(t)	Disaster risk management and disaster relief work.</h4>
    </div>
    <div class="AccordionPanelContent cnt">
     
    	<p style="color:#333; font-size:14px;">Texts will be added soon.</p>
	 
    </div>
  </div>
  
  <div class="AccordionPanel">
    <div class="AccordionPanelTab">
      <h4>(u)	Towards reducing child mortality.</h4>
    </div>
    <div class="AccordionPanelContent cnt">
     
    	<p style="color:#333; font-size:14px;"><strong>India has:-</strong><br />
	i.The highest rate of neo-natal deaths (around 35%) in the world.<br />
	ii.40% of child malnutrition within the developing world.<br />
	iii.50% of child mortality.<br />
	iv.Reducing number of girls in 0-6 age, group -927 girls for every 1000 boys.<br />
	v.High school dropout rates especially amongst girls.<br />
	vi.High rate of child marriages.<br />
	vii.Large number of child laborers.<br />
	viii.Large number of sexually abused children.<br /><br />
“Child protection” is about protecting children from or against any perceived or real danger or risk to their life, their personhood and childhood. failing to protect children from issues such as violence in schools, child labour, harmfull traditional practices, absence of parental care and commercial sexual exploitation is unacceptable. Children who live in extreme poverty are often the most vulnerable and experience violence, exploitation and discrimination the most.<br />
<br />
Stress elimination in Juvenile.<br />
<br />
<strong>Observation homes:-</strong>
With support from the women and child development department, government of odisha, launched a programme to provide comprehensive physical, mental, emotional, and spiritual development for all inmates living in three juvenile observation homes in the states of odisha(Berhampur and Rourkela districts). the aim of the programme was to keep the inmates stress free, calm and inspire them to lead crime free life.<br />
<br />

<strong>Preventing child marriages.</strong>
Despite many countries enacting marriageable age laws to limit marriage to a minimum age of 16 to 18, depending on jurisdiction, traditional marriages are widespread. poverty, religion, tradition and superstition are often reason why child marriage is practiced in certain societies.<br />
<br />

According to UNICEF’s state of the world’s children-2009 report, 47 percent of India’s women aged 20-24 were married before the legal age of 18, with 56% in rural areas. the report also showed that 40% of the world’s child marriages occur in India.

</p>
	 
    </div>
  </div>
  
  <div class="AccordionPanel">
    <div class="AccordionPanelTab">
      <h4>(v)	Promote gender equality and Women’s empowerment project.</h4>
    </div>
    <div class="AccordionPanelContent cnt">
     
    	<p style="color:#333; font-size:14px;">Towards combating sex selective abortions has been one of our core focus areas.<br />
The child sex ration is a powerful indicator of the social health of any society. Calculated as number of girls per 1000 boys in the 0-6 years age group, the ratio has shown a sharp decline in India from 976 girls per 1000 boys in 1961 to 927 as per the 2001 census. In certain parts of the country, there are less than 800 girls for every 1000 boys. The rapidly declining child sex ratio can have severe impacts on the society as seen through increased incodences of violence against women, rape, abduction, trafficking and the onset of practices such as polyandry and women being ‘bought ‘ as brides.
<br /><br />
Prenatal sex selection is illegal in India. The country is committed to the principles of gender justice and equity, but legislation and policing alone cannot change generations of cultural practice and the killing of female children, either in the womb or soon after birth continues. According to government reports, as many as 2 million fetuses are aborted each year for no other reason than they happen to be female. In Punjab, the government claims that the numbers of missing girls will increase by 40 percent in the forthcoming generation. The situation calls for a deep-seated change in our perception of women and gender discrimination.<br />
<br />
	<em>Killing 1 million cows is equivalent to killing 1 vedic scholar.</em><br />

	<em>Killing 1 million vedic scholars is equivalent to killing 1 Saint.</em><br />

	<em>Killing 1 million Saint is equivalent to killing 1 Female Child.</em><br />
<br />
<strong>-	H.H. Sri Sri Ravi Shankar</strong> referring to the girl child being given a place of importance in society as per the Dharma Shastras.<br />
<br />
So JYB Foundation arranged seminar, workshop, and rally to promote Gender Equality.<br />
<br />

<strong>Seminar Topics:</strong><br />

1.	India’s missing Daughters: Faith for Action against Sex Selection.<br />
2.	Save the Girl Child.<br />
3.	Project “No to Sex Selection”.<br />
4.	International Women’s Conference :-Shakti, the strength of women	- Celebrating Success.<br />
<br />
Women Empowerment Centre have been training rural women and empowering them in activities like tailoring, candle making, agarbati (incense stick) making, producing utensil clearing powder and screen printing.
</p>
	 
    </div>
  </div>
  
  <div class="AccordionPanel">
    <div class="AccordionPanelTab">
      <h4>(w)	Towards improving maternal health.</h4>
    </div>
    <div class="AccordionPanelContent cnt">
     
    	<p style="color:#333; font-size:14px;">More than 350,000 women die annually from complications during pregnancy or child birth, all most all of them-99% are in developing countries.
<br /><br />
Every year, more than 1 million children are left motherless and children who have lost their mothers are up to 10 times more likely to die prematurely than those who have not.<br />
<br />
	So Jagad Guru Yoga Bharat Foundation for ‘Maternal Health’ raise awareness on the general hygiene (gynecology), contraception and health during pregnancy, childbirth and general  children’s health and healthy eating and home remedies. Broader issues such as the status of women in rural societies, basic legal literacy and economic opportunities were also covered.
</p>
	 
    </div>
  </div>
  
  <div class="AccordionPanel">
    <div class="AccordionPanelTab">
      <h4>(x)	Preventing indoor air pollution in rural households.( The “Room to Breathe” campaign).</h4>
    </div>
    <div class="AccordionPanelContent cnt">
     
    	<p style="color:#333; font-size:14px;"><strong>THE ‘ROOM TO BREATHE’ CAMPAIGN</strong><br />
<br />For millions of low-income people in developing countries, a stove is a pile of stones leated by an open wood-or cow-dung-burning fire in their homes. This method of cooking poses a serious health hazard of indoor air pollution (IAP) resulting from the burning of biomass fuels, which leads to respiratory diseases. As women are primarily responsible for cooking, and as children often spend time with their mothers while they are engaged in cooking activities, women and young children disproportionately affected.
<br /><br />
To address the increasing and harmful impact of IAP, Envirofit and shell foundation (UK) have recently launched a range of clean burning biomass cooking stoves in India. It is claimed that the stoves reduce toxic omissions by as much as 80%, uses 50% less fuel and reduce cooking time by 40%.
</p>
	 
    </div>
  </div>
  
  <div class="AccordionPanel">
    <div class="AccordionPanelTab">
      <h4>(y)	Awareness on anti- raggingcampaigning and awareness against nudity and obscenity.</h4>
    </div>
    <div class="AccordionPanelContent cnt">
     
    	<p style="color:#333; font-size:14px;">Texts will be added soon.</p>
	 
    </div>
  </div>

  <div class="AccordionPanel">
    <div class="AccordionPanelTab">
      <h4>(z)	Awareness on prevention of cruelty to animal and save cow saveindia.</h4>
    </div>
    <div class="AccordionPanelContent cnt">
     
    	<p style="color:#333; font-size:14px;">Texts will be added soon.</p>
	 
    </div>
  </div>

</div>
<!--<div style="font-size:12px; padding:10px; height:320px; overflow:auto">
        a.	De-addiction program (free yourself from the habit)<br />
b.	Antitobacco campaign (Tobacco free youth, tobacco free India)<br />
c.	March against terrorism and corruption. (Standup take action)<br />
d.	Suicide prevention through project Hope<br />
e.	Smart prison program through yoga (Inner freedom for the imprisoned).<br />
f.	Yoga for defence personnel<br />
g.	Mission green earth (Plant for planet)<br />

        	h.	Safe driving awareness through project “Yoga Sarathi”.<br />
i.	Orphanage activities<br />
j.	Mission Healthy India Healthy world.<br />
k.	Clean India – Beautiful India prog. (clean inside-clean outside)<br />
l.	HIV – AIDS awareness among rural and slum adolescents.<br />
m.	Blood donation camp. (Give Red Live Green).<br />
n.	Issue Based satsangs. (Not pravachan but svavachan)<br />
o.	Action for rural rejuvenation. (Gramayan)<br />
p.	Village olympics<br />
q.	Tribal welfare project.<br />
r.	Annapurna Project. (A meal today, a life tomorrow).<br />
s.	Swavalamban campus (Job oriented program)<br />
t.	Disaster risk management and disaster relief work.<br />
u.	Towards reducing child mortality. <br />
v.	Promote gender equalityandWomen’s empowerment project.<br />
w.	Towards improving maternal health.<br />
x.	Preventing indoor air pollution in rural households.( The “Room to Breathe” campaign).<br />
y.	Awareness on anti- raggingcampaigning and awareness against nudity and obscenity.<br />
z.	Awareness on prevention of cruelty to animal and save cow saveindia.

        </div>-->



      </div>
      
	  
      
    </div>
  </div>
                    
                </div>
            </div>
        </div>
		
    <?php include("footer.php"); ?>
	
<script type="text/javascript">
var Accordion1 = new Spry.Widget.Accordion("Accordion1");
    </script>
</body>
</html>
