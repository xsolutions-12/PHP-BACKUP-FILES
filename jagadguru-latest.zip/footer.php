<div class="foot">
    <div style="width:880px; margin:0 auto; text-align:left">
    <table width="890" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td style="line-height:20px;"> All Rights Reserved &copy; 2014 Jagadguru Yoga Bharat Foundation<br />
    Designed, Developed & Maintained by <a href="http://xprosolutions.co.in" target="_blank" style="text-decoration:none; color:#FFFF00;"> &nbsp;&nbsp;<strong>XPRO Solutions Pvt. Ltd.</strong></a></td>

        <td>
        
        <a href="http://www.diya.net.in/" target="_blank"><img src="images/diya.png" width="56" height="57" alt="" style="float:right;" /></a><a href="http://www.dsvv.ac.in/" target="_blank"><img src="images/dsvv.png" width="55" height="57" alt=""  style="float:right;"/></a></td>
  </tr>
</table>

   
      </div>
    </div>