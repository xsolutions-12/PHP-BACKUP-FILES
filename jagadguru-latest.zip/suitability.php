<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Jagad Guru Yoga Bharat Foundation</title>
    <link rel="stylesheet" href="yoga_style.css" />
     <link href="tab/style1.css" rel="stylesheet" type="text/css">
</head>

<body>

	<?php include("header1.php"); ?>
	    
		<div class="main"  >
    	<div class="content_wrap">
            <div style="width:100%; height:30px;"></div>
            <div class="main_wrap"  >
                <div class="wrapper1">                	
     
    <div>
      <div class="tabpage"  style="text-align:center">
      <h2>SUITABILITY OF YOGA FOR CHILDREN</h2>
      <h4 style="float:right; text-align:right; color:#666">Yogacharya Dr. Biswaranjan Rath,<br />
Faculty, P.G. Department of Yoga, Utkal University 
</h4><br /><br /><br />

<br />
<p style="text-align:justify; font-size:12px">
In India, Children were traditionally introduced to the practice of yoga in their 8th year.  In our ancient culture, boys and girls alike were initiated into Surya Namaskara, Nadisodhana Pranayam and Gayatri Mantra at this magical age which represents childhood’s end.  Now the significance of this age is becoming apparent to modern scientists who recognize that the eighth year of life represents a crucial milestone in the physiological and psychological development of each individual, marking the beginning of the transition of awareness from childhood into adult life.  The following are a number of facts which have been discovered by scientists concerning children of this age.<br /><br />
<strong>1.</strong>	The pineal gland, which has a controlling influence over the pituitary and the whole Endocrine System, begins to decay in the eighth year.  The pineal is a tiny gland, located in the Medulla Oblongata of the brain.  Many children do not cope well during this transitional period, when sexual awareness is developing.  They become emotionally unbalanced and disturbed during their pre-adolescent and adolescent years and show disruptive behaviour such as anger, resentment or violence.  All these can be directly or indirectly attributed to hormonal imbalance.  For this, the child can be taught Surya Namaskara a dynamic exercise involving twelve different movements which would provide stretching and relaxation for the body and would help to rebalance the energy.  He can practice Shambhavi Mudra, focusing the gaze on the eyebrow centre which is essential for maintaining the health of the pineal.<br /><br />
<strong>2.</strong>	The number of minute alveoli (air sacs) in the lungs goes on increasing up till the eighth year.  Doctors note that this is the ideal age for the introduction of Pranayama into the daily routine.<br /><br />
<strong>3.</strong>	According to Psychologists, the child’s reasoning capacities, and moral education, begins from the age of eight years.  This is the time when a child can be considered ready to learn and to concentrate seriously.  Children who practice Yoga from this age are destined to expand and develop their natural attributes, capacities and talents to the fullest extent, thereby leading successful, useful and liberating lives.<br /><br />
All the above facts emphasize the need to introduce yoga to children so that it could develop their physical stamina, bring about emotional stability and unfold their intellectual and creative talents.  Today’s parents are increasingly concerned about the total development of their children.  Yoga is a gift of our ancient culture.  Why not hand it down to our children for their complete well being?<br /><br />
	In Saraswati Vidya Mandir School, I am taking Yoga class once every week.  In this school all the students are practicing yoga with good discipline and great attention.  The Saraswati Vidya Mandir Schools is like a “Blooming Lotus.”<br /><br />
	The destiny of the whole world depends on the little children.  If you want to see the silver lining on the horizon, it is not you and me, but the children who have to be spiritualised.<br />
<span style="float:right;"><strong>-	Swami Satyananda Paramahansa</strong></span><br /><br />
Children should be properly moulded by the teachers and parents.  They are highly susceptible like malleable metal.  They are very imitative and they will copy our behaviour.  If we set before them the path of good life, if we can inspire them with the principles of good physical and mental health and high ideals, they will turn out to be good citizens and ideal persons.<br />
<span style="float:right;"><strong>- Paramahansa Swami Sivananda Saraswati</strong></span>

</p>
      </div>
      
	  
      
    </div>
  </div>
                    
                </div>
            </div>
        </div>
		
    <?php include("footer.php"); ?>
	
</body>
</html>
