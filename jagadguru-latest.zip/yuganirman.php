
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Jagad Guru Yoga Bharat Foundation</title>
    <link rel="stylesheet" href="yoga_style.css" />
     <link href="tab/style1.css" rel="stylesheet" type="text/css">
</head>

<body>

	<?php include("header1.php"); ?>
	    
	<div class="main"  >
    	<div class="content_wrap">
            <div style="width:100%; height:30px;"></div>
            <div class="main_wrap"  >
                <div class="wrapper1">                	
     
    <div>
      <div class="tabpage" id="tabpage_1" style="text-align:left;padding-left:15px;">
  <h3>YUGA NIRMAN VIDYALAYA / VIDYA PITHAM</h3><br />
  <strong style="font-size:18px;">Education for everyone</strong><br />
<br />
<p style="color:#333; font-size:13px;">
<em>“The roots of Education are bitter, but the fruits are very sweet.”</em>		….. <strong>Aristotle</strong>.<br />
<br />

<em>“The basic purpose of life and the basic purpose of education is to enhance one’s boundaries of perception. I don’t want the children to just survive after twelve years of schooling here. They must blossom and flower wherever they go.”</em>				….. <strong>SADGURU</strong><br />
<br />

<em>“There is need for an educational institution, which could mould its students into noble and enlightened human beings selfless, warm-hearted, compassionate and kind.</em>
								….. <strong>Pandit Shri Ram Sharma Acharya</strong><br />
<br />
<strong>Education as a ‘heart making’ and not merely as a bread earning process.</strong>.<br />
<br />

In tribal and rural parts of India it is common to find children growing up with no formal education. In accessible rural areas parents often prefer to sent their children as domestic helpers on to farms to earn a few rupees, rather than provide them with an education.<br />
<br />

This is even more so far a girl child. It is common practice that when she turns 14 she gets married, by 20 has five children, has no education behind her, no money and furthermore no self-confidence and no self-esteem. Slums areas in India have their own set of challenges. Lack of availability of free education forces children to look for other means to earn a small income with many turning to drugs, violence, alcohol and tobacco at a young age.<br />
<br />
<strong>Beyond academics:-</strong><br />

School is not just about learning the basic reading, writing and arithmetic – or even about passing an examination; but rather, education means nurturing the wellbeing of children on all levels-academically, physically and mentally.<br />
<br />

So, YUGA NIRMAN VIDYALAYA’s mission has been providing free, value based education in India in stress free, student friendly environments for tribal, rural and slum children.<br />
<br />

YUGA NIRMAN VIDYALAYA’s mission is to unite contemporary education with spiritual training to cultivate well-rounded competent and personally uplifted students with a scientific and offering service to the society.<br />
<br />

Born out of the vision of Satguru Pt. Shri Ram Sharma Acharya to provide holistic, value-based education and developing generations of youth who will lead a purposeful life, full of empathy towards all beings in creation.<br />
<br />

To promote holistic education in a stress free and child friendly environment, vision is to provide world class holistic education which will facilitate cognitive, physical, emotional, social and spiritual growth.<br />
<br />

Here integrated styles of education that blend ancient and modern, eastern and western, scientific and spiritual styles of teaching.<br />
<br />
<strong>Mission to:-</strong><br />

i.   Establish at least one school in every district of India where learning is inspirational and fun and a sense of belongingness is created.<br />
ii.  Establish one institute of higher education in every state in India to establish a standard in education that will become a role model.<br />
iii. Develop students into society conscious Global citizens. 97% School attendance, 10% dropout rate, 45% of the students being girls.<br />
    </p>
     </div>
      
	  
      
    </div>
  </div>
                    
                </div>
            </div>
        </div>
	 
    <?php include("footer.php"); ?>
	
</body>
</html>
