<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Jagad Guru Yoga Bharat Foundation</title>
    <link rel="stylesheet" href="yoga_style.css" />
     <link href="tab/style1.css" rel="stylesheet" type="text/css">
</head>

<body>

	<?php include("header1.php"); ?>

		<div class="main" >
    	<div class="content_wrap">
            <div style="width:100%; height:30px;"></div>
            <div class="main_wrap"  >
                <div class="wrapper1">                	
     
    <div>
      <div class="tabpage" id="tabpage_1">
    
<h3>Devasanskriti Yoga Vidyalaya</h3><br />
<div class="cnt2">
  <img src="images/founder.png" width="226" height="255" alt="" style="float:right;   margin-left:20px; margin-bottom:10px;" />
<p style="color:#333; font-size:13px;">
	<strong style="font-size:15px;">Modern Ailments – Yoga & Holistic Health Treatment.</strong><br />
	<br />
Without caring for stale remedy everybody is tempted for quick relief through numerous drugs having dangerous side effects and unbearable cost. Imprudent prescription and mad rush for material success are promoting it. People paying heavy price for it in terms of losing memory, vitality, spirituality and immune power.<br /><br />
The ageless ethics of prosperity and health is integration of body mind and spirit through detoxification and self knowledge. Its pragmatic approach is called yoga, which heals the aspirant from within.<br />
DSYV is a focal institute for planning, training, promotion and coordination of yoga education, training, therapy and research in all its aspects.<br />
<br />

<strong>Our vision</strong><br />
To become a centre for Excellence in yogic science and naturopathy for a healthy, peaceful and prosperous society.<br />
<br />
<strong>Our mission</strong><br />
To impart education and training in yoga and naturopathy with clinical research and implementation in therapy for a holistic growth of society.<br /><br />
<strong>About the institute :-</strong><br />
Deva sanskriti Yoga Vidyalaya came to existence in the year 2006 with an objective of providing widespread yogic education in the state of Odisha and creating opportunities for research in yoga.<br />
It aims to be a national Institute subsequently catering to the country of India and abroad. It is an organization under the tutelage of Jagad Guru Yoga Bharat Foundation Trust.<br /><br />
It aims at providing :<br /><br />
	Diploma in Naturopathy and yoga therapy (One year)<br />
	Certificate course in Yoga and Naturopathy (three months)<br />
	Health Management Courses (One month)<br /><br />
This Institute has been established with a twofold agenda. The first one is to produce Yoga and Naturopathy professionals through education, training and research. There is a lack of such qualified professionals in our country. It will carry forward the highly scientific yogic and nature cure traditions of India. These professionals will be able to spread true spirit of this knowledge.<br />
It also intends to establish a modernized research center for catering to the needs of the present society.<br /><br />
<strong>Objectives</strong><br />
	To increase mass awareness about the health benefits of yoga.<br />
	To impart training facility on standard yoga practices for physical, mental and spiritual wellbeing of the people.<br />
	To create a network of yoga teaching institutes / centers for propagation and promotion of yoga.<br />
	To co-ordinate yoga in School Health programme.<br />



</p>
</div>

      </div>
      
	  
      
    </div>
  </div>
                    
                </div>
            </div>
        </div>
		
    <?php include("footer.php"); ?>
	
</body>
</html>
