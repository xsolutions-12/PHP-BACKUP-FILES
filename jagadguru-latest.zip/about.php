<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Jagad Guru Yoga Bharat Foundation</title>
    <link rel="stylesheet" href="yoga_style.css" />
     <link href="tab/style1.css" rel="stylesheet" type="text/css">
		<script src="tab/tabs.js" type="text/javascript"></script>
</head>

<body>
<div class="p1" >

	<?php include("header1.php"); ?>

    
    <div class="main" >
    	<div class="content_wrap">
            <div style="width:100%; height:30px;"></div>
            <div class="main_wrap"  >
                <div class="wrapper" style="padding:30px 0;">                	
                    <div id="tabContainer">
    <div class="tabs">
      <ul>
        <li id="tabHeader_1">Founder</li>
        <li id="tabHeader_2">Career Objectives</li>
		<li id="tabHeader_3">Mission & Vision</li>
      </ul>
    </div>
    <div class="tabscontent">
      <div class="tabpage" id="tabpage_1">
      <img src="images/founder.png" width="226" height="255" alt="" style="float:right; margin-top:45px; margin-right:25px;" />
<h3>Yogacharya Dr. Biswa Ranjan Rath</h3><br />
<p style="color:#333; font-size:14px;">R.M.P. Alternative Therapy, B. Pharma, M.Sc. DFSM,<br />
M.D. Yoga Therapy, DMLT, CNCC, CCAM, YIC<br />
Founder, Jagadguru Yoga Bharat Foundation<br />
Faculty, P.G. Dept. of Yoga, Utkal University <br />
Guest Faculty, Dept. of Yoga, Devsanskriti Vishwa Vidyalaya<br />
Master Trainer in Yoga, C.H.S.E. Govt. of Odisha<br />
Co-ordinator, Divine India Youth Association (DIYA), Bhubaneswar, Odisha<br />
President, Yoga Professionals association of Odisha<br />
Director & Research Head,  Devsanskriti Yoga Vidyalaya<br />
Co-ordinator, Shriram Vichara Mancha (Established on ideology of Yuga Rishi Pandit Shriram Sharma Acharya).</p>


      </div>
      <div class="tabpage" id="tabpage_2">
      <h3>Yoga Career Builder by Dr. Biswa Ranjan Rath</h3><br />
        <p style="color:#333; font-size:14px;">To promote the benefit of yogic principles for the new millennium by combining the best of the west (modern scientific research) with the best of the East (Yoga and spiritual lore) not only for alleviating human suffering but also for individual growth and universal peace, harmony and brotherhood.</p>
      </div>
	  <div class="tabpage" id="tabpage_3">
       <p style="color:#333; font-size:13px;">The modern busiest society is gradually become stressful and violent due to the over competitiveness  and high ambitions. Life becomes uncertain; there is no peace and harmony. The gun culture, hiffy culture and drug culture are crippling day by day. Every body is victimised by the psycho-somatic disorders.<br />
         <br />
         Also the antisocial and anti-moral activities are very common in the society. In one line we may say that the society has already lost its peace and harmony. In order to bring the balance and harmony in the society “Yogic Science and Holistic Health Management” is a wonderful means. It primarily corrects the individual perception and gives new vision and secondary helps to establish unity in diversity, which would change the nature of society. So that everybody could experience the real test of the society as well as essence of life. <br />
<br />
Conceptualized by Swami Vivekananda, Yuga Rishi PanditShriRamsharma Acharya and Dr. A.P.J. Abdulkalam, Honorable Ex-President of India, <strong>JYB Foundation</strong> emphasizes upon simultaneous development of self and society. Inspired by its founder’s vision of making the world a violence free, stressfree, global family, the organization is engaged in various initiatives that uplift humanity and enhance the quality of life for millions.<br />
<br />

The goal of the organization is to serve society by strengthening the individual. It does this by offering programmes that eliminate stress, create a sense of belongingness, restore human values, and encourage people from all backgrounds, religions and cultural traditions to come together to tackle key concerns in society. In additon, it has also pioneered serveral projects of immense social value.From its powerful yoga programs for inner transformation to its inspiring social and environmental projects, JYB foundation activities are designed to create an inclusive culture that is the basis for global peace and development.</p>

      </div>
      
    </div>
  </div>
                    
                </div>
            </div>
        </div>
    </div>
		
    <?php include("footer.php"); ?>
	
</div>
</body>
</html>