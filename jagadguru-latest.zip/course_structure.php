<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Jagad Guru Yoga Bharat Foundation</title>
    <link rel="stylesheet" href="yoga_style.css" />
     <link href="tab/style1.css" rel="stylesheet" type="text/css">
</head>

<body>

	<?php include("header1.php"); ?>

	<div class="main"  >
    	<div class="content_wrap">
            <div style="width:100%; height:30px;"></div>
            <div class="main_wrap"  >
                <div class="wrapper1">                	
     
    <div>
      <div class="tabpage" id="tabpage_1" style="text-align:left;padding-left:15px;">
  <!--<img src="images/under.png" width="526" height="421" alt="" />-->
  <h3>Course Structure of Yoga</h3><br />
  <strong style="font-size:18px;">(A) 	Yoga Certificate Course </strong><br />
<br />
<p style="color:#333; font-size:13px;">
	1. 	Yoga Foundation Course (YFC)<br />
	2. 	Yoga Instructor Course (YIC)<br />
	3. 	Yoga Teacher’s Training Course (YTTC)<br />
	4. 	Yoga Teacher’s Certificate Course (YTCC)<br />
	5. 	Teacher’s Training Course in Yoga & Naturopathy<br />
	6. 	The Yoga: Step-By-Step Course<br />
	7. 	PG Diploma in Yoga Therapy & Education (1 year, 2 Semester)<br />
	8. 	Master Degree in Yoga Therapy & Education (2 years, 4 semester)<br />
	9.	Balsanskar Kendra Teacher’s Certificate Course<br /><br />

<strong style="font-size:18px;">(B) 	Yoga Camp</strong><br />
<br />

	1. 	Art of Graceful Ageing (Senior Citizen’s orientation camp through Yoga)<br />
	2. 	Suicide Prevention through project “HOPE”<br />
	3. 	Ancient Techonology for the Modern Mind (Man Making Nation Building)<br />
		Bank / BPO / Office / Corporate / Club / Association<br />
	4. 	WeekendYoga Retreat (for Corporate / BPO / IT Software )<br />
	5. 	Yoga for Executive-Self Management of excessive tension (SMET-2 days)<br />
	6. 	Yoga for Computer Professionals<br />
	7. 	ResidentialYogaShibirs of 15 days duration<br />
	8. 	Residential Spiritual retreats of 7 days duration<br />
	9. 	The Yoga of Mother Hood (for pregnant woman)<br />
	10. 	Holistic System Management (HOLYSM- for 3 days)<br />
	11. 	Yoga Intensive for Sportsman (YIS) -7 days<br />
	12. 	Yoga Intensive for Musicians (YIM) - 7days<br />
	13. 	Stress ManagementProgram for corporate executive<br />
	14.	Yoga SikhyaShibir<br />
	15. 	Inner Technology-Technologies for inner wellbeing<br />
	16. 	Yoga for Defence Personnel<br />
	17. 	Women’s Holistic Health Through Yogic Treatment<br /> 
		(for working women & House mothers)-for all ladiess
	18. 	Yoga in Prisons-Transforming the Criminal<br />
		Smart Prison Program by Yoga (Inner Freedom for the Imprisoned)
	19. 	Scientific Yoga & Holistic Health Treatment & Training<br /> 
	20. 	Yoga Excellence Program for General Group (3 months)<br />
	21. 	Yoga Training for Safe Driving (Yoga SarathiProgramme)<br />
	22. 	Yoga for development Eye Sight
    </p>
   </div>
      
	  
      
    </div>
  </div>
                    
                </div>
            </div>
        </div>
		
    <?php include("footer.php"); ?>
	
</body>
</html>
