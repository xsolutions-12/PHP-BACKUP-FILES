<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Jagad Guru Yoga Bharat Foundation</title>
    <link rel="stylesheet" href="yoga_style.css" />
     <link href="tab/style1.css" rel="stylesheet" type="text/css">
</head>

<body>

	<?php include("header1.php"); ?>

		<div class="main" >
    	<div class="content_wrap">
            <div style="width:100%; height:30px;"></div>
            <div class="main_wrap"  >
                <div class="wrapper1">                	
     
    <div>
      <div class="tabpage" id="tabpage_1">
    
<h3>Devasanskriti Yoga Vidyalaya</h3><br />
<div class="cnt2">
  <img src="images/founder.png" width="226" height="255" alt="" style="float:right;   margin-left:20px; margin-bottom:10px;" />
<p>
	We felt that need of the day is to start one National Platform whereby we can bring in the required energy and synergy by bringing together different yoga associations. That’s how our vision and mission started taking shape, hence this Yoga professionals Association of India.<br />
In fact it was not merely meant to have one association but also drive home the point what a coming together of likeminded group if determined can achieve to explore and excel in the field of yoga, by catering to the needs of different age groups and different sectors from all walks of life, by providing Ancient solutions to modern problems and by preserving this ancient practice and wisdom for the future generations to come.<br /><br />
As the saying goes, Coming together is a beginning; Keeping together is a progress; Working together is a success, it is important that all of us should come together and work for the common cause. Of course all of us may be individually committed to the propagation of Yoga or may be individually doing our own to inspire and motivate the people in their chosen field. But the question is, Is it enough to bring the desired results? Or Is there something where all of us can find some common ground and common cause without compromising our individual interests.<br /><br />
So it is with this goal and objective we have been striving to bring fruition on these lines. We are still working on the contours and modalities to make the association more responsive, accountable, teacher friendly and above all people friendly.<br />
It is therefore requested that you, being a Yoga teacher and one who is committed to the service of humanity are requested to join this august and noble venture to make it succeed in its mission. It is only when direct our energy and synergy on our hopes, our dreams and on our goals on a combined platform, we can succeed. It is also requested to give your valuable suggestions and ideas to make this association more effective and more efficient to achieve its goal.<br />
It is therefore requested that you not only become a member of the association but also take active participation in this activities in the larger interest of the public. We do hope that in the times to come, together we shall definitely grow and succeed in our mission to serve the humanity. Thank you and look forward to join our hands with you. May God bless us All.<br />
Aims and objectives : Yoga Professionals Association of India.<br /><br />
a.	To encourage people to adopt the Yogic life to improve their physical, psychological, social and spiritual well being.<br />
b.	To exhort the youth to imbibe the spirit of Yogic culture so as to realise their talent immense potential and unleash the tremendous power and energy for the benefit of the society.<br />
c.	To establish linkage and synergy among different institutions and Associations in Yoga for creating Excellence.<br />
d.	To pursue people to acquire certification and qualification in yoga discipline and to take up yoga as a fulfilling career and also to create a platform for their employment.<br />
e.	To carryout social activities and to serve the humanity by establishing yoga centers in every nook and corner of the country.<br />
f.	To pursue the Government and other Institutional authorities to promote Yoga education in all educational Institutes, schools and colleges; also to prove that yoga is the last resort for all evils of the society.<br />
g.	To publish Magazines, Newsletters and to conduct seminars, workshops to bring special knowledge based attention and interest about yoga and also to create a website to provide online consultation.<br />
h.	To educate people on the ancient traditions of Yoga and Naturopathy & to propagate the scientific aspects of the same.<br />
i.	To enable the learners through training on the applications of yoga and Naturopathy in everyday life.<br />
j.	State and National Level Yoga Conventions to propagate the message of Yoga.<br /><br />
A sincere and fervent appeal to join and strengthen hands of the group of yoga professionals is made to all associations and individuals to become members of the yoga professionals Association of India for the study and propagation of yoga on the scientific and traditional lines.

</p>
</div>

      </div>
      
	  
      
    </div>
  </div>
                    
                </div>
            </div>
        </div>
		
    <?php include("footer.php"); ?>
	
</body>
</html>
