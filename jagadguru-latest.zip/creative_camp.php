<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Jagad Guru Yoga Bharat Foundation</title>
    <link rel="stylesheet" href="yoga_style.css" />
     <link href="tab/style1.css" rel="stylesheet" type="text/css">
</head>

<body>

	<?php include("header1.php"); ?>

		<div class="main"  >
    	<div class="content_wrap">
            <div style="width:100%; height:30px;"></div>
            <div class="main_wrap"  >
                <div class="wrapper1">                	
     
    <div>
      <div class="tabpage" id="tabpage_1" style="text-align:left;padding-left:15px;">
  <h3>Creative Camp for Student's Future Enlightment</h3><br />
  <strong style="font-size:18px;">CHILDREN ARE THE FUTURE OF THE NATION</strong><br />
<br />
<p style="color:#333; font-size:13px;">
	Children are the future of the nation, they are the backbone of our nation, if we inculcate good values and virtues in them from a young age then we can certainly reach great heights. They should be taught about our rich culture, and we should teach them the harmful effects of addiction like alcohol, drugs, fast food, cold drinks and how the nation’s wealth can be conserved. If children are healthy, the nation will also be conserved. if children are healthy, the nation will also be healthy. <br />
<br />
Yogacharya Biswa Ranjan organizes special camps for children with this objective in mind, the presence of children in these camps has been between 25 thousand to 1.25 lakh in 100 camps organized at different places, which has given direct benefit to more than 50-60 thousand lakh children.<br />
<br />
We are confident that if children practice yoga along with their grandparents, then no body can stop India from getting back its status of the world mentor. Today several millions of children are learning yoga foromYogacharyaBiswaranjan. We are presenting a few pictures here to show the over whelming response from children. Yogacharys’ s efforts have inspired children towards patriotism, culture and balanced diet. They will definitely be able to control the temptation for junk food and cold drinks.<br />
<br />
<strong>Goals to be made through yoga for their Futur:e</strong><br />
<br />
1. 	Yoga for shaping children’s future(for class-I to Class-V students)<br />
	2. 	Personality Enhancement Program by Yoga(For Class-VI to Class-VIII)<br />
	3. 	Student Excellence Prgoram (Step) by Yoga(for Class-IX to Class-XII)<br />
	4. 	Yogic management Camp for Teens(Elgibility- 13 to 19 years approx.)<br />
	5. 	Personality Development program by Yoga(Eligibility-All non-technical graduate students)<br />
	6. 	Inner Engineering programme through Yoga  	(Techonologies for wellbeing)
		Eligibility - All Technical Graduate Students	<br />
	7. 	Yogic stress management program for students examination PHOBIA 
		Exam with smile program through Yoga (Parikhya De Haste Haste)<br />
	8. 	Student’s Memory Development Program By Yoga(SmrutiVardhakKarmasala)<br /> 
	9. 	Yoga Programforall student’s disease<br />
	10. 	Youth Leadership Training Program(YLTP)<br />
	11. 	Youth Empowerment Seminars (YES+) for college /university students Accelarating Excellence<br />
	12. 	De-addiction ProgrammeThrough Yoga<br />
	13. 	Vijay Hi Vijay (Youth Leadership Development Camp through Yoga)<br />
	14. 	VidyarambhaSanskar<br />
	15. 	DhoolKePhool Workshop through Yoga(for slum children/SarUtthakeJiyo)<br />
	16. 	Yoga &Celibicy Management<br />
	17. 	Youth Empowerment program through Yoga(Qualification with quality)
		MBA / Medical / Pharmacy / Physiotherapy / Postgraduate of any curriculum and Ph.D level<br />
	18. 	Balsanskar Kendra Teacher’s Certificate Course<br />
	19. 	Student UpliftmentProgramme by Yoga(Career with character)<br />
		For Diploma Engineering / ITI / Nursing / D-Pharma / DMLT /BBA/BCA<br />
	20.	Excel Teacher program through Yoga (Able Teacher Nation Leader)<br />
    </p>
     </div>
    </div>
  </div>
                    
                </div>
            </div>
        </div>
		
    <?php include("footer.php"); ?>
	
</body>
</html>
