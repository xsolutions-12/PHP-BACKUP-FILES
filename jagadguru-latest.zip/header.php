	<div class="bar">
		<div style="width:900px; margin:0px auto; text-align:left">
		<div  class="top_menu" style="float:left"><a href="index.php" style="color:#FFFF00;">Home</a> <a href="about.php" style="color:#FFFF00;">About Us</a> </div>
		<div style="width:300px; float:right; text-align:right; padding-top:3px; padding-right: 10px;"><a href="https://www.facebook.com/biswaranjan.rath.391"><img src="image/icon/f.png" alt="" width="28" height="28" border="0" /></a>&nbsp;&nbsp;<a href="https://x.com/DrBiswaranjanR1?t=4dpjeixngbCLxHd1EU1rng&s=08"><img src="image/icon/t.png" alt="" width="28" height="28" border="0" /></a>&nbsp;&nbsp;<a href="https://www.instagram.com/yogacharyadrbiswaranjan?igsh=cmV6eW9ncGVmdzdv"><img src="image/icon/i.png" alt="" width="28" height="28" border="0" /></a>&nbsp;&nbsp;<a href="https://www.youtube.com/@drbiswaranjanrath1316"><img src="image/icon/yt.png" alt="" width="28" height="28" border="0" /></a>&nbsp;&nbsp;<a href="#"><img src="image/icon/tl.png" alt="" width="28" height="28" border="0" /></a></div>
		</div>
    </div>
	
	<div id="welcome">
            
            <div id="popup">
				<div class="popup_bg">
            <!-- ANY CONTENTS -->
                <a href=""><img class="close_button" src="image/close.png"/></a>
                 <h3>Welcome To Our Website !</h3><br />
                <p>
				The whole world is in crisis. On the surface it appears as if humanity is moving towards selfdestruction with its weapons of mass destruction, terrorism, insatiable selfish desire and complete lack of sensitivity towards nature. However, a deeper perspective reveals another vision which can be compared to the labour pain of Mother Earth. A new Era is being born slowly and quietly behind the curtain of chaos and confusion. A new humanity is preparing to bring down heavenly atmosphere on this earth through leading of <strong>JagadGuru Bharat</strong>.<br /><br />
Swami Vivekananda after his historic parikrama of Bharat sat in Kanyakumari on 25-26-27 December 1892 and meditated on the past, present and future of Bharat. He realized and showed the way to National regeneration, organise people with ideals of Renunciation and service and vision of making <strong>Bharat JagadGuru</strong>.<br /><br />
So <strong>JagadGuru Yoga Bharat Foundation</strong>, Founded by <strong>Yogacharya Dr. Biswa Ranjan Rath</strong> is a registered public charitable Trust, volunteer run, International, Non-Government, Non-political, Non-religious, not-for profit, humanitarian, public service, social, educational and spiritual organisation which addresses all aspects of human wellbeing. The trust does not have any commercial or profit motives.<br /><br />
This is a patriotic & reformative and constructive revolution to bring holistic development of self, family and society. This is away from the boundaries of caste, creed or religion, economic or social status, age or gender, nationality, language, education and belief and provides a guideline to all to lead a better life. This is also believes in a proper blend of science and spirituality so that we can see the positive & constructive happenings all around.				</p>
				</div>
            </div>
	</div>

	<a href="Balsanskar.php"><div class="bsk"></div></a>
	
	<div class="spacer">
    	<div class="logo">
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="44%"><a href="index.php"><img src="image/logo.png" alt="Jagadguru Yoga Foundation" /></a></td>
    <td width="56%" align="right" valign="middle">
		<img src="images/arising.png" alt="" />	</td>
  </tr>
</table>

		
		</div>
	    <div class="nav">
		    <!--<div class="sf-menu">
                <ul>
                    <li><a href="index.php">home</a></li>
                    <li><a href="about.php">about us</a></li>
                    <li><a href="youth.php">youth & yoga</a></li>
                    <li><a href="gallery.php">gallery</a></li>
                    <li><a href="contact.php">contact us</a></li>
                </ul>
        	</div> -->
			<div class="menu">
			 <a href="youth.php">Youth & Yoga</a>        <a href="DevSanskriti.php">Devsanskriti Yoga Vidyalaya</a>         <a href="Yoga_professionals.php">Yoga Professionals Association of Odisha</a>        <a href="course_structure.php">Yoga Course Structure</a>        <a href="creative_camp.php">Creative Camp for Students</a>         <a href="gallery.php">Gallery</a> 
			</div>
		</div>
    </div>