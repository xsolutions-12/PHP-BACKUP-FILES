<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Jagad Guru Yoga Bharat Foundation</title>
    <link rel="stylesheet" href="yoga_style.css" />
   <link rel="stylesheet" href="gallery/lightbox.css" type="text/css" media="screen" />
	<script type="text/javascript" src="gallery/prototype.js"></script>
	<script type="text/javascript" src="gallery/scriptaculous.js?load=effects"></script>
	<script type="text/javascript" src="gallery/lightbox.js"></script>
</head>

<body>

	<?php include("header1.php"); ?>

	<div class="main"  >
			<div class="content_wrap">
				<div style="width:100%; height:30px;"></div>
				<div class="main_wrap"  >
					 <div class="wrapper1" style="padding:30px 30px;">             	
							 <h3>Press meet on Statute of Unity with Cabinet Minister of Gujurat</h3>
							 <div class="galry" >
							   <a href="gallery/big/press.jpg" title="press meet on statute of unity with cabinet minister of gujurat" rel="lightbox[Brussels199]"><img src="gallery/thumb/pressmeet.jpg" /></a>
								 
							 </div>
							 <h3>Arogya Fair 2012 Bhubaneswar</h3>
							 <div class="galry" >
							   <a href="gallery/big/arogya1.JPG" title="Arogya Fair 2012 Bhubaneswar" rel="lightbox[Brussels1]"><img src="gallery/thumb/arogya1.jpg" /></a>
								<a href="gallery/big/arogya2.JPG" title="Arogya Fair 2012 Bhubaneswar" rel="lightbox[Brussels1]"><img src="gallery/thumb/arogya2.jpg" /></a>
								<a href="gallery/big/Yoga_Exhibition.JPG" title="Arogya Fair 2012 Bhubaneswar" rel="lightbox[Brussels1]"><img src="gallery/thumb/Yoga_Exhibition.jpg" /></a>
							 </div>
							  <h3>Bharatiya Yoga Sansthan Annual Meeting 2012 Utkal University Bhubaneswar</h3> 
							 <div class="galry">
							   <a href="gallery/big/ysansthan1.jpg" title="" rel="lightbox[Brussels]"><img src="gallery/thumb/ysansthan1.jpg" /></a>
		  <a href="gallery/big/ysansthan2.jpg" title="" rel="lightbox[Brussels]"><img src="gallery/thumb/ysansthan2.jpg" /></a>
          <a href="gallery/big/bharatya.jpg" title="" rel="lightbox[Brussels]"><img src="gallery/thumb/bharatya.jpg" /></a>
							 </div>
							  <h3>Biswa Odia Samaj Sammilani 2013 Janata Maidan, Bhubaneswar</h3>
							 <div class="galry">
								<a href="gallery/big/bodiasamaj1.jpg" title="" rel="lightbox[Brussels2]"><img src="gallery/thumb/bodiasamaj1.jpg" /></a>
		<a href="gallery/big/bodiasamaj2.jpg" title="" rel="lightbox[Brussels2]"><img src="gallery/thumb/bodiasamaj2.jpg" /></a>
							 </div>                       
							 <h3>CHSE Yoga Orientation Camp Odisha</h3> 
	 
							 <div class="galry">
								<a href="gallery/big/chse1.jpg" title="" rel="lightbox[Brussels3]"><img src="gallery/thumb/chse1.jpg" /></a>
		 
		<a href="gallery/big/chse2.jpg" title="" rel="lightbox[Brussels3]"><img src="gallery/thumb/chse2.jpg" /></a>
		<a href="gallery/big/chse3.jpg" title="" rel="lightbox[Brussels3]"><img src="gallery/thumb/chse3.jpg" /></a>
		 
							 </div>
							  <h3>Yoga for children</h3>
							 <div class="galry" >
								<a href="gallery/big/chdn1.jpg" title="" rel="lightbox[Brussels4]"><img src="gallery/thumb/chdn1.jpg" /></a>
		<a href="gallery/big/chdn2.jpg" title="" rel="lightbox[Brussels4]"><img src="gallery/thumb/chdn2.jpg" /></a>
		<a href="gallery/big/chdn3.jpg" title="" rel="lightbox[Brussels4]"><img src="gallery/thumb/chdn3.jpg" /></a>
		<a href="gallery/big/chdn4.jpg" title="" rel="lightbox[Brussels4]"><img src="gallery/thumb/chdn4.jpg" /></a>
		<a href="gallery/big/chdn5.jpg" title="" rel="lightbox[Brussels4]"><img src="gallery/thumb/chdn5.jpg" /></a>
		 <a href="gallery/big/chdn6.jpg" title="" rel="lightbox[Brussels4]"><img src="gallery/thumb/chdn6.jpg" /></a>
		<a href="gallery/big/chdn7.jpg" title="" rel="lightbox[Brussels4]"><img src="gallery/thumb/chdn7.jpg" /></a>
		<a href="gallery/big/chdn8.jpg" title="" rel="lightbox[Brussels4]"><img src="gallery/thumb/chdn8.jpg" /></a>
        <a href="gallery/big/bachpan.jpg" title="" rel="lightbox[Brussels4]"><img src="gallery/thumb/bachpan.jpg" /></a>
        <a href="gallery/big/children.jpg" title="" rel="lightbox[Brussels4]"><img src="gallery/thumb/children.jpg" /></a>
        <a href="gallery/big/children1.jpg" title="" rel="lightbox[Brussels4]"><img src="gallery/thumb/children1.jpg" /></a>
        <a href="gallery/big/yoga_with_children.jpg" title="" rel="lightbox[Brussels4]"><img src="gallery/thumb/yoga_with_children.jpg" /></a>
							 </div>
							 
							  <h3>Yoga for Engineering and Management</h3>
							 <div class="galry" >
								<a href="gallery/big/eng_mngnt1.jpg" title="" rel="lightbox[Brussels6]"><img src="gallery/thumb/eng_mngnt.jpg" /></a>
		<a href="gallery/big/eng_mngnt2.JPG" title="" rel="lightbox[Brussels6]"><img src="gallery/thumb/eng_mngnt2.jpg" /></a>
		<a href="gallery/big/eng_mngnt3.JPG" title="" rel="lightbox[Brussels6]"><img src="gallery/thumb/eng_mngnt3.jpg" /></a>
		<a href="gallery/big/eng_mngnt4.JPG" title="" rel="lightbox[Brussels6]"><img src="gallery/thumb/eng_mngnt4.jpg" /></a>
		<a href="gallery/big/eng_mngnt5.JPG" title="" rel="lightbox[Brussels6]"><img src="gallery/thumb/eng_mngnt5.jpg" /></a>
		<a href="gallery/big/eng_mngnt6.JPG" title="" rel="lightbox[Brussels6]"><img src="gallery/thumb/eng_mngnt6.jpg" /></a>
		<a href="gallery/big/eng_mngnt7.JPG" title="" rel="lightbox[Brussels6]"><img src="gallery/thumb/eng_mngnt7.jpg" /></a>
							 </div>
							  <h3>Yoga in Bal Sanskar Kendra</h3> 
							 <div class="galry">
		<a href="gallery/big/balsanskar1.jpg" title="" rel="lightbox[Brussels7]"><img src="gallery/thumb/balsanskar1.jpg" /></a>
		<a href="gallery/big/balsanskar2.jpg" title="" rel="lightbox[Brussels7]"><img src="gallery/thumb/balsanskar2.jpg" /></a>
		<a href="gallery/big/balsanskar3.jpg" title="" rel="lightbox[Brussels7]"><img src="gallery/thumb/balsanskar3.jpg" /></a>
		 <a href="gallery/big/balsanskar4.jpg" title="" rel="lightbox[Brussels7]"><img src="gallery/thumb/balsanskar4.jpg" /></a>
		<a href="gallery/big/balsanskar5.jpg" title="" rel="lightbox[Brussels7]"><img src="gallery/thumb/balsanskar5.jpg" /></a>
		<a href="gallery/big/balsanskar6.jpg" title="" rel="lightbox[Brussels7]"><img src="gallery/thumb/balsanskar6.jpg" /></a>
							 </div>
							  <h3>Yoga in Boys Hostel</h3>
							 <div class="galry" >
				<a href="gallery/big/b_hostel1.jpg" title="" rel="lightbox[Brussels8]"><img src="gallery/thumb/b_hostel1.jpg" /></a>
				<a href="gallery/big/b_hostel2.jpg" title="" rel="lightbox[Brussels8]"><img src="gallery/thumb/b_hostel2.jpg" /></a>
				<a href="gallery/big/b_hostel3.jpg" title="" rel="lightbox[Brussels8]"><img src="gallery/thumb/b_hostel3.jpg" /></a>
				<a href="gallery/big/b_hostel4.jpg" title="" rel="lightbox[Brussels8]"><img src="gallery/thumb/b_hostel4.jpg" /></a>
							 </div>
							  <h3>Yoga in Corporate Sector</h3> 
							 <div class="galry">
						  <a href="gallery/big/crprt1.jpg" title="" rel="lightbox[Brussels9]"><img src="gallery/thumb/crprt1.jpg" /></a>
		<a href="gallery/big/crprt2.jpg" title="" rel="lightbox[Brussels9]"><img src="gallery/thumb/crprt2.jpg" /></a>
		<a href="gallery/big/crprt3.jpg" title="" rel="lightbox[Brussels9]"><img src="gallery/thumb/crprt3.jpg" /></a><a href="gallery/big/crprt4.jpg" title="" rel="lightbox[Brussels9]"><img src="gallery/thumb/crprt4.jpg" /></a>
							 </div>
							 
							 <h3>Yoga in Cultural Events</h3> 
	 
							 <div class="galry">
				   <a href="gallery/big/cultural1.jpg" title="" rel="lightbox[Brussels10]"><img src="gallery/thumb/cultural1.jpg" /></a>
		 <a href="gallery/big/cultural2.jpg" title="" rel="lightbox[Brussels10]"><img src="gallery/thumb/cultural2.jpg" /></a>
		  <a href="gallery/big/cultural3.jpg" title="" rel="lightbox[Brussels10]"><img src="gallery/thumb/cultural3.jpg" /></a> 
		  <a href="gallery/big/cultural4.jpg" title="" rel="lightbox[Brussels10]"><img src="gallery/thumb/cultural4.jpg" /></a> 
		  <a href="gallery/big/cultural5.jpg" title="" rel="lightbox[Brussels10]"><img src="gallery/thumb/cultural5.jpg" /></a>
          <a href="gallery/big/yoga_award.jpg" title="" rel="lightbox[Brussels10]"><img src="gallery/thumb/yoga_award.jpg" /></a>
          <a href="gallery/big/yoga_award1.jpg" title="" rel="lightbox[Brussels10]"><img src="gallery/thumb/yoga_award1.jpg" /></a>
          <a href="gallery/big/yoga_award2.jpg" title="" rel="lightbox[Brussels10]"><img src="gallery/thumb/yoga_award2.jpg" /></a>
          <a href="gallery/big/yoga_with_foreigners.jpg" title="" rel="lightbox[Brussels10]"><img src="gallery/thumb/yoga_with_foreigners.jpg" /></a>
          <a href="gallery/big/yoga_with_foreigners1.jpg" title="" rel="lightbox[Brussels10]"><img src="gallery/thumb/yoga_with_foreigners1.jpg" /></a>
							 </div>
							  <h3>Yoga in Girls Hostel</h3>
							 <div class="galry" >
			  <a href="gallery/big/g_hostel1.jpg" title="" rel="lightbox[Brussels11]"><img src="gallery/thumb/g_hostel1.jpg" /></a>
		<a href="gallery/big/g_hostel2.jpg" title="" rel="lightbox[Brussels11]"><img src="gallery/thumb/g_hostel2.jpg" /></a>
							 </div>
							  <h3>Yoga in Junior College</h3> 
							 <div class="galry">
				  <a href="gallery/big/j_college1.jpg" title="" rel="lightbox[Brussels12]"><img src="gallery/thumb/j_college1.jpg" /></a>
		<a href="gallery/big/j_college2.jpg" title="" rel="lightbox[Brussels12]"><img src="gallery/thumb/j_college2.jpg" /></a>
		<a href="gallery/big/j_college3.jpg" title="" rel="lightbox[Brussels12]"><img src="gallery/thumb/j_college3.jpg" /></a>
		<a href="gallery/big/j_college4.jpg" title="" rel="lightbox[Brussels12]"><img src="gallery/thumb/j_college4.jpg" /></a>
		
							 </div>
							  <h3>Yoga in Orphan Age</h3>
							 <div class="galry" >
					   <a href="gallery/big/orphan1.jpg" title="" rel="lightbox[Brussels13]"><img src="gallery/thumb/orphan1.jpg" /></a>
		 <a href="gallery/big/orphan2.jpg" title="" rel="lightbox[Brussels13]"><img src="gallery/thumb/orphan2.jpg" /></a>
		  <a href="gallery/big/orphan3.jpg" title="" rel="lightbox[Brussels13]"><img src="gallery/thumb/orphan3.jpg" /></a>
							 </div> 
								 <h3>Yoga in School</h3> 
							 <div class="galry">
					<a href="gallery/big/school1.jpg" title="" rel="lightbox[Brussels5]"><img src="gallery/thumb/school1.jpg" /></a>
		<a href="gallery/big/school2.jpg" title="" rel="lightbox[Brussels5]"><img src="gallery/thumb/school2.jpg" /></a>
		<a href="gallery/big/school3.jpg" title="" rel="lightbox[Brussels5]"><img src="gallery/thumb/school3.jpg" /></a>
		<a href="gallery/big/school4.jpg" title="" rel="lightbox[Brussels5]"><img src="gallery/thumb/school4.jpg" /></a>
		<a href="gallery/big/school5.jpg" title="" rel="lightbox[Brussels5]"><img src="gallery/thumb/school5.jpg" /></a>
		<a href="gallery/big/school6.jpg" title="" rel="lightbox[Brussels5]"><img src="gallery/thumb/school6.jpg" /></a>
		<a href="gallery/big/school7.jpg" title="" rel="lightbox[Brussels5]"><img src="gallery/thumb/school7.jpg" /></a>
		<a href="gallery/big/school8.jpg" title="" rel="lightbox[Brussels5]"><img src="gallery/thumb/school8.jpg" /></a>
		<a href="gallery/big/school9.jpg" title="" rel="lightbox[Brussels5]"><img src="gallery/thumb/school9.jpg" /></a>
		<a href="gallery/big/school10.jpg" title="" rel="lightbox[Brussels5]"><img src="gallery/thumb/school10.jpg" /></a>
		
							 </div>
							 
							 
							 <h3>Yoga in University</h3>
							 <div class="galry" >
			   <a href="gallery/big/university1.jpg" title="" rel="lightbox[Brussels14]"><img src="gallery/thumb/university1.jpg" /></a>
		 <a href="gallery/big/university2.jpg" title="" rel="lightbox[Brussels14]"><img src="gallery/thumb/university2.jpg" /></a>
		 <a href="gallery/big/university3.jpg" title="" rel="lightbox[Brussels14]"><img src="gallery/thumb/university3.jpg" /></a>
		 <a href="gallery/big/university4.jpg" title="" rel="lightbox[Brussels14]"><img src="gallery/thumb/university4.jpg" /></a>
		 <a href="gallery/big/university5.jpg" title="" rel="lightbox[Brussels14]"><img src="gallery/thumb/university5.jpg" /></a>
		 <a href="gallery/big/university6.jpg" title="" rel="lightbox[Brussels14]"><img src="gallery/thumb/university6.jpg" /></a>
		 <a href="gallery/big/university7.jpg" title="" rel="lightbox[Brussels14]"><img src="gallery/thumb/university7.jpg" /></a>
		 <a href="gallery/big/university8.jpg" title="" rel="lightbox[Brussels14]"><img src="gallery/thumb/university8.jpg" /></a>
		 <a href="gallery/big/university9.jpg" title="" rel="lightbox[Brussels14]"><img src="gallery/thumb/university9.jpg" /></a>
		 <a href="gallery/big/university10.jpg" title="" rel="lightbox[Brussels14]"><img src="gallery/thumb/university10.jpg" /></a>
		 <a href="gallery/big/university11.jpg" title="" rel="lightbox[Brussels14]"><img src="gallery/thumb/university11.jpg" /></a> 
		 <a href="gallery/big/university12.jpg" title="" rel="lightbox[Brussels14]"><img src="gallery/thumb/university12.jpg" /></a>
		 <a href="gallery/big/university13.jpg" title="" rel="lightbox[Brussels14]"><img src="gallery/thumb/university13.jpg" /></a>
		 <a href="gallery/big/university14.jpg" title="" rel="lightbox[Brussels14]"><img src="gallery/thumb/university14.jpg" /></a>
							 </div>
							 
							 <h3>Yoga in Missionary School</h3>
							 <div class="galry" >
					<a href="gallery/big/missionary.jpg" title="" rel="lightbox[Brussels15]"><img src="gallery/thumb/missionary.jpg" /></a>
		 
							 </div>
							 
							 <h3>Yoga Sarathi</h3>
							 <div class="galry" >
					   <a href="gallery/big/sarathi1.jpg" title="" rel="lightbox[Brussels16]"><img src="gallery/thumb/sarathi1.jpg" /></a>
		<a href="gallery/big/sarathi2.jpg" title="" rel="lightbox[Brussels16]"><img src="gallery/thumb/sarathi2.jpg" /></a>
							 </div> 
							 
							 <h3>Yoga Teacher's Training Programme</h3>
							 <div class="galry" >
					   <a href="gallery/big/teachers1.jpg" title="" rel="lightbox[Brussels17]"><img src="gallery/thumb/teachers1.jpg" /></a>
		 <a href="gallery/big/teachers2.jpg" title="" rel="lightbox[Brussels17]"><img src="gallery/thumb/teachers2.jpg" /></a>
							 </div>
						 
					</div>
				</div>
			</div>
		</div>
		
    <?php include("footer.php"); ?>
	
</body>
</html>
