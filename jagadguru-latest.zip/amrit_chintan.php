<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Jagad Guru Yoga Bharat Foundation</title>
    <link rel="stylesheet" href="yoga_style.css" />
     <link href="tab/style1.css" rel="stylesheet" type="text/css">
</head>

<body>

	<?php include("header1.php"); ?>

		<div class="main"  >
    	<div class="content_wrap">
            <div style="width:100%; height:30px;"></div>
            <div class="main_wrap"  >
                <div class="wrapper1">                	
     
    <div>
      <div class="tabpage" id="tabpage_1" style="text-align:left;padding-left:15px;">
  <h3>AMRIT CHINTAN</h3><br />
  <strong style="font-size:18px;">Thoughts by Pandit Shri Ram Sharma Acharya</strong><br />
<br />
<p style="color:#333; font-size:13px;">
01.	Self realization is the best service in the world.<br />		
02.	“Teachers are the Epoch Builders, Students are the Builders of Nations Destiny.”<br />
03.	No price is too high to make yourself a better person. He alone is wise who knows how to repair the broken and heal the wounded. Those who have achieved harmony in their thoughts, words and actions attain true awakening.<br />
04.	“Self-refinement is the best service of the society.”<br />
05.	Education is not preparation for life, Education is life itself.<br />
06.	The only worthwhile precept is one that is practiced.<br />
07.	He alone is a true warrior who maintains his integrity, courage, and patience in adversity.<br />
08.	Don’t indulge in self-praise. Your good deeds will speak for themselves.<br />
09.	Time is the most precious gift of life. If you love life, do not squander it in indolence.<br />
10.	As worm eats up the cloth, so does jealousy a human being.<br />
11.	He alone lives a worthwhile life, who has a cool head, warm blood a loving heart, and zest for life.<br />
12.	Failure indicates half-hearted effort towards success.<br />
13.	Study of inspiring books is like communion with living deities; it gives instant gifts of light and bliss.<br />
14.	Sin always comes with four accomplices-decline, disgrace, distress and disease.<br />
15.	There are two ways to be happy: minimize your needs; and live in harmony with the circumstances.<br />
16.	An aimless person is like the pendulum which merely swings to and fro without any forward movement.<br />
17.	Not riches, but nobility of character and honesty are the true touchstones of greatness.<br />
18.	One becomes what one thinks and does.<br />
19.	A noble person is humble like the poor in riches & prosperity; and generous like the rich in adversity.<br />
20.	End of vanity is the beginning of nobility.<br />
21.	If the elders practice what they preach to their children, this world will become a heaven.<br />
22.	A family knit together, by bonds of loving cooperation and mutual understanding, is a living model of heaven on earth.<br />
23.	Scriptures and holy books are like teachers who impart life-transforming teachings without caning or admonition.<br />
24.	The fragrance of flowers spreads only in the direction of the wind; the reputation of a noble person spreads in all directions.<br />
25.	To be born in human form is effortless; to be a human being needs persistent effort.<br />
26.	Prosperity is not attained by earning money, but by building good character and purity of thoughts.<br />
27.	Do not treat the people, the way you would not like people to treat you.<br />
28.	Man is the master of his own destiny. If one can change his thinking process, he or she can control the circumstances.<br />
29.	If man begins to reform himself, he can reform the world very well.<br />
30.	Our mind is a fertile field. You can produce whatever you like by doing right. Use it properly- As you sow, so you reap.<br />
31.	If wealth is lost, nothing is lost. If health is lost, something is lost. If character is lost, everything is lost.<br />
32.	Make your thoughts sublime and auspicious. Refine & purify them. They will take you to the supreme bliss of heaven.<br />
33.	Try to be humane. If you succeed in it, you will succeed everywhere.<br />
34.	God has given eyes, ears, hands, feet and nostrils in pairs, but tongue is only one. Therefore, speak less and do more.<br />
35.	Do not expect the circumstances to be always favorable. This world has not been created for you alone.<br />
36.	If you wish to gift something to someone, then give the best gift of encouragement that can awaken one’s self confidence.<br />
37.	To see the change, be the change.<br />
38.	Refining one is the greatest service to humanity.<br /><br />
  <strong style="font-size:18px;">Swami Vivekananda Inspiration</strong><br />
<br />
39.	Truth is indestructible,
	Virtue is indestructible,
	Purity is indestructible.<br />

40.	Religion is the manifestation of the divinity already in man.<br />

41.	When there comes affliction in heart,
	When the storm of sorrow blows all around,
	And it seems light will be seen no more,
	When hope and courage are almost gone, it is then,
	In the midst of this great spiritual tempest,
	That the light of brahman within gleams.<br />

42.	My idea of education is
	Personal contact with the teacher…
	Gurugriha-vasa. Without the personal life
	Of a teacher there would be no education.<br />

43.	When death is so certain,
	It is better to die for a good cause.<br />

44.	One ounce of practice is worth
	Twenty thousand tons of big talk.<br />

45.	Strength, strength is what the Upanishads
	Speak to me from every page.
	This is the one great thing to remember,
	It has been the one great lesson
	I have been taught in my life.<br />

46.	Unselfishness is God.<br />

47.	No man should be judged by his defects.<br />

48.	If you think yourselves impure,
	Impure you will be. If you think yourselves pure,
	Pure you will be. This teaches us.
	Not to think ourselves as weak,
	But as strong, omnipotent, omniscient.<br />

49.	All expansion is life,
	all contraction is death.<br />

50.	You cannot believe in God
	Until you believe in yourself.<br />

51.	Everything is fraught with fear;
	Renunciation alone is fearless.<br />

52.	My child, what I want is muscles of iron
	And nerves of steel, inside which dwells
	A mind of the same material as that of which
	The thunderbolt is made.<br />

53.	Divine wisdom is to be got by
	Devotion, meditation and chasity.<br />

54.	Neither numbers nor powers nor wealth
	Nor learning nor eloquence nor anything else
	Will prevail, but purity, living the life,
	In one word, anubhuti, realization.<br />

55.	Education is not the amount of information
	That is put into your brain and runs riot there,
	Undigested, all your life. We must have 
life-building, man-making, character-making
assimilation of ideas.<br />

56.	I hate only one thing in the world-hypocrisy.<br />

57.	Men, men, these are wanted:
	Everything else will be ready,
	But strong, vigorous, believing young men,
	Sincere to the backbone are wanted.<br />

58.	Every duty is holy and devotion to duty 
is the highest form of worship of god.<br />

59.	As you have come into this world,
	Leave some mark behind. Otherwise,
	Where is the difference between you
	And the trees and stones? They,
	Too come into existence, decay and die.<br />

60.	Bear in mind, my children, that only cowards
	And those who are weak commit sin and tell lies.
	The brave are always moral, Try to be moral,
	Try to be brave, try to be sympathising.<br />

61.	Wealth goes, beauty vanishes, life flies,
	Powers fly-but the lord abidethfor ever,
	Love abidethfor ever.<br />

62.	Him I call a mahatman (great soul)
	Whose heart bleeds for the poor,
	Otherwise he is a duratman (wicked soul).<br />

63.	The calmer we are and
	the less disturbed our nerves,
	the more shall we love and
	the better will our work be.<br />

64.	It is better to wear out than to rust out…
	Specially for the sake of doing
	the least good to others.<br />

65.	Hate not the most object sinner,
	Look not to his exterior.
	Turn thy gaze inward,
	Where resides the paramatman.<br />

66.	Test everything, try everything,
	And then believe it,
	And if you find it for the good of many,
	Give it to all.<br />


67.	Religions of the world have become
	Lifeless mockeries. What the world wants is character.
	The world is in need of those whose life is
	One burning love, selfless. That love
	Will make every word tell like thunderbolt.<br />

68.	There is no sin nor virtue,
	There is only ignorance.
	By realization of non-duality
	This ignorance is dispelled.<br />

69.	The moment I have realized god sitting
	In the temple of every human body,
	The moment I stand in reverence
	Before every human being and see god in him
	That moment I am free from bondage.<br />

70.	Work, work the idea, the plan, my boys,
	My brave, noble, good souls – to the wheel,
	To the wheel put your shoulders !
	Stop not to look back for name,
	Or fame, or any such nonsense.<br />

71.	The knowledge of god is the highest knowledge,
	And knowing god alone we can know man.<br />

72.	Religion is the idea which is raising
	The brute unto man and man unto god.<br />

73.	I do not believe in any politics.
	God and truth are the only politics in the world,
	Everything else is trash.<br />

74.	And the only religion that ought to be taught
	Is the religion of fearlessness.
	Either in this world or in the world of religion,
	It is true that fear is the sure cause of
	Degradation and sin.<br />

75.	Men, men, these are wanted: everything else
	Will be ready, but strong, vigorous, believing
	Youngmen, sincere to the backbone,
	Are wanted. A hundred such and the world becomes revolutionized.<br />

76.	The whole secret of existence is to have no fear.
	Never fear what will become of you,
	Depend on no one. Only the moment you reject
	All help are you free.<br />


77.	Every step that has been really gained
	In the world has been gained by love;
	Criticizing can never do any good,
	It has been tried for thousands of years.<br />

78.	The greater a man has become,
	The fiercer or deal he has had to pass through.<br />

79.	But mark you, if you give up that spirituality,
	Leaving it aside to go after the
	Materializing civilization of the west,
	The result will be that in three generations
	You will be an extinct race.<br />

80.	Know that all sins and all evils can be
	Summed up in that one word, weakness.<br />

81.	Physical weakness is the cause of at least
	One-third of our miseries.<br />

82.	So long as the millions live in hunger
	And ignorance, I hold every man a traitor who,
	Having been educated at their expense,
	Pays not the least heed to them.<br />

83.	We have wept long enough,
	No more weeping, but stand on your feet and be men.<br />

84.	Krishna did everything but
	Without any attachment; he was in the world,
	But not of it. “Do all work but without attachment;
	Work for work’s sake, never for yourself.”<br />

85.	The best thermometer to the progress
	Of a nation is its treatment of its women.<br />

86.	I think I can !
	I know I can !
	Positive thinking is half the work…<br />

87.	First steps to SUCCESS
	Is daring to BEGIN.<br />

88.	BORN TO LEAD :
	“If your actions inspire others
	To dream more, learn more, do more and become more
	You are a Leader.<br />


89.	Throughout the history of mankind,
	If any motive power has been more potent
	Than another in the lives of all great men
	And women, it is that of faith in themselves.<br />

90.	A man who can work for five days, or even for
	Five minutes, without any selfish motive whatever,
	Without thinking of future, of heaven, of punishment,
	Or anything of the kind, has in him the capacity to
	Become a powerful moral giant.<br />

91.	Do not show me sights.
	I have seen the Himalayas !
	I would not go ten steps to see sights;
	But I would go a thousand miles to see a 
	[great] human being!<br />

92.	The universe is ours to enjoy.
	But want nothing. To want is weakness.
	Want makes us beggars, and we are sons of
	The king, not beggars.<br />

93.	The gita is like a bouquet composed of
	Beautiful flowers of spiritual truths collected From the Upanishads.<br />

94.	True religion comes not from the teaching
	Of men or the reading of books;
	It is the awakening of the spirit within us,
	Consequent upon-pure and heroic action.<br />

95.	O India !forget not that thy marriage thy wealth,
	Thy life are not for sense-pleasure,
	Are not for thy individual personal happiness.<br />

96.	Great work requires great and
	Persistent effort for a long time.
	Neither need we trouble ourselves if a few fail.<br />

97.	All power is within you;
	You can do anything and everything.
	Believe in that, do not believe that you are weak.
	Stand up and express the divinity with in you.<br />

98.	Break your chain and be free for ever.
	What frightens you, what holds you down?
	Only ignorance and delusion;
	Nothing else can bind you.
	You are the pure one, the ever-blessed.<br />


99.	Will sin cure sin, weakness cure weakness;
	Strength, o man, strength. Say the Upanishads,
	Stand up and be strong.<br />

100.	Arise and awake and see her seated here
	On her eternal throne, rejuvenated,
	More glorious than she ever was
	This motherland of ours.<br />
101.	The history of the world is the history of
	A few men who had faith in themselves.
	That faith calls out the divinity within.
	You can do anything.<br />

102.	One may gain political and
	Social independence, but if one is a slave
	To his passions and desires, one cannot feel
	The pure joy of real freedom.<br />

103.	None but the brave deserves the fair
	None but the bravest deserves salvation.<br />

104.	He who knows how to obey
	Knows how to command.
	Learn obedience first.<br />

105.	First you have to build the body
	By good nutritious food – then only
	Will the mind be strong.
	The mind is but the subtle part of body.<br />

106.	The great secret of true success,
	Of true happiness. Then, is this;
	The man who asks for no return,
	The perfectly unselfish man,
	Is the most successful.<br />

107.	The first sign that you are becoming religious
	Is that you are becoming cheerful.<br />

108.	Go on loving. If a man is angry,
	There is no reason why you should be angry;
	If he degrades himself, that is no reason
	Why you should degrade yourself.<br />

109.	Hold your money merely as custodian
	For what is God’s. Have no attachment for it.<br />

110.	Obedience to the guru without questioning,
	And strict observance of brahmacharya…..	This is the secret of success.<br />
    
111.	Knowledge was the finding of unity indiversity,
	And the highest point in every science was
	Reached when it found the one unity
	Underlying all variety.<br />

112.	One of the greatest lessons I have learnt
	In my life is to pay as much attention
	To the means of work as to its end.<br />

113.	With the manifestation of the Atman
	You will find that science, philosophy,
	And everything will be easily mastered.<br />

114.	What we want is neither happiness nor misery.
	Both make us forget our true nature;
	Both are chains-one iron, one gold.<br />

115.	Everybody must be trained to practice
	Absolute brahmacharya, and then,
	And then only, faith – shraddha – will come.<br />

116.	The internal universe, the real,
	Is infinitely greater than the external,
	Which is only a shadowy projection of the true one.
	This world is neither true nor untrue,
	It is shadow of truth.<br />

117.	If there is one word that you find
	Coming out like a bomb from the Upanishads,
	Bursting like a bomb-shell upon masses of ignorance, it is the word fearlessness.<br />

118.	Each thought is a little hammer blow
	On the lump of iron which our bodies are,
	Manufacturing out of it what we want it to be.<br />

119.	If you cannot attain salvation in this life,
	What proof is there that you can attain it
	In the life or lives to come ?<br />

120.	My hope is in you. Will you respond
	To the call of your nation? Each one of you
	Has a glorious future if you dare believe me.<br />

121.	Anything that makes you weak physically,
	Intellectually and spiritually, reject as posion;
	There is no life in it, it cannot be true.<br />

122.	If one has to attend day and night
	To what this man says or that man writes,
	No great work is achieved in this world.<br />

123.	The old religions said that he was an atheist
	Who did not believe in God.
	The new religion says that he is the atheist
	Who does not believe in himself.<br />

124.	Everything that makes for oneness is truth.
	Love is truth, and hatred is false,
	Because hatred makes for multiplicity.<br />

125.	The will is stronger than anything else.
	Everything must go down before the will,
	For that comes from god and god himself;
	A pure and a strong will is omnipotent.<br />

126.	The essential thing in religion is making the heart pure,
	The kingdom of heaven is within us, but only the pure
	In heart can see the king.<br />

127.	Throughout the history of mankind, if any
	Motive power has been more potent than
	Another in the lives of all great men and women,
	It is that of faith in themselves. Born with
	The consciousness that they were to be great,
	They became great.<br />

128.	The higher the moral nature. The higher
	The perception and the stronger the will.<br />

129.	Do not lose heart, do not lose faith in your guru.
	Do not lose faith in God. So long as you possess these three,
	Nothing can harm you, my child.<br />

130.	The knowledge of brahman is
	The ultimate goal – the highest destiny of man.<br />

131.	Everything must be sacrificed, if necessary,
	For that one sentiment, universality.<br />

132.	Whatever is weak, avoid !it is death.
	If it is strength, go down into hell
	And get hold of it!
	There is salvation only for the brave.<br />

133.	Everything can be sacrificed for truth,
	But truth cannot be sacrificed for anything.<br />

134.	Are great things ever done smoothly?
	Time, patience, and indomitable will must show.<br />

135.	My son, I believe in God, and I believe in man,
	I believe in helping the miserable.
	I believe in going even to hell to save others.<br />

136.	The remedy for weakness is not brooding
	Over weakness, but thinking of strength.
	Teach men of the strength
	That is already within them.<br />

137.	No religion for you, my children,
	But morality and bravery. No cowardice,
	No sin. No crime, no weakness
	-The rest will come of itself.<br />

138.	There is that infinite soul,
	Assuring the infinite possibility
	And the infinite capacity of
	All to become great and good.<br />

139.	If it is impossible to attain perfection here
	And now, there is no proof that we can attain
	Perfection in any other life.<br />

140.	The poor, the illiterate, the ignorant,
	The afflicted – let these be your God.
	Know that service to these alone
	Is the highest religion.<br />

141.	The world is ready to give up its secrets
	If we only know how to knock, how to give it
	The necessary blow. The strength and force
	Of the blow come through concentration.<br />

142.	Great things can be done by great sacrifices only.
	No selfishness, no name, no fame,
	Yours or mine, nor my master’s even !<br />

143.	Each soul is potentially divine.
	The goal is to manifest this divinity within
	By controlling nature, external and internal.<br />

144.	We want that education by which
	Character is formed. Strength of mind is increased
	The intellect is expanded, and by which
	One can stand on one’s own feet.<br />

145.	Who makes us ignorant ?We ourselves.
	We put our hands over our eyes
	And weep that it is dark.<br />
    
146.	The soul is infinite, ornmipotent,
	And omniscient, stand up, assert yourself,
	Proclaim the God within you, do not deny Him !<br />

147.	A hundred thousand men and women,
	Fired with the zeal of holiness, fortified with
	Eternal faith in the lord, and nerved to
	Lion’s courage by their sympathy for the poor
	And the fallen and the downtrodden,
	Will go over the length and breadth of the land,
	Preaching the gospel of salvation,
	The gospel of help, the gospel of social raising up
	The gospel of equality.<br />

148.	The secret of life is not enjoyment
	But education through experience.<br />

149.	Faith, faith, faith in ourselves,
	Faith, faith in God…
	This is the secret of greatness.<br />

150.	It is life to do good, it is death not to do good to others.<br />

151.	The unselfish man says, “I will be last,
	I do not care to go to heaven,
	I will even go to hell if by doing so
	I can help any brothers.”
	This unselfishness is the test of religion.<br />

152.	All knowledge that the world has ever received
	Comes from the mind; the infinite library
	Of the universe is in your own mind.<br />

153.	It is the patient upbuilding of character,
	The intense struggle to realize the truth,
	Which alone will tell in the future of humanity.<br />

154.	Knowledge can only be got in one way,
	The way of experience;
	There is no other way to know.<br />

155.	What we want is muscles of iron and
	Nerves of steel. We have wept long enough.
	No more weeping, but stands on
	Your feet and be men.<br />

156.	The world is a grand moral gymnasium
	Wherein we have all to take exercise so as to
	Become stronger and stronger spiritually.<br />

157.	The national deals of India are renunciation
	And service. Intensify her in those channels,
	And the rest will take care of itself.<br />

158.	Can you see your own eyes? God is like that.
	He is as close as your own eyes.
	He is your own, even though you can’t see him.<br />

159.	Let us all work hard, my brethren;
	This is no time for sleep. On our work depends
	The coming of the india of the future.
	She is there ready waiting. She is only sleeping.<br />

160.	Take up this (Upanishadic) philosophy;
	The greatest truths are the simplest things
	In the world, simple as your own existence.<br />

161.	It may be that I shall find it good to get outside
	Of my body – to cast it off like a disused garment.
	But I shall not cease to work ! I shall inspire
	Men everywhere, until the world shall
	Know that it is one with god.<br />

162.	Truce to foolish talk; talk of the lord.
	Life is too short to be spent in talking
	About frauds and cranks.<br />

163.	If you do not raise the women, who are
	Living embodiment of the divine Mother,
	Don’t think that you have any other way to rise.<br />

164.	In the history of each nation, you will
	Always find that only those individuals
	Who have believed in themselves
	Have become great and strong.<br />

165.	Religion is not a thing of imagination
	But of direct perception. He who has seen
	Even a single spirit is greater than
	Many a book-learned pandit.<br />

166.	An atheist can be charitable
	But not religious.
	But the religious man must be charitable.<br />

167.	You have to grow from inside out.
	None can teach you, none can make you
	Spiritual. There is no other teacher
	But your own soul.<br />

168.	Stand and die in your own strength;
	If there is any sin in the world, it is weakness;
	Avoid all weakness, for weakness is sin,
	Weakness is death.<br />

169.	Blame neither man, nor god, nor anyone
	In the world. When you find yourselves suffering,
	Blame yourselves, and try to do better.<br />

170.	This is the gist of all worship
	To be pure and to do good to others.<br />

171.	My faith is in the younger generation.
	The modern generation, out of them will come my workers. 
They will work out the whole problem like lions.<br />

172.	So long as the millions live in hunger and ignorance,
	I hold every man a traitor who, having been educated
	At their expense, pays not the least heed to them.<br />

173.	We must go out and conquer the world through
	Out spirituality and philosophy. There is no other alternative.
	We must do it or die.<br />

174.	Education is the manifestation of the perfection already in man.<br />

175.	We want that education by which character is formed,
	Strength of mind is increased, the intellect is expanded,
	And by which one can stand on one’s own feet.<br />

176.	If you have faith in all the three hundred and thirty
	Millions of your mythological gods,…..and still have no
	Faith in yourselves, there is no salvation for you.
	Have faith in yourselves, and stand up on that faith and
	Be strong; that is what we need.<br />

177.	This is the gist of all worship to be pure and to do good to others.<br />
178.	Education is the manifestation of the perfection already in man. Religion is the manifestation of the divinity already in man.<br />
179.	Strength is life, weakness is death.<br />
180.	Proclaim the glory of the Atman with the roar of a lion, and impart fearlessness unto all beings by saying.
	‘Arise, awake and stop not till the goal is reached.’<br />
181.	He is an atheist who does not believe in himself. The old religion said that he was an atheist who did not believe in God. The new religion says that he is an atheist who does not believe in himself.’<br />
182.	On our work depends the coming future of India.<br />
183.	May I be born again and again…
	And suffer a thousand miseries
	If I may only worship
	The only God I believe in….
	My God the wicked.
	My God the afflicted.
	My God the poor of
	All races.”<br />
184.	Now I have one thought that is ‘India’.
	The soil of India is my highest heaven.<br />
185.	It may be that I shall find it good
	To get outside my body, to cast it off like a
	Worn-out garment
	But I shall not cease to work
	I shall inspire men everywhere, until the world shall
	Know that it is one with God.<br />
186.	I consider, that the great national sin is the neglect of the masses and this is one of the causes of our downfall…
	If you want to regenerate India. We must work for them.<br />
187.	I am proud to belong to a religion which has taught the world both tolerance and universal acceptance. We believe not only in universal toleration, but we accept all religion as true, I am proud to belong to a Nation which has sheltered the persecuted and the refugees of all religions and all nations of the earth….<br />
188.	The world is the great gymnasium! Where we come to make ourselves strong.<br />
189.	“India I loved before I came away. Now the very dust of India has become holy to me, the very air is now to me holy. It is now the holy land, the place of pilgrimage, the Tirtha.<br />
190.	The brave alone do great things, not the cowards.
	We need to have three things; the heart to feel, the brain to conceive, the hand to work.<br />
191.	Work unto Death, I am with you, and when I am gone, my spirit will work with you. This life comes and goes wealth, Fame, enjoyments are only of a few days. It is better, far better to die on the field of duty, preaching the truth, than to die like a worldly worm. Advance!<br />
192.	“I don’t see into the future, nor do I care to see. But one vision I see clear as life before me, that ancient mother has awakened once more. Sitting on her throne – rejuvenated more glorious than ever. Proclaim her to all the world with the voice of peace and benediction.<br />
193.	A CALL TO THE YOUTH : SWAMI VIVEKANANDA
	My faith is in the younger generation, the modern generation, out of them will come my workers. They will work out the whole problem like lions.
	Men, men, these are wanted : everything else will be ready, but strong, vigorous, believing young men, sincere to the backbone, are wanted, A hundred such and the world becomes revolutionized.
	Stand up, be bold, be strong. Take the whole responsibility on your own shoulders, and know that you are the creator of your own destiny.<br />
194.		“They alone live who live for others, rest are more dead than alive.”<br />
195.		“The earth is enjoyed by Heroes, be a Hero.”<br />
196.		Take the whole responsibility on your shoulders, & know that you are the creator of your own Destiny. All the strength and succour you want is within yourselves.<br />
197.		“Men, men, these are wanted : everything else will be ready, but strong, vigorous, believing young men, sincere to the backbone, are wanted. A hundred such and the world becomes revolutionized. The will is stronger than anything else. Everything must go down before the will, for that comes from God and God Himself; a pure and a strong will is omnipotent. …. What we want is strength, so believe in yourselves… What we want is muscles of iron and nerves of steel. No more weeping, but stand on your feet and be men. It is man making theories that we want. It is man-making education all round that we want.<br />
198.	Power will come, glory will come,
Goodness will come, purity will come,
And everything that is excellent will come,
When this sleeping soul is roused to
Self-conscious activity.<br />

199.	Three things are necessary to make every man great, every nation great:
i.	Conviction of the powers of goodness.
ii.	Absence of jealousy and suspicion.
iii.	Helping all who are trying to be and do good.<br />

200.	Always first learn to be a servant,
And then you will be fit to be a master.<br />

201.	My faith is in the younger generation,
The modern generation,
Out of them will come my workers.
They will work out the whole problem, like lions.<br />

202.	The whole universe is a play of Unity in variety, and of variety in unity.<br />

203.	After so much austerity. I have understood this 
as the real truth- God is present in every jiva; 
there is no other God besides that; 
who serves jiva, serves God indeed.<br />

204.	Nor name nor fame it is character that cleaves through admantine walls of difficulties.<br />

205.	Man is higher than all animals,Than all angels; none is greater than man.<br />

206.	Take up one idea.
Make that one idea your life…
Think of it, dream of it, live on that idea…
And just leave every other idea alone…
This is the way to success….<br />

207.	Arise !Awake ! And Stop Not…. Till the goal is reached.<br />

208.	Stand as a rock: you are indestructible.
You are the self (atman).
The God of the universe.<br />

209.	It is impossible to find God
Outside of ourselves. Our own souls
Contribute all the divinity that is outside of us.
We are the greatest temple.<br /><br />
  <strong style="font-size:18px;">Good Thoughts</strong><br />
<br />
210.	Strength does not come from winning,
	Yourstruggle develop your strength.
	When you go through hardship and decide not to surrender,
	That is strength !<br />
211.	When a drop of water falls on a lake,
	It loses its identity.
	When it falls on a lotus leaf,
	It shines like a pearl.
	The drop of water is same
	But company does matter.<br />
212.	True love transcends all barriers. It is universal. This love, I consider to be my religion.
-Mata Amritanandamayi<br />
213.	Health is the dynamic expression of life. Service is the expression of joy & love. In service your heart starts to blossom and a completely new dimension opens up in your life. Ask yourself how can I be usefull to those around me and to the whole world?
-Sri SriRavishankar<br />
214.	India is the cradle of the human race, the birth place of human speech, the mother of history, the grandmother of legend, and the great grandmother of tradition. Our most valuable and most astrictive materials in the history of man are treasured up in India only.
-Mark Twain<br />
215.	Yoga is not an ancient myth buried in oblivion. It is the most valuable inheritance of the present. Yoga is the essential need of today and the culture of tomorrow.
-Swami SatyanandaParamhansa<br />
216.	“Know Yoga, know peace.
	No Yoga, No peace.
	Now Yoga, Now peace.”<br />
217.	A Good Example Has Twice the values of Good Advice.<br />
218.	Success is not final, failure is not fatal! It is the courage to continue that counts.
-Winston Churchill<br />
219.	A teacher affects eternity, he can never tell where his influence stops.<br />
220.	The END of EDUCATION IS CHARACTER.<br />
221.	When a person really desires something all the universe conspires to help that person to realize his dreams.
-Paulo Coelho, The Alchemist<br />
222.	The company of Good people is like entering a perfume shop. Whether you buy anything or not, you are bound to receive the Fragrance.<br />
223.	Imagine a soccer game without a goal post, so the winning strategy is : set goals and don’t rest till the goal is not achieved, short term or long.<br />
224.	A universal Truth, a vehicle can’t cross the limit which its fuel provides, similarly a human being can’t cross his limit which its dream provides. So Dream<br />
225.	It is not an achievement to make 1000’s friends in a year, but an achievement is when you make a friendship for 1000’s years.<br />
226.	Faith only grows when you use it.
-Sri RamkrishnaParamhamsa<br />
227.	I slept & dreamt that the life was nothing but joy; I awake & saw that life was service. I served & understand that service was joy.
-Rabindranath Tagore<br />
228.	Never choose a dear one without understanding and never loose a dear one because of misunderstanding.<br />
229.	We make a living
		By what we get…!
	We make a life
		By what we give…!!<br />
230.	Every success has a trail of failures behind it.<br />

231.	Best awarded Hoarding in London.
	“Improve your food Habits. Eat your Food As your medicines. Otherwise you have to Eat medicines As your food….”<br />
232.	Read Everydaylead a better life.<br />
233.	A winner never quits, a quitter never wins…<br />

234.	The roots of education are bitter,
	But the fruits are very sweet.					-Aristotle<br />
235.	Genius is one percent inspiration
	Ninety nine percent perspiration.<br />
236.	Do not go where the path may lead
	Go where there is no path and leave a trail.
– Ralph Waldo Emerson.<br />
237.	Truth is the virtue but
	Higher still is truthful living.
– Guru Nanak<br />
238.	An eye for eye only ends up
	Making the whole world blind.
– Mahatma Gandhi<br />
239.	The foolish man seeks
	Happiness in the distance the wise
	grows it under his feet.
– James Oppenheim.<br />
240.	Success is the ability to go
	From failure to failure
	Without losing your enthusiasm.
– Winston churchill<br />
241.	You have to do the right things….
	You may never know what
	Results come from your actions
	But if you do nothing
	There will be no results
-Mahatma Gandhi<br />
242.	Inhale death
	Exhale life.
	Tobacco is silent killer.<br />
243.	Yesterday is history
	Tomorrow is mystery.
	Today is a Gift.<br />
244.	T – Transforming the
	E- Emotional
	A – abuse of
	C – Children with the
	H – Help of Love.<br />
245.	The Secret of getting AHEAD
	Is getting STARTED.<br />
246.	Education is not preparation for life, education is life itself.<br />
247.	Kill Me			Don’t waste Food
	Or Give me food	We too can taste Good.
10 	Million people die every year from hunger and hunger related diseases. Almost half of the victims are children.
248.	The wonder that is Sanskrit.
	If I was asked what is the greatest treasure which India possesses and what is her finest heritage, I would answer unhesitatingly – it is the Sanskrit language and literature and all that it contains.
– Jawaharlal Nehru<br />
249.	Destiny is not a matter of chance, it is a matter of choice; it is not a thing to be waited for. It is a thing to be achieved. Let us repeat endlessly to ourself. We will achieve extra ordinary success in life. It all depends on us.<br />
250.	People will always throw stones in your path.
	It depends on you what you makes from it, A wall or A Bridge. Your decision will change your life.<br />
251.	Education is bringing together the thinking Brain with Active finger.
252.	Your smiling face makes you and others happy.<br />
253.	Dream is not what you see in sleep.
	It is that which do not let you sleep.
-Dr. APJ Abdul Kalam<br />
254.	The education of the Heart cannot be
	Imparted through Books,
	It is possible only with the living
	Touch of the teacher.
-Mahatma Gandhi<br />
255.	It is not your aptitude.
	But your attitude that
	Determines your altitude.<br />
256.	….test me as
	Money lenders
	Test their coins…
	You must not
	Accept me until
	You have tested
	Me thoroughly ….”
-Sri RamKrishnaParamhamsa<br />
257.	One piece of iron is in the image in the temple
	and another the knife in the hand of the Butcher.
	But when they touch the philosopher stone
	Both alike turn to Gold.
	So Lord look not upon my evil qualities.<br />
258.	Anger is just one letter short of DANGER 
PATIENCE is the Best attitude on road.<br />
259.	Short but a very deep thought: ‘Do you want happiness in life! If yes…. Then never be a beggar of love. Always be a donor of it.<br />
260.	Don’t limit your challenges, challenge your limits.<br />
261.	Born with personality is an Accidents,
	But dying with a personalities is an Achievement.<br />
262.	30 states, 1618 languages. 6400 caste, 6 religion, 6 ethnic groups, 290 major festivals in 1 country! Be proud to be an INDIAN! HAPPY INDEPENDENE DAY. JAY HIND!!<br />
263.	If your actions inspire others to dream more, learn more, do more and become more, you are a leader.<br />
264.	B E
	Yourself
	An original is always
	Worth more than a copy.<br />
265.	Come together
	Work together
	And
	Achieve together.<br />
266.	Sun glows for a day, candle for an hour, match stick for a minute. But a good day can glow forever,
	So start your day with a SMILE.<br />
267.	Obstacles can’t stop you, Problems can’t stop you
			Most of all
	Other people can’t stop you, The only one who stops you
			Is yourself.<br />
268.	“If you have a strong commitment to your goals and dreams, if you wake up every day with a passion to do your job, everything is possible.”
-  Chantal Petitelerc.<br />
269.	Difficulties in your
	life do not come to
	destroy you, but to
	help you realize
	your hidden
	potential and power,
	let difficulties
	know that you too
	are difficult.
-Dr. A.P.J. Abdulkalam<br />
270.	“We are guilty of many errors and many faults,
	But our worst crime is abandoning the children,
	Neglecting the fountain of life,
	Many of things we need can wait,
	But the child cannot…
	Right now is the time his bones are being formed,
	His blood is being made,
	And his senses are being developed,
	To him we cannot answer – ‘tomorrow’
	Because His name is ‘To-Day’.”
-Gabriela Mistral<br />
271.	The only thing necessary for the triumph of evil is for good men to do nothing.
– Edmund Burke<br />
272.	The Education system is like a Bicycle, where the front wheel is the Teacher, and the Back wheel having the hub is the Parent. The parent provides motivation to the child to move forward while the teacher gives direction.
	First be –> then do –> then tell.			-SathyaSai Baba<br />

273.	Children close their ears to what the
		Teacher say.
	But they open their eyes to what the
		Teacher do.						-SathyaSai Baba
	Choose Between – 	Instruct or Inspire
				Heartificial or Artificial
				Information or experience.
				Teach or motivate to learn.<br />
274.	Give me six hours to chop down a tree and I will spend the first four sharpening the axe.
– Abraham Lincon.<br />
275.	Imagination is more important than knowledge.
-Albert Einstein<br />
276.	My pain may be the reason for somebody’s laugh, but my laugh must never be the reason for somebody’s pain.
-Charlie Chaprilin.<br />
277.	It is not in the stars to hold our destiny but in ourselves.
-William Shakespeare<br />
278.	A man can’t ride your back unless it’s bent.
-Martin Luther King<br />
279.	Quality means doing it right when no one is looking.
-Henry Ford.<br />
280.	Peace begins with a smile.
-Mother Teresa.<br />

281.	Find the good. It’s all round you. Find it show case it and you’ll start believing it.
-Jesse Owens.<br />
282.	You must be the change. You wish to see in the world.
-Mahatma Gandhi<br />
283.	The empires of the future are the empires of the mind.
-Winston Churchill<br />
284.	If you can dream it, you can do it.
-Walt Disney<br />
285.	A friend in need is a friend Indeed.<br />
286.	Work done in the true spirit – is meditation.<br />
287.	Improvement always begins with I.<br />
288.	We can’t spell
Sccess without	U.<br />
289.	None of us
	Is as strong as
	ALL
	Of us.<br />
290.	IDEAS won’t
	WORK
	UNLESS YOU DO.<br />
291.	GOALS
	Give direction,
	Purpose and meaning
	To life.<br />
292.	TEAM WORK
	MEANS
	MORE WE And
	LESS ME.<br />
293.	Opportunity
	Does not
	Knock
	Twice.<br />
294.	Happiness shared
	Is
	Happiness doubled.<br />
295.	Your greatness is presented by your conduct.
	Your learning, your social status, your economic status
	And your political status has nothing to do with your greatness.<br />
296.	Creating difference between
Eligibility and Employability.<br />
297.	If  “U” SALUTE YOUR DUTY.
“U” NEED NOT SALUTE ANYBODY.
BUT IF “U” POLLUTE YOUR DUTY “U” HAVE
TO SALUTE EVERYBODY….<br />
298.	When an American friend asked how she could help Swami Vivekananda in his work. Swamiji told her : “Love India”.<br />
299.	Swami Vivekanandaji letter to the Maharaja of Mysore reads in part :
My noble prince the life is short, the vanities of the world are transient, but they alone live who live for others, the rest are more dead than alive.”<br />
300.	“If the poor boy can’t come to school,
School must go to him.”<br />
301.	SMS FOR DIVALI :-
EkDiyaDeshKeLiye… EkSochSamajKeliye… aurekprayasparibartankeliye.YehsuvKamnaaajaapke like.<br />
302.	A small body of determined spirits
Fired by an unquenchable faith in
Their mission can alter the course ofHistory.
-	Mahatma Gandhi<br />
303.	A person’s wealth is measured
By his ability to share and not by
What he hoards.						-H.H. Sri Sri Ravi Shankar<br />
304.	“A portion of your earnings given in
Service, brings Abundance.”			-H.H. Sri Sri Ravi Shankar<br />
305.	Happiness follows knowledge
Knowledge brings Generosity
Generosity brings Abundance.			-H.H. Sri Sri Ravi Shankar<br />
306.	There is no substitute to sincerity.<br />
307.	Courtesy pays nothing but costs more.<br />
308.	All that glitters is not gold.<br />
309.	Beauty consist in purity of Heart.<br />
310.	Promises will not help the needly.<br />
311.	Speech is silver silence is golden.<br />
312.	Beautiful behavior is the finest of all arts.<br />
313.	Service to humanity is service to God.<br />
314.	Duty is God.<br />
315.	Responsibility is the crown of all virtues.<br />
316.	Punctuality and successfulness are the two sides of the same coin.<br />
317.	There is no religion higher than truth & righteousness<br />
318.	Where women are worshipped that place is the heaven.<br />
319.	Disagree with dissent is not disloyalty.<br />
320.	Money earned by hard works, never wasted like water.<br />
321.	Without a rich heart wealthy person is an ugly beggar.<br />
322.	Without ego you can go on, (but) with ego you are gone/ no where.<br />
323.	A quiet tongue shows a wise head.<br />
324.	Everybody becomes wise after the event.<br />
325.	Failures are the pillar of success.<br />
326.	Mother and mother land are greater than the heaven.<br />
327.	It is the essence of genius to make use of simplest ideas.<br />
328.	Better a noble death than wretched life.<br />
329.	We may learn most from those who know least.<br />
330.	Caution is the eldest child of wisdom.<br />
331.	Behind every fair copy there must be a rough note.<br />
332.	A little learning is dangerous.<br />
333.	Idle/Lazy mind is devil’s workshop.<br />
334.	Time and tides wait for none.<br />
335.	Earning blessing is preferred more than earning money.<br />
336.	Simplicity is more powerful than a nuclear weapon.<br />
337.	Purity is the mother of peace and prosperity.<br />
338.	Yoga is not only a process by which disorders and diseases are rectified but also a process to move from normal Health to positive health and finally perfect health.<br />
339.	Every parent would like to have a child
Whose personality shines wherever the child
goes in the world, it is the personality that
Is appreciated everywhere in the world.
Such pleasing personality is what is the
Main aim of this education.
-	Sri Sri Ravi Shankar<br />
340.	Man is capable of incredible things of infinite knowledge and bliss if he takes steps to raise the level of awareness. Yoga systematically unlocks the portals of higher consciousness and leads man beyond the horizon of limitation to a greater vision of fulfillment with in this very life. -ParamhamsaSatyananda<br />
341.	There is need for an educational institution, which could mould its students into noble and enlightened human beings selfless, warm-hearted, compassionate and kind.<br />

342.	LET YOGA BE YOUR WAY OF LIFE.<br />
343.	Be Good, Do Good &Do it Now.			- Swami Sivananda<br />
344.	People living in today’s world, who have to step into new dimensions of consciousness and open new doors of perception to bring about a healthy atmosphere for humankind, need to practice yoga.
-	Sri Swami Satyananda<br />
345.	“The source of life is within you. If you remain in touch with that source, everything about you will be beautiful.”
-	Sadhguru,Isha Foundation<br />
346.	As we have physical science to create external wellbeing there is a whole inner dimension of science to create inner well-being. I call it inner Engineering.
-	Sadhguru<br />

347.	“People living in today’s world, who have to step into new dimensions of consciousness and open new doors of perception to bring about a healthy atmosphere for human kind, need to practice yoga.”
-ParamahansaSwami Satyananda<br />
348.	“Yoga is going to be the culture of the future. The world can never be saved unless a complete process of reorientation of the yogic culture is imparted to every man, woman and child. Yoga is a universal culture and represents the sentiments, aspirations and the ideals, not only of one nation, but of the whole world.”
-	ParamahansaSwami Satyananda<br />
349.	“As we have physical science to create external well-being there is a whole inner dimension of science to create inner-well-being. I call it inner Engineering.”
-	SadhGuru<br />
350.	“The source of life is within you. If you remain in touch with that source, everything about you will be beautiful.
-	Sadhguru<br />
351.	“How deeply you touch another life
	Is how rich your life is.” 
-	Sadhguru<br />
352.	“When we talk about yoga as a method, we are referring to a whole technology, which leads you on to inclusion, which brings absolutely clear perception of the realities in which we exist.”
-	Sadhguru<br />
353.	“Work is an expression of who you are :
	So who you are is what needs to be worked at.”
-	Sadhguru<br />
354.	Human values are most valuable
	It is the main duty of every conscious man to protect it.
355.	To ignore the world condition in the name of spirituality is wrong Enlightenment means the ability to recognize oneself in a living creatures. We should be able to help others and love them as if we see ourselves in them. That is the goal of spiritual practices.          -Amma<br />
356.	Love is our true essence. Love is the uniting force. Love does not make distinction between race, colour, religion or nationality. In reality, we are all beads strong on the thread of love. If this world is to experience true peace, this truth must awaken in the hearts of human kind.
– Amma<br />
357.	“The need of the hour is for a system of education where the roots are deep and there are fresh shoots on the tree – “a combination of the newness and the ancientness.”
-	His Holiness Sri Sri Ravi Shankar<br />
358.	I want you to know the power, the liberation of another kind of science – the inner science, the yogic science – through which you can become the master of your own destiny.
-	Sadhguru<br />

359.	What is YOGA?
	“The word Yoga means union. Union means you begin to experience the universality of who you are.”
-	Sadhguru<br />
360.	Yoga is not a religion
	Yoga is a science
	“As there are physical science
	To create external wellbeing, yoga is the
	Science for inner wellbeing. Yoga has nothing
	To do with any particular religion.
	It is science for inner wellbeing.
-	SadhGuru<br />
361.	“If you make mud into food, that is called agriculture. If you make food into a human being, this is called digestion, if you make a human being into mud again, we call this cremation. If you can make this flesh or even a stone or even an empty space into a divine possibility, or if you transform the physical into the non-physical, that is called consecration.
– Sadhguru<br />
362.	Your body is a precious gift to you from mother nature.
	Honour this gift.
-	Sri SriRaviShankar<br />
363.	“Health is not the mere absence of disease,
	It is the dynamic expression of life.
	Health is….. being established in the self.
-	Sri SriRaviShankar<br />
364.	“Meditation is seeing God, inside you,
	Love is, seeing God, in the person next to you.”
-	Sri SriRaviShankar<br />
365.	When you cannot handle the mind directly, if can be handled through breath. The mind is like a kite and the breath is like the string.
-	Sri SriRaviShankar<br />
366.	 “Light unto Yourself”
	“No other thing do I know, oh monks, that brings so much harm as a mind that is untamed, unguarded, unprotected and uncontrolled. Such a mind truly brings much harm!”
	“No other thing do I know, oh monks, that brings so much benefit as a mind that is tamed, guarded, protected and controlled. Such a mind truly brings great benefit!”					-Mahatma Buddha<br />
367.	“Unless thinetwo eyes become one,
	You cannot enter the kingdom of God.”
	“The kingdom of God is within”
	“See ye the kingdom of God
	And his righteousness first
	And then all else will be added unto you.”<br />

368.	You cannot change
	Your FUTURE,
	But, you can change
	your habits,
	and surely your habits
	will change your FUTURE.				-Dr. APJ Abdul Kalam<br />

369.	Not all of us
	Can do great things. But
	We can do small things
	With GREAT love.					-Mother Teresa<br />

370.	The greater the difficulty,
	The more the glory in surmounting it.”			-Epicurus<br />
371.	Teacher should be able to relate to young minds, in every way, be young in spirit, enthusiastic and cheerful, 
	since they are to educate the leaders of the Future.
	Their words, their actions and their own lives should provide living examples to young Students.			
-Dr. SarvapalliRadhakrishnan (05.09.1988-17.04.1975)<br />	
372.	Before the calander turns a new leaf cover…
	Before the mobile network get flooded with messages…
	Before the mail boxes get congested…
	My family joins with me to wish you
	Happiness, prosperity and continued success…
	In your life forever.
	Wish you and your family a Very Happy New Year…!!<br />

373.	Achievement:
	“There is no limit to how great you can
	Become or how high you can soar, Expect
	The limits you impose on yourself.”<br />

374.	Challenge:
	“Do not follow where the path may lead.
	Go instead where there is no path and Leave ATrial.”<br />

375.	Failure means delay not defeat.<br />

376.	The very first word to
	Learn in friendship is …. Trust ….<br />

377.	The strongest weapon in this world
	Is nothing but Love.<br />

378.	Before you say: “I Can’t”..
		Say: “I’ll Try!”
	Then Give It
		Your Best !<br />

379.	Angry people cause hurt and GET hurt
	KEEP COOL !<br />

380.	Smile and the world smiles with you
	Keep Smiling…..<br />

381.	Actions speak louder than words.
	Prove your worth !<br />

382.	There are three sides of an argument
	YOUR SIDE, MY SIDE AND ….. THE RIGHT SIDE.<br />

383.	No defeat is final…
	Until you stop TRYING !<br />

384.	Be Positive:
	1 Tree makes
	1 Lakh matchsticks
	1 Lakh matchstick can burn 1 Lakh Trees
	Similarly 1 Negative Thought or doubt can burn
	Thousands of dreams.
	So, be Positive Always.
	BE YOURSELF
An original is Always
Worth more than a copy.<br />

385.	Success:
	The only time
	You will find success before work
	Is in the dictionary.<br />

386.	No one can do
		Everything.
	But everyone can do
		Something.<br />


387.	The way to get noticed..
	… Is to do quality work !<br />

388.	The man who wins
	Is the one who thinks he can !<br />

389.	The great thing in the world
	Is not so much where we stand,
	As in what direction we are moving.<br />

390.	Think positive !
	Say to yourself every morning !
-	Today is going to be a great day !
-	I can handle more than I think I can !
-	Things don’t get better by worrying about them !
-	I can be satisfied if I try to do my best !
-	There is always something to be happy about !
-	I’m going to make someone happy today !
-	It’s not good to be down !
-	Life is great, make the most of it !
BE AN OPTIMIST !<br />

391.	A teacher can never teach unless
	He is still learning himself
	A lamp can never light another lamp
	Unless it continues to burn its own flame.			-Rabindranath Tagore<br />

392.	A river cuts the rock.
	Not because of its power,
	But because of its consistency.
	Remember never lose your
	Hope & keep continue your
	Effort towards the target.<br />

393.	“Listen to your Elder’s Advice”, not because they are always “RIGHT”, but because they have more experiences of being “WRONG”.<br />

394.	Beware of Ego: It is a Sword with two edges the OUTER edge cuts your POPULARITY, while, the INNER edge cuts your PURITY.<br />

395.	Strong persons also commit mistakes just as weak persons. Only difference is that ‘Strong’ persons ADMIT Mistakes, but ‘Weak’ persons look for Excuses.<br />

396.	A correct understanding about life: “Your problem is not really your problem; your reaction to the problem is actually your problem.”<br />

397.	Your mind is great friend if you control it; it is your great enemy if mind controls you.<br />

398.	Clock makes a sound as ‘tiktik’, but listen carefully, it’s not tiktik, its real sound is ‘Quick Quick’- saying time is precious. Use it in best ways.<br />

399.	Performance always comes from Passion and not from Pressure, be passionate… Love what you do and do what you love… success will be always yours…<br />

400.	Those who make you smile thank them. Those who make you cry-tolerate them. But those who make you smile when tears are in your eyes-trust them.<br />

401.	‘Success’ is like a ladder and no one has ever climbed a ladder, with their hands in their pockets.<br />

402.	Be like a candle, which burns itself but gives light to others.<br />

403.	Everybody says: “Mistake is the first step of success”, but, it is not true, the correction of mistake is the step of success.<br />

404.	The 1st rule for a successful family is to demonstrate- MY FATHER IS BETTER THAN ME. The 2nd rule is not to forget the 1st rule.<br />

405.	Beware of little of 1st generation knowledge, money or power. It may make one blind and ignorant, leading to arrogance and self destructive behavior.<br />

406.	Good things come to those who wait; Better things come to those who believe in themselves.<br />

407.	The simple ways for ‘Happy Living’: Forget two things in life: 1) The good you did for other. 2) The bad done by others for you.<br />

408.	CHANGE is the nature of life, but CHALLENGE is the aim of life. So, we have to challenge the changes, not changing the challenges…!<br />

409.	The bend in the road is not the end of the road unless you refuse to take a turn.<br />

410.	Soldier: “Sir, we are surrounded by enemies on all sides.” Major: “Excellent! We can attack in any direction! Attitude decides your Success in life.<br />

411.	When you are in light, everything will follow you, but when you enter the dark, even your own shadow will leave you. That’s life.<br />

412.	If people criticize you, shout at you, tease you, make fun of you, stay cool and just remember that in every game only audience makes noise, not the player.<br />

413.	Listen to everyone and learn from everyone, because nobody knows everything but everyone knows something.<br />

414.	Life is all about 3 things: Winning, losing and sharing, that is winning others heart, losing bad things and sharing happy moments.<br />

415.	Little faith says, “You can do it.” Big faith says, “You will do it.” Great faith says, “It is done.” Nothing is impossible when you believe in yourself.<br />

416.	Every king was once a crying baby and every great building was once blueprint. It’s not about where you are today, but where YOU’LL REACH Tomorrow.<br />

417.	Don’t think hard about the past, it brings tears. Don’t think more about future, it brings fears. Live this moment with smile, it brings cheers.<br />

418.	Sometimes your ambitions get flop. Sometimes your assumptions go wrong… But your goal is still waiting for you.<br />

419.	Self confidence may not bring success but it gives a power to face all challenges.<br />

420.	UMBRELLA can’t stop the rain but protect us! Confidence may not bring Success but it gives a heart to face any challenge!<br />

421.	How hard is the logic of human mind…? It seeks compromise when we are wrong and it speaks judgement when others are wrong…!<br />

422.	Don’t look where you fall, but look where you slipped. Look at life through the windshield, not through the rear view of mirror…<br />

423.	Don’t keep your dreams in your eyes, they may fall with tears. Keep them in your heart, so that every heartbeat remind you to convert them into reality.<br />

424.	Every morning you have two choices: Continue your sleep, dreaming or wake up and chase your dreams. Choice is yours…??<br />

425.	A strong and positive attitude creates more miracles than any other thing, because life is 10% how you make it, and 90% how you take it.<br />

426.	God upsets our plan only to set up his own plan for us… While we see our present and plan our future… He sees our future and then plans our present.<br />

427.	Charlie Chaplin words: Life laughs at you, when you are unhappy. Life smiles at you, when you are happy. But, life salutes you, when you make others happy.<br />

428.	Hillary challenged Mount Everest, I will come again and conquer you because as a mountain you can’t grow but as a Human I can.<br />

429.	Comparison is the best way to judge your progress. But don’t compare yourself with others. Just compare your yesterday with your today.<br />

430.	Two ways to be happy in life: Never take help of Tears to show your emotions and never take help of WORDS to show your anger.<br />

431.	Don’t see others as doing better than your own records EVERYDAY and you will surely get success because success is a fight between you and yourself.<br />

432.	Difficulties do not come to destroy you, but to help you realize your hidden powers.<br />

433.	Tolerance for other faiths imparts to us a truer understanding of our own.-Mahatma Gandhi<br />

434.	When people hurt you frequently, think of them as a sand paper………. They scratch and hurt you, but in the end they are finished and you get polished to dazzle.<br />

435.	The word ‘LISTEN’ contains the same letters as the word ‘SILENT’… Does it mean when we are listening we are actually silent??<br />

436.	Growing seed makes ‘No Sound’, but the falling tree makes ‘Huge Noise’. Destruction has noise, creation is always quiet. This is the power of silence.<br />

437.	Life at any time is a drawing without use of an eraser.<br />

438.	Do not accept others’ definition about life…………… it is your life, define it yourself.<br />

439.	Once a wise man asked god, ‘What is the meaning of life?’. God Said, ‘Life itself has no meaning in it, but life itself is an opportunity to create a meaning of it.’<br />

440.	The beauty of life does not lie in ‘how much you are happy’; but the real beauty depends on ‘how much others are happy with you.’<br />

441.	We are not chemicals………. So, we always can think before reacting………<br />

442.	The greatest mistake we the humans make in our relationships: We listen half, understand quarter, think zero and react double.<br />

443.	The best pair in the world is ‘Smile & Cry’. They won’t meet each other at a time, if they meet; that is the best moment in your life.<br />

444.	Education is a progressive discovery of our own ignorance.<br />

445.	A correct decision can double our confidence; A wrong decision can double the experience.<br />

446.	Friendship is like a tree. It is not measured on how tall it could be, but on how deep the roots have grown.<br />

447.	A good and healthy relationship must be like a sugar cane. You crush it, twist it, squeeze it, beat it to pulpand all you get is only sweetness….!!!<br />

448.	Relationships never die a natural death… They are always murdered by ‘Ego’, ‘Vested Interest’ or ‘Lack of Communication’.<br />

449.	Richness is not earning more, not spending more or not saving more. Actually richness is when you need ‘No More’.<br />

450.	Be attached to the world with a Detached attitude.<br />

451.	If ‘U’ think positively sound becomes music, movement becomes dance, smile becomes laughter, mind becomes meditation & life becomes celebration.<br />

452.	A little knowledge that acts is worth infinitely more than much knowledge that is idle.<br />

453.	Vision without action is merely a dream. Action without vision just passes the time. Vision with action can change the world.<br />

454.	To accomplish great things we must first dream, then visualize, then plan…. Believe.. Act...<br />

455.	Happiness dawns when what you think, what you say and what you do are in harmony.<br />

456.	To acquire knowledge, one must study; but to acquire wisdom one must observe.<br />

457.	Never mistake knowledge for wisdom. One helps you to make a living; the other helps you to make a life.<br />

458.	Winners must have two things; definite goals and a burning desire to achieve them.<br />

459.	If you focus on result, you will never change; if you focus on change, you will get results.<br />

460.	Science is organized knowledge. Wisdom is organized life.<br />

461.	Winners must have two things-definite goals and a burning desire to achieve them.<br />

462.	Patience with family is love, patience with others is respect, patience with self is confidence and patience with god is faith.<br />

463.	Work is the rent you pay on earth to obtain your place in heaven.<br />

464.	It is not the river that runs, but the water. It is not the time that passes but us (the life).<br />

465.	Concern should drive us into action, and not into depression.<br />

466.	Blessed are those who can give without remembering and take without forgetting.<br />

467.	Success is not final, failure is not fatal; it is ‘the courage to continue’ that counts.<br />

468.	Anger is one letter short of ‘d-anger’.<br />

469.	Fear is a cage, where you are locked up; and faith is the key to freedom.<br />

470.	Life is a journey, not a destination – we determine our destiny by the direction we take.<br />

471.	Your life is your message to the world. Make it inspiring.		-Lorrin L Lee<br />

472.	Character, not brain, will count at the crucial moment.		-R.N. Tagore<br />

473.	To err is human; to forgive is divine.					-Alexander Pope<br />

474.	Yesterday is a cancelled cheque; tomorrow is a promissory note; today is the only cash you have- so spend it wisely.						-Kay Lyons<br />

475.	Anxiety is the rust of life, destroying its brightness and weakening its power-Tryan Edwards<br />

476.	The rate at which a person can mature is directly proportional to the embarrassment he can tolerate.							-Doug Engelbart<br />	

477.	It is thousand times better to have common sense without education than to have education without common sense.					-Robert G. Ingersall<br />

478.	If a country is to be corruption free and become a nation of beautiful minds, I strongly feel there are three societal members who can make a difference. They are the father, the mother and the teacher.						-A.P.J. Abdul Kalam<br />

479.	By three methods we may learn wisdom: first, by reflection, which is noblest; second, by imitation, which is easiest; and third, by experience, which is the most bitter.       –Confucius<br />

480.	Patience is the leading characteristic of great minds.<br />

481.	Knowledge speaks, but wisdom listens.<br />

482.	Education is progressive discovery of our own ignorance.<br />

483.	To think good thoughts is one thing, to act upon them is another.<br />

484.	Jealousy eats a person in the same way as the moth eats the cloth.<br />

485.	The birth of a human being is easy but it requires a great effort to be humane.<br />

486.	Failure only proves that there was something wanting in the effort for achieving success.<br />

487.	Identity of a civilized man is his modesty: hard on the self and soft on others.<br />

488.	It is million times better to do what should be written as a sermon than to write a sermon.<br />

489.	Wise are those who think before speaking; and fools are those who speak first and think later.<br />

490.	A river cuts the rock, not because of its power,
	But because of its consistency.
	Remember never lose your hope and keep continue,
	Your effort towards the target.<br />

491.	NO is not denial. NO is ‘next opportunity’.<br />

492.	Behaviour is the result of your attitude.<br />

493.	He has wealth who has nobleness.<br />

494.	Peace is a spiritual event.<br />

495.	Truth is the only safe ground to stand upon.<br />

496.	Winners never sleep they just take rest.<br />

497.	Anger is itself a punishment.<br />

498.	Relationship is the extension of understanding.<br />

499.	Without the study of Sanskrit one cannot become a true Indian or a true learned man.
-Mahatma Gandhi<br />

500.	Great is the Art of Beginning but Greater is the Art of Finishing.		–Lazarus Long<br />

501.	The health of the people is really the foundation upon which all their happiness and all other powers as a state depend.					-Benjamin Disraeli
</p>
     </div>
    </div>
  </div>
                    
                </div>
            </div>
        </div>
		
    <?php include("footer.php"); ?>
	
</body>
</html>
