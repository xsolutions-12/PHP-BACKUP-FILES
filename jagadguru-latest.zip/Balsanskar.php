<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Jagad Guru Yoga Bharat Foundation</title>
    <link rel="stylesheet" href="yoga_style.css" />
     <link href="tab/style1.css" rel="stylesheet" type="text/css">
</head>

<body>

	<?php include("header1.php"); ?>

    <div class="main"  >
    	<div class="content_wrap">
            <div style="width:100%; height:30px;"></div>
            <div class="main_wrap">
                <div class="wrapper1">                	
     
    <div>
      <div class="tabpage" id="tabpage_1">
    
<h3>Objectives of Bal Sanskar Kendra</h3><br />
<div class="cnt2">
  <img src="images/bal.png" width="226" height="255" alt="" style="float:right;   margin-left:20px; margin-bottom:10px;" />
<p>
	To build up human values in students along with normal school/college education.<br /><br />
<li>To awaken cultural and spiritual consciousness.</li>
<li>To introduce the importance of Indian Culture.</li>
<li>To inspire the students for refinement of character,adoption of ideal path,development of divinity,noble deeds and importance of human glory.</li>
<li>Elimination of bad company and create awareness against all kinds of evil habits and addictions.</li>
<li>Development of self-confidence-cultural,ethical,moral values,no vested interests,increased love for national glory and humanitarian service.</li>
<li>To introduce the students to the pristine glory and greatness of the Indian culture and important scientific researches of the Indian sages.</li>
<li>Development of human values and teaching of the art of living.</li>
<li>Holistic development of the personality.</li>
<li>Development of the intellegent quotient(I.Q),emotional quotient(E.Q) and Spiritual quotient(S.Q).</li>
<li>Aimed at development of refinement in thinking,character and behavior.</li>

</p>
</div>

      </div>
      
	  
      
    </div>
  </div>
                    
                </div>
            </div>
        </div>
		
    <?php include("footer.php"); ?>
	
</body>
</html>
