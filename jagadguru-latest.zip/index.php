<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>Jagad Guru Yoga Bharat Foundation</title>
	<link rel="stylesheet" href="yoga_style.css" />
	<link href="popup.css" rel="stylesheet"/>
	<link href="tab/style.css" rel="stylesheet" type="text/css">
	<script src="tab/tabs.js" type="text/javascript"></script>
</head>

<body>
<div class="p1">
	
	<?php include("header.php"); ?>
    
    <div class="main">
    	<div class="content_wrap">
            <div class="slider">
                <div class="slider_wrap">
                    <iframe src="banner.html" frameborder="0" scrolling="no"></iframe>
                </div>
            </div>
            <div class="main_wrap">
                <div class="wrapper">
				
				<div>
				<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="70%" align="left" valign="top">
		<div class="grid_1 wlcm">
                            <h3>Welcome To Our Website !</h3>
                            <p>The whole world is in crisis. On the surface it appears as if humanity is moving towards selfdestruction with its weapons of mass destruction, terrorism, insatiable selfish desire and complete lack of sensitivity towards nature. However, a deeper perspective reveals another vision which can be compared to the labor pain of mother earth. A new era is being born slowly and quietly behind the curtain of chaos and confusion. A new humanity is preparing to bring down heavenly atmosphere on this earth through leading of <strong>JagadGuru Bharat</strong>. <span style="padding-left:310px;">....&nbsp;<a href="#welcome" style="color:#900;"><em>Know More</em></a></span> 
</p>
                </div>
	</td>
    <td width="30%" align="center" valign="top">
		<div class="grid_2" style="background:url(image/surya-namaskara-a.gif) no-repeat right #fff; width:230px; border:1px solid #ccc; border-radius:200px; margin-left:-10px;   margin-top:10px; box-shadow:0px 0px 5px -2px #333; "><p style="margin-top:20px; width:90%; display:block; height:20px; margin-left:8px; font-weight:bold">Surya Namaskar</p>
		</div>
	</td>
  </tr>
  <tr>
    <td>
		<div id="tabContainer">
    <div class="tabs">
      <ul>
        <li id="tabHeader_1">News</li>
        <li id="tabHeader_2">Upcoming Events</li>
		<li id="tabHeader_3">Participants Experience</li>
      </ul>
    </div>
    <div class="tabscontent">
      <div class="tabpage" id="tabpage_1">
       <table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="17%" align="left" valign="top" style=" border-bottom: 1px dashed #e6ae75;"><img src="images/news1.png" alt="" /></td>
    <td width="3%" align="left" valign="top" style=" border-bottom: 1px dashed #e6ae75;">&nbsp;</td>
    <td width="80%" align="left" valign="top" style="padding-bottom:15px; border-bottom: 1px dashed #e6ae75;">
		<h5>Yuganirman vidyapitham (Education for everyone)</h5> 
		<p>
		The whole world is in crisis. On the surface it appears as if humanity is moving towards selfdestruction with its weapons of mass destruction, terrorism, insatiable selfish desire and complete lack of sensitivity towards nature.
		</p>
	</td>
  </tr>
  <tr>
  	<td>&nbsp;</td><td></td><td></td>
  </tr>
  <tr>
    <td width="17%" align="left" valign="top" style=" border-bottom: 1px dashed #e6ae75;"><img src="images/news1.png" alt="" /></td>
    <td width="3%" align="left" valign="top" style=" border-bottom: 1px dashed #e6ae75;">&nbsp;</td>
    <td width="80%" align="left" valign="top" style="padding-bottom:15px; border-bottom: 1px dashed #e6ae75;">
		<h5>Yuganirman vidyapitham (Education for everyone)</h5> 
		<p>
		The whole world is in crisis. On the surface it appears as if humanity is moving towards selfdestruction with its weapons of mass destruction, terrorism, insatiable selfish desire and complete lack of sensitivity towards nature.
		</p>
	</td>
  </tr>
</table>

      </div>
      <div class="tabpage" id="tabpage_2">
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="17%" align="left" valign="top" style=" border-bottom: 1px dashed #e6ae75;"><img src="images/news1.png" alt="" /></td>
    <td width="3%" align="left" valign="top" style=" border-bottom: 1px dashed #e6ae75;">&nbsp;</td>
    <td width="80%" align="left" valign="top" style="padding-bottom:15px; border-bottom: 1px dashed #e6ae75;">
		<h5>Yuganirman vidyapitham (Education for everyone)</h5> 
		<p class="dt">13th Jan 2014</p>
		<p>
		The whole world is in crisis. On the surface it appears as if humanity is moving towards selfdestruction with its weapons of mass destruction, terrorism, insatiable ...
		</p>
	</td>
  </tr>
  <tr>
  	<td>&nbsp;</td><td></td><td></td>
  </tr>
  <tr>
    <td width="17%" align="left" valign="top" style="  "><img src="images/news1.png" alt="" /></td>
    <td width="3%" align="left" valign="top" style="  ">&nbsp;</td>
    <td width="80%" align="left" valign="top" style="padding-bottom:15px;  ">
		<h5>Yuganirman vidyapitham (Education for everyone)</h5> 
		<p class="dt">13th Jan 2014</p>
		<p>
		The whole world is in crisis. On the surface it appears as if humanity is moving towards selfdestruction with its weapons of mass destruction, terrorism, insatiable selfish desire and complete lack of sensitivity towards nature.
		</p>
	</td>
  </tr>
</table>
      </div>
	  <div class="tabpage" id="tabpage_3">
       <table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="17%" align="left" valign="top" style=" border-bottom: 1px dashed #e6ae75;"><img src="images/news1.png" alt="" /></td>
    <td width="3%" align="left" valign="top" style=" border-bottom: 1px dashed #e6ae75;">&nbsp;</td>
    <td width="80%" align="left" valign="top" style="padding-bottom:15px; border-bottom: 1px dashed #e6ae75;">
		<h5>Yuganirman vidyapitham (Education for everyone)</h5> 
		<p>
		The whole world is in crisis. On the surface it appears as if humanity is moving towards selfdestruction with its weapons of mass destruction, terrorism, insatiable selfish desire and complete lack of sensitivity towards nature.
		</p>
	</td>
  </tr>
  <tr>
  	<td>&nbsp;</td><td></td><td></td>
  </tr>
  <tr>
    <td width="17%" align="left" valign="top" style=" border-bottom: 1px dashed #e6ae75;"><img src="images/news1.png" alt="" /></td>
    <td width="3%" align="left" valign="top" style=" border-bottom: 1px dashed #e6ae75;">&nbsp;</td>
    <td width="80%" align="left" valign="top" style="padding-bottom:15px; border-bottom: 1px dashed #e6ae75;">
		<h5>Yuganirman vidyapitham (Education for everyone)</h5> 
		<p>
		The whole world is in crisis. On the surface it appears as if humanity is moving towards selfdestruction with its weapons of mass destruction, terrorism, insatiable selfish desire and complete lack of sensitivity towards nature.
		</p>
	</td>
  </tr>
</table>
      </div>
      
    </div>
  </div>
	</td>
    <td align="left" valign="top" class="side_menu" style="padding-top:25px;">
		<h3>Services</h3>
		<ul>
			<li><a href="humanity.php">Humanitarian activity and social Reconstruction.</a></li>
			<li><a href="aryan.php">Arising India youth association (Aryan)</a></li>
			<li><a href="yuganirman.php">Yuganirman vidyapitham</a> </li>
			<li><a href="Jagadguru_research.php">Jagadguru educational and health research centre</a></li>
			<li><a href="Scientific_spirituality.php">Scientific spirituality</a></li>
			<li><a href="#">Videos</a></li>
			<li><a href="devasanskriti.php">DevSanskriti publication</a></li>
			<li><a href="#">Donation and membership.</a></li>
			 
		</ul>
	</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
				</div>
                    <div class="rows">
                        <div class="grid_2 artcl">
                            <h3>Article of the Day</h3>
							<a href="suitability.php"><p class="atcl">
								 Suitability of Yoga for children
							</p></a>
                            <a href="yoga_benefits.php"><p class="atcl">
								 Benefits of Yoga
							</p></a>
                        </div>
                        <div class="grid_2" style="margin-left:10px;">
                            <h3>Amrit Chintan</h3>
							<marquee direction="up" scrollamount="2" class="thought" onmouseover="this.stop();" onmouseout="this.start();">
							<p>	
                            <em>Self realization is the best service in the world.</em><br />
								<strong>-	Pandit Shri Ram Sharma Acharya</strong><br />
                                
                            <em>Teachers are the Epoch Builders, Students are the Builders of Nations Destiny.</em><br />
								<strong>-	Pandit Shri Ram Sharma Acharya</strong><br />
                                
                            <em>No price is too high to make yourself a better person. He alone is wise who knows how to repair the broken and heal the wounded. Those who have achieved harmony in their thoughts, words and actions attain true awakening.</em><br />
								<strong>-	Pandit Shri Ram Sharma Acharya</strong><br />
                                
                            <em>Self-refinement is the best service of the society.</em><br />
								<strong>-	Pandit Shri Ram Sharma Acharya</strong><br />
                                
                            <em>Education is not preparation for life, Education is life itself.</em><br />
								<strong>-	Pandit Shri Ram Sharma Acharya</strong><br />
                                
                            <em>Truth is indestructible,Virtue is indestructible,Purity is indestructible.</em><br />
								<strong>-	Swami Vivekananda</strong><br />
                                
                            <em>Religion is the manifestation of the divinity already in man.</em><br />
								<strong>-	Swami Vivekananda</strong><br />
                                
                            <em>One ounce of practice is worth,Twenty thousand tons of big talk.</em><br />
								<strong>-	Swami Vivekananda</strong><br />
                                
                            <em>All expansion is life,all contraction is death.</em><br />
								<strong>-	Swami Vivekananda</strong><br />
                                
                            <em>You cannot believe in God,Until you believe in yourself.</em><br />
								<strong>-	Swami Vivekananda</strong><br />
                            
                            </p>
							</marquee>
                            <span style="padding-left:120px;font-size:12px;">....&nbsp;<a href="amrit_chintan.php" style="color:#900;"><em>Get all the Chintans</em></a></span>
                        </div>
                        <div class="side_menu" style="margin-left: 42px;">
                            <h3>Contact Us</h3><br />
                          <p>
                            	<strong>Plot No.</strong> - N5/518<br />
IRC Village<br />
Nayapalli<br />
Bhubaneswar - 751015<br /><br />

<strong>Contact No.</strong> - 0674 - 2362888  <em style="color:#666;">(O)</em> <br />
+91 - 9337710225<em style="color:#666;">  (personal) </em><br />
+91 - 9937994372<br />
Email me: biswaranjan@jagadguruyoga.org<br />
<span style="padding-left:63px;">jagadguruyoga@gmail.com</span>
                            </p>
                        </div>
                        
                    </div>
                    <!--<div class="rows">
                        
                         <table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td style="padding:25px 15px 25px 35px;" width="50%">
		<h3 style="font-weight:normal;">Balsanskar Kendra</h3>
	</td>
    <td width="50%" style="padding:25px 15px 25px 35px">
		<h3 style="font-weight:normal;">Videos</h3>
	</td>
  </tr>
</table>

						   
                    </div> -->
                    
                </div>
            </div>
        </div>
    </div>
	 
    <?php include("footer.php"); ?>
	
</div>
</body>
</html>