
<!--Start Preloader -->
<!--<div class="preloader"></div>-->
<!--End Preloader --> 

<!--Start header area-->
  

<!--Start header area--> 
<section class="header-area">
    <div class="container">
        <div class="row min-head">
            <div class="col-lg-3 col-md-3">
                <div class="logo">
                    <a href="index.php">
                        <img src="images/resources/logo.png" alt="Awesome Logo">
                    </a>
                </div>
            </div>
            <div class="col-lg-9 col-md-9">
                <div class="header-right">
                    <ul>
                        <li>
                            <div class="icon-holder">
                                <span class="flaticon-technology"></span>
                            </div>
                            <div class="text-holder">
                                <h4>Call Us</h4>
                                <span>(0674) 2475468</span>    
                            </div>
                        </li>
                        <li>
                            <div class="icon-holder">
                                <span class="flaticon-pin"></span>
                            </div>
                            <a href="https://goo.gl/maps/HpKtjUMS2EeauYMV6" target="_blank"><div class="text-holder">
                                <h4>Location</h4>
                                <span>Kalinga Vihar, Bhubaneswar</span>    
                            </div></a>
                        </li>
                        <li>
                            <div class="icon-holder">
                                <span class="flaticon-agenda"></span>
                            </div>
                            <a href="mailto:loyola_ssps@yahoo.com"><div class="text-holder">
                                <h4>Email</h4>
                                <span>loyola_ssps@yahoo.com</span>    
                            </div></a>
                        </li>        
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>   
<!--End header area-->  

      

<!--Start mainmenu area-->
<section class="mainmenu-area stricky">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <!--Start mainmenu-->
                <nav class="main-menu" style="    float: none;
    position: relative;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-wrap: wrap;" >
                    <div class="navbar-header">   	
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                    </div>
                    <div class="navbar-collapse collapse clearfix">
                        <ul class="navigation clearfix">
                            <li class="m-hom"><a href="index.php">Home</a></li>
                            <li class="m-abo"><a href="about.php">About Us</a></li>
                            <li class="m-abo"><a href="who-we-are.php">Who We Are</a></li>
                            <li class="m-abo"><a href="mission-vision.php">Mission & Vision</a></li>
                            <li class="m-ser"><a href="services.php">Services</a></li>
                            <li class="m-fac"><a href="facilities.php">Facilities</a></li>
                            <li class="m-fac"><a href="gallery.php">Gallery</a></li>
                            <li class="m-con"><a href="outcome.php">Outcome</a></li>
                            <li class="m-con"><a href="contact.php">Contact Us</a></li>
                        </ul>
                    </div>
                </nav>
                <!--End mainmenu-->   
            </div>
        </div>
    </div>
</section>
<!--End mainmenu area-->