
<!--Start footer area-->  
<footer class="footer-area">
    <div class="container">
        <div class="row">
            <!--Start single footer widget-->
            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                <div class="single-footer-widget pd-bottom50">
                    <div class="title">
                        <h3> Hospital</h3>
                        <span class="border"></span>
                    </div>
                    <div class="our-info">
                        <p class="text-justify">Managed by Missionary Sisters, Servants of the Holy Spirit, the Loyola Hospital is situated in the heart of Kalinga Vihar in Bhubaneswar. As a private, non-profit, provides quality healthcare services at affordable prices. </p>
                        <a href="about.php" class="fot-btn">View More</a>
                                            
                    </div>
                       
                </div>
                <br>
                <br>
                <a href="https://www.facebook.com/Loyola-Hospital-107311745016386" target="_blank"><img class="imgicon" src="images/loyolafbicon.png" width="32" height="32"></a>&nbsp;&nbsp;
                        <a href="https://www.youtube.com/channel/UCmuVo4tEe4ODpsaBcjYb9EA" target="_blank"><img class="imgicon" src="images/youtube-logo.png" width="32" height="32"></a> 
            </div>
            
            <!--End single footer widget-->
            <!--Start single footer widget-->
            <div class="col-lg-2 col-md-6 col-sm-6 col-xs-12">
                <div class="single-footer-widget pd-bottom50">
                    <div class="title">
                        <h3>Quick Links</h3>
                        <span class="border"></span>
                    </div>
                    <ul class="Quick-links">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="about.php">About Us</a></li>
                        <li><a href="facilities.php">Facilities</a></li>
                        <li><a href="services.php">Services</a></li>
                        <li><a href="contact.php">Contact Us</a></li>
                    </ul>
                </div>
            </div>
            <!--End single footer widget-->
            <!--Start single footer widget-->
            <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
                <div class="single-footer-widget mar-bottom">
                    <div class="title">
                        <h3>Get In Touch </h3>
                        <span class="border"></span>
                    </div>
                    <ul class="footer-contact-info">
                        <li>
                            <div class="icon-holder">
                                <span class="flaticon-pin"></span>
                            </div>
                            <div class="text-holder">
                                <h5>HIG-488, K-5 Kalinga Vihar, Bhubaneswar, Odisha 751019.<br> <strong>Regd. No.</strong> 780/2007<br> <strong>An ISO 9001:</strong>2015 Certified Hospital</h5>
                            </div>
                        </li>
                        <li>
                            <div class="icon-holder">
                                <span class="flaticon-interface"></span>
                            </div>
                            <div class="text-holder">
                                <h5>loyola_ssps@yahoo.com</h5>
                            </div>
                        </li>
                        <li>
                            <div class="icon-holder">
                                <span class="flaticon-technology-1"></span>
                            </div>
                            <div class="text-holder">
                                <h5>(0674) 2475468, 9438104123</h5>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
            <!--Start single footer widget-->
            <!--Start single footer widget-->
            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12"><div class="single-footer-widget mar-bottom">
                <div class="title">
                        <h3>Location </h3>
                        <span class="border"></span>
                    </div>
                <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14972.738820733573!2d85.7571705!3d20.2511731!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x542c3da7e7747f5d!2sLoyola%20hospital!5e0!3m2!1sen!2sin!4v1630289216484!5m2!1sen!2sin" width="100%" height="200" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
            </div></div>
            <!--End single footer widget-->
        </div>
    </div>
</footer>   
<!--End footer area-->

<!--Start footer bottom area-->
<section class="footer-bottom-area">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <div class="copyright-text">
                    <p>Copyrights &copy; 2021 All Rights Reserved, Powered by <a href="http://xprosolutions.co.in/">XPRO.</a></p> 
                </div>
            </div>
            <!--<div class="col-md-4">-->
            <!--    <ul class="footer-social-links">-->
            <!--        <li><a href="https://www.facebook.com/Loyola-Hospital-107311745016386"><i class="fa fa-facebook"></i></a></li>-->
            <!--        <li><a href="https://www.youtube.com/channel/UCmuVo4tEe4ODpsaBcjYb9EA"><i class="fa fa-youtube"></i></a></li>-->
            <!--    </ul>-->
            <!--</div>-->
        </div>
    </div>
</section>
<!--End footer bottom area-->

</div>

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target="html"><span class="flaticon-triangle-inside-circle"></span></div>

