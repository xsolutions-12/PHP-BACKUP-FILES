<?php

if(isset($_POST["submit"])){
    
    $name = $_POST["form_name"];
    $email_id = $_POST["form_email"];
    
    $phone = $_POST["form_phone"];
    $address = $_POST["address"];
    $message = $_POST["form_message"];
   
    
   
       
       
         
             
         
            //   $email="loyola_ssps@yahoo.com";
               $email="loyolahospital8@gmail.com";
            //   $email="parthamohanmohanty372@gmail.com";
               
                //$file='attachments/'.$temp;
                $mailto = $email;
                $subject = 'Feedback';
                $font='"Myriad Pro"';
                $message="<table>
                			<tr><td>Name</td><td>:</td><td>$name</td></tr>
                			<tr><td>Email</td><td>:</td><td> $email_id</td></tr>
                			
                			<tr><td>Phone</td><td>:</td><td>$phone</td></tr>
                			<tr><td>Address</td><td>:</td><td>$address</td></tr>
                				<tr><td>Message</td><td>:</td><td>$message</td></tr>
                		  </table>
                		 
                <br />
                <br />
                <br />
                <br />";
                                    
                //$content = file_get_contents($file);
                //$content = chunk_split(base64_encode($content));
                                    
                $separator = md5(time());
                $eol = "\r\n";
                $headers = "From: Feedback Loyola Hospital<loyolahospital8@gmail.com>" . $eol;
                $headers .= "MIME-Version: 1.0" . $eol;
                $headers .= "Content-Type: multipart/mixed; boundary=\"" . $separator . "\"" . $eol;
                $headers .= "Content-Transfer-Encoding: 7bit" . $eol;
                $headers .= "This is a MIME encoded message." . $eol;
                
                                    
                $body = "--" . $separator . $eol;
                $body .= "Content-type: text/html; charset=iso-8859-1\r\n";
                $body .= "Content-Transfer-Encoding: 8bit" . $eol;
                $body .= $message . $eol;
                                    
                // $body .= "--" . $separator . $eol;
                // $body .= "Content-Type: application/octet-stream; name=\"" . $dname1 . "\"" . $eol;
                // $body .= "Content-Transfer-Encoding: base64" . $eol;
                // $body .= "Content-Disposition: attachment" . $eol;
                // $body .= $content . $eol;
                //$body .= "--" . $separator . "--";
            
                if (mail($mailto, $subject, $body, $headers)) {
                      ?>
                 
                 <script>alert("Thank you for contacting Loyola Hospital. \nYour feedback has been sent!");</script>
                     
            <?php                      
                 }else{ ?>
                 
                 <script>alert("Mail cannot be Send");</script>
                     
            <?php   }
         
            
     
      ?>
   
     
     <script>
     location.href ='index.php';
	   </script>
	      <?php   }
         
            
     
      ?>