<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Contact Us</title>

	<!-- responsive meta -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- For IE -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<?php include_once'include/css.php'; ?>
    
</head>
<body class="contact-page">
    
    
    <!--//floating icons-->
    <div class="sticky-container">
    <ul class="sticky">
        <li>
            <a href="https://www.facebook.com/Loyola-Hospital-107311745016386" target="_blank"><img class="imgicon" src="images/loyolafbicon.png" width="32" height="32"></a>
            <!--<p><a href="https://www.facebook.com/Loyola-Hospital-107311745016386" target="_blank"></a></p>-->
        </li>
        <!--<li>-->
        <!--    <img src="images/twitter-circle.png" width="32" height="32">-->
        <!--    <p><a href="https://twitter.com/codexworldblog" target="_blank">Follow Us on<br>Twitter</a></p>-->
        <!--</li>-->
        <!--<li>-->
        <!--    <img src="images/gplus-circle.png" width="32" height="32">-->
        <!--    <p><a href="https://plus.google.com/codexworld" target="_blank">Follow Us on<br>Google+</a></p>-->
        <!--</li>-->
        <!--<li>-->
        <!--    <img src="images/linkedin-circle.png" width="32" height="32">-->
        <!--    <p><a href="https://www.linkedin.com/company/codexworld" target="_blank">Follow Us on<br>LinkedIn</a></p>-->
        <!--</li>-->
        <li>
            <a href="https://www.youtube.com/channel/UCmuVo4tEe4ODpsaBcjYb9EA" target="_blank"><img class="imgicon" src="images/youtube-logo.png" width="32" height="32"></a>
            <!--<p><a href="https://www.youtube.com/channel/UCmuVo4tEe4ODpsaBcjYb9EA" target="_blank"></a></p>-->
        </li>
        <!--<li>-->
        <!--    <img src="images/pin-circle.png" width="32" height="32">-->
        <!--    <p><a href="https://www.pinterest.com/codexworld" target="_blank">Follow Us on<br>Pinterest</a></p>-->
        <!--</li>-->
    </ul>
</div>



    
    
<div class="boxed_wrapper">

<?php include_once'include/header.php'; ?>

<!--Start breadcrumb area-->     
<section class="breadcrumb-area" style="background-image: url(images/resources/breadcrumb-bg.jpg);">
	<div class="container">
	    <div class="row">
	        <div class="col-md-12">
	            <div class="breadcrumbs">
	                <h1>Contact Us</h1>
	            </div>
	        </div>
	    </div>
	</div>
	<div class="breadcrumb-bottom">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="left pull-left">
                        <ul>
                            <li><a href="index-2.html">Home</a></li>
                            <li><i class="fa fa-angle-right" aria-hidden="true"></i></li>
                            <li class="active">Contact Us</li>
                        </ul>
                    </div>   
                </div>
            </div>
        </div>
    </div>
</section>
<!--End breadcrumb area-->

<!--Start contact form area-->
<section class="contact-form-area">
    <div class="container">
        <div class="sec-title">
            <h1>Get In Touch</h1>
            <span class="border"></span>
        </div>
        <div class="row">
            <div class="col-lg-8 col-md-7">
                <div class="contact-form">
                    <form id="contact-form" name="contact_form" class="default-form" action="feedback.php" method="post">
                        <h2>Feedback</h2>
                        <div class="row">
                            <div class="col-md-6">
                                <input type="text" name="form_name" value="" placeholder="Your Name*" required="">
                            </div>
                            <div class="col-md-6">
                                <input type="email" name="form_email" value="" placeholder="Email Id">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <input type="tel" name="form_phone" value="" placeholder="Phone">
                            </div>
                            <div class="col-md-6">
                                <input type="text" name="address" value="" placeholder="Address">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <textarea name="form_message" placeholder="Your Message.." required=""></textarea>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <input id="form_botcheck" name="form_botcheck" class="form-control" type="hidden" value="">
                                <button class="thm-btn bgclr-1" type="submit" name="submit" data-loading-text="Please wait...">Send Message</button>
                            </div>
                        </div>
                    </form>  
                </div>
            </div>
            <div class="col-lg-4 col-md-5">
                <div class="quick-contact">
                    <div class="title">
                        <h2>Quick Contact</h2>
                        <p>If you have any questions simply use the following contact details.</p>
                    </div>
                    <ul class="contact-info">
                        <li>
                            <div class="icon-holder">
                                <span class="flaticon-pin"></span>
                            </div>
                            <div class="text-holder">
                                <h5><span>Address:</span>  HiG-488, Kalinga Vihar, Kalinga Vihar LIG, Patrapada, Bhubaneswar, Odisha 751019.</h5>
                            </div>
                        </li>
                        <li>
                            <div class="icon-holder">
                                <span class="flaticon-technology"></span>
                            </div>
                            <div class="text-holder">
                                <h5><span>Phone:</span> (0674) 2475468<br> 9438104123</h5>
                            </div>
                        </li>
                        <li>
                            <div class="icon-holder">
                                <span class="flaticon-interface"></span>
                            </div>
                            <div class="text-holder">
                                <h5><span>Email:</span> loyola_ssps@yahoo.com</h5>
                            </div>
                        </li>
                    </ul>
                    <br>
                    <br>
                    <!--<ul class="social-links">-->
                    <!--    <li> <a href="https://www.facebook.com/Loyola-Hospital-107311745016386" target="_blank"><img class="imgicon" src="images/loyolafbicon.png" width="32" height="32"></a>&nbsp;&nbsp;</li>-->
                    <!--<li><a href="https://www.youtube.com/channel/UCmuVo4tEe4ODpsaBcjYb9EA" target="_blank"><img class="imgicon" src="images/youtube-logo.png" width="32" height="32"></a> </li>-->
                    <!--</ul>-->
                    <a href="https://www.facebook.com/Loyola-Hospital-107311745016386" target="_blank"><img class="imgicon" src="images/loyolafbicon.png" width="32" height="32"></a>&nbsp;&nbsp;
                <a href="https://www.youtube.com/channel/UCmuVo4tEe4ODpsaBcjYb9EA" target="_blank"><img class="imgicon" src="images/youtube-logo.png" width="32" height="32"></a>
                </div>  
                
            </div>
            
        </div>
    </div>
</section>
<!--End contact form area-->  

<!--Start contact map area-->
<section class="contact-map-area">
    <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14972.738820733573!2d85.7571705!3d20.2511731!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x542c3da7e7747f5d!2sLoyola%20hospital!5e0!3m2!1sen!2sin!4v1630289216484!5m2!1sen!2sin" width="100%" height="400" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
</section>
<!--End contact map area-->

<?php include_once'include/footer.php'; ?>

<?php include_once'include/js.php'; ?>

</body>
</html>