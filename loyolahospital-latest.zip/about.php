<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>About Us</title>

	<!-- responsive meta -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- For IE -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<!-- master stylesheet -->
	<?php include_once'include/css.php'; ?>

</head>
<body class="about-page">
    
    
    <!--//floating icons-->
    <div class="sticky-container">
    <ul class="sticky">
        <li>
            <a href="https://www.facebook.com/Loyola-Hospital-107311745016386" target="_blank"><img class="imgicon" src="images/loyolafbicon.png" width="32" height="32"></a>
            <!--<p><a href="https://www.facebook.com/Loyola-Hospital-107311745016386" target="_blank"></a></p>-->
        </li>
        <!--<li>-->
        <!--    <img src="images/twitter-circle.png" width="32" height="32">-->
        <!--    <p><a href="https://twitter.com/codexworldblog" target="_blank">Follow Us on<br>Twitter</a></p>-->
        <!--</li>-->
        <!--<li>-->
        <!--    <img src="images/gplus-circle.png" width="32" height="32">-->
        <!--    <p><a href="https://plus.google.com/codexworld" target="_blank">Follow Us on<br>Google+</a></p>-->
        <!--</li>-->
        <!--<li>-->
        <!--    <img src="images/linkedin-circle.png" width="32" height="32">-->
        <!--    <p><a href="https://www.linkedin.com/company/codexworld" target="_blank">Follow Us on<br>LinkedIn</a></p>-->
        <!--</li>-->
        <li>
            <a href="https://www.youtube.com/channel/UCmuVo4tEe4ODpsaBcjYb9EA" target="_blank"><img class="imgicon" src="images/youtube-logo.png" width="32" height="32"></a>
            <!--<p><a href="https://www.youtube.com/channel/UCmuVo4tEe4ODpsaBcjYb9EA" target="_blank"></a></p>-->
        </li>
        <!--<li>-->
        <!--    <img src="images/pin-circle.png" width="32" height="32">-->
        <!--    <p><a href="https://www.pinterest.com/codexworld" target="_blank">Follow Us on<br>Pinterest</a></p>-->
        <!--</li>-->
    </ul>
</div>
    
    
    
<div class="boxed_wrapper">
<?php include_once'include/header.php'; ?>

<!--Start breadcrumb area-->     
<section class="breadcrumb-area" style="background-image: url(images/resources/breadcrumb-bg.jpg);">
	<div class="container">
	    <div class="row">
	        <div class="col-md-12">
	            <div class="breadcrumbs">
	                <h1>About Us</h1>
	            </div>
	        </div>
	    </div>
	</div>
	<div class="breadcrumb-bottom">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="left pull-left">
                        <ul>
                            <li><a href="index.php">Home</a></li>
                            <li><i class="fa fa-angle-right" aria-hidden="true"></i></li>
                            <li class="active">About Us</li>
                        </ul>
                    </div>   
                </div>
            </div>
        </div>
    </div>
</section>
<!--End breadcrumb area-->

<!--Start welcome area-->
<section class="welcome-area">
    <div class="container">
        <div class="row" style="display: flex;align-items: center;flex-wrap: wrap;">
            <div class="col-md-6">
                <div class="img-holder">
                    <img src="images/resources/welcome.jpg" alt="Awesome Image">    
                </div>
                <div class="inner-content">
                    <p><strong><i>"Each moment in life is precious, let's make it happy"</i></strong></p>
                </div>
            </div>
            <div class="col-md-6">
                <div class="text-holder">
                    <div class="title">
                        <h1>Welcome to Loyola Hospital</h1>
                        <p style="text-align: justify;">Managed by Missionary Sisters, Servants of the Holy Spirit, the Loyola Hospital Registered under government of Odisha  is situated in the heart of Kalinga Vihar in Bhubaneshwar. As a private, non-profit, provides quality healthcare services at affordable prices. This service is notable because though there are a number of private hospitals in the vicinity, the high cost of medical care becomes a hurdle in ensuring proper care for those from the economically backward parts of the society. By the efforts of the founder of Loyola hospital late Father George Antony Hess of the Society of Jesus, along with other benefactors, the hospital opened its doors to the neighbourhood of Kalinga Vihar and beyond in 2002. These Sisters have also worked tirelessly with the villagers and slum-dwellers in the surrounding area to ensure that economic background isn’t a hassle to receive the right medical care on their watch. By organising health camps, awareness programmes as well as following up regular check-ups, the Sisters of Loyola Hospital have looked into timely management of existing medical conditions and prevention of new diseases to ensure the neighbourhood’s well-being. It’s this selfless service that has earned the trust of the people who continue to feel safe at Loyola hospital.</p>  
                        
                    </div>
                     
                </div>
            </div>
        </div>
    </div>    
</section>
<!--End welcome area-->
 
<!--End certificates area-->  
<?php include_once'include/footer.php'; ?>

<?php include_once'include/js.php'; ?>



</body>
</html>