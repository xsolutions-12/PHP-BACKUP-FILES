<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Palliative Care</title>

	<!-- responsive meta -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- For IE -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<!-- master stylesheet -->
	<?php include_once'include/css.php'; ?>

</head>
<body class="gallery-page">
<div class="boxed_wrapper">
<?php include_once'include/header.php'; ?>

<!--Start breadcrumb area-->     
<section class="breadcrumb-area" style="background-image: url(images/resources/breadcrumb-bg.jpg);">
	<div class="container">
	    <div class="row">
	        <div class="col-md-12">
	            <div class="breadcrumbs">
	                <h1>Palliative Care</h1>
	            </div>
	        </div>
	    </div>
	</div>
	<div class="breadcrumb-bottom">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="left pull-left">
                        <ul>
                            <li><a href="index.php">Home</a></li>
                            <li><i class="fa fa-angle-right" aria-hidden="true"></i></li>
                            <li class="active">Palliative Care</li>
                        </ul>
                    </div>   
                </div>
            </div>
        </div>
    </div>
</section>
<!--End breadcrumb area-->

<!--Start welcome area-->
<section class="welcome-area">
    <div class="container">
        <div class="row" style="display: flex;align-items: flex-start;flex-wrap: wrap;">
            
            <div class="col-md-6">
                <ul>
                    <li> Admission of the patients by filling all the admission procedures e.g. patient’s history, background, home environment.</li>
                    <li>Observation of patients’ behavior and providing knowledge about the disease.</li>
                    <li>Winning of their confidence by creating a homely and caring environment for the patients by the trained staff members.</li>
                    <li>Administration of timely medicines to relieve them from mental trauma and physical pain.</li>
                    <li>Maintenance of routine time table for the patients’ baths, dressing of the wounds, oral hygiene etc.</li>
                    <li>Provision of nutritional diet as per the needs of the patient.</li>
                    <li>Daily diversional therapy, counseling and other recreational activities will be provided for the patients.</li>
                    <li>Relatives will be encouraged to visit the patients and to take them home if the patients show improvement and wish to go home.</li>
                    <li>Last wishes of the patients or any other desires will be fulfilled to the extent possible.</li>
                    <li>Staff will be given regular refresher trainings to update and equip them in order to be able to offer optimum care to the patients.</li>
                    <li>Schools, colleges, youth clubs, people from the corporate sectors and the local community will be motivated and encouraged to visit the patients, to entertain them or offer their voluntary services according to their convenience.</li>
                    <li>National days, festivals and other anniversary days will be celebrated.</li>
                </ul>
            </div>
            <div class="col-md-6">
                <h4>Services offered in palliative care</h4>
                <ul>
                    <li> <b>25 beds as in-patients department that:</b></li>
                    <li>Sharing room(2beds and 3beds)</li>
                    <li>Private  -  Single room</li>
                    <li>Rehabilitative unit of 12beds </li>
                    <li>Comfort, dignity, peace and better quality of life.</li>
                </ul>
            </div>
            
        </div>
    </div>    
</section>
<!--End welcome area-->
 
<!--End certificates area-->  
<?php include_once'include/footer.php'; ?>

<?php include_once'include/js.php'; ?>



</body>
</html>