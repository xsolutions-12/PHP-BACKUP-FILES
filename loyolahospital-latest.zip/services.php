<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Services</title>

	<!-- responsive meta -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- For IE -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<!-- master stylesheet -->
	<?php include_once'include/css.php'; ?>

</head>
<body class="ser-page">
    
    
    <!--//floating icons-->
    <div class="sticky-container">
    <ul class="sticky">
        <li>
            <a href="https://www.facebook.com/Loyola-Hospital-107311745016386" target="_blank"><img class="imgicon" src="images/loyolafbicon.png" width="32" height="32"></a>
            <!--<p><a href="https://www.facebook.com/Loyola-Hospital-107311745016386" target="_blank"></a></p>-->
        </li>
        <!--<li>-->
        <!--    <img src="images/twitter-circle.png" width="32" height="32">-->
        <!--    <p><a href="https://twitter.com/codexworldblog" target="_blank">Follow Us on<br>Twitter</a></p>-->
        <!--</li>-->
        <!--<li>-->
        <!--    <img src="images/gplus-circle.png" width="32" height="32">-->
        <!--    <p><a href="https://plus.google.com/codexworld" target="_blank">Follow Us on<br>Google+</a></p>-->
        <!--</li>-->
        <!--<li>-->
        <!--    <img src="images/linkedin-circle.png" width="32" height="32">-->
        <!--    <p><a href="https://www.linkedin.com/company/codexworld" target="_blank">Follow Us on<br>LinkedIn</a></p>-->
        <!--</li>-->
        <li>
            <a href="https://www.youtube.com/channel/UCmuVo4tEe4ODpsaBcjYb9EA" target="_blank"><img class="imgicon" src="images/youtube-logo.png" width="32" height="32"></a>
            <!--<p><a href="https://www.youtube.com/channel/UCmuVo4tEe4ODpsaBcjYb9EA" target="_blank"></a></p>-->
        </li>
        <!--<li>-->
        <!--    <img src="images/pin-circle.png" width="32" height="32">-->
        <!--    <p><a href="https://www.pinterest.com/codexworld" target="_blank">Follow Us on<br>Pinterest</a></p>-->
        <!--</li>-->
    </ul>
</div>
    
    
    
<div class="boxed_wrapper">
<?php include_once'include/header.php'; ?>

<!--Start breadcrumb area-->     
<section class="breadcrumb-area" style="background-image: url(images/resources/breadcrumb-bg.jpg);">
	<div class="container">
	    <div class="row">
	        <div class="col-md-12">
	            <div class="breadcrumbs">
	                <h1>Services</h1>
	            </div>
	        </div>
	    </div>
	</div>
	<div class="breadcrumb-bottom">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="left pull-left">
                        <ul>
                            <li><a href="index.php">Home</a></li>
                            <li><i class="fa fa-angle-right" aria-hidden="true"></i></li>
                            <li class="active">Services</li>
                        </ul>
                    </div>   
                </div>
            </div>
        </div>
    </div>
</section>
<!--End breadcrumb area-->

<!--Start Medical Departments area-->
<section class="medical-departments-area ser-sec">
    <div class="container">
        <div class="sec-title">
            <h1 style="margin-bottom: -1px;">Medical Services</h1>
            <span class="border"></span>
        <p style="margin-top: 15px;font-size:20px;font-family:bookman old style;color: #0392ce;">We have medical and surgical services and the supporting laboratories, equipment and personnel that make up the medical and surgical mission of a hospital or hospital system.</p>
            <!--<span class="border"></span>-->
        </div>
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

                <div class="row">
                    <!--Start single item-->
                    <div class="single-item text-center col-lg-3 col-md-3 col-xs-6">
                        <div class="iocn-holder">
                            <img src="images/icon/med.png" alt="Medicine">   
                        </div>
                        <div class="text-holder">
                            <h3>Medicine</h3>
                    </div>
                    </div>
                    <!--End single item-->
                    <!--Start single item-->
                    <div class="single-item text-center col-lg-3 col-md-3 col-xs-6">
                        <div class="iocn-holder">
                            <img src="images/icon/ort.png" alt="Orthopedic">      
                        </div>
                        <div class="text-holder">
                            <h3>Orthopedic</h3>
                    </div>
                    </div>
                    <!--End single item-->
                    <!--Start single item-->
                    <div class="single-item text-center col-lg-3 col-md-3 col-xs-6">
                        <div class="iocn-holder">
                            <img src="images/icon/nur.png" alt="Nursing Care">     
                        </div>
                        <div class="text-holder">
                            <h3>Nursing Care</h3>
                    </div>
                    </div>
                    <!--End single item-->
                    <!--Start single item-->
                    <div class="single-item text-center col-lg-3 col-md-3 col-xs-6">
                        <div class="iocn-holder">
                            <img src="images/icon/phy.png" alt="Physiotherapy">  
                        </div>
                        <div class="text-holder">
                            <h3>Physiotherapy</h3>
                    </div>
                    </div>
                    <!--End single item-->

                    <!--Start single item-->
                    <div class="single-item text-center col-lg-3 col-md-3 col-xs-6">
                        <div class="iocn-holder">
                            <img src="images/icon/ped.png" alt="Paediatric Issue">  
                        </div>
                        <div class="text-holder">
                            <h3>Paediatric Issue</h3>
                    </div>
                    </div>
                    <!--End single item-->

                    <!--Start single item-->
                    <div class="single-item text-center col-lg-3 col-md-3 col-xs-6">
                        <div class="iocn-holder">
                            <img src="images/icon/sur.png" alt="Surgery">  
                        </div>
                        <div class="text-holder">
                            <h3>Surgery</h3>
                         </div>
                    </div>
                    <!--End single item-->
                    <!--Start single item-->
                    <div class="single-item text-center col-lg-3 col-md-3 col-xs-6">
                        <div class="iocn-holder">
                            <img src="images/icon/pal.png" alt="Palliative care">  
                        </div>
                        <div class="text-holder">
                            <h3>Palliative Care</h3>
                    </div>
                    </div>
                    <!--End single item-->
                    <!--Start single item-->
                    <div class="single-item text-center col-lg-3 col-md-3 col-xs-6">
                        <div class="iocn-holder">
                            <img src="images/icon/den.png" alt="Dental">  
                        </div>
                        <div class="text-holder">
                            <h3>Dental</h3>
                          </div>
                    </div>
                    <!--End single item-->
                </div>
            </div>    
        </div>
    </div>
</section>
<!--End Medical Departments area--> 
 
<!--End certificates area-->  
<?php include_once'include/footer.php'; ?>

<?php include_once'include/js.php'; ?>



</body>
</html>