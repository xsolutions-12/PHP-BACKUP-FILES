<!DOCTYPE html>
<html>
<head>
	<title>Faculty PGDM</title>
	<?php include_once 'include/css.php'; ?>
</head>
<body class="about-page">
	<div class="container">
		<div class="main-wrap">
			<?php include_once 'include/header.php'; ?>
			<div class="inner-page-sec">
				<div class="row">
					<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<h1 class="inner-title">Faculty Members - PGDM</h1>
						<div style="">
							<table style="margin-top: 10px; height: 242px; width: 900px;" border="0" cellspacing="0" width="900" height="1041">
<thead>
<tr style="height: 40px; background-color: #ffffcc;" align="center" valign="middle">
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">
<p><strong>Faculty</strong></p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">
<p>
<strong>Designation</strong></p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">
<p>
<strong>Qualification
</strong></p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">
<p><strong>No. of Publications</strong></p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">
<p><strong>Experience</strong></p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">
<p><strong>Year Joined</strong></p>
</td>
</tr>
</thead>
<tbody>
<tr>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">
<p><img src="images/dcmishra.png" alt="faculty" width="120" height="140"></p>
<p><strong>Prof.D.C. Misra<br></strong></p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">
<p><strong>Director</strong></p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">
<p><strong>&nbsp; UG</strong> - B.Sc(Engg), LLB</p>
<p><strong>&nbsp; PG</strong> - MCP(IIT-KGP)</p>
<p><strong>&nbsp; Doctorate</strong> - ICMPB, IHS(Holland)</p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">
<p>&nbsp;<strong>Nat.Journal</strong> - 05</p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">
<p><strong>&nbsp;</strong><strong>Teaching</strong> - 11</p>
<p>&nbsp;<strong>Industry</strong> - 29</p>
<p>&nbsp;<strong>Research</strong> - 37</p>
<p>&nbsp;</p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">&nbsp;06.01.2008<br></td>
</tr>
<tr>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">
<p><img src="images/kartika_ch.jpg" alt="faculty" width="120" height="140"></p>
<p><strong>Mr. Kartik<br>Chandra Samal<br></strong></p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">
<p><strong>Lecturer<br></strong></p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">
<p><strong>&nbsp;UG</strong> - B.Com</p>
<p><strong>&nbsp;PG</strong> - M.Com, MBA(Finance) </p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">
<p>&nbsp;</p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">
<p>&nbsp;<strong>Teaching</strong> - 13</p>
<p>&nbsp;<strong>Industry</strong> - 01</p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">&nbsp;05.01.201</td>
</tr>
<tr>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">
<p><strong>Mr. Srinivas Mishra</strong>
</p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col"><strong>Asst. Professor</strong> <br></td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">
<p>&nbsp;<strong>&nbsp;</strong></p>
<p><strong>&nbsp;</strong></p>
<p><strong>&nbsp;UG</strong> - B.Com</p>
<p>&nbsp;<strong>PG</strong> - PGDM(Finance)</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col"><strong>&nbsp;</strong><strong>&nbsp;</strong><br></td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">&nbsp;
<p><strong>&nbsp;Teaching</strong> - 03</p>
<p><strong>&nbsp;</strong></p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">&nbsp;29.12.2010</td>
</tr>
<tr>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">
<p><img src="images/adarsh.jpg" alt="faculty" width="120" height="140"></p>
<p><strong>Mr. Adarsa Panigrahi<br></strong></p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">&nbsp;<strong>Lecturer</strong> <br></td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">&nbsp;
<p>&nbsp;<strong>UG</strong> - B.Sc</p>
<p>&nbsp;<strong>PG</strong> - PGDM, PGDTTM(Marketing)</p>
<strong>&nbsp;</strong><br></td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col"><strong>&nbsp;</strong>
<br></td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">
<p>&nbsp;<strong>Teaching</strong> - 07</p>
<p>&nbsp;<strong>Research</strong> - 09</p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">&nbsp;01.02.2011</td>
</tr>
<tr>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">
<p><img src="images/anupama.jpg" alt="faculty"></p>
<p><strong>Miss Anupama Jena<br></strong></p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">&nbsp;<strong>Lecturer<br></strong></td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">
<p><span><strong>&nbsp;UG</strong> -&nbsp;<span>B.A(Hons.)<br></span></span></p>
<p><span><span><strong>&nbsp;PG</strong> - M.A(Eng.)</span></span></p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col"><br></td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">&nbsp;<strong>Teaching</strong> - 04<br></td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">
<p>&nbsp;<span>01.01.2009</span></p>
</td>
</tr>
<tr>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">
<p><strong>Miss Debika Patnaik<br></strong></p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col"><strong>Lecturer</strong>&nbsp;</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">
<p>&nbsp;</p>
<p>&nbsp;</p>
<p><span><strong>UG</strong>&nbsp;-&nbsp;<span>B.A(Hons.)<br></span></span></p>
<p><span><span><strong>PG</strong>&nbsp;- MBA(HR)</span></span></p>
<p><span><span><br></span></span></p>
<p><span><span><strong>&nbsp;</strong><span>&nbsp;</span><br></span></span></p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">&nbsp;</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">&nbsp;<strong>Teaching</strong><span>&nbsp;- 03</span></td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px; text-align: center;" scope="col"><span>&nbsp;</span> 18.11.2010<br></td>
</tr>
<tr>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">
<p><img src="images/simmi.jpg" alt="faculty"></p>
<strong>Mrs. Simmi Kumari</strong><br></td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col"><strong>Lecturer</strong><br></td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col"><strong>&nbsp;UG</strong> - B.Sc
<p><strong>&nbsp;PG</strong> - PGDM(Marketing)</p>
<br></td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">&nbsp;</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">
<p>&nbsp;<strong>Teaching</strong> - 03</p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">&nbsp;29.12.2010</td>
</tr>
<tr>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">
<p><img src="images/snigdha.jpg" alt="faculty"></p>
<p><strong>Mrs. Snigdha Prasad<br></strong></p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col"><strong>Lecturer</strong>&nbsp;</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col"><strong>&nbsp;</strong><strong>UG</strong><span>&nbsp;- B.Sc</span>
<p><strong>&nbsp;PG</strong>&nbsp;- <span>PGDM(HR)<br></span></p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col"><br></td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">&nbsp;<strong>Teaching</strong> - 03<br></td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">&nbsp;29.12.2010</td>
</tr>
<tr>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">
<p><strong>Mr. Sanjay Rout</strong></p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">
<p><strong>Lecturer</strong><span><br></span></p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">
<p><strong>&nbsp;</strong></p>
<p><strong>&nbsp;</strong></p>
<p><strong>&nbsp;UG</strong><span>&nbsp;- BSc</span>
</p>
<p><strong>&nbsp;PG</strong>&nbsp;- MCA(System)</p>
<p>&nbsp;</p>
<p><span><br></span></p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col"><br></td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col"> <strong>&nbsp; Teaching</strong> - 01</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">&nbsp;<span>28.05.2010</span></td>
</tr>
</tbody>
</table>
						</div>
						
					<?php include_once 'include/footer.php'; ?>
				</div>
			</div>
		</div>
	</div>




	
	<?php include_once 'include/js.php'; ?>

</body>
</html>