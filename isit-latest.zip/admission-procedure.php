<!DOCTYPE html>
<html>
<head>
	<title>Admission Procedure</title>
	<?php include_once 'include/css.php'; ?>
</head>
<body class="about-page">
	<div class="container">
		<div class="main-wrap">
			<?php include_once 'include/header.php'; ?>
			<div class="inner-page-sec">
				<div class="row">
					<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<h1 class="inner-title">Admission Procedure</h1>
						<h5 class="sm-head">Eligibility criteria for MCA admission:</h5>
						<p>Candidates having passed +3 in any discipline including BCA having mathematics (excluding Business Mathematics) as one of the subject in +2 or +3 level are eligible to join this program.</p>
						<h5 class="sm-head">Procedure</h5>
						<p>Students desirous of joining MCA program are to appear in the Orissa Joint Entrance Examination (OJEE) every year during (March – April). Advertisement is published in all the local papers. Examination is conducted in the major cities in Orissa and some of the major cities in Eastern India. In the (OJEE) examination every successful candidate will be assigned a rank for each program separately.</p>


						<p>Through a central counseling conducted by (OJEE) the candidate will get the opportunity, according to his rank to choose one of the colleges offering the selected programme. Fees payable and documents required at the time of central counseling will be published by Orissa JEE through advertisement.</p>


						<p>The Orissa JEE will send a list of candidates to the respective colleges and students have to enroll themselves at the college level to be conducted by each college separately.</p>


						<p>Total fees payable to the college will be informed to the student by the respective college. Every year the Govt. decides about the percentage of seats to be filled by each college and programme through OJEE and procedure for fillig up rest of the seats.</p>

					</div>
					<?php include_once 'include/footer.php'; ?>
				</div>
			</div>
		</div>
	</div>




	
	<?php include_once 'include/js.php'; ?>

</body>
</html>