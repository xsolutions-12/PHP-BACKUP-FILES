<!DOCTYPE html>
<html>
<head>
	<title>JEE</title>
	<?php include_once 'include/css.php'; ?>
</head>
<body class="about-page">
	<div class="container">
		<div class="main-wrap">
			<?php include_once 'include/header.php'; ?>
		<!--	<div class="inner-page-sec">-->
		<!--		<div class="row">-->
		<!--			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">-->
		<!--				<h1 class="inner-title">JOINT ENTRANCE EXAMINATION-2011, ORISSA - FOR ADMISSION TO MCA</h1>-->
		<!--				<table style="float: left; width: 100%; font-size: 12px; height: 258px; font-weight: normal;" border="1" cellpadding="5" align="center">-->
		<!--					<tbody>-->
		<!--					<tr>-->
		<!--					<td><strong>Date of Examination</strong></td>-->
		<!--					<td><strong>Sunday, May 6, 2012</strong></td>-->
		<!--					</tr>-->
		<!--					<tr>-->
		<!--					<td><strong>Sale of Application form    begins on </strong></td>-->
		<!--					<td><strong>February 10, 2012</strong></td>-->
		<!--					</tr>-->
		<!--					<tr>-->
		<!--					<td><strong>Last date of sale of application form</strong></td>-->
		<!--					<td><strong>March 15, 2012</strong></td>-->
		<!--					</tr>-->
		<!--					<tr>-->
		<!--					<td><strong>Last date of receipt of completed application form</strong></td>-->
		<!--					<td><strong>March 22, 2012</strong></td>-->
		<!--					</tr>-->
		<!--					<tr>-->
		<!--					<td><strong>Online registration through OJEE 2012 website begins on</strong></td>-->
		<!--					<td><strong>February 10, 2012</strong></td>-->
		<!--					</tr>-->
		<!--					<tr>-->
		<!--					<td><strong>Last date of for online registration through OJEE 2012 website<br></strong></td>-->
		<!--					<td><strong>March 15, 2012</strong></td>-->
		<!--					</tr>-->
		<!--					<tr>-->
		<!--					<td>-->
		<!--					<p><strong>Last date of receipt of confirmation slip and demand draft (for online application only)</strong></p>-->
		<!--					</td>-->
		<!--					<td><strong>March 22, 2012</strong></td>-->
		<!--					</tr>-->
		<!--					<tr>-->
		<!--					<td><strong>Date of despatch of Admit Card</strong></td>-->
		<!--					<td><strong>April 05, 2011</strong></td>-->
		<!--					</tr>-->
		<!--					</tbody>-->
		<!--				</table>-->
		<!--				<h5 class="sm-head">ELIGIBILITY</h5>-->
		<!--				<p>For admission to First Year Master programme in Computer Application(MCA):</p>-->

		<!--				<p>Passed or appearing in 2012 for the Bachelor's Degree examination of minimum 3 years duration in any discipline(with pass in Mathematics at 10+2 level) from any university of Odisha or equivalent recognised university as defined by UGC. The candidate should have obtained atleast 50% marks (45% in case of candidate belonging to SC/ST category) in the qualifying examination.</p>-->

		<!--				<h5 class="sm-head">RESERVATION</h5>-->
		<!--				<p>The reservatiion of seats in different colleges under various categories will be as per the policy of the Govt. of Odisha. The percentage of seats to be reserved for different categories is subject to change and the decision of the State Government as on the date of councelling will be applicable.</p>-->

		<!--				<h5 class="sm-head">OUTSIDE STATE CANDIDATE</h5>-->
		<!--				<p>Outside State candidates are not eligible for admission in Govt. Colleges but they are eligible for admission to Private Colleges except private Medical (MBBS/MDS)Colleges as per Odisha Government rule.</p>-->

		<!--				<h1 class="inner-title">HOW TO GET APPLICATION FORM</h1>-->

		<!--				<h5 class="sm-head">(A) APPLICATION FORM CAN BE OBTAINED FROM BANKS/POST OFFICES:</h5>-->
		<!--				<p>On payment of Rs. 550/- from the following branches of Syndicate Banks/ State Bank of India/Post office.</p>-->

		<!--				<h5 class="sm-head">SYNDICATE BANK</h5>-->
		<!--				<p>Angul, Balasore, Bargarh, Baripada, Berhampur (Main Br. and Engineering School Road Br.), Bhadrak, Bhubaneswar (IRC, Kalpana Square, Nayapalli, Utkal University Campus, Vanivihar, DDCE, CEB campus Branch), Chandikhol, Cuttack (Choudhury Bazar, B.K. Road), Dhenkanal, Jagatsinghpur, Jajpur Road, Jharsuguda,Jaipur, Kavisuryanagar, Kendrapada, Keonjhar, Paradeep (PPL Campus and PPT Br.), Puri, Rourkela (Bisra Rd. and BPUT Campus Br.), Salipur, Sambalpur (Brooks Hill and Ainthapali Br.), Titilagarh, Asansol, Bhilai, Bilashpur, Bokaro, Burdwan, Dhanbad, Durgapur, Deoghar, Hazaribag, Gaya, Guwahati, Hyderabad (Khairatabad), Jamshedpur, Kharagpur, Kolkata (Dharamtalla, Gariahat, Barabazar, Rasbehari Avenue, Salt Lake), New Delhi (Transport Bhawan), Patna, Raipur, Ranchi, Vishakpatnam (Main), Nayapalli Bhubaneswar(Controlling Branch)</p>-->

		<!--				<h5 class="sm-head">STATE BANK OF INDIA</h5>-->
		<!--				<p>Angul, Aska, Athagarh, Balangir, Balasore, Bargarh, Baripada, Berhampur (Main), Bhadrak, Bhanjanagar, Bhawanipatna, Bhubaneswar (OUAT Campus, Laxmisagar), Boudh, Chatrapur, Cuttack (Main Branch, Link Road), Deogarh, Dhenkanal, Jagatsinghpur, Jajpur Town, Jaleswar, Jeypore, Jharsuguda, Kendrapara, Keonjhar, Khurda, Malkangiri, Nawarangpur, Nawapara, Nayagarh, Parlakhemundi, Phulbani, Puri, Rairangpur, Rayagada, Rourkela (Main, Uditnagar), Sambalpur (Main), Sonepur, Sundargarh, Talcher. SBI Burla( Controlling Branch)</p>-->

		<!--				<h5 class="sm-head">POST OFFICES</h5>-->
		<!--				<p>Angul(HO), Athgarh(H.O.), Aska(H.O.), Banki(MDG), Boudh Bazar(S.O.), Bargarh(H,O.), Baripada(H.O.), Balasore(HO), Bhadrak(HO), Bhanajanagar(H.O.), Bhawanipatna(H.O.), Balangir(HO), Bhubaneswar(GPO), BJB Nagar(S.O.), Berhampur(GM)(HO), Chhatrapur(H.O.), Cuttack (GPO), College square Cuttack (MDG), Dhenkanal(H.O.), Damanjodi(S.O), Jagatsinghpur (HO), Jajpur(HO), Jaleswar(H.O.), Jeypore(K)(H.O.), Jharsuguda(H.O) Koraput(HO), Khurda(H.O.) Nayagarh(HO), Kendrapara(H.O), Keonjhargarh(H.O.), Malakangiri MDG, Puri(HO), Paralakhemundi(H.O.), Phulbani(H.O), Rairangpur(H.O.), Rayagada(HO), Rourkela(HO), Uditnagar(H.O.), Sundergarh(HO), Sambalpur(HO), Nimapara(MDG), Sunabeda-2(S.O.), Sonepur (MDG), Nawarangpur (MDG).</p>-->

		<!--				<h5 class="sm-head">(B) APPLICATION FORM CAN BE FILLED ONLINE THROUGH THE WEBSITE :</h5>-->
		<!--				<p> <a href="https://ojee.nic.in/publicinfo/public/home.aspx" target="_blank">www.ojee.nic.in</a> or <a href="https://odishajee.com/" target="_blank">www.odishajee.com</a>.</p>-->
		<!--					<p>The applicant has to submit the receipt of confirmation slip and demand draft to Chairman, OJEE-2012. The draft should be made for Rs.550/- drawn in favour of "OJEE-2012" on any nationalized bank payable at bhubaneswar.</p>-->

		<!--				<h5 class="sm-head">A) APPLICATION FORM CAN BE OBTAINED FROM OJEE-2012 OFFICE:</h5>-->
		<!--				<p>Candidates can also apply for application form by post on payment of A/C payee demand draft for Rs. 550/- drawn in favour of "OJEE-2012" on any nationalized bank payable at bhubaneswar along with a stamped (Rs.75/-) 30cm x 25cm Size cloth lined self addressed envelope from the office of the Chairman, OJEE-2012, JEE Cell, Gandamunda, P.O.: Khandagiri, Bhubaneswar - 751030.</p>-->

		<!--				<p>Old question papers of OJEE-2011 for Rs 10/- per booklet will be on sale from the following branches of Syndicate Bank only subject to availability: Angul, Balasore, Baripada, Berhampur, Bhubaneswar (Kalpana Square, Nayapalli, Vanivihar), Cuttack (Choudhury Bazar), Rourkela and Sambalpur.</p>-->

		<!--				<h5 class="sm-head">HOW TO SEND APPLICATION FORM</h5>-->
		<!--				<p>The completed application form is to be submitted to the Banks/Post Offices from which it is purchased or to be sent by registered/speed post/registered courier service to the address given below.</p>-->

		<!--				<p><strong>CONTACT ADDRESS</strong></p>-->
		<!--				<ul>-->
		<!--					<li>Chairman, OJEE -2012,</li>-->
		<!--					<li>JEE Cell, Gandamunda, P.O.: Khandagiri,</li>-->
		<!--					<li>Bhubaneswar-751030</li>-->
		<!--					<li>Phone:- 06742352456:</li>-->
		<!--					<li>Fax:- 06742352457</li>-->
		<!--					<li>Website:- www.odishajee.com</li>-->
		<!--					<li>email:- contactojee2012@gmail.com</li>-->
		<!--					<li>For further detail information regarding OJEE-2012, Please log on to<a href="https://ojee.nic.in/publicinfo/public/home.aspx" target="_blank"> www.ojee.nic.in</a> or <a href="https://odishajee.com/" target="_blank">www.odishajee.com</a></li>-->
		<!--				</ul>-->
		<!--			<?php include_once 'include/footer.php'; ?>-->
		<!--		</div>-->
		<!--	</div>-->
		<!--</div>-->
					<div class="inner-page-sec">
				<div class="row">
					<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<h1 style="text-align: center;">COMING SOON !!</h1>
					<?php include_once 'include/footer.php'; ?>
				</div>
			</div>
		</div>

	</div>




	
	<?php include_once 'include/js.php'; ?>

</body>
</html>