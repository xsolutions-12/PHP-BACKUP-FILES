<!DOCTYPE html>
<html>
<head>
	<title>Faculty MCA</title>
	<?php include_once 'include/css.php'; ?>
</head>
<body class="about-page">
	<div class="container">
		<div class="main-wrap">
			<?php include_once 'include/header.php'; ?>
			<div class="inner-page-sec">
				<div class="row">
					<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<h1 class="inner-title">Faculty Members - MCA</h1>
						<div style="">
							<table style="margin-top: 10px; height: 242px; width: 900px;" border="0" cellspacing="0" width="900" height="1041">
<thead>
<tr style="height: 40px; background-color: #ffffcc;" align="center" valign="middle">
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">
<p><strong>Faculty</strong></p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">
<p>
<strong>Designation</strong></p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">
<p>
<strong>Qualification
</strong></p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">
<p><strong>No. of Publications</strong></p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">
<p><strong>Experience</strong></p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">
<p><strong>Year Joined</strong></p>
</td>
</tr>
</thead>
<tbody>
<tr>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">
<p><img src="images/rajalaxmi_rath.gif" alt="faculty" width="122" height="120"></p>
<p><strong>Mrs. Rajalaxmi Rath<br></strong></p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">
<p><strong>Lecturer</strong></p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">
<p><strong>&nbsp; UG</strong> - Sc</p>
<p><strong>&nbsp; PG</strong> - MCA(CS)</p>
<strong>&nbsp;</strong>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">
<p>&nbsp;<strong>&nbsp;</strong></p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" valign="middle" scope="col">
<p><strong>&nbsp;</strong><strong>Teaching</strong> - 08</p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">&nbsp;12.07.2007</td>
</tr>
<tr>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">
<p><img src="images/sarojlakshmi.gif" alt="faculty" width="128" height="120">&nbsp;</p>
<p><strong>Mrs. Sarojlaxmi Jena<br></strong></p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col"><strong>Lecturer</strong> <br></td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">
<p>&nbsp;<strong>UG</strong> - BA</p>
<p>&nbsp;<strong>PG</strong> - MCA(CS)</p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">&nbsp;</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">
<p>&nbsp;<strong>Teaching</strong> - 06&nbsp;
</p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">&nbsp;02.07.2007</td>
</tr>
<tr>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">
<p><img src="images/voomika-manasaja.jpg" alt="faculty" width="128" height="125"></p>
<p><strong>Miss Voomika Manasaja<br></strong></p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col"><strong>Asst. Professor</strong> <br></td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">
<p>&nbsp;<strong>UG</strong> - B.Tech</p>
<p>&nbsp;<strong>PG</strong> - M.Tech</p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">&nbsp;</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">
<p>&nbsp;<strong>Teaching</strong> - 05<strong>&nbsp;</strong></p>
<p><strong>&nbsp;Industry </strong>- 01<strong><br></strong></p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">&nbsp;17.07.2010</td>
</tr>
<tr>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">
<p><img src="images/p.k.dash.png" alt="faculty" width="128" height="145"></p>
<p>
<strong>Shri P.K. Dash</strong></p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">&nbsp;<strong>System <br>Administrator<br></strong></td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">
<p>&nbsp;<strong>UG</strong> - B.Com(Hons), ADCH</p>
<p>&nbsp;<strong>PG</strong> - MCA</p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">&nbsp;</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">
<p>&nbsp;<strong>Teaching</strong> - 04</p>
<p>&nbsp;<strong>Industry</strong> - 08</p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">&nbsp;11.01.2004</td>
</tr>
<tr>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">
<p><img src="images/bspattnaik.gif" alt="faculty" width="122" height="120"></p>
<p><strong>Shri. Bhabani <br>Sankar Pattnaik<br></strong></p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col"><strong>Lecturer</strong> <br></td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">
<p>&nbsp;<strong>UG</strong> - BCA(Hons.)</p>
<p><strong>&nbsp;PG - </strong>MCA<strong><br></strong></p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">&nbsp;</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">
<p>&nbsp;<strong>Teaching</strong> - 05</p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">&nbsp;01.09.2008</td>
</tr>
<tr>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">
<p><img src="images/sesansu-sekhar.jpg" alt="faculty" width="128" height="150"></p>
<p><strong>Shri. Shesansu Sekhar<br></strong></p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col"><strong>&nbsp;Lecturer</strong></td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">
<p>&nbsp;<strong>UG</strong> - B.Sc</p>
<p>&nbsp;<strong>PG</strong> - MCA</p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">&nbsp;</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">&nbsp;<strong>Teaching</strong> - 03<br></td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">&nbsp;28.05.2010</td>
</tr>
<tr>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">
<p><img src="images/ritesh-chandra-roy.jpg" alt="faculty" width="128" height="141"></p>
<p><strong>Shri. Ritesh Ch. Roy</strong></p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col"><strong>Lecturer</strong></td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">
<p>&nbsp;<strong>UG</strong> - B.Com</p>
<p>&nbsp;<strong>PG</strong> - MCA</p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">&nbsp;</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">
<p><strong>&nbsp;Teaching</strong> - 03</p>
<p>&nbsp;<strong>Industry</strong> - 04</p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">&nbsp;28.05.2010</td>
</tr>
<tr>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">
<p><strong><img src="images/bhagyalaxmi-mohanty.jpg" alt="faculty" width="108" height="144"></strong></p>
<p><strong>Miss Bhagyalaxmi <br>Mohanty<br></strong></p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col"><strong>Lecturer</strong></td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">
<p>&nbsp;<strong>UG</strong> - B.A</p>
<p>&nbsp;<strong>PG</strong> - MCA</p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">&nbsp;</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">
<p><strong>&nbsp;Teaching</strong> - 03</p>
</td>
<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">&nbsp;29.12.2010</td>
</tr>
</tbody>
</table>
							<p>&nbsp;</p>
							<table style="height: 40px; width: 86px;" border="0" width="86" height="40" align="center">
								<tbody>
								<tr>
								<td style="background-color: #107dc2;" align="center"><strong><a title="next page" href="faculty-mca.php"><span style="color: #ffffff;">« Previous</span></a></strong></td>
								</tr>
								</tbody>
							</table>
						</div>
						
					<?php include_once 'include/footer.php'; ?>
				</div>
			</div>
		</div>
	</div>




	
	<?php include_once 'include/js.php'; ?>

</body>
</html>