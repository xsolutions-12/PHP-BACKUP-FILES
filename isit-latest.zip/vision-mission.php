<!DOCTYPE html>
<html>
<head>
	<title>Vision & Mission</title>
	<?php include_once 'include/css.php'; ?>
</head>
<body class="about-page">
	<div class="container">
		<div class="main-wrap">
			<?php include_once 'include/header.php'; ?>
			<div class="row">
				<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="inner-page-sec">
						<h1 class="inner-title">Vision & Mission</h1>
						<p>The Indian Institute of Science and Information Technology (IISIT), a premier IT School is an intellectual community rightly blended with spiritualism & strong traditions. It owes its inception to the Grace and Blessing of Beloved Bhagawan Sri Sathya Sai Baba. Drawing its precedence from the education, value & culture prophesised by Sri Sathya Sai Baba & His exemplary Institutes, it is committed to maintain a rare excellence both in educational experience and help making a profession out of business.</p>

						<p>IISIT reinforces the importance of character and leadership grooming in Management Education brought out by the rare combination of BPUT’s Academic curriculum superimposed on IISIT’s ideals for the development of the Self.</p>

						<p>It prepares students to shoulder leadership and responsibilities as executive, managers, teachers and officers in various fields and become warriors of the twenty first century to unite humanity with the bond of Love.</p>

						<p>IISIT envisions turning out perfect man and woman reinstating Information Technology that translates of Transformation Technology of Eternal Human Values, which develops total personality of each student besides promoting creativity and professional excellence.</p>

						<p>IISIT envisions running out perfect executives, whose breath is love, whose hands are in the society, whose heart is in work but whose head is in forest.</p>

 

						<p>To conclude, IISIT's educational achievements is a bold experiment in Man-Making & People-Building, which has already started giving dividends.</p>
					</div>
				</div>
				<?php include_once 'include/footer.php'; ?>
			</div>
		</div>
	</div>




	
	<?php include_once 'include/js.php'; ?>

</body>
</html>