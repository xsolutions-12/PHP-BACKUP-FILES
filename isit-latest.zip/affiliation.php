<!DOCTYPE html>
<html>
<head>
	<title>Affiliation</title>
	<?php include_once 'include/css.php'; ?>
</head>
<body class="about-page">
	<div class="container">
		<div class="main-wrap">
			<?php include_once 'include/header.php'; ?>
			<div class="row">
				<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="inner-page-sec">
						<h1 class="inner-title">Affiliation</h1>
						<p><strong>Indian Institute of Science and Information Technology (IISIT)</strong>, Bhubaneswar received its first approval from <strong>All India Council for Technical Education (AICTE)</strong>, New Delhi vide letter No. F.NO.411/OR-01/APR(CSO/BSO/95), dated 18th January 1995 to run <strong>Master of Computer Application (MCA)</strong> programme (3 Years Full Time) with an intake of 30 seats for the academic session 1994-1995.</p>

						<p>IISIT has go its first provisional affiliation from <strong>Utkal University</strong>, Vanivihar, Bhubaneswar vide notification No. AFF.455/10344/95, dated 20.05.1995 to run MCA programme (3 Years Full Time) with an intake of 30 seats for the academic session 1994-1995.</p>
						<p>From 1994-95 onwards, upto 2001-2002, <strong>IISIT</strong>, continues to be affiliated from both <strong>AICTE</strong> and <strong>Utkal University</strong>.</p>
						<p>But from 2002-2003, with the inception of <strong>BPUT</strong> Orissa<strong> IISIT</strong> is coming within its purview.</p>

						<p>During the year 2002-2003,<strong> IISIT</strong> has again got its conditional approval from <strong>AICTE</strong>, vide letter No. F.NO.411/OR-01/MCP(CS)/94, dated 03.06.2002 to run MCA programme (3 Years Full Time) with an intake of 45 seats for the academic session 2002-03.</p>

						<p>Again during the year 2002-03, <strong>IISIT</strong> has got its provisional affiliation form <strong>BPUT</strong>, Orissa vide notification No. BPUT/201, dated 16.03.2004 to run MCA programme (3 Years Full Time) with an intake of 45 seats for the academic session 2002-03.</p>

						<p>In the year 2004-2005, <strong>IISIT</strong> has got its extension of <strong>AICTE</strong> approval vide letter No. F.NO.411/OR-01/MCP(CS)/94, dated 11.07.2004 to run MCA programme (3 Years Full Time) with an intake of 60 seats for the academic session 2004-05.</p>

						<p>In the year 2004-2005, <strong>IISIT</strong> has also got its provisional affiliation from <strong>BPUT,</strong> Orissa vide letter No. BPUT/2402/54 dated 03.05.2006 to run MCA programme (3 Years Full Time) with an intake of 60 seats for the academic session 2004-05.</p>

						<p>Now for the ongoing academic session 2007-08 <strong>IISIT</strong> has already got its approval from <strong>AICTE</strong>, vide letter No. F.NO.411/OR-01/MCP(CS)/94 dated 30.08.2007 to run MCA programme (3 Years Full Time) with an intake of 90 seats for the academic session 2025-2026.</p>

 

						<p>To conclude, IISIT's educational achievements is a bold experiment in Man-Making & People-Building, which has already started giving dividends.</p>
					</div>
				</div>
				<?php include_once 'include/footer.php'; ?>
			</div>
		</div>
	</div>




	
	<?php include_once 'include/js.php'; ?>

</body>
</html>