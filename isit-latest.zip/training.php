<!DOCTYPE html>
<html>
<head>
	<title>Training</title>
	<?php include_once 'include/css.php'; ?>
</head>
<body class="about-page">
	<div class="container">
		<div class="main-wrap">
			<?php include_once 'include/header.php'; ?>
			<div class="inner-page-sec">
				<div class="row">
					<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<h1 class="inner-title">Training</h1>
						<table style="margin-left: auto; margin-right: auto;" border="1" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td style="width: 364px;" align="center" valign="middle">
<p><strong>Sl No.</strong></p>
</td>
<td style="width: 364px;" align="center" valign="middle">
<p><strong>Module</strong></p>
</td>
<td style="width: 364px;" align="center" valign="middle">
<p><strong>Hours</strong></p>
</td>
</tr>
<tr>
<td style="width: 364px;" align="center" valign="middle">
<p><strong>1</strong></p>
</td>
<td style="width: 364px;" align="center" valign="middle">
<p><strong>Quantitative Aptitude/Reasoning</strong></p>
</td>
<td style="width: 364px;" align="center" valign="middle">
<p><strong>40</strong></p>
</td>
</tr>
<tr>
<td style="width: 364px;" align="center" valign="middle">
<p><strong>2</strong></p>
</td>
<td style="width: 364px;" align="center" valign="middle">
<p><strong>Verbal Ability(English)</strong></p>
</td>
<td style="width: 364px;" align="center" valign="middle">
<p><strong>20</strong></p>
</td>
</tr>
<tr>
<td style="width: 364px;" align="center" valign="middle">
<p><strong>3</strong></p>
</td>
<td style="width: 364px;" align="center" valign="middle">
<p><strong>Soft Skills &amp; GD/PI</strong></p>
</td>
<td style="width: 364px;" align="center" valign="middle">
<p><strong>30</strong></p>
</td>
</tr>
<tr>
<td style="width: 364px;" align="center" valign="middle">
<p><strong>4</strong></p>
</td>
<td style="width: 364px;" align="center" valign="middle">
<p><strong>Technical Skills</strong></p>
</td>
<td style="width: 364px;" align="center" valign="middle">
<p><strong>30</strong></p>
</td>
</tr>
<tr>
<td style="width: 364px;" align="center" valign="middle">
<p><strong>5</strong></p>
</td>
<td style="width: 364px;" align="center" valign="middle">
<p><strong>&nbsp;Simulation Tests &amp; Analysis</strong></p>
</td>
<td style="width: 364px;" align="center" valign="middle">
<p><strong>20</strong></p>
</td>
</tr>
</tbody>
</table>

<p>&nbsp;</p>
<ul>
<li>Quantitative Aptitude (Math)</li>
<li>Logical &amp; Analytical Reasoning</li>
<li>Verbal Ability (Reading Comprehension,
Vocabulary, Grammar, Usage)</li>
<li>Soft skills and Effective Communication</li>
<li>Personality Development/Group
Discussion/Interview Techniques</li>
<li>Technical skills (Campus oriented C,C++,DBMS,
Data structures, OS)</li>
<li>Simulation Tests and Analysis</li>
</ul>
						
					<?php include_once 'include/footer.php'; ?>
				</div>
			</div>
		</div>
	</div>




	
	<?php include_once 'include/js.php'; ?>

</body>
</html>