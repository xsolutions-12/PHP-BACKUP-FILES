<!DOCTYPE html>
<html>
<head>
	<title>Faculty MCA</title>
	<?php include_once 'include/css.php'; ?>
</head>
<body class="about-page">
	<div class="container">
		<div class="main-wrap">
			<?php include_once 'include/header.php'; ?>
			<div class="inner-page-sec">
				<div class="row">
					<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<h1 class="inner-title">Faculty Members - MCA</h1>
						<div style="">
							<table style="margin-top: 10px; height: 242px; width: 900px;" border="0" cellspacing="0" width="900" height="1041">
							<thead>
							<tr style="height: 40px; background-color: #ffffcc;" align="center" valign="middle">
							<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">
							<p><strong>Faculty</strong></p>
							</td>
							<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">
							<p>
							<strong>Name
							</strong></p>
							</td>
							<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">
							<p>
							<strong>Designation</strong></p>
							</td>
							<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">
							<p><strong>Year Joined</strong></p>
							</td>
							<!--<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">-->
							<!--<p><strong>Experience</strong></p>-->
							<!--</td>-->
							<!--<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">-->
							<!--<p><strong>No. of Publications</strong></p>-->
							<!--</td>-->
							</tr>
							</thead>
							<tbody>
							    
							<!--<tr>-->
							<!--<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">-->
							<!--<p><img src="images/faculty/user.png" alt="faculty"></p>-->
							<!--<p><strong>Prof.D.C. Misra<br></strong></p>-->
							<!--</td>-->
							<!--<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">-->
							<!--<p><strong>Director</strong></p>-->
							<!--</td>-->
							<!--<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">-->
							<!--<p><strong>&nbsp; UG</strong> - B.Sc(Engg), LLB</p>-->
							<!--<p><strong>&nbsp; PG</strong> - MCP(IIT-KGP)</p>-->
							<!--<p><strong>&nbsp; Doctorate</strong> - ICMPB, IHS(Holland)</p>-->
							<!--</td>-->
							<!--<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" scope="col">-->
							<!--<p>&nbsp;<strong>Nat.Journal</strong> - 05</p>-->
							<!--</td>-->
							<!--<td style="border-color: #dddddd; border-style: solid; border-width: 1px; text-align: center;" scope="col">-->
							<!--<p><strong>Teaching</strong> </p>-->
							<!--<p>&nbsp;<strong>Industry</strong> - 29</p>-->
							<!--<p>&nbsp;<strong>Research</strong> - 37</p>-->
							<!--<p>&nbsp;</p>-->
							<!--</td>-->
							<!--<td style="border-color: #dddddd; border-style: solid; border-width: 1px; text-align: center;" scope="col">06.01.2008<br></td>-->
							<!--</tr>-->
							
							<tr>
							<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">
							<p><img src="images/faculty/tapan.png" alt="faculty"></p>
							</td>
							<td style="border-color: #dddddd; border-style: solid; border-width: 1px; font-size: 13px;" align="center" valign="middle" scope="col">
							<p><strong>Prof (Dr) TAPAN KUMAR PANDA </strong></p>
							</td>
							<td style="border-color: #dddddd; border-style: solid; border-width: 1px; text-align: center; font-size: 13px;" scope="col"><strong>Director Academics</strong></p></td>
							<td style="border-color: #dddddd; border-style: solid; border-width: 1px; text-align: center; font-size: 13px;" scope="col">13-03-2025</td>
							</tr>
							
							<tr>
							<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">
							<p><img src="images/faculty/jk-panda.png" alt="faculty"></p>
							</td>
							<td style="border-color: #dddddd; border-style: solid; border-width: 1px; text-align: center; font-size: 13px;" align="center" valign="middle" scope="col"><strong>Prof (Dr) JAYAKRUSHNA  PANDA</strong> <br></td>
							<td style="border-color: #dddddd; border-style: solid; border-width: 1px; text-align: center; font-size: 13px;" scope="col"><strong>Principal</strong></p></td>
							<td style="border-color: #dddddd; border-style: solid; border-width: 1px; text-align: center; font-size: 13px;" scope="col">24-04-2017</td>
							</tr>
							
							<tr>
							<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">
							<p><img src="images/faculty/sanjay.png" alt="faculty" ></p>
							</td>
							<td style="border-color: #dddddd; border-style: solid; border-width: 1px; text-align: center; font-size: 13px;" align="center" valign="middle" scope="col"><strong>Mr. SANJAY KUMAR ROUT</strong> <br></td>
							<td style="border-color: #dddddd; border-style: solid; border-width: 1px; text-align: center; font-size: 13px;" scope="col"><strong>Assistant Professor</strong></p></td>
							<td style="border-color: #dddddd; border-style: solid; border-width: 1px; text-align: center; font-size: 13px;" scope="col">28-05-2010</td>
							</tr>
							
							<tr>
							<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">
							<p><img src="images/faculty/simmi.png" alt="faculty"></p>
							</td>
							<td style="border-color: #dddddd; border-style: solid; border-width: 1px; font-size: 13px;" align="center" valign="middle" scope="col"><strong>Mrs. SIMMI BHAGAT<br></strong></td>
							<td style="border-color: #dddddd; border-style: solid; border-width: 1px; text-align: center; font-size: 13px;" scope="col"><strong>Assistant Professor</strong></p></td>
							</td>
							<td style="border-color: #dddddd; border-style: solid; border-width: 1px; text-align: center; font-size: 13px;" scope="col"><span>01-05-2017</span></td>
							</tr>
							
							<tr>
							<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">
							<p><img src="images/faculty/sanjiv.png" alt="faculty"></p>
							</td>
							<td style="border-color: #dddddd; border-style: solid; border-width: 1px; font-size: 13px;" align="center" valign="middle" scope="col"><strong>Mr. SANJlV BHAGAT</strong></td>
							<td style="border-color: #dddddd; border-style: solid; border-width: 1px; text-align: center; font-size: 13px;" scope="col"><strong>Assistant Professor</strong></p></td>
							</td>
							<td style="border-color: #dddddd; border-style: solid; border-width: 1px; text-align: center; font-size: 13px;" scope="col">01-09-1996</td>
							</tr>
							
							<tr>
							<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">
							<p><img src="images/faculty/suryansh.png" alt="faculty" ></p>
							<td style="border-color: #dddddd; border-style: solid; border-width: 1px; font-size: 13px;" align="center" valign="middle" scope="col"><strong>Mr. SURYASNA TA PRATYUSH DASH</strong><br></td>
							<td style="border-color: #dddddd; border-style: solid; border-width: 1px;  text-align: center; font-size: 13px;" scope="col"><strong>Assistant Professor</strong></p>
							</td>
							<td style="border-color: #dddddd; border-style: solid; border-width: 1px; text-align: center; font-size: 13px;" scope="col">01-06-2011</td>
							</tr>
							
							<tr>
							<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">
							<p><img src="images/faculty/sujit.png" alt="faculty" ></p>
							</td>
							<td style="border-color: #dddddd; border-style: solid; border-width: 1px; font-size: 13px;" align="center" valign="middle" scope="col"><strong>Mr. SUJIT KUMAR PANIGRAHI</strong></td>
							<td style="border-color: #dddddd; border-style: solid; border-width: 1px; text-align: center; font-size: 13px;" scope="col"><strong>Assistant Professor</strong></span></p>
							</td>
							<td style="border-color: #dddddd; border-style: solid; border-width: 1px; text-align: center; font-size: 13px;" scope="col"><span>07-04-2025</span></td>
							</tr>
							
							<tr>
							<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">
							<p><img src="images/faculty/smruti-sikha.png" alt="faculty"></p>
							</td>
							<td style="border-color: #dddddd; border-style: solid; border-width: 1px; font-size: 13px;" align="center" valign="middle" scope="col"><strong>Miss. SMRUTlSIKHA DASH</strong></td>
							<td style="border-color: #dddddd; border-style: solid; border-width: 1px;  text-align: center; font-size: 13px;" scope="col"><strong>Assistant Professor</strong></span></p>
							</td>
							<td style="border-color: #dddddd; border-style: solid; border-width: 1px;  text-align: center; font-size: 13px;" scope="col"><span>07-05-2025</span></td>
							</tr>
							
							<tr>
							<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">
							<p><img src="images/faculty/manas-stpthy.png" alt="faculty"></p>
							<p>
							</td>
							<td style="border-color: #dddddd; border-style: solid; border-width: 1px; font-size: 13px;" align="center" valign="middle" scope="col"><strong>Mr. MANAS RANJAN SATAPATHY</strong></td>
							<td style="border-color: #dddddd; border-style: solid; border-width: 1px;  text-align: center; font-size: 13px;" scope="col"><strong>Assistant Professor</strong></span></p>
							</td>
							<td style="border-color: #dddddd; border-style: solid; border-width: 1px;  text-align: center; font-size: 13px;" scope="col"><span>17-05-2024</span></td>
							</tr>
							
							<tr>
							<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">
							<p><img src="images/faculty/dibakar.png" alt="faculty"></p>
							<p>
							</td>
							<td style="border-color: #dddddd; border-style: solid; border-width: 1px; font-size: 13px;" align="center" valign="middle" scope="col"><strong>Mr. DIBAKAR  PRADHAN</strong></td>
							<td style="border-color: #dddddd; border-style: solid; border-width: 1px;  text-align: center; font-size: 13px;" scope="col"><strong>Assistant Professor</strong></span></p>
							</td>
							<td style="border-color: #dddddd; border-style: solid; border-width: 1px;  text-align: center; font-size: 13px;" scope="col"><span>07-05-2025</span></td>
							</tr>


							<tr>
							<td style="border-color: #dddddd; border-style: solid; border-width: 1px;" align="center" valign="middle" scope="col">
							<p><img src="images/faculty/shilpa-suman.png" alt="faculty"></p>
							<p>
							</td>
							<td style="border-color: #dddddd; border-style: solid; border-width: 1px; font-size: 13px;" align="center" valign="middle" scope="col"><strong>Miss. SILPA SUMAN SAHOO</strong></td>
							<td style="border-color: #dddddd; border-style: solid; border-width: 1px;  text-align: center; font-size: 13px;" scope="col"><strong>Assistant Professor</strong></span></p>
							</td>
							<td style="border-color: #dddddd; border-style: solid; border-width: 1px;  text-align: center; font-size: 13px;" scope="col"><span>07-04-2025</span></td>
							</tr>
							</tbody>
							</table>
							<!--<p>&nbsp;</p>-->
							<!--<table style="height: 40px; width: 86px;" border="0" width="86" height="40" align="center">-->
							<!--	<tbody>-->
							<!--	<tr>-->
							<!--	<td style="background-color: #107dc2;" align="center"><strong><a title="next page" href="faculty-mca2.php"><span style="color: #ffffff;">Next »</span></a></strong></td>-->
							<!--	</tr>-->
							<!--	</tbody>-->
							<!--</table>-->
						</div>
						
					<?php include_once 'include/footer.php'; ?>
				</div>
			</div>
		</div>
	</div>




	
	<?php include_once 'include/js.php'; ?>

</body>
</html>