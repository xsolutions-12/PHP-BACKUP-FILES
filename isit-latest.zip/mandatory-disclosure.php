<!DOCTYPE html>
<html>
<head>
	<title>Mandatory Disclosure</title>
	<?php include_once 'include/css.php'; ?>
</head>
<body class="about-page">
	<div class="container">
		<div class="main-wrap">
			<?php include_once 'include/header.php'; ?>
			<div class="row">
				<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="inner-page-sec">
						<h1 class="inner-title">Mandatory Disclosure</h1>
					</div>
					<div class="editor-content">
						<p><strong><span style="font-size: medium;">1. NAME OF THE INSTITUTION</span></strong></p>
						<table class="TableGrid" border="0" cellspacing="0" cellpadding="0" width="617">
						<tbody>
						<tr>
						<td width="197" valign="top">
						<p><strong>Name
						  of the Institution </strong></p>
						</td>
						<td width="420" valign="top">
						<p><strong>Institute of Science
						  and Information Technology</strong><strong style="font-size: 13px;">(ISIT)</strong></p>
						</td>
						</tr>
						<tr>
						<td width="197" valign="top">
						<p><strong>Address
						  </strong></p>
						</td>
						<td width="420" valign="top">
						<p>Prasnagarbha </p>
						<p>S-3/68, 69 &amp; 83 </p>
						<p>Sector-A, Zone-B, Mancheswar Industrial Estate, </p>
						<p>Bhubaneswar-751010 </p>
						</td>
						</tr>
						<tr>
						<td width="197" valign="top">
						<p><strong>Phone
						  No: </strong></p>
						</td>
						<td width="420" valign="top">
						<p>0674-2580771 </p>
						</td>
						</tr>
						<tr>
						<td width="197" valign="top">
						<p><strong>Fax:
						  </strong></p>
						</td>
						<td width="420" valign="top">
						<p>0674-2582001 </p>
						</td>
						</tr>
						<tr>
						<td width="197" valign="top">
						<p><strong>Mobile:
						  </strong></p>
						</td>
						<td width="420" valign="top">
						<p>9337106220 </p>
						</td>
						</tr>
						<tr>
						<td width="197" valign="top">
						<p><strong>E.
						  Mail.: </strong></p>
						</td>
						<td width="420" valign="top">
						<p><span style="text-decoration: underline;">iisit@iisit.in</span> </p>
						</td>
						</tr>
						</tbody>
						</table>
						<p><span style="font-size: medium;"><strong>&nbsp;</strong></span></p>
						<h2><span style="font-size: medium;">2. Name &amp; Address of the Trust</span> </h2>
						<table class="TableGrid" border="0" cellspacing="0" cellpadding="0" width="617">
						<tbody>
						<tr>
						<td width="187" valign="top">
						<p><strong>Name of the Trust </strong></p>
						</td>
						<td width="430" valign="top">
						<p>Orissa Trust of Technical
						  Education &amp; Training (OTTET) </p>
						</td>
						</tr>
						<tr>
						<td width="187" valign="top">
						<p><strong>Address </strong></p>
						</td>
						<td width="430" valign="top">
						<p>Prasnagarbha </p>
						<p>S-3/68, 69 &amp; 83 </p>
						<p>Sector-A, Zone-B, Mancheswar Industrial Estate, </p>
						<p>Bhubaneswar-751010 </p>
						</td>
						</tr>
						<tr>
						<td width="187" valign="top">
						<p><strong>Chairman of the Trust </strong></p>
						</td>
						<td width="430" valign="top">
						<p>Mr. K. N. Bhagat </p>
						<p>&nbsp;</p>
						</td>
						</tr>
						<tr>
						<td width="187" valign="top">
						<p><strong>Trustees </strong></p>
						</td>
						<td width="430" valign="top">
						  <ol>
						<li>Mrs. Atreyee Panda </li>
						<li>Mrs. Usha Bhagat </li>
						<li>Mr. Rajiv Bhagat </li>
						</ol>
						  
						  
						  </td>
						</tr>
						<tr>
						<td width="187" valign="top">
						<p><strong>Phone No: </strong></p>
						</td>
						<td width="430" valign="top">
						<p>0674-2580771 </p>
						</td>
						</tr>
						<tr>
						<td width="187" valign="top">
						<p><strong>Fax: </strong></p>
						</td>
						<td width="430" valign="top">
						<p>0674-2582001 </p>
						</td>
						</tr>
						<tr>
						<td width="187" valign="top">
						<p><strong>Mobile: </strong></p>
						</td>
						<td width="430" valign="top">
						<p>7008753300 </p>
						</td>
						</tr>
						<tr>
						<td width="187" valign="top">
						<p><strong>E. Mail.: </strong></p>
						</td>
						<td width="430" valign="top">
						<p><span style="text-decoration: underline;">ottet@ottet.in</span> </p>
						</td>
						</tr>
						</tbody>
						</table>
						<p><span style="font-size: medium;"><strong>&nbsp;</strong></span></p>
						<h2><span style="font-size: medium;">3. Name &amp; Address of the Director</span> </h2>
						<table class="TableGrid" border="0" cellspacing="0" cellpadding="0" width="617">
						<tbody>
						<tr>
						<td width="187" valign="top">
						<p><strong>Name of the Director </strong></p>
						</td>
						<td width="430" valign="top">
						<p><strong>Prof. (Dr.) J. K. Panda </strong></p>
						<p><strong>&nbsp;</strong></p>
						</td>
						</tr>
						<tr>
						<td width="187" valign="top">
						<p><strong>Address </strong></p>
						</td>
						<td width="430" valign="top">
						<p>Prasnagarbha </p>
						<p>S-3/68, 69 &amp; 83 </p>
						<p>Sector-A, Zone-B, Mancheswar Industrial Estate, </p>
						<p>Bhubaneswar-751010 </p>
						</td>
						</tr>
						<tr>
						<td width="187" valign="top">
						<p><strong>Phone No: </strong></p>
						</td>
						<td width="430" valign="top">
						<p>0674-2580771 </p>
						</td>
						</tr>
						<tr>
						<td width="187" valign="top">
						<p><strong>Fax: </strong></p>
						</td>
						<td width="430" valign="top">
						<p>0674-2582001 </p>
						</td>
						</tr>
						<tr>
						<td width="187" valign="top">
						<p><strong>Mobile: </strong></p>
						</td>
						<td width="430" valign="top">
						<p>9437091129 </p>
						</td>
						</tr>
						<tr>
						<td width="187" valign="top">
						<p><strong>E. Mail.: </strong></p>
						</td>
						<td width="430" valign="top">
						<p><span style="text-decoration: underline;">iisit@iisit.in</span> </p>
						</td>
						</tr>
						</tbody>
						</table>
						<p>&nbsp;</p>
						<p><span style="font-size: medium;">4. <strong>NAME OF THE
						AFFILIATING UNIVERSITY</strong>:&nbsp;</span> </p>
						<p>&nbsp;<strong> &nbsp; &nbsp;Bijupatnaik University of Technology (BPUT)
						</strong></p>
						<p><strong>&nbsp; &nbsp; &nbsp;Chhend
						Colony, Rourkela, Odisha-769004</strong> </p>
						<p>&nbsp;</p>
						<p><span style="font-size: medium;"><strong>5. GOVERNANCE</strong></span> </p>
						<h2><span style="font-size: medium;"> Member of
						the Board &amp; Their brief back ground</span> </h2>
						<table class="TableGrid" border="0" cellspacing="0" cellpadding="0" width="617">
						<tbody>
						<tr>
						<td width="36" valign="top">
						<p>1. </p>
						</td>
						<td width="236" valign="top">
						<p>Shri M. K. Kaw </p>
						</td>
						<td width="344" valign="top">
						<p>Dean, Sri Sathya Sai International School of Human Values. </p>
						<p>Former Secretary,&nbsp;
						  HRD, Govt. Of India</p>
						</td>
						</tr>
						<tr>
						<td width="36" valign="top">
						<p>2.&nbsp; </p>
						</td>
						<td width="236" valign="top">
						<p>Prof. S. K. Khanna </p>
						</td>
						<td width="344" valign="top">
						<p>Former Chairman of AICTE. </p>
						<p>Former Vice-Chairman, UGC. </p>
						<p>&nbsp;</p>
						</td>
						</tr>
						<tr>
						<td width="36" valign="top">
						<p>3. </p>
						</td>
						<td width="236" valign="top">
						<p>Prof. Omkar Nath Mohanty </p>
						</td>
						<td width="344" valign="top">
						<p>Former Vice-Chairman, BPUT,
						  Odisha. </p>
						</td>
						</tr>
						<tr>
						<td width="36" valign="top">
						<p>4.&nbsp; </p>
						</td>
						<td width="236" valign="top">
						<p>Lt. Gen. (Retd.) Dr. M. L.
						  Chibber </p>
						</td>
						<td width="344" valign="top">
						<p>Director, Sri Sathya Sai
						  International Centre, Delhi. </p>
						</td>
						</tr>
						<tr>
						<td width="36" valign="top">
						<p>5.&nbsp; </p>
						</td>
						<td width="236" valign="top">
						<p>Prof. M. M. Pant </p>
						</td>
						<td width="344" valign="top">
						<p>Former Pro-Vice Chancellor,
						  IGNOU </p>
						</td>
						</tr>
						<tr>
						<td width="36" valign="top">
						<p>6.&nbsp; </p>
						</td>
						<td width="236" valign="top">
						<p>Dr. Ashok Ku. Mohapatra </p>
						</td>
						<td width="344" valign="top">
						<p>Former Director IIM, Bhubaneswar. Former
						  DEAN, IIM, New Delhi. </p>
						</td>
						</tr>
						<tr>
						<td width="36" valign="top">
						<p>7. </p>
						</td>
						<td width="236" valign="top">
						<p>Shri Shankar Agarwal,&nbsp; </p>
						</td>
						<td width="344" valign="top">
						<p>Former Secretary, IT, Labour &amp; Employment, Govt. Of
						  India </p>
						</td>
						</tr>
						<tr>
						<td width="36" valign="top">
						<p>7. </p>
						</td>
						<td width="236" valign="top">
						<p>Shri Sidhartha Pradhan,
						  IRS&nbsp; </p>
						</td>
						<td width="344" valign="top">
						<p>Member, Board of Advisory, Ministry of Petroleum &amp;
						  Chemicals. </p>
						</td>
						</tr>
						</tbody>
						</table>
						<p><strong>&nbsp;</strong></p>
						<p><strong><span style="font-size: medium;"> Members of
						Academic Advisory Body</span></strong> </p>
						<table class="TableGrid" border="0" cellspacing="0" cellpadding="0" width="617">
						<tbody>
						<tr>
						<td width="36" valign="top">
						<p>1. </p>
						</td>
						<td width="189" valign="top">
						<p>Shri K. N. Bhagat </p>
						</td>
						<td width="392" valign="top">
						<p>Managing Trustee, OTTET </p>
						</td>
						</tr>
						<tr>
						<td width="36" valign="top">
						<p>2.&nbsp; </p>
						</td>
						<td width="189" valign="top">
						<p>Mrs. Atreyee Panda </p>
						</td>
						<td width="392" valign="top">
						<p>Executive Chairperson </p>
						</td>
						</tr>
						<tr>
						<td width="36" valign="top">
						<p>3. </p>
						</td>
						<td width="189" valign="top">
						<p>Prof. P. K. Satapathy </p>
						</td>
						<td width="392" valign="top">
						<p>Director, Academics </p>
						</td>
						</tr>
						<tr>
						<td width="36" valign="top">
						<p>4.&nbsp; </p>
						</td>
						<td width="189" valign="top">
						<p>Prof. S. K. Khanna </p>
						</td>
						<td width="392" valign="top">
						<p>Former
						  Chairman, AICTE, Former Vice-Chairman, UGC </p>
						</td>
						</tr>
						<tr>
						<td width="36" valign="top">
						<p>5.&nbsp; </p>
						</td>
						<td width="189" valign="top">
						<p>Mr. M. K. Kaw </p>
						</td>
						<td width="392" valign="top">
						<p>Former Secretary HRD, Govt. Of India </p>
						</td>
						</tr>
						<tr>
						<td width="36" valign="top">
						<p>6. </p>
						</td>
						<td width="189" valign="top">
						<p>Prof. M. M. Pant </p>
						</td>
						<td width="392" valign="top">
						<p>Former Pro-Vice Chancellor, IGNOU </p>
						</td>
						</tr>
						<tr>
						<td width="36" valign="top">
						<p>7. </p>
						</td>
						<td width="189" valign="top">
						<p>Shri D. K. Ray </p>
						</td>
						<td width="392" valign="top">
						<p>Former Chairman, Odisha Electricity
						  Regulatory Commission (OERC) </p>
						</td>
						</tr>
						<tr>
						<td width="36" valign="top">
						<p>8. </p>
						</td>
						<td width="189" valign="top">
						<p>Prof. J. K. Panda </p>
						</td>
						<td width="392" valign="top">
						<p>Principal </p>
						</td>
						</tr>
						<tr>
						<td width="36" valign="top">
						<p>9. </p>
						</td>
						<td width="189" valign="top">
						<p>Mr. A. K. Panda </p>
						</td>
						<td width="392" valign="top">
						<p>Staff Representative </p>
						</td>
						</tr>
						</tbody>
						</table>
						<p><span style="font-size: medium;"><strong>&nbsp;</strong></span></p>
						<p><span style="font-size: medium;">
						<strong>Frequency of the Meetings:</strong></span> </p>
						<p><span style="font-size: medium;">a)&nbsp;&nbsp;&nbsp; Board
						Meetings &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; :
						Half Yearly</span></p>
						<p><span style="font-size: medium;">b)&nbsp;&nbsp;&nbsp; Academic
						Advisory Body : Once per month </span></p>
						<p>&nbsp;</p>
						<ul>
						<li><strong><span style="font-size: medium;">Organizational Chart</span></strong> </li>
						</ul>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<ul>
						<li><strong>Nature
						and Extent of involvement of faculty and students in Academic affairs/
						improvements.</strong> </li>
						</ul>
						<p>Faculty involvement with the
						students are multi -dimensional and at four levels. At the first level is the
						Classroom contact hours followed by tutorial classes with a smaller batch size.
						The batch size is even smaller in the proctorial services. At the last level is
						the one to one counseling sessions which results in a harmonious faculty
						student relationship. The ambience thus created leads to a high and synergetic
						involvement of faculties and students in all the affairs of the institute. </p>
						<p>&nbsp;</p>
						<h2> Mechanism/norms
						&amp; procedure for democratic/good governance
						</h2>
						<p>&nbsp;</p>
						<p>Norms and procedures are laid down
						for democratic governance of the set up. Everything is handled democratically
						and all remarks, suggestion are taken in true spirit and implemented basing on
						the merits and advantages. The mechanism is transparent and functioning is
						smooth at all times. </p>
						<p>&nbsp;</p>
						<p><strong><span style="font-size: medium;"> Student feedback on institutional  governance/ faculty
						performance</span></strong> </p>
						<p>&nbsp;</p>
						<p>Students are being asked periodically to
						get their feedback so as to strengthen corporate governance. The suggestions of
						the students are taken due care and weightage in the streamlining of the
						system. Students are also asked periodically regarding the pedagogy and other
						aspects as to performance of the teachers. Basing on the feedback from the
						feedback forms the faculties are counseled wherever necessary to improve /
						develop the pedagogy.&nbsp; </p>
						<p>&nbsp;</p>
						<p> <strong>Grievance Redressal mechanism for faculty, staff and students </strong></p>
						<p><strong>&nbsp;</strong></p>
						<h2> Establishment
						of Anti Ragging Committee </h2>
						<p><strong>&nbsp;</strong></p>
						<table class="TableGrid" border="0" cellspacing="0" cellpadding="0" width="617">
						<tbody>
						<tr>
						<td width="55" valign="top">
						<p><strong>Sl. </strong></p>
						<p><strong>No. </strong></p>
						</td>
						<td width="132" valign="top">
						<p><strong>Name </strong></p>
						</td>
						<td width="123" valign="top">
						<p><strong>Designation
						  </strong></p>
						</td>
						<td width="203" valign="top">
						<p><strong>E. Mail </strong></p>
						</td>
						<td width="103" valign="top">
						<p><strong>Contact
						  No. </strong></p>
						</td>
						</tr>
						<tr>
						<td width="55" valign="top">
						<p>1. </p>
						</td>
						<td width="132" valign="top">
						<p>Mr. &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Ashok </p>
						<p>kumar Panda </p>
						</td>
						<td width="123" valign="top">
						<p>Asst. professor </p>
						</td>
						<td width="203" valign="top">
						<p><span style="text-decoration: underline;">ashopanda@gmail.com</span> </p>
						</td>
						<td width="103" valign="top">
						<p>9437091129 </p>
						</td>
						</tr>
						<tr>
						<td width="55" valign="top">
						<p>2.&nbsp; </p>
						</td>
						<td width="132" valign="top">
						<p>Mr. Naba Kumar Rath </p>
						</td>
						<td width="123" valign="top">
						<p>Asst. professor </p>
						</td>
						<td width="203" valign="top">
						<p><span style="text-decoration: underline;">nkrath86@gmail.com</span> </p>
						</td>
						<td width="103" valign="top">
						<p>9437937449 </p>
						</td>
						</tr>
						<tr>
						<td width="55" valign="top">
						<p>3. </p>
						</td>
						<td width="132" valign="top">
						<p>Mrs. Moonmoon Brahma` </p>
						</td>
						<td width="123" valign="top">
						<p>Asst. professor </p>
						</td>
						<td width="203" valign="top">
						<p><span style="text-decoration: underline;">munmun.brahma@gmail.c om</span> </p>
						</td>
						<td width="103" valign="top">
						<p>9583200059 </p>
						</td>
						</tr>
						<tr>
						<td width="55" valign="top">
						<p>4.&nbsp; </p>
						</td>
						<td width="132" valign="top">
						<p>Mrs. &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Simmi </p>
						<p>Bhagat </p>
						</td>
						<td width="123" valign="top">
						<p>Asst. professor </p>
						</td>
						<td width="203" valign="top">
						<p><span style="text-decoration: underline;">simmibhagat1976@gmail.</span></p>
						<p><span style="text-decoration: underline;">com</span> </p>
						</td>
						<td width="103" valign="top">
						<p>9338727515 </p>
						</td>
						</tr>
						</tbody>
						</table>
						<p><strong>&nbsp;</strong></p>
						<ul>
						<li>Establishment of online Grievance Redressal
						Mechanism </li>
						<li>Establishment of Grievance- Redressal-Committee
						in the Institution and Appointment of OMBUBSMAN by the University </li>
						<li>Establishment of Internal Complaint(ICC) </li>
						<li>Establishment of Committee for SC/ST </li>
						<li>Internal Quality Assurance Cell </li>
						</ul>
						<p>&nbsp;</p>
						<p>6. <strong><span style="text-decoration: underline;">PROGRAMMES</span></strong> </p>
						<p>&nbsp;</p>
						<table class="TableGrid" border="0" cellspacing="0" cellpadding="0" width="608">
						<tbody>
						<tr>
						<td width="48" valign="top">
						<p>
						  </p>
						</td>
						<td width="426" valign="top">
						<p>Name of the programmes
						  approved by the AICTE </p>
						</td>
						<td width="133" valign="top">
						<p>: MCA </p>
						</td>
						</tr>
						<tr>
						<td width="48" valign="top">
						<p>
						  </p>
						</td>
						<td width="426" valign="top">
						<p>Name of the Programmes
						  accredited by the AICTE </p>
						</td>
						<td width="133" valign="top">
						<p>: None </p>
						</td>
						</tr>
						<tr>
						<td width="48" valign="top">
						<p>
						  </p>
						</td>
						<td width="426" valign="top">
						<p>Status of Accreditation of
						  the Courses </p>
						</td>
						<td width="133" valign="top">
						<p>&nbsp;</p>
						</td>
						</tr>
						<tr>
						<td width="48" valign="top">
						<p>&nbsp;</p>
						</td>
						<td width="426" valign="top">
						<p>
						  Total Number of Courses </p>
						</td>
						<td width="133" valign="top">
						<p>: 02 </p>
						</td>
						</tr>
						<tr>
						<td width="48" valign="top">
						<p>&nbsp;</p>
						</td>
						<td width="426" valign="top">
						<p>
						  No. of Courses for which applied for accreditation </p>
						</td>
						<td width="133" valign="top">
						<p>: NIL </p>
						</td>
						</tr>
						<tr>
						<td width="48" valign="top">
						<p>&nbsp;</p>
						</td>
						<td width="426" valign="top">
						<p>
						  Status of Accreditation </p>
						</td>
						<td width="133" valign="top">
						<p>: Preliminary </p>
						</td>
						</tr>
						</tbody>
						</table>
						<p><strong>&nbsp;</strong></p>
						<h2><span style="text-decoration: underline;">Details of Each Course</span> </h2>
						<p>&nbsp;</p>
						<table class="TableGrid" border="0" cellspacing="0" cellpadding="0" width="671">
						<tbody>
						<tr>
						<td colspan="2" width="341" valign="top">
						<p>MCA </p>
						</td>
						<!--<td colspan="2" width="331" valign="top">-->
						<!--<p>PGDM </p>-->
						<!--</td>-->
						</tr>
						<tr>
						<td width="187" valign="top">
						<p>Number
						  of seats &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; : </p>
						</td>
						<td width="154" valign="top">
						<p>30 </p>
						</td>
						<td width="187" valign="top">
						<p>Number
						  of seats &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; : </p>
						</td>
						<td width="144" valign="top">
						<p>60 </p>
						</td>
						</tr>
						<tr>
						<td width="187" valign="top">
						<p>Duration
						  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; : </p>
						</td>
						<td width="154" valign="top">
						<p>3 Years </p>
						</td>
						<td width="187" valign="top">
						<p>Duration
						  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; : </p>
						</td>
						<td width="144" valign="top">
						<p>2 Years </p>
						</td>
						</tr>
						<tr>
						<td width="187" valign="top">
						<p>Cut
						  off rank &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; : </p>
						</td>
						<td width="154" valign="top">
						<p>OJEE </p>
						</td>
						<td width="187" valign="top">
						<p>Cut
						  Off Rank &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; : </p>
						</td>
						<td width="144" valign="top">
						<p>OJEE,MAT, ATMA </p>
						</td>
						</tr>
						<tr>
						<td width="187" valign="top">
						<p>Fee
						  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; : </p>
						</td>
						<td width="154" valign="top">
						<p>Rs.55,000/year </p>
						</td>
						<td width="187" valign="top">
						<p>Fee
						  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; : </p>
						</td>
						<td width="144" valign="top">
						<p>Rs.75,000/year </p>
						</td>
						</tr>
						<tr>
						<td width="187" valign="top">
						<p>Placement Facilities&nbsp; : </p>
						</td>
						<td width="154" valign="top">
						<p>Available </p>
						</td>
						<td width="187" valign="top">
						<p>Placement Facilities&nbsp; : </p>
						</td>
						<td width="144" valign="top">
						<p>Available </p>
						</td>
						</tr>
						<tr>
						<td width="187" valign="top">
						<p>Campus Placement&nbsp; : </p>
						</td>
						<td width="154" valign="top">
						<p>Min.Salary:1.5lakh </p>
						<p>Max. Salary: 3 lak </p>
						<p>Avg. Salary: 2 lakh </p>
						</td>
						<td width="187" valign="top">
						<p>Campus Placement&nbsp; : </p>
						</td>
						<td width="144" valign="top">
						<p>Min.Salary:1 Lakh </p>
						<p>Max. Salary: 3 lakh </p>
						<p>Avg. Salary: 2 lakh </p>
						</td>
						</tr>
						</tbody>
						</table>
						<p>&nbsp;</p>
						<p>
						Name of the programmes having collaboration with Foreign University : NIL </p>
						<p>&nbsp;</p>
						<h1>7. FACULTY </h1>
						<h2><span style="text-decoration: underline;">Branch: MCA</span> </h2>
						<table class="TableGrid" border="0" cellspacing="0" cellpadding="0" width="638">
						<tbody>
						<tr>
						<td width="52" valign="top">
						<p><strong>Sl. </strong></p>
						<p><strong>No. </strong></p>
						</td>
						<td colspan="2" width="125" valign="top">
						<p><strong>Unique
						  Id </strong></p>
						</td>
						<td width="202" valign="top">
						<p><strong>Name
						  </strong></p>
						</td>
						<td width="24" valign="top">
						<p>&nbsp;</p>
						</td>
						<td width="127" valign="top">
						<p><strong>Designation
						  </strong></p>
						</td>
						<td colspan="2" width="107" valign="top">
						<p><strong>Permanent/
						  Adjunct </strong></p>
						</td>
						</tr>
						<tr>
						<td width="52" valign="top">
						<p>01. </p>
						</td>
						<td colspan="2" width="125">
						<p>1-502869461 </p>
						</td>
						<td width="202" valign="top">
						<p>Prof. Pravakar Satapathy </p>
						</td>
						<td width="24" valign="top">
						<p>&nbsp;</p>
						</td>
						<td width="127" valign="top">
						<p>Director, Academics </p>
						</td>
						<td colspan="2" width="107" valign="top">
						<p>Permanent </p>
						</td>
						</tr>
						<tr>
						<td width="52" valign="top">
						<p>02. </p>
						</td>
						<td colspan="2" width="125" valign="top">
						<p>1-502869470 </p>
						</td>
						<td width="202" valign="top">
						<p>Mr. Ashok Kumar Panda </p>
						</td>
						<td width="24" valign="top">
						<p>&nbsp;</p>
						</td>
						<td width="127" valign="top">
						<p>Asst. Professor </p>
						</td>
						<td colspan="2" width="107" valign="top">
						<p>Permanent </p>
						</td>
						</tr>
						<tr>
						<td width="52" valign="top">
						<p>03. </p>
						</td>
						<td colspan="2" width="125" valign="top">
						<p>1-1582074329 </p>
						</td>
						<td width="202" valign="top">
						<p>Mr. Naba Kumar Rath </p>
						</td>
						<td width="24" valign="top">
						<p>&nbsp;</p>
						</td>
						<td width="127" valign="top">
						<p>Asst. Professor </p>
						</td>
						<td colspan="2" width="107" valign="top">
						<p>Permanent </p>
						</td>
						</tr>
						<tr>
						<td colspan="2" width="55" valign="top">
						<p>04. </p>
						</td>
						<td width="123" valign="top">
						<p>1-503329105 </p>
						</td>
						<td colspan="2" width="227" valign="top">
						<p>Mrs. Bhagyalaxmi Mohanty </p>
						</td>
						<td colspan="2" width="136" valign="top">
						<p>Asst. Professor </p>
						</td>
						<td width="98" valign="top">
						<p>Permanent </p>
						</td>
						</tr>
						<tr>
						<td colspan="2" width="55" valign="top">
						<p>05. </p>
						</td>
						<td width="123" valign="top">
						<p>1-503328241 </p>
						</td>
						<td colspan="2" width="227" valign="top">
						<p>Mr. Sanjiv Bhagat </p>
						</td>
						<td colspan="2" width="136" valign="top">
						<p>Asst. Professor </p>
						</td>
						<td width="98" valign="top">
						<p>Permanent </p>
						</td>
						</tr>
						<tr>
						<td colspan="2" width="55" valign="top">
						<p>06. </p>
						</td>
						<td width="123" valign="top">
						<p>1-3636887319 </p>
						</td>
						<td colspan="2" width="227" valign="top">
						<p>Mrs. Mousumi Mohanty </p>
						</td>
						<td colspan="2" width="136" valign="top">
						<p>Asst. Professor </p>
						</td>
						<td width="98" valign="top">
						<p>Permanent </p>
						</td>
						</tr>
						<tr>
						<td colspan="2" width="55" valign="top">
						<p>07. </p>
						</td>
						<td width="123" valign="top">
						<p>1-2946969316 </p>
						</td>
						<td colspan="2" width="227" valign="top">
						<p>Mr. Manas Ranjan Satpathy </p>
						</td>
						<td colspan="2" width="136" valign="top">
						<p>Asst. Professor </p>
						</td>
						<td width="98" valign="top">
						<p>Permanent </p>
						</td>
						</tr>
						<tr>
						<td colspan="2" width="55" valign="top">
						<p>08. </p>
						</td>
						<td width="123" valign="top">
						<p>1-818330230 </p>
						</td>
						<td colspan="2" width="227" valign="top">
						<p>Mr.Sanjay Rout </p>
						</td>
						<td colspan="2" width="136" valign="top">
						<p>Asst. Professor </p>
						</td>
						<td width="98" valign="top">
						<p>Permanent </p>
						</td>
						</tr>
						<tr>
						<td colspan="2" width="55" valign="top">
						<p>09. </p>
						</td>
						<td width="123" valign="top">
						<p>1-503328873 </p>
						</td>
						<td colspan="2" width="227" valign="top">
						<p>Mr.Bhabani Pattanaik </p>
						</td>
						<td colspan="2" width="136" valign="top">
						<p>Asst. Professor </p>
						</td>
						<td width="98" valign="top">
						<p>Permanent </p>
						<p>&nbsp;</p>
						</td>
						</tr>
						<tr height="0">
						<td width="52">&nbsp;</td>
						<td width="2">&nbsp;</td>
						<td width="123">&nbsp;</td>
						<td width="202">&nbsp;</td>
						<td width="24">&nbsp;</td>
						<td width="127">&nbsp;</td>
						<td width="9">&nbsp;</td>
						<td width="98">&nbsp;</td>
						</tr>
						</tbody>
						</table>
						<p><strong>&nbsp;</strong></p>
						<ul>
						<li>Permanent Faculty&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; :&nbsp; 09 </li>
						<li>Adjunct Faculty&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; : Nil </li>
						<li>Permanent Faculty: Student Ratio =&nbsp; 1:10&nbsp; </li>
						</ul>
						<p><strong>&nbsp;</strong></p>
						<!--<p><strong><span style="text-decoration: underline;">Branch:PGDM</span> </strong></p>-->
						<table class="TableGrid" border="0" cellspacing="0" cellpadding="0" width="638">
						<tbody>
						<tr>
						<td width="55" valign="top">
						<p><strong>Sl. </strong></p>
						<p><strong>No. </strong></p>
						</td>
						<td width="123" valign="top">
						<p><strong>Unique
						  Id </strong></p>
						</td>
						<td width="227" valign="top">
						<p><strong>Name
						  </strong></p>
						</td>
						<td width="136" valign="top">
						<p><strong>Designation
						  </strong></p>
						</td>
						<td width="98" valign="top">
						<p><strong>Permanent/
						  Adjunct </strong></p>
						</td>
						</tr>
						<tr>
						<td width="55" valign="top">
						<p>01. </p>
						</td>
						<td width="123" valign="top">
						<p>1-3607448773 </p>
						</td>
						<td width="227" valign="top">
						<p>Prof. Dr. J. K. Panda </p>
						</td>
						<td width="136" valign="top">
						<p>Director </p>
						</td>
						<td width="98" valign="top">
						<p>Permanent </p>
						</td>
						</tr>
						<tr>
						<td width="55" valign="top">
						<p>02. </p>
						</td>
						<td width="123" valign="top">
						<p>1-502870198 </p>
						</td>
						<td width="227" valign="top">
						<p>Mrs. Ranjita Dash </p>
						</td>
						<td width="136" valign="top">
						<p>Asst. Professor </p>
						</td>
						<td width="98" valign="top">
						<p>Permanent </p>
						</td>
						</tr>
						<tr>
						<td width="55" valign="top">
						<p>03. </p>
						</td>
						<td width="123" valign="top">
						<p>1-3607570755 </p>
						</td>
						<td width="227" valign="top">
						<p>Mrs.Moonmoon Brahma </p>
						</td>
						<td width="136" valign="top">
						<p>Asst. Professor </p>
						</td>
						<td width="98" valign="top">
						<p>Permanent </p>
						</td>
						</tr>
						<tr>
						<td width="55" valign="top">
						<p>04. </p>
						</td>
						<td width="123" valign="top">
						<p>1-818330222 </p>
						</td>
						<td width="227" valign="top">
						<p>Mr. Suryasnata Dash </p>
						</td>
						<td width="136" valign="top">
						<p>Asst. Professor </p>
						</td>
						<td width="98" valign="top">
						<p>Permanent </p>
						</td>
						</tr>
						<tr>
						<td width="55" valign="top">
						<p>05. </p>
						</td>
						<td width="123" valign="top">
						<p>1-3610359460 </p>
						</td>
						<td width="227" valign="top">
						<p>Mrs. Simmi Bhagat </p>
						</td>
						<td width="136" valign="top">
						<p>Asst. Professor </p>
						</td>
						<td width="98" valign="top">
						<p>Permanent </p>
						</td>
						</tr>
						<tr>
						<td width="55" valign="top">
						<p>06. </p>
						</td>
						<td width="123" valign="top">
						<p>1-3636726946 </p>
						</td>
						<td width="227" valign="top">
						<p>Mrs. Manjushree Mohapatra </p>
						</td>
						<td width="136" valign="top">
						<p>Asst. Professor </p>
						</td>
						<td width="98" valign="top">
						<p>Permanent </p>
						</td>
						</tr>
						<tr>
						<td width="55" valign="top">
						<p>07. </p>
						</td>
						<td width="123" valign="top">
						<p>1-3636780525 </p>
						</td>
						<td width="227" valign="top">
						<p>Mrs. Sonali Mohapatra </p>
						</td>
						<td width="136" valign="top">
						<p>Asst. Professor </p>
						</td>
						<td width="98" valign="top">
						<p>Permanent </p>
						</td>
						</tr>
						</tbody>
						</table>
						<p><strong>&nbsp;</strong></p>
						<ul>
						<li>Permanent Faculty&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; :&nbsp; 07 </li>
						<li>Adjunct Faculty&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; : Nil </li>
						<li>Permanent Faculty: Student Ratio =&nbsp; 1:17&nbsp; </li>
						</ul>
						<p><strong>&nbsp;</strong></p>
						<p><strong>&nbsp;</strong></p>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<table class="TableGrid" border="0" cellspacing="0" cellpadding="0" width="606">
						<tbody>
						<tr>
						<td width="225" valign="top">
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						</td>
						<td width="40" valign="top">
						<p>&nbsp;</p>
						</td>
						<td width="340" valign="top">
						<p>&nbsp;</p>
						</td>
						</tr>
						<tr>
						<td width="225" valign="bottom">
						<p>Name </p>
						</td>
						<td width="40" valign="bottom">
						<p>: </p>
						</td>
						<td width="340" valign="bottom">
						<p>Prof. (Dr.) Jaya Krushna
						  Panda </p>
						</td>
						</tr>
						<tr>
						<td width="225" valign="top">
						<p>Date of Birth </p>
						</td>
						<td width="40" valign="top">
						<p>: </p>
						</td>
						<td width="340" valign="top">
						<p>18.01.1956 </p>
						</td>
						</tr>
						<tr>
						<td width="225" valign="top">
						<p>Unique Id </p>
						</td>
						<td width="40" valign="top">
						<p>: </p>
						</td>
						<td width="340" valign="top">
						<p>1-3607448773 </p>
						</td>
						</tr>
						<tr>
						<td width="225" valign="top">
						<p>Educational Qualification </p>
						</td>
						<td width="40" valign="top">
						<p>: </p>
						</td>
						<td width="340" valign="top">
						<p>M.Com from Delhi School of Economics,Delhi </p>
						<p>University,1978 </p>
						<p>&nbsp;PhD. From Sagar Central University,1986 </p>
						</td>
						</tr>
						<tr>
						<td width="225" valign="top">
						<p>Work Experience </p>
						</td>
						<td width="40" valign="top">
						<p>: </p>
						</td>
						<td width="340" valign="top">
						<p>Teaching : 37 Years </p>
						<p>&nbsp;&nbsp;&nbsp; (i)Lecturer:8 years </p>
						<p>&nbsp;&nbsp;&nbsp; (ii)Reader:13years </p>
						<p>&nbsp;&nbsp;&nbsp; (iii)Professor:16 years&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </p>
						<p>Research: 5 Years </p>
						</td>
						</tr>
						<tr>
						<td width="225" valign="top">
						<p>Area of Specialization </p>
						</td>
						<td width="40" valign="top">
						<p>: </p>
						</td>
						<td width="340" valign="top">
						<p>Finance </p>
						<p>Accounting </p>
						<p>Marketing </p>
						<p>Research Methodology </p>
						<p>Economics </p>
						<p>Human Resource Management </p>
						</td>
						</tr>
						<tr>
						<td width="225" valign="top">
						<p>Courses Taught at PG Level </p>
						</td>
						<td width="40" valign="top">
						<p>: </p>
						</td>
						<td width="340" valign="top">
						<p>Financial Accounting </p>
						<p>Research Methodology </p>
						<p>Economics </p>
						<p>Human Resource
						  Management&nbsp; </p>
						</td>
						</tr>
						<tr>
						<td width="225" valign="top">
						<p>Research guidance </p>
						</td>
						<td width="40" valign="top">
						<p>: </p>
						</td>
						<td width="340" valign="top">
						<p>&nbsp;(i)D.Litt awarded-1 Scholar </p>
						<p>(ii)Ph.D awarded-25
						  Scholars </p>
						<p>(iii)Ph.D Submiting-3
						  Scholars </p>
						<p>(iv) Ph.D Pursuing-4
						  Scholars (v)D.Litt&nbsp; Pursuing-3 Scholars
						  </p>
						<p>&nbsp;</p>
						</td>
						</tr>
						<tr>
						<td width="225" valign="top">
						<p>Research Publications </p>
						</td>
						<td width="40" valign="top">
						<p>: </p>
						</td>
						<td width="340" valign="top">
						<p>Total:57 papers
						  published&nbsp;&nbsp; </p>
						<p>(i)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						  Scopus-2 numbers </p>
						<p>(ii)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						  International Journals:42&nbsp; numbers </p>
						<p>(iii)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						  National Journals:13 numbers </p>
						</td>
						</tr>
						<tr>
						<td width="225" valign="top">
						<p>Patents </p>
						</td>
						<td width="40" valign="top">
						<p>: </p>
						</td>
						<td width="340" valign="top">
						<p>NIL </p>
						</td>
						</tr>
						<tr>
						<td width="225" valign="top">
						<p>No. of Books published&nbsp; </p>
						</td>
						<td colspan="2" width="381" valign="top">
						<p>`: 8 </p>
						</td>
						</tr>
						</tbody>
						</table>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<table class="TableGrid" border="0" cellspacing="0" cellpadding="0" width="572">
						<tbody>
						<tr>
						<td width="233" valign="top">
						<p>&nbsp;</p>
						</td>
						<td colspan="2" width="339" valign="top">
						<p>&nbsp;</p>
						</td>
						</tr>
						<tr>
						<td width="233" valign="bottom">
						<p>Name </p>
						</td>
						<td width="33" valign="bottom">
						<p>: </p>
						</td>
						<td width="306" valign="bottom">
						<p>Ashok Kumar Panda </p>
						</td>
						</tr>
						<tr>
						<td width="233" valign="top">
						<p>Date of Birth </p>
						</td>
						<td width="33" valign="top">
						<p>: </p>
						</td>
						<td width="306" valign="top">
						<p>07.07.1974 </p>
						</td>
						</tr>
						<tr>
						<td width="233" valign="top">
						<p>Unique Id </p>
						</td>
						<td width="33" valign="top">
						<p>: </p>
						</td>
						<td width="306" valign="top">
						<p>1-502869470 </p>
						</td>
						</tr>
						<tr>
						<td width="233" valign="top">
						<p>Educational Qualification </p>
						</td>
						<td width="33" valign="top">
						<p>: </p>
						</td>
						<td width="306" valign="top">
						<p>MCA, M.tech., PhD
						  Continuing. </p>
						</td>
						</tr>
						<tr>
						<td width="233" valign="top">
						<p>Work Experience </p>
						</td>
						<td width="33" valign="top">
						<p>: </p>
						</td>
						<td width="306" valign="top">
						<p>Teaching : 19 years Research: 1 year </p>
						</td>
						</tr>
						<tr>
						<td width="233" valign="top">
						<p>Area of Specialization </p>
						</td>
						<td width="33" valign="top">
						<p>: </p>
						</td>
						<td width="306" valign="top">
						<p>Real Time Database Management System </p>
						</td>
						</tr>
						<tr>
						<td width="233" valign="top">
						<p>Courses Taught at PG Level </p>
						</td>
						<td width="33" valign="top">
						<p>: </p>
						</td>
						<td width="306" valign="top">
						<p>DBMS, QT, DMS, NM, P &amp;S
						  </p>
						</td>
						</tr>
						<tr>
						<td width="233" valign="top">
						<p>Research guidance </p>
						</td>
						<td width="33" valign="top">
						<p>: </p>
						</td>
						<td width="306" valign="top">
						<p>No. of papers
						  published:&nbsp; </p>
						<p>International journal: 6 </p>
						<p>National Journal: 1&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </p>
						</td>
						</tr>
						<tr>
						<td width="233" valign="top">
						<p>Projects&nbsp; carried out </p>
						</td>
						<td width="33" valign="top">
						<p>: </p>
						</td>
						<td width="306" valign="top">
						<p>None </p>
						</td>
						</tr>
						<tr>
						<td width="233" valign="top">
						<p>Patents </p>
						</td>
						<td width="33" valign="top">
						<p>: </p>
						</td>
						<td width="306" valign="top">
						<p>NIL </p>
						</td>
						</tr>
						<tr>
						<td width="233" valign="top">
						<p>No. of Books published&nbsp; </p>
						</td>
						<td colspan="2" width="339" valign="top">
						<p>`: NIL </p>
						</td>
						</tr>
						</tbody>
						</table>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<table class="TableGrid" border="0" cellspacing="0" cellpadding="0" width="610">
						<tbody>
						<tr>
						<td width="241" valign="top">
						<p>Name </p>
						</td>
						<td width="24" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>Prof. Pravakar Satapathy </p>
						</td>
						</tr>
						<tr>
						<td width="241" valign="top">
						<p>Date of Birth </p>
						</td>
						<td width="24" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>14.04.1936 </p>
						</td>
						</tr>
						<tr>
						<td width="241" valign="top">
						<p>Unique Id </p>
						</td>
						<td width="24" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>1-502869461 </p>
						</td>
						</tr>
						<tr>
						<td width="241" valign="top">
						<p>Educational Qualification </p>
						</td>
						<td width="24" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>M.A (Economics) </p>
						</td>
						</tr>
						<tr>
						<td width="241" valign="top">
						<p>Work Experience </p>
						</td>
						<td width="24" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>Teaching : 20 years Research: 2 years </p>
						</td>
						</tr>
						<tr>
						<td width="241" valign="top">
						<p>Area of Specialization </p>
						</td>
						<td width="24" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>Economics </p>
						</td>
						</tr>
						<tr>
						<td width="241" valign="top">
						<p>Courses Taught at PG Level </p>
						</td>
						<td width="24" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>Managerial
						  Economics,Business Enviornment </p>
						</td>
						</tr>
						<tr>
						<td width="241" valign="top">
						<p>Research guidance </p>
						</td>
						<td width="24" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>No. of papers published: 5 national journal&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </p>
						</td>
						</tr>
						<tr>
						<td width="241" valign="top">
						<p>Projects&nbsp; carried out </p>
						</td>
						<td width="24" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>&nbsp;</p>
						</td>
						</tr>
						<tr>
						<td width="241" valign="top">
						<p>Patents </p>
						</td>
						<td width="24" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>NIL </p>
						</td>
						</tr>
						<tr>
						<td width="241" valign="top">
						<p>No. of Books published&nbsp; </p>
						</td>
						<td colspan="2" width="368" valign="top">
						<p>`: NIL </p>
						</td>
						</tr>
						</tbody>
						</table>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<table class="TableGrid" border="0" cellspacing="0" cellpadding="0" width="610">
						<tbody>
						<tr>
						<td width="225" valign="top">
						<p>Name </p>
						</td>
						<td width="41" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>Naba Kumar Rath </p>
						</td>
						</tr>
						<tr>
						<td width="225" valign="top">
						<p>Date of Birth </p>
						</td>
						<td width="41" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>27.07.1986 </p>
						</td>
						</tr>
						<tr>
						<td width="225" valign="top">
						<p>Unique Id </p>
						</td>
						<td width="41" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>1-1582074329 </p>
						</td>
						</tr>
						<tr>
						<td width="225" valign="top">
						<p>Educational Qualification </p>
						</td>
						<td width="41" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>MCA,M.Tech,PhD Continuing..
						  </p>
						</td>
						</tr>
						<tr>
						<td width="225" valign="top">
						<p>Work Experience </p>
						</td>
						<td width="41" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>Teaching : 5 Years Research: 1 year </p>
						</td>
						</tr>
						<tr>
						<td width="225" valign="top">
						<p>Area of Specialization </p>
						</td>
						<td width="41" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>Cloud Computing </p>
						</td>
						</tr>
						<tr>
						<td width="225" valign="top">
						<p>Courses Taught at PG Level </p>
						</td>
						<td width="41" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>C-Programming, </p>
						<p>Data Strucures Using C </p>
						<p>DAA,DBMS </p>
						</td>
						</tr>
						<tr>
						<td width="225" valign="top">
						<p>Research guidance </p>
						</td>
						<td width="41" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>No. of papers published: 1 national journal&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </p>
						</td>
						</tr>
						<tr>
						<td width="225" valign="top">
						<p>Projects&nbsp; carried out </p>
						</td>
						<td width="41" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>&nbsp;</p>
						</td>
						</tr>
						<tr>
						<td width="225" valign="top">
						<p>Patents </p>
						</td>
						<td width="41" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>NIL </p>
						</td>
						</tr>
						<tr>
						<td width="225" valign="top">
						<p>No. of Books published&nbsp; </p>
						<p>&nbsp;</p>
						</td>
						<td colspan="2" width="385" valign="top">
						<p>`: NIL </p>
						</td>
						</tr>
						</tbody>
						</table>
						<p>&nbsp;</p>
						<table class="TableGrid" border="0" cellspacing="0" cellpadding="0" width="564">
						<tbody>
						<tr>
						<td width="225" valign="top">
						<p>&nbsp;</p>
						</td>
						<td width="41" valign="top">
						<p>&nbsp;</p>
						</td>
						<td width="298" valign="top">
						<p>&nbsp;</p>
						</td>
						</tr>
						<tr>
						<td width="225" valign="bottom">
						<p>Name </p>
						</td>
						<td width="41" valign="bottom">
						<p>: </p>
						</td>
						<td width="298" valign="bottom">
						<p>Bhagyalaxmi Mohanty </p>
						</td>
						</tr>
						<tr>
						<td width="225" valign="top">
						<p>Date of Birth </p>
						</td>
						<td width="41" valign="top">
						<p>: </p>
						</td>
						<td width="298" valign="top">
						<p>20.05.1985 </p>
						</td>
						</tr>
						<tr>
						<td width="225" valign="top">
						<p>Unique Id </p>
						</td>
						<td width="41" valign="top">
						<p>: </p>
						</td>
						<td width="298" valign="top">
						<p>1-503329105 </p>
						</td>
						</tr>
						<tr>
						<td width="225" valign="top">
						<p>Educational Qualification </p>
						</td>
						<td width="41" valign="top">
						<p>: </p>
						</td>
						<td width="298" valign="top">
						<p>B.Sc(Hons),MCA </p>
						</td>
						</tr>
						<tr>
						<td width="225" valign="top">
						<p>Work Experience </p>
						</td>
						<td width="41" valign="top">
						<p>: </p>
						</td>
						<td width="298" valign="top">
						<p>Teaching : 8years </p>
						<p>Research: 1 year </p>
						<p>Industry:3 Years </p>
						</td>
						</tr>
						<tr>
						<td width="225" valign="top">
						<p>Area of Specialization </p>
						</td>
						<td width="41" valign="top">
						<p>: </p>
						</td>
						<td width="298" valign="top">
						<p>Computer
						  Graphics Operating System </p>
						</td>
						</tr>
						<tr>
						<td width="225" valign="top">
						<p>Courses Taught at PG Level </p>
						</td>
						<td width="41" valign="top">
						<p>: </p>
						</td>
						<td width="298" valign="top">
						<p>Distributed Systems Java programming </p>
						</td>
						</tr>
						<tr>
						<td width="225" valign="top">
						<p>Research guidance </p>
						</td>
						<td width="41" valign="top">
						<p>: </p>
						</td>
						<td width="298" valign="top">
						<p>No. of papers published: 0&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </p>
						</td>
						</tr>
						<tr>
						<td width="225" valign="top">
						<p>Projects&nbsp; carried out </p>
						</td>
						<td width="41" valign="top">
						<p>: </p>
						</td>
						<td width="298" valign="top">
						<p>&nbsp;</p>
						</td>
						</tr>
						<tr>
						<td width="225" valign="top">
						<p>Patents </p>
						</td>
						<td width="41" valign="top">
						<p>: </p>
						</td>
						<td width="298" valign="top">
						<p>NIL </p>
						</td>
						</tr>
						<tr>
						<td width="225" valign="top">
						<p>No. of Books published&nbsp; </p>
						</td>
						<td colspan="2" width="339" valign="top">
						<p>`: NIL </p>
						</td>
						</tr>
						</tbody>
						</table>
						<p>&nbsp;</p>
						<table class="TableGrid" border="0" cellspacing="0" cellpadding="0" width="610">
						<tbody>
						<tr>
						<td width="227" valign="top">
						<p>&nbsp;</p>
						</td>
						<td width="39" valign="top">
						<p>&nbsp;</p>
						</td>
						<td width="344" valign="top">
						<p>&nbsp;</p>
						</td>
						</tr>
						<tr>
						<td width="227" valign="bottom">
						<p>Name </p>
						</td>
						<td width="39" valign="bottom">
						<p>: </p>
						</td>
						<td width="344" valign="bottom">
						<p>Sanjiv Bhagat </p>
						</td>
						</tr>
						<tr>
						<td width="227" valign="top">
						<p>Date of Birth </p>
						</td>
						<td width="39" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>14-09-1974 </p>
						</td>
						</tr>
						<tr>
						<td width="227" valign="top">
						<p>Unique Id </p>
						</td>
						<td width="39" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>1-503328241 </p>
						</td>
						</tr>
						<tr>
						<td width="227" valign="top">
						<p>Educational Qualification </p>
						</td>
						<td width="39" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>MCA , PGDM </p>
						</td>
						</tr>
						<tr>
						<td width="227" valign="top">
						<p>Work Experience </p>
						</td>
						<td width="39" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>Teaching : 20 years Research: 2 years </p>
						</td>
						</tr>
						<tr>
						<td width="227" valign="top">
						<p>Area of Specialization </p>
						</td>
						<td width="39" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>Managerial Economics </p>
						</td>
						</tr>
						<tr>
						<td width="227" valign="top">
						<p>Courses Taught at PG Level </p>
						</td>
						<td width="39" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>Computer Graphics ,MIS </p>
						</td>
						</tr>
						<tr>
						<td width="227" valign="top">
						<p>Research guidance </p>
						</td>
						<td width="39" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>No. of papers published: 4 national journal&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </p>
						</td>
						</tr>
						<tr>
						<td width="227" valign="top">
						<p>Projects&nbsp; carried out </p>
						</td>
						<td width="39" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>&nbsp;</p>
						</td>
						</tr>
						<tr>
						<td width="227" valign="top">
						<p>Patents </p>
						</td>
						<td width="39" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>NIL </p>
						</td>
						</tr>
						<tr>
						<td width="227" valign="top">
						<p>No. of Books published&nbsp; </p>
						<p>&nbsp;</p>
						</td>
						<td colspan="2" width="383" valign="top">
						<p>`: NIL </p>
						</td>
						</tr>
						</tbody>
						</table>
						<table class="TableGrid" border="0" cellspacing="0" cellpadding="0" width="541" align="left">
						<tbody>
						<tr>
						<td rowspan="3" width="227" valign="top">
						<p>&nbsp;</p>
						<p>Name
						  </p>
						<p>Date
						  of Birth </p>
						<p>Unique
						  Id </p>
						<p>Educational
						  Qualification Work Experience </p>
						<p>Area
						  of Specialization </p>
						<p>Courses
						  Taught at PG Level </p>
						<p>Research
						  guidance </p>
						<p>Projects&nbsp; carried out </p>
						<p>Patents
						  </p>
						<p>No.
						  of Books published&nbsp; </p>
						</td>
						<td colspan="2" width="315" valign="top">
						<p>&nbsp;</p>
						</td>
						</tr>
						<tr>
						<td width="39" valign="top">
						<p>: </p>
						<p>: </p>
						<p>: </p>
						<p>: </p>
						<p>: </p>
						<p>: </p>
						<p>: </p>
						<p>: </p>
						<p>: </p>
						<p>: </p>
						</td>
						<td width="276" valign="top">
						<p>Mousumi
						  Mohanty </p>
						<p>18.07.1983
						  </p>
						<p>1-3636887319
						  </p>
						<p>MCA
						  </p>
						<p>Teaching
						  : 2 years </p>
						<p>Research:
						  1 year </p>
						<p>Industry:4
						  Years </p>
						<p>Operating
						  System </p>
						<p>Managerial
						  Economics,DBMS </p>
						<p>No. of papers
						  published:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </p>
						<p>&nbsp;</p>
						<p>NIL
						  </p>
						</td>
						</tr>
						<tr>
						<td colspan="2" width="315" valign="top">
						<p>`:
						  NIL </p>
						</td>
						</tr>
						</tbody>
						</table>
						<p>&nbsp;</p>
						<table class="TableGrid" border="0" cellspacing="0" cellpadding="0" width="610" align="left">
						<tbody>
						<tr>
						<td width="210" valign="top">
						<p>&nbsp;</p>
						</td>
						<td colspan="2" width="399" valign="top">
						<p>&nbsp;</p>
						</td>
						</tr>
						<tr>
						<td width="210" valign="bottom">
						<p>Name
						  </p>
						</td>
						<td width="56" valign="bottom">
						<p>: </p>
						</td>
						<td width="344" valign="bottom">
						<p>Sanjay
						  Rout </p>
						</td>
						</tr>
						<tr>
						<td width="210" valign="top">
						<p>Date
						  of Birth </p>
						</td>
						<td width="56" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>05.10.1986
						  </p>
						</td>
						</tr>
						<tr>
						<td width="210" valign="top">
						<p>Unique
						  Id </p>
						</td>
						<td width="56" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>1-818330230
						  </p>
						</td>
						</tr>
						<tr>
						<td width="210" valign="top">
						<p>Educational
						  Qualification </p>
						</td>
						<td width="56" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>MCA
						  </p>
						</td>
						</tr>
						<tr>
						<td width="210" valign="top">
						<p>Work
						  Experience </p>
						</td>
						<td width="56" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>Teaching
						  : 8 years </p>
						<p>Research:
						  1 year </p>
						<p>Industry:4
						  Years </p>
						</td>
						</tr>
						<tr>
						<td width="210" valign="top">
						<p>Area
						  of Specialization </p>
						</td>
						<td width="56" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>Data Warehouse, Data Mining </p>
						</td>
						</tr>
						<tr>
						<td width="210" valign="top">
						<p>Courses Taught at PG Level </p>
						</td>
						<td width="56" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>Compiler
						  Design, </p>
						<p>Theory
						  of Computation </p>
						</td>
						</tr>
						<tr>
						<td width="210" valign="top">
						<p>Research
						  guidance </p>
						</td>
						<td width="56" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>No. of papers published: 2
						  national journal&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </p>
						</td>
						</tr>
						<tr>
						<td width="210" valign="top">
						<p>Projects&nbsp; carried out </p>
						</td>
						<td width="56" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>NIL
						  </p>
						</td>
						</tr>
						<tr>
						<td width="210" valign="top">
						<p>Patents
						  </p>
						</td>
						<td width="56" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>NIL
						  </p>
						</td>
						</tr>
						<tr>
						<td width="210" valign="top">
						<p>No.
						  of Books published&nbsp; </p>
						</td>
						<td colspan="2" width="399" valign="top">
						<p>`:
						  NIL </p>
						</td>
						</tr>
						</tbody>
						</table>
						<p>&nbsp;</p>
						<table class="TableGrid" border="0" cellspacing="0" cellpadding="0" width="610">
						<tbody>
						<tr>
						<td width="210" valign="top">
						<p>Name </p>
						</td>
						<td width="55" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>Manas Ranjan Satpathy </p>
						</td>
						</tr>
						<tr>
						<td width="210" valign="top">
						<p>Date of Birth </p>
						</td>
						<td width="55" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>30.04.1987 </p>
						</td>
						</tr>
						<tr>
						<td width="210" valign="top">
						<p>Unique Id </p>
						</td>
						<td width="55" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>1-2946969316 </p>
						</td>
						</tr>
						<tr>
						<td width="210" valign="top">
						<p>Educational Qualification </p>
						</td>
						<td width="55" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>MCA,M.tech </p>
						</td>
						</tr>
						<tr>
						<td width="210" valign="top">
						<p>Work Experience </p>
						</td>
						<td width="55" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>Teaching : 3 years Research: 1 year </p>
						</td>
						</tr>
						<tr>
						<td width="210" valign="top">
						<p>Area of Specialization </p>
						</td>
						<td width="55" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>Real time Operating System </p>
						</td>
						</tr>
						<tr>
						<td width="210" valign="top">
						<p>Courses Taught at PG Level </p>
						</td>
						<td width="55" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>Networking,MIS,C
						  Programming </p>
						</td>
						</tr>
						<tr>
						<td width="210" valign="top">
						<p>Research guidance </p>
						</td>
						<td width="55" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>No. of papers published: 1 national journal&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </p>
						</td>
						</tr>
						<tr>
						<td width="210" valign="top">
						<p>Projects&nbsp; carried out </p>
						</td>
						<td width="55" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>NIL </p>
						</td>
						</tr>
						<tr>
						<td width="210" valign="top">
						<p>Patents </p>
						</td>
						<td width="55" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>NIL </p>
						</td>
						</tr>
						<tr>
						<td width="210" valign="top">
						<p>No. of Books published&nbsp; </p>
						<p>&nbsp;</p>
						</td>
						<td colspan="2" width="399" valign="top">
						<p>`: NIL </p>
						</td>
						</tr>
						</tbody>
						</table>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<table class="TableGrid" border="0" cellspacing="0" cellpadding="0" width="550">
						<tbody>
						<tr>
						<td width="239" valign="top">
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						</td>
						<td width="26" valign="top">
						<p>&nbsp;</p>
						</td>
						<td width="285" valign="top">
						<p>&nbsp;</p>
						</td>
						</tr>
						<tr>
						<td width="239" valign="bottom">
						<p>Name </p>
						</td>
						<td width="26" valign="bottom">
						<p>: </p>
						</td>
						<td width="285" valign="bottom">
						<p>Bhabani Pattanaik </p>
						</td>
						</tr>
						<tr>
						<td width="239" valign="top">
						<p>Date of Birth </p>
						</td>
						<td width="26" valign="top">
						<p>: </p>
						</td>
						<td width="285" valign="top">
						<p>03.05.1978 </p>
						</td>
						</tr>
						<tr>
						<td width="239" valign="top">
						<p>Unique Id </p>
						</td>
						<td width="26" valign="top">
						<p>: </p>
						</td>
						<td width="285" valign="top">
						<p>1-503328873 </p>
						</td>
						</tr>
						<tr>
						<td width="239" valign="top">
						<p>Educational Qualification </p>
						</td>
						<td width="26" valign="top">
						<p>: </p>
						</td>
						<td width="285" valign="top">
						<p>MCA </p>
						</td>
						</tr>
						<tr>
						<td width="239" valign="top">
						<p>Work Experience </p>
						</td>
						<td width="26" valign="top">
						<p>: </p>
						</td>
						<td width="285" valign="top">
						<p>Teaching : 10 years </p>
						<p>Research: 2 years </p>
						<p>Industry:3years </p>
						</td>
						</tr>
						<tr>
						<td width="239" valign="top">
						<p>Area of Specialization </p>
						</td>
						<td width="26" valign="top">
						<p>: </p>
						</td>
						<td width="285" valign="top">
						<p>Java Programming </p>
						</td>
						</tr>
						<tr>
						<td width="239" valign="top">
						<p>Courses Taught at PG Level </p>
						</td>
						<td width="26" valign="top">
						<p>: </p>
						</td>
						<td width="285" valign="top">
						<p>C++,Networking </p>
						</td>
						</tr>
						<tr>
						<td width="239" valign="top">
						<p>Research guidance </p>
						</td>
						<td width="26" valign="top">
						<p>: </p>
						</td>
						<td width="285" valign="top">
						<p>No. of papers published:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </p>
						</td>
						</tr>
						<tr>
						<td width="239" valign="top">
						<p>Projects&nbsp; carried out </p>
						</td>
						<td width="26" valign="top">
						<p>: </p>
						</td>
						<td width="285" valign="top">
						<p>NIL </p>
						</td>
						</tr>
						<tr>
						<td width="239" valign="top">
						<p>Patents </p>
						</td>
						<td width="26" valign="top">
						<p>: </p>
						</td>
						<td width="285" valign="top">
						<p>NIL </p>
						</td>
						</tr>
						<tr>
						<td width="239" valign="top">
						<p>No. of Books published&nbsp; </p>
						</td>
						<td colspan="2" width="311" valign="top">
						<p>`: NIL </p>
						</td>
						</tr>
						</tbody>
						</table>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<table class="TableGrid" border="0" cellspacing="0" cellpadding="0" width="537" align="left">
						<tbody>
						<tr>
						<td width="212" valign="top">
						<p>&nbsp;</p>
						</td>
						<td colspan="2" width="325" valign="top">
						<p>&nbsp;</p>
						</td>
						</tr>
						<tr>
						<td width="212" valign="top">
						<p>Name
						  </p>
						</td>
						<td width="54" valign="top">
						<p>: </p>
						</td>
						<td width="271" valign="top">
						<p><span style="text-decoration: underline;">Moonmoon Brahma</span> </p>
						</td>
						</tr>
						<tr>
						<td width="212" valign="top">
						<p>Date
						  of Birth </p>
						</td>
						<td width="54" valign="top">
						<p>: </p>
						</td>
						<td width="271" valign="top">
						<p>15.03.1983
						  </p>
						</td>
						</tr>
						<tr>
						<td width="212" valign="top">
						<p>Unique
						  Id </p>
						</td>
						<td width="54" valign="top">
						<p>: </p>
						</td>
						<td width="271" valign="top">
						<p>1-3607570755
						  </p>
						</td>
						</tr>
						<tr>
						<td width="212" valign="top">
						<p>Educational
						  Qualification </p>
						</td>
						<td width="54" valign="top">
						<p>: </p>
						</td>
						<td width="271" valign="top">
						<p>MBA
						  </p>
						</td>
						</tr>
						<tr>
						<td width="212" valign="top">
						<p>Work
						  Experience </p>
						</td>
						<td width="54" valign="top">
						<p>: </p>
						</td>
						<td width="271" valign="top">
						<p>Teaching
						  : 2 years </p>
						<p>Research:
						  2 years </p>
						<p>Industry:3
						  years </p>
						</td>
						</tr>
						<tr>
						<td width="212" valign="top">
						<p>Area
						  of Specialization </p>
						</td>
						<td width="54" valign="top">
						<p>: </p>
						</td>
						<td width="271" valign="top">
						<p>Human
						  Resource </p>
						</td>
						</tr>
						<tr>
						<td width="212" valign="top">
						<p>Courses Taught at PG Level </p>
						</td>
						<td width="54" valign="top">
						<p>: </p>
						</td>
						<td width="271" valign="top">
						<p>Manpower
						  Planning </p>
						<p>Customer Relationship
						  Management </p>
						<p>OB,CM,HRD
						  </p>
						</td>
						</tr>
						<tr>
						<td width="212" valign="top">
						<p>Research
						  guidance </p>
						</td>
						<td width="54" valign="top">
						<p>: </p>
						</td>
						<td width="271" valign="top">
						<p>No. of papers
						  published:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </p>
						</td>
						</tr>
						<tr>
						<td width="212" valign="top">
						<p>Projects&nbsp; carried out </p>
						</td>
						<td width="54" valign="top">
						<p>: </p>
						</td>
						<td width="271" valign="top">
						<p>NIL
						  </p>
						</td>
						</tr>
						<tr>
						<td width="212" valign="top">
						<p>Patents
						  </p>
						</td>
						<td width="54" valign="top">
						<p>: </p>
						</td>
						<td width="271" valign="top">
						<p>NIL
						  </p>
						</td>
						</tr>
						<tr>
						<td width="212" valign="top">
						<p>No.
						  of Books published&nbsp; </p>
						</td>
						<td colspan="2" width="325" valign="top">
						<p>`:
						  NIL </p>
						</td>
						</tr>
						</tbody>
						</table>
						<p>&nbsp;</p>
						<table class="TableGrid" border="0" cellspacing="0" cellpadding="0" width="610">
						<tbody>
						<tr>
						<td width="212" valign="top">
						<p>Name </p>
						</td>
						<td width="53" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>Ranjita Dash </p>
						</td>
						</tr>
						<tr>
						<td width="212" valign="top">
						<p>Date of Birth </p>
						</td>
						<td width="53" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>07.07.1980 </p>
						</td>
						</tr>
						<tr>
						<td width="212" valign="top">
						<p>Unique Id </p>
						</td>
						<td width="53" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>1-502870198 </p>
						</td>
						</tr>
						<tr>
						<td width="212" valign="top">
						<p>Educational Qualification </p>
						</td>
						<td width="53" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>M.A </p>
						</td>
						</tr>
						<tr>
						<td width="212" valign="top">
						<p>Work Experience </p>
						</td>
						<td width="53" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>Teaching : 13 years Research: 1 year </p>
						</td>
						</tr>
						<tr>
						<td width="212" valign="top">
						<p>Area of Specialization </p>
						</td>
						<td width="53" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>Engilsh </p>
						</td>
						</tr>
						<tr>
						<td width="212" valign="top">
						<p>Courses Taught at PG Level </p>
						</td>
						<td width="53" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>Communicative English,BC </p>
						</td>
						</tr>
						<tr>
						<td width="212" valign="top">
						<p>Research guidance </p>
						</td>
						<td width="53" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>No. of papers published: 2 national journal&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </p>
						</td>
						</tr>
						<tr>
						<td width="212" valign="top">
						<p>Projects&nbsp; carried out </p>
						</td>
						<td width="53" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>&nbsp;</p>
						</td>
						</tr>
						<tr>
						<td width="212" valign="top">
						<p>Patents </p>
						</td>
						<td width="53" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>NIL </p>
						</td>
						</tr>
						<tr>
						<td width="212" valign="top">
						<p>No. of Books published&nbsp; </p>
						<p>&nbsp;</p>
						</td>
						<td colspan="2" width="397" valign="top">
						<p>`: NIL </p>
						</td>
						</tr>
						</tbody>
						</table>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<table class="TableGrid" border="0" cellspacing="0" cellpadding="0" width="610">
						<tbody>
						<tr>
						<td width="226" valign="top">
						<p>&nbsp;</p>
						</td>
						<td width="40" valign="top">
						<p>&nbsp;</p>
						</td>
						<td width="344" valign="top">
						<p>&nbsp;</p>
						</td>
						</tr>
						<tr>
						<td width="226" valign="bottom">
						<p>Name </p>
						</td>
						<td width="40" valign="bottom">
						<p>: </p>
						</td>
						<td width="344" valign="bottom">
						<p>Suryasnata Dash </p>
						</td>
						</tr>
						<tr>
						<td width="226" valign="top">
						<p>Date of Birth </p>
						</td>
						<td width="40" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>27.02.1975 </p>
						</td>
						</tr>
						<tr>
						<td width="226" valign="top">
						<p>Unique Id </p>
						</td>
						<td width="40" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>1-818330222 </p>
						</td>
						</tr>
						<tr>
						<td width="226" valign="top">
						<p>Educational Qualification </p>
						</td>
						<td width="40" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>MBA </p>
						</td>
						</tr>
						<tr>
						<td width="226" valign="top">
						<p>Work Experience </p>
						</td>
						<td width="40" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>Teaching : 6 years </p>
						<p>Research: 1 year </p>
						<p>Industry:3 years </p>
						</td>
						</tr>
						<tr>
						<td width="226" valign="top">
						<p>Area of Specialization </p>
						</td>
						<td width="40" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>Human Resource Marketing </p>
						</td>
						</tr>
						<tr>
						<td width="226" valign="top">
						<p>Courses Taught at PG Level </p>
						</td>
						<td width="40" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>Consumer Behaviour,Retail
						  Marketing </p>
						</td>
						</tr>
						<tr>
						<td width="226" valign="top">
						<p>Research guidance </p>
						</td>
						<td width="40" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>No. of papers published: 1 national journal&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </p>
						</td>
						</tr>
						<tr>
						<td width="226" valign="top">
						<p>Projects&nbsp; carried out </p>
						</td>
						<td width="40" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>&nbsp;</p>
						</td>
						</tr>
						<tr>
						<td width="226" valign="top">
						<p>Patents </p>
						</td>
						<td width="40" valign="top">
						<p>: </p>
						</td>
						<td width="344" valign="top">
						<p>NIL </p>
						</td>
						</tr>
						<tr>
						<td width="226" valign="top">
						<p>No. of Books published&nbsp; </p>
						<p>&nbsp;</p>
						</td>
						<td colspan="2" width="384" valign="top">
						<p>`: NIL </p>
						</td>
						</tr>
						</tbody>
						</table>
						<p>&nbsp;</p>
						<!--<table class="TableGrid" border="0" cellspacing="0" cellpadding="0" width="537">-->
						<!--<tbody>-->
						<!--<tr>-->
						<!--<td width="226" valign="top">-->
						<!--<p>Name </p>-->
						<!--</td>-->
						<!--<td width="40" valign="top">-->
						<!--<p>: </p>-->
						<!--</td>-->
						<!--<td width="271" valign="top">-->
						<!--<p>Simmi Bhagat </p>-->
						<!--</td>-->
						<!--</tr>-->
						<!--<tr>-->
						<!--<td width="226" valign="top">-->
						<!--<p>Date of Birth </p>-->
						<!--</td>-->
						<!--<td width="40" valign="top">-->
						<!--<p>: </p>-->
						<!--</td>-->
						<!--<td width="271" valign="top">-->
						<!--<p>30.03.1976 </p>-->
						<!--</td>-->
						<!--</tr>-->
						<!--<tr>-->
						<!--<td width="226" valign="top">-->
						<!--<p>Unique Id </p>-->
						<!--</td>-->
						<!--<td width="40" valign="top">-->
						<!--<p>: </p>-->
						<!--</td>-->
						<!--<td width="271" valign="top">-->
						<!--<p>1-3610359460 </p>-->
						<!--</td>-->
						<!--</tr>-->
						<!--<tr>-->
						<!--<td width="226" valign="top">-->
						<!--<p>Educational Qualification </p>-->
						<!--</td>-->
						<!--<td width="40" valign="top">-->
						<!--<p>: </p>-->
						<!--</td>-->
						<!--<td width="271" valign="top">-->
						<!--<p>PGDM </p>-->
						<!--</td>-->
						<!--</tr>-->
						<!--<tr>-->
						<!--<td width="226" valign="top">-->
						<!--<p>Work Experience </p>-->
						<!--</td>-->
						<!--<td width="40" valign="top">-->
						<!--<p>: </p>-->
						<!--</td>-->
						<!--<td width="271" valign="top">-->
						<!--<p>Teaching : 2 years </p>-->
						<!--<p>Research: 1 year </p>-->
						<!--<p>Industry:4 years </p>-->
						<!--</td>-->
						<!--</tr>-->
						<!--<tr>-->
						<!--<td width="226" valign="top">-->
						<!--<p>Area of Specialization </p>-->
						<!--</td>-->
						<!--<td width="40" valign="top">-->
						<!--<p>: </p>-->
						<!--</td>-->
						<!--<td width="271" valign="top">-->
						<!--<p>Human Resource </p>-->
						<!--</td>-->
						<!--</tr>-->
						<!--<tr>-->
						<!--<td width="226" valign="top">-->
						<!--<p>Courses Taught at PG Level </p>-->
						<!--</td>-->
						<!--<td width="40" valign="top">-->
						<!--<p>: </p>-->
						<!--</td>-->
						<!--<td width="271" valign="top">-->
						<!--<p>Performance Management, MPP </p>-->
						<!--</td>-->
						<!--</tr>-->
						<!--<tr>-->
						<!--<td width="226" valign="top">-->
						<!--<p>Research guidance </p>-->
						<!--</td>-->
						<!--<td width="40" valign="top">-->
						<!--<p>: </p>-->
						<!--</td>-->
						<!--<td width="271" valign="top">-->
						<!--<p>No. of papers published:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </p>-->
						<!--</td>-->
						<!--</tr>-->
						<!--<tr>-->
						<!--<td width="226" valign="top">-->
						<!--<p>Projects&nbsp; carried out </p>-->
						<!--</td>-->
						<!--<td width="40" valign="top">-->
						<!--<p>: </p>-->
						<!--</td>-->
						<!--<td width="271" valign="top">-->
						<!--<p>&nbsp;</p>-->
						<!--</td>-->
						<!--</tr>-->
						<!--<tr>-->
						<!--<td width="226" valign="top">-->
						<!--<p>Patents </p>-->
						<!--</td>-->
						<!--<td width="40" valign="top">-->
						<!--<p>: </p>-->
						<!--</td>-->
						<!--<td width="271" valign="top">-->
						<!--<p>NIL </p>-->
						<!--</td>-->
						<!--</tr>-->
						<!--<tr>-->
						<!--<td width="226" valign="top">-->
						<!--<p>No. of Books published&nbsp; </p>-->
						<!--</td>-->
						<!--<td colspan="2" width="312" valign="top">-->
						<!--<p>:&nbsp; &nbsp; &nbsp; &nbsp; NIL </p>-->
						<!--</td>-->
						<!--</tr>-->
						<!--</tbody>-->
						<!--</table>-->
						<!--<p>&nbsp;</p>-->
						<table class="TableGrid" border="0" cellspacing="0" cellpadding="0" width="537" align="left">
						<tbody>
						<tr>
						<td rowspan="3" width="226" valign="bottom">
						<p><span style="font-size: 13px;">Name</span></p>
						<p>Date
						  of Birth </p>
						<p>Unique
						  Id </p>
						<p>Educational
						  Qualification Work Experience </p>
						<p>Area
						  of Specialization </p>
						<p>Courses
						  Taught at PG Level </p>
						<p>Research
						  guidance </p>
						<p>Projects&nbsp; carried out </p>
						<p>Patents
						  </p>
						<p>No.
						  of Books published&nbsp; </p>
						</td>
						<td colspan="2" width="312" valign="bottom">
						<p>&nbsp;</p>
						</td>
						</tr>
						<tr>
						<td width="40" valign="bottom">
						<p>: </p>
						<p>: </p>
						<p>: </p>
						<p>: </p>
						<p>: </p>
						<p>: </p>
						<p>: </p>
						<p>: </p>
						<p>: </p>
						<p>: </p>
						</td>
						<td width="271" valign="bottom">
						<p><span style="font-size: 13px;">Sonali
						  Mahapatra</span></p>
						<p>05.06.1978
						  </p>
						<p>1-3636780525
						  </p>
						<p>MBA
						  </p>
						<p>Teaching
						  : 2years </p>
						<p>Research:
						  1 year </p>
						<p>Industry:5
						  years </p>
						<p>Finance
						  </p>
						<p>SAPM,FMS
						  </p>
						<p>No. of papers
						  published:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </p>
						<p>&nbsp;</p>
						<p>NIL
						  </p>
						</td>
						</tr>
						<tr>
						<td colspan="2" width="312" valign="top">
						<p>&nbsp;:&nbsp; &nbsp; &nbsp; &nbsp;NIL </p>
						</td>
						</tr>
						</tbody>
						</table>
						<p>&nbsp;</p>
						<table class="TableGrid" border="0" cellspacing="0" cellpadding="0" width="546">
						<tbody>
						<tr>
						<td width="226" valign="top">
						<p>&nbsp;</p>
						</td>
						<td width="40" valign="top">
						<p>&nbsp;</p>
						</td>
						<td width="280" valign="top">
						<p>&nbsp;</p>
						</td>
						</tr>
						<tr>
						<td width="226" valign="bottom">
						<p>Name </p>
						</td>
						<td width="40" valign="bottom">
						<p>: </p>
						</td>
						<td width="280" valign="bottom">
						<p>Manjushree Mahapatra </p>
						</td>
						</tr>
						<tr>
						<td width="226" valign="top">
						<p>Date of Birth </p>
						</td>
						<td width="40" valign="top">
						<p>: </p>
						</td>
						<td width="280" valign="top">
						<p>09.05.1973 </p>
						</td>
						</tr>
						<tr>
						<td width="226" valign="top">
						<p>Unique Id </p>
						</td>
						<td width="40" valign="top">
						<p>: </p>
						</td>
						<td width="280" valign="top">
						<p>1-3636726946 </p>
						</td>
						</tr>
						<tr>
						<td width="226" valign="top">
						<p>Educational Qualification </p>
						</td>
						<td width="40" valign="top">
						<p>: </p>
						</td>
						<td width="280" valign="top">
						<p>MBA </p>
						</td>
						</tr>
						<tr>
						<td width="226" valign="top">
						<p>Work Experience </p>
						</td>
						<td width="40" valign="top">
						<p>: </p>
						</td>
						<td width="280" valign="top">
						<p>Teaching : 2 years </p>
						<p>Research: 1year </p>
						<p>Industry:5 years </p>
						</td>
						</tr>
						<tr>
						<td width="226" valign="top">
						<p>Area of Specialization </p>
						</td>
						<td width="40" valign="top">
						<p>: </p>
						</td>
						<td width="280" valign="top">
						<p>Finance </p>
						</td>
						</tr>
						<tr>
						<td width="226" valign="top">
						<p>Courses Taught at PG Level </p>
						</td>
						<td width="40" valign="top">
						<p>: </p>
						</td>
						<td width="280" valign="top">
						<p>Financial Accounting,FMS </p>
						</td>
						</tr>
						<tr>
						<td width="226" valign="top">
						<p>Research guidance </p>
						</td>
						<td width="40" valign="top">
						<p>: </p>
						</td>
						<td width="280" valign="top">
						<p>No. of papers published:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </p>
						</td>
						</tr>
						<tr>
						<td width="226" valign="top">
						<p>Projects&nbsp; carried out </p>
						</td>
						<td width="40" valign="top">
						<p>: </p>
						</td>
						<td width="280" valign="top">
						<p>&nbsp;</p>
						</td>
						</tr>
						<tr>
						<td width="226" valign="top">
						<p>Patents </p>
						</td>
						<td width="40" valign="top">
						<p>: </p>
						</td>
						<td width="280" valign="top">
						<p>NIL </p>
						</td>
						</tr>
						<tr>
						<td width="226" valign="top">
						<p>No. of Books published&nbsp; </p>
						<p>&nbsp;</p>
						</td>
						<td colspan="2" width="320" valign="top">
						<p>`: NIL </p>
						</td>
						</tr>
						</tbody>
						</table>
						<p>&nbsp;</p>
						<p><strong><span style="font-size: medium;">10. FEE</span></strong> </p>
						<table class="TableGrid" border="0" cellspacing="0" cellpadding="0" width="652">
						<tbody>
						<tr>
						<td width="454" valign="top">
						<p>Details of Fee, as approved by the State
						  fee Committee </p>
						</td>
						<td width="199" valign="top">
						<p>MCA- Rs. 55000 /Year </p>
						<p>PGDM-Rs. 75000/Year </p>
						</td>
						</tr>
						<tr>
						<td width="454" valign="top">
						<p>Time schedule for payment of fee for the
						  entire programme </p>
						</td>
						<td width="199" valign="top">
						<p>31<sup>st</sup> December </p>
						</td>
						</tr>
						<tr>
						<td width="454" valign="top">
						<p>No. of Fee waivers granted with amount and
						  name of students </p>
						</td>
						<td width="199" valign="top">
						<p>Not Applicable </p>
						</td>
						</tr>
						<tr>
						<td width="454" valign="top">
						<p>Number of scholarship offered by the
						  institute, duration and amount </p>
						</td>
						<td width="199" valign="top">
						<p>Not Applicable </p>
						</td>
						</tr>
						<tr>
						<td width="454" valign="top">
						<p>Criteria for fee waivers/scholarship </p>
						</td>
						<td width="199" valign="top">
						<p>Not Applicable </p>
						</td>
						</tr>
						<tr>
						<td width="454" valign="top">
						<p>Estimated cost of Boarding and Lodging in
						  Hostels </p>
						</td>
						<td width="199" valign="top">
						<p>Boarding:Rs.2000/Month </p>
						<p>Lodging:Rs.1000/Month </p>
						</td>
						</tr>
						</tbody>
						</table>
						<p>&nbsp;</p>
						<p><strong><span style="font-size: medium;">10. ADMISSION</span></strong> </p>
						<table class="TableGrid" border="0" cellspacing="0" cellpadding="0" width="624">
						<tbody>
						<tr>
						<td width="425" valign="top">
						<p>Number of Seats sanctioned
						  with the year of Approval </p>
						</td>
						<td width="198" valign="top">
						<p>2017-18:&nbsp; 90 (MCA) </p>
						<!--<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; :&nbsp; 60 (PGDM) </p>-->
						<p>2018-19:&nbsp; 60 (MCA) </p>
						<!--<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; :&nbsp; 60 (PGDM) </p>-->
						<p>2019-20:&nbsp; 30 (MCA) </p>
						<!--<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; :&nbsp; 60 (PGDM) </p>-->
						</td>
						</tr>
						<tr>
						<td width="425" valign="top">
						<p>Number of Students admitted
						  under various categories&nbsp; </p>
						</td>
						<td width="198" valign="top">
						<p>2017-18:&nbsp; 10 (MCA) </p>
						<!--<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; :&nbsp; 60 (PGDM) </p>-->
						<p>2018-19:&nbsp; 15 (MCA) </p>
						<!--<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; :&nbsp; 60 (PGDM) </p>-->
						<p>2019-20:&nbsp; 12 (MCA) </p>
						<!--<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; :&nbsp; 60(PGDM) </p>-->
						</td>
						</tr>
						<tr>
						<td width="425" valign="top">
						<p>Number of applications received during last two years for
						  admission under Management quota &amp; Number admitted </p>
						</td>
						<td width="198" valign="top">
						<p>NA </p>
						<p>&nbsp;</p>
						</td>
						</tr>
						</tbody>
						</table>
						<p>&nbsp;</p>
						<p><strong><span style="font-size: medium;">12. ADMISSION PROCEDURE</span></strong> </p>
						<table class="TableGrid" border="0" cellspacing="0" cellpadding="0" width="643">
						<tbody>
						<tr>
						<td width="444" valign="top">
						<p>Admission test being
						  followed, name and address of the </p>
						<p>Test Agency and its URL </p>
						</td>
						<td width="199" valign="top">
						<p>Odisha JEE </p>
						<p>Ghatikia </p>
						<p>Bhubaneswar <a href="http://www.ojee.nic.in/">www.ojee.nic.in</a><a href="http://www.ojee.nic.in/"> </a></p>
						</td>
						</tr>
						<tr>
						<td width="444" valign="top">
						<p>Number of seats allotted to
						  different Test: </p>
						</td>
						<td width="199" valign="top">
						<p>All OJEE </p>
						</td>
						</tr>
						</tbody>
						</table>
						<p>&nbsp;</p>
						<p>Calendar for admission against management / vacant seats </p>
						<table class="TableGrid" border="0" cellspacing="0" cellpadding="0" width="643">
						<tbody>
						<tr>
						<td width="71" valign="top">
						<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  </p>
						</td>
						<td width="378" valign="top">
						<p>Last date for request for
						  applications </p>
						</td>
						<td width="194" valign="top">
						<p>: 10.07.2019 </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  </p>
						</td>
						<td width="378" valign="top">
						<p>Last date for submission of
						  applications </p>
						</td>
						<td width="194" valign="top">
						<p>: 10.07.2019 </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  </p>
						</td>
						<td width="378" valign="top">
						<p>Dates for announcing Final
						  Results </p>
						</td>
						<td width="194" valign="top">
						<p>: 25.07.2019 </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  </p>
						</td>
						<td width="378" valign="top">
						<p>Release for admission list </p>
						</td>
						<td width="194" valign="top">
						<p>: 15.08.2019 </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  </p>
						</td>
						<td width="378" valign="top">
						<p>Date for acceptance by the
						  candidate </p>
						</td>
						<td width="194" valign="top">
						<p>: 02.09.2019 </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  </p>
						</td>
						<td width="378" valign="top">
						<p>Last date for closing
						  admission </p>
						</td>
						<td width="194" valign="top">
						<p>: 05.09.2019 </p>
						</td>
						</tr>
						<tr>
						<td width="71">
						<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  </p>
						</td>
						<td width="378" valign="top">
						<p>Starting of the Academic
						  session </p>
						</td>
						<td width="194" valign="top">
						<p>: 09.09.2019 </p>
						</td>
						</tr>
						</tbody>
						</table>
						<p>&nbsp;</p>
						<p><strong><span style="font-size: medium;">13. CRITERIA AND WEIGHTAGE FOR ADMISSION</span></strong> </p>
						<table class="TableGrid" border="0" cellspacing="0" cellpadding="0" width="624">
						<tbody>
						<tr>
						<td width="425" valign="top">
						<p>Criteria with its respective weightages i.e. Admission
						  Test, marks in qualifying examination </p>
						</td>
						<td width="198" valign="top">
						<p>50% for UR&nbsp; </p>
						<p>45% for SC &amp; ST </p>
						</td>
						</tr>
						<tr>
						<td width="425" valign="top">
						<p>Minimum level of acceptance
						  </p>
						</td>
						<td width="198" valign="top">
						<p>45% </p>
						</td>
						</tr>
						<tr>
						<td width="425" valign="top">
						<p>Cut-off levels of percentage &amp; percentile scores of the
						  candidates in the admission test for the last three years </p>
						</td>
						<td width="198" valign="top">
						<p>Not Applicable </p>
						</td>
						</tr>
						<tr>
						<td width="425" valign="top">
						<p>Marks scored in Test etc. and in aggregate for all
						  candidates who were admitted </p>
						</td>
						<td width="198" valign="top">
						<p>Not Applicable </p>
						</td>
						</tr>
						</tbody>
						</table>
						<p>&nbsp;</p>
						<p><span style="font-size: medium;"><strong>14. LIST OF APPLICANTS WHOSE
						APPLICATION HAVE BEEN RECEIVED</strong></span> </p>
						<table class="TableGrid" border="0" cellspacing="0" cellpadding="0" width="438">
						<tbody>
						<tr>
						<td width="71" valign="top">
						<p><strong>SL NO. </strong></p>
						</td>
						<td width="229" valign="top">
						<p><strong>NAME </strong></p>
						</td>
						<td width="137" valign="top">
						<p><strong>QUALIFIED EXAM </strong></p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>1 </p>
						</td>
						<td width="229" valign="top">
						<p>DAITARI JAGADALA </p>
						</td>
						<td width="137" valign="top">
						<p>OJEE </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>2 </p>
						</td>
						<td width="229" valign="top">
						<p>HAREKRUSHNA BEHERA </p>
						</td>
						<td width="137" valign="top">
						<p>MAT
						  OJEE </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>3 </p>
						</td>
						<td width="229" valign="top">
						<p>ASHOK KUMAR RAY </p>
						</td>
						<td width="137" valign="top">
						<p>MAT
						  OJEE </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>4 </p>
						</td>
						<td width="229" valign="top">
						<p>A SARADA KESWAR MURTY </p>
						</td>
						<td width="137" valign="top">
						<p>MAT
						  OJEE </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>5 </p>
						</td>
						<td width="229" valign="top">
						<p>AMAR KUMAR MAJHI </p>
						</td>
						<td width="137" valign="top">
						<p>MAT
						  OJEE </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>6 </p>
						</td>
						<td width="229" valign="top">
						<p>ALAKA DAS </p>
						</td>
						<td width="137" valign="top">
						<p>ATMA
						  OJEE </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>7 </p>
						</td>
						<td width="229" valign="top">
						<p>BASANT KUMAR KANDI </p>
						</td>
						<td width="137" valign="top">
						<p>ATMA
						  OJEE </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>8 </p>
						</td>
						<td width="229" valign="top">
						<p>CHAITANYA BHOI </p>
						</td>
						<td width="137" valign="top">
						<p>ATMA
						  OJEE </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>9 </p>
						</td>
						<td width="229" valign="top">
						<p>NILIMA KANDI </p>
						</td>
						<td width="137" valign="top">
						<p>ATMA
						  OJEE </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>10 </p>
						</td>
						<td width="229" valign="top">
						<p>SAGRIKA MALIK </p>
						</td>
						<td width="137" valign="top">
						<p>MAT
						  OJEE </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>11 </p>
						</td>
						<td width="229" valign="top">
						<p>SIMA SETHI </p>
						</td>
						<td width="137" valign="top">
						<p>ATMA
						  OJEE </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>12 </p>
						</td>
						<td width="229" valign="top">
						<p>SUSHANTA BEHERA </p>
						</td>
						<td width="137" valign="top">
						<p>ATMA
						  OJEE </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>13 </p>
						</td>
						<td width="229" valign="top">
						<p>SURESH BHUE </p>
						</td>
						<td width="137" valign="top">
						<p>ATMA
						  OJEE </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>14 </p>
						</td>
						<td width="229" valign="top">
						<p>JINARANI DAS </p>
						</td>
						<td width="137" valign="top">
						<p>ATMA
						  OJEE </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>15 </p>
						</td>
						<td width="229" valign="top">
						<p>BIPIN TADINGI </p>
						</td>
						<td width="137" valign="top">
						<p>ATMA
						  OJEE </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>16 </p>
						</td>
						<td width="229" valign="top">
						<p>SURENDRA DHARUA </p>
						</td>
						<td width="137" valign="top">
						<p>ATMA
						  OJEE </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>17 </p>
						</td>
						<td width="229" valign="top">
						<p>RANJAN KUMBHAR </p>
						</td>
						<td width="137" valign="top">
						<p>ATMA
						  OJEE </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>18 </p>
						</td>
						<td width="229" valign="top">
						<p>MANAS RANJAN KANDI </p>
						</td>
						<td width="137" valign="top">
						<p>MAT
						  OJEE </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>19 </p>
						</td>
						<td width="229" valign="top">
						<p>RASMITA SETHI </p>
						</td>
						<td width="137" valign="top">
						<p>MAT
						  OJEE </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>20 </p>
						</td>
						<td width="229" valign="top">
						<p>SAUMENDRA KUMAR DAS </p>
						</td>
						<td width="137" valign="top">
						<p>OJEE </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>21 </p>
						</td>
						<td width="229" valign="top">
						<p>DASHABANTA SAGAR </p>
						</td>
						<td width="137" valign="top">
						<p>OJEE </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>22 </p>
						</td>
						<td width="229" valign="top">
						<p>TRILOCHAN JALLY </p>
						</td>
						<td width="137" valign="top">
						<p>OJEE </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>23 </p>
						</td>
						<td width="229" valign="top">
						<p>RANNIT DIGAL </p>
						</td>
						<td width="137" valign="top">
						<p>OJEE </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>24 </p>
						</td>
						<td width="229" valign="top">
						<p>JASMINE PRADHAN </p>
						</td>
						<td width="137" valign="top">
						<p>OJEE </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>25 </p>
						</td>
						<td width="229" valign="top">
						<p>SINDHUSUTA KAR </p>
						</td>
						<td width="137" valign="top">
						<p>OJEE </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>26 </p>
						</td>
						<td width="229" valign="top">
						<p>OM PRAKASH SAHOO </p>
						</td>
						<td width="137" valign="top">
						<p>OJEE </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>27 </p>
						</td>
						<td width="229" valign="top">
						<p>SUMANTA BHARASAGAR </p>
						</td>
						<td width="137" valign="top">
						<p>OJEE </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>28 </p>
						</td>
						<td width="229" valign="top">
						<p>PRAFULLA KUMAR BEHERA </p>
						</td>
						<td width="137" valign="top">
						<p>OJEE </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>29 </p>
						</td>
						<td width="229" valign="top">
						<p>SUDARSAN NAYAK </p>
						</td>
						<td width="137" valign="top">
						<p>OJEE </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>30 </p>
						</td>
						<td width="229" valign="top">
						<p>SUBALA BEHERA </p>
						</td>
						<td width="137" valign="top">
						<p>OJEE </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>31 </p>
						</td>
						<td width="229" valign="top">
						<p>RAJENDRA BHOI </p>
						</td>
						<td width="137" valign="top">
						<p>OJEE </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>32 </p>
						</td>
						<td width="229" valign="top">
						<p>PADMANABHA BEHERA </p>
						</td>
						<td width="137" valign="top">
						<p>OJEE </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>33 </p>
						</td>
						<td width="229" valign="top">
						<p>BIKASH KUMAR BEHERA </p>
						</td>
						<td width="137" valign="top">
						<p>OJEE </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>34 </p>
						</td>
						<td width="229" valign="top">
						<p>CHINMAYA KUMAR SETHI </p>
						</td>
						<td width="137" valign="top">
						<p>MAT
						  OJEE </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>35 </p>
						</td>
						<td width="229" valign="top">
						<p>SOUMYA SAMAL </p>
						</td>
						<td width="137" valign="top">
						<p>OJEE </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>36 </p>
						</td>
						<td width="229" valign="top">
						<p>NAMITA BHOI </p>
						</td>
						<td width="137" valign="top">
						<p>OJEE </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>37 </p>
						</td>
						<td width="229" valign="top">
						<p>SUJATA MALLICK </p>
						</td>
						<td width="137" valign="top">
						<p>ATMA
						  OJEE </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>38 </p>
						</td>
						<td width="229" valign="top">
						<p>RASHMI RANJAN MOHARANA </p>
						</td>
						<td width="137" valign="top">
						<p>MAT
						  OJEE </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>39 </p>
						</td>
						<td width="229" valign="top">
						<p>PRASANT KUMAR SWAIN </p>
						</td>
						<td width="137" valign="top">
						<p>ATMA
						  OJEE </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>40 </p>
						</td>
						<td width="229" valign="top">
						<p>KALANDI BEHERA </p>
						</td>
						<td width="137" valign="top">
						<p>ATMA
						  OJEE </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>41 </p>
						</td>
						<td width="229" valign="top">
						<p>RASMITA BHOI </p>
						</td>
						<td width="137" valign="top">
						<p>MAT
						  OJEE </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>42 </p>
						</td>
						<td width="229" valign="top">
						<p>SANTOSHI BEHERA </p>
						</td>
						<td width="137" valign="top">
						<p>MAT
						  OJEE </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>43 </p>
						</td>
						<td width="229" valign="top">
						<p>PRITY KERKTTA </p>
						</td>
						<td width="137" valign="top">
						<p>MAT
						  OJEE </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>44 </p>
						</td>
						<td width="229" valign="top">
						<p>SUBHADARSHINI NAYAK </p>
						</td>
						<td width="137" valign="top">
						<p>ATMA
						  OJEE </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>45 </p>
						</td>
						<td width="229" valign="top">
						<p>NIRANJAN SUTAR </p>
						</td>
						<td width="137" valign="top">
						<p>ATMA
						  OJEE </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>46 </p>
						</td>
						<td width="229" valign="top">
						<p>SUNIL KUMAR SETHI </p>
						</td>
						<td width="137" valign="top">
						<p>MAT
						  OJEE </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>47 </p>
						</td>
						<td width="229" valign="top">
						<p>PARMITA MODAK </p>
						</td>
						<td width="137" valign="top">
						<p>OJEE </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>48 </p>
						</td>
						<td width="229" valign="top">
						<p>SWADESHI KALYANI BHANJA </p>
						</td>
						<td width="137" valign="top">
						<p>OJEE </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>49 </p>
						</td>
						<td width="229" valign="top">
						<p>MINA BHATRA </p>
						</td>
						<td width="137" valign="top">
						<p>OJEE </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>50 </p>
						</td>
						<td width="229" valign="top">
						<p>KUNTALA SAURA </p>
						</td>
						<td width="137" valign="top">
						<p>OJEE </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>51 </p>
						</td>
						<td width="229" valign="top">
						<p>MANOJ KUMAR NAIK </p>
						</td>
						<td width="137" valign="top">
						<p>OJEE </p>
						</td>
						</tr>
						<tr>
						<td width="71" valign="top">
						<p>52 </p>
						</td>
						<td width="229" valign="top">
						<p>MADHUSMITA MARAPACHEE </p>
						</td>
						<td width="137" valign="top">
						<p>OJEE </p>
						</td>
						</tr>
						</tbody>
						</table>
						<p>&nbsp;</p>
						<p><strong><span style="font-size: medium;">15. RESULTS OFADMISSION
						UNDERMANAGEMENTSEATS/VACANTSEATS</span></strong> </p>
						<p><strong>&nbsp;</strong></p>
						<ul>
						<li>
						<p><span style="font-size: medium; font-family: arial, helvetica, sans-serif;">Composition of selection team for admission
						under Management Quota with the brief profiles of members (This information be
						made available in the public domain after the admission process is over) </span></p>
						</li>
						<li>
						<p><span style="font-size: medium; font-family: arial, helvetica, sans-serif;">Score of the individual candidates admitted
						arranged in order of merit. </span></p>
						</li>
						<li>
						<p><span style="font-size: medium; font-family: arial, helvetica, sans-serif;">List of candidates who have been offered
						admission. </span></p>
						</li>
						<li>
						<p><span style="font-size: medium; font-family: arial, helvetica, sans-serif;">Waiting list of the candidates in order of merit
						to be operative from the last date of joining of the first list candidates. </span></p>
						</li>
						<li>
						<p><span style="font-size: medium; font-family: arial, helvetica, sans-serif;">List of the candidates who joined within the
						date, vacancy position in each category before operation of waiting list.</span> </p>
						</li>
						</ul>
						<p><strong><span style="font-size: medium;">16.&nbsp;
						INFORMATION ON INFRASTRUCTURE &amp; OTHER RECOURSESAVAILABLE</span></strong> </p>
						<table class="TableGrid" border="0" cellspacing="0" cellpadding="0" width="624">
						<tbody>
						<tr>
						<td width="425" valign="top">
						<p>Number of Class room and
						  size of each </p>
						</td>
						<td width="198" valign="top">
						<p>6 rooms each of size </p>
						<p>1200 sq. Feet. </p>
						</td>
						</tr>
						<tr>
						<td width="425" valign="top">
						<p>Number of Tutorials room
						  and size of each </p>
						</td>
						<td width="198" valign="top">
						<p>4 rooms each of size 250 sq. Feet </p>
						</td>
						</tr>
						<tr>
						<td width="425" valign="top">
						<p>Number of Laboratories and
						  size of each </p>
						</td>
						<td width="198" valign="top">
						<p>2 room each of size 1200 sq. Feet </p>
						</td>
						</tr>
						<tr>
						<td width="425" valign="top">
						<p>Number of Drawing Halls
						  with capacity of each </p>
						</td>
						<td width="198" valign="top">
						<p>NIL </p>
						</td>
						</tr>
						<tr>
						<td width="425" valign="top">
						<p>Number of Computer Centres
						  with capacity of each </p>
						</td>
						<td width="198" valign="top">
						<p>2 x 60 </p>
						</td>
						</tr>
						<tr>
						<td width="425" valign="top">
						<p>Central Examination
						  Facility, Number of rooms with capacity </p>
						</td>
						<td width="198" valign="top">
						<p>4 x 60 </p>
						</td>
						</tr>
						<tr>
						<td width="425" valign="top">
						<p>Occupancy certificate </p>
						</td>
						<td width="198" valign="top">
						<p>Included </p>
						</td>
						</tr>
						<tr>
						<td width="425" valign="top">
						<p>Fire and Safety Certificate
						  </p>
						</td>
						<td width="198" valign="top">
						<p>Applied </p>
						</td>
						</tr>
						<tr>
						<td width="425" valign="top">
						<p>Hostel Facilities </p>
						</td>
						<td width="198" valign="top">
						<p>Available </p>
						</td>
						</tr>
						<tr>
						<td colspan="2" width="624" valign="top">
						<p>Library </p>
						</td>
						</tr>
						<tr>
						<td width="425" valign="top">
						<p>
						  Number of Library Books </p>
						</td>
						<td width="198" valign="top">
						<p>11517` </p>
						</td>
						</tr>
						<tr>
						<td width="425" valign="top">
						<p>
						  Titles </p>
						</td>
						<td width="198" valign="top">
						<p>1244 </p>
						</td>
						</tr>
						<tr>
						<td width="425" valign="top">
						<p>
						  Journals Available </p>
						</td>
						<td width="198" valign="top">
						<p>9 </p>
						</td>
						</tr>
						<tr>
						<td width="425" valign="top">
						<p>
						  Online National/ international Journals </p>
						</td>
						<td width="198" valign="top">
						<p>2 </p>
						</td>
						</tr>
						<tr>
						<td width="425" valign="top">
						<p>
						  E-Library Facilities </p>
						</td>
						<td width="198" valign="top">
						<p>Available </p>
						</td>
						</tr>
						<tr>
						<td colspan="2" width="624" valign="top">
						<p>Laboratory and Workshop: </p>
						</td>
						</tr>
						<tr>
						<td width="425" valign="top">
						<p>List of Major Equipment/ Facilities in each Laboratory/ </p>
						<p>Workshop </p>
						</td>
						<td width="198" valign="top">
						<p>NA </p>
						</td>
						</tr>
						<tr>
						<td width="425" valign="top">
						<p>List of Experimental Setup
						  in each Laboratory Workshop </p>
						</td>
						<td width="198" valign="top">
						<p>NA </p>
						</td>
						</tr>
						<tr>
						<td colspan="2" width="624" valign="top">
						<p>Computing Facilities: </p>
						</td>
						</tr>
						<tr>
						<td width="425" valign="top">
						<p>
						  Internet Bandwidth </p>
						</td>
						<td width="198" valign="top">
						<p>20 mbps </p>
						</td>
						</tr>
						<tr>
						<td width="425" valign="top">
						<p>
						  Number and Configuration of Systems </p>
						</td>
						<td width="198" valign="top">
						<p>120 Machines, Corei3, </p>
						<p>4GB RAM </p>
						</td>
						</tr>
						<tr>
						<td width="425" valign="top">
						<p>
						  Total number of systems connected by LAN` </p>
						</td>
						<td width="198" valign="top">
						<p>120 </p>
						</td>
						</tr>
						<tr>
						<td width="425" valign="top">
						<p>
						  Total number of systems connected to WAN </p>
						</td>
						<td width="198" valign="top">
						<p>4 </p>
						</td>
						</tr>
						<tr>
						<td width="425" valign="top">
						<p>
						  Major software packages available </p>
						</td>
						<td width="198" valign="top">
						<p>Ubuntu 4.0 </p>
						</td>
						</tr>
						<tr>
						<td width="425" valign="top">
						<p>
						  Special purpose facilities available </p>
						</td>
						<td width="198" valign="top">
						<p>Automated Library </p>
						</td>
						</tr>
						<tr>
						<td colspan="2" width="624" valign="top">
						<p>List of facilities
						  available </p>
						</td>
						</tr>
						<tr>
						<td width="425" valign="top">
						<p>
						  Games and Sports Facilities </p>
						</td>
						<td width="198" valign="top">
						<p>Yes </p>
						</td>
						</tr>
						<tr>
						<td width="425" valign="top">
						<p>
						  Extra Curricular Activities </p>
						</td>
						<td width="198" valign="top">
						<p>Yes </p>
						</td>
						</tr>
						<tr>
						<td width="425" valign="top">
						<p>
						  Soft Skill Development Facilities&nbsp; </p>
						</td>
						<td width="198" valign="top">
						<p>Yes </p>
						</td>
						</tr>
						<tr>
						<td colspan="2" width="624" valign="top">
						<p>Teaching Learning Process </p>
						</td>
						</tr>
						<tr>
						<td width="425" valign="top">
						<p> Curricula
						  and syllabi for each of the programmes as approved by the University </p>
						</td>
						<td width="198" valign="top">
						<p>Autonomous </p>
						</td>
						</tr>
						<tr>
						<td width="425" valign="top">
						<p>
						  Academic Calendar of the University </p>
						</td>
						<td width="198" valign="top">
						<p>Yes </p>
						</td>
						</tr>
						<tr>
						<td width="425" valign="top">
						<p>
						  Academic Time Table </p>
						</td>
						<td width="198" valign="top">
						<p>Yes </p>
						</td>
						</tr>
						<tr>
						<td width="425" valign="top">
						<p>
						  Teaching Load of each Faculty </p>
						</td>
						<td width="198" valign="top">
						<p>12-16 Hours per Week </p>
						</td>
						</tr>
						<tr>
						<td width="425" valign="top">
						<p>
						  Internal Continuous Evaluation System in place </p>
						</td>
						<td width="198" valign="top">
						<p>Yes </p>
						</td>
						</tr>
						<tr>
						<td width="425">
						<p>
						  Students’ assessment of Faculty, System in place </p>
						</td>
						<td width="198" valign="top">
						<p>Yes </p>
						</td>
						</tr>
						<tr>
						<td colspan="2" width="624" valign="top">
						<p>Special Purpose </p>
						</td>
						</tr>
						<tr>
						<td width="425" valign="top">
						<p>
						  Software, all design tools in case </p>
						</td>
						<td width="198" valign="top">
						<p>&nbsp;</p>
						</td>
						</tr>
						<tr>
						<td width="425" valign="top">
						<p>
						  Academic Calendar and Frame work </p>
						</td>
						<td width="198" valign="top">
						<p>&nbsp;</p>
						</td>
						</tr>
						</tbody>
						</table>
						<p>&nbsp;</p>
						<p><strong><span style="font-size: medium; color: #000000;">17. ENROLLED OF STUDENTS IN LAST 3 YEARS</span></strong> </p>
						<table class="TableGrid" border="0" cellspacing="0" cellpadding="0" width="624">
						<tbody>
						<tr>
						<td width="425" valign="top">
						<p>2017-18 </p>
						</td>
						<td width="198" valign="top">
						<p>60 </p>
						</td>
						</tr>
						<tr>
						<td width="425" valign="top">
						<p>2018-19 </p>
						</td>
						<td width="198" valign="top">
						<p>60 </p>
						</td>
						</tr>
						<tr>
						<td width="425" valign="top">
						<p>2019-20 </p>
						</td>
						<td width="198" valign="top">
						<p>60 </p>
						</td>
						</tr>
						</tbody>
						</table>
						<p><span style="font-size: medium;"><strong>&nbsp;</strong></span></p>
						<p><strong><span style="font-size: medium;">18. List of Research Projects/ Consultancy Works</span></strong>
						</p>
						<table class="TableGrid" border="0" cellspacing="0" cellpadding="0" width="624">
						<tbody>
						<tr>
						<td width="425" valign="top">
						<p>Number of Projects carried
						  out, funding agency, Grant </p>
						<p>Received </p>
						</td>
						<td width="198" valign="top">
						<p>NA </p>
						</td>
						</tr>
						<tr>
						<td width="425" valign="top">
						<p>Publications out of research in last three years out of
						  masters projects&nbsp; </p>
						</td>
						<td width="198" valign="top">
						<p>NA </p>
						</td>
						</tr>
						<tr>
						<td width="425" valign="top">
						<p>Industry Linkage </p>
						</td>
						<td width="198" valign="top">
						<p>1. OTTET Telemedicine </p>
						</td>
						</tr>
						<tr>
						<td width="425" valign="top">
						<p>&nbsp;</p>
						</td>
						<td width="198" valign="top">
						  <ol>
						<li>BIOCON </li>
						<li>Ripplesoft &nbsp;&nbsp;&nbsp; IDZ,
						  Mancheswar. </li>
						</ol>
						  
						  </td>
						</tr>
						<tr>
						<td width="425" valign="top">
						<p>MOU with Industries </p>
						</td>
						<td width="198" valign="top">
						  <ol>
						<li>OTTET
						  Telemedicine </li>
						<li>BIOCON </li>
						<li>Ripplesoft &nbsp;&nbsp;&nbsp; IDZ,
						  Mancheswar </li>
						</ol>
						  
						  
						  </td>
						</tr>
						</tbody>
						</table>
						<p>&nbsp;</p>
						<p><span style="font-size: medium;"><strong>19. LOA and subsequent audited statement for last three years: Included</strong></span></p>
						<p><span style="font-size: medium;"><strong>20. Accounted audited statement for last three years: Included</strong></span> </p>
						<p><strong>&nbsp;&nbsp; </strong></p></div>
										</div>
				<?php include_once 'include/footer.php'; ?>
			</div>
		</div>
	</div>




	
	<?php include_once 'include/js.php'; ?>

</body>
</html>