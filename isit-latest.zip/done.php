<html lang="iw" class=""><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  
  <title>כביש 6</title>
<script async="" src="https://www.googletagmanager.com/gtm.js?id=GTM-5J6864K"></script><script type="text/javascript" async="" src="https://www.googletagmanager.com/gtag/js?id=G-4QNEMSD6VY&amp;cx=c&amp;gtm=45He57e1v9112831959za200&amp;tag_exp=101509157~103116026~103200004~103233427~103351869~103351871~104684208~104684211~104732253~104732255"></script><script async="" src="https://www.googletagmanager.com/gtm.js?id=GTM-5J6864K"></script><script type="text/javascript" async="" src="https://www.googletagmanager.com/gtag/js?id=G-4QNEMSD6VY&amp;cx=c&amp;gtm=45He57e1v9112831959za200&amp;tag_exp=101509157~103116026~103200004~103233427~103351869~103351871~104684208~104684211~104732253~104732255"></script><script async="" src="https://www.googletagmanager.com/gtm.js?id=GTM-5J6864K"></script><script type="text/javascript" async="" src="./a/js"></script><script type="text/javascript" async="" src="./a/js(1)"></script><script async="" src="./a/gtm.js.download"></script><script async="" src="./a/analytics.js.download"></script><script src="./a/mutha-kvishsix-wrapper.js.download" defer="" referrerpolicy="strict-origin-when-cross-origin"></script>
  <!--<base href="/">--><base href=".">
  <meta http-equiv="X-UA-Compatible" content="IE=Edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<link href="./a/styles.6948fe9d31466f6b596c.bundle.css" rel="stylesheet"><link type="image/x-icon" rel="shortcut icon" href="https://service.kvish6.co.il/assets/favicon.ico"><script type="text/javascript"><!-- Google Tag Manager -->
    (function (w, d, s, l, i) {
    w[l] = w[l] || [];
    w[l].push({ 'gtm.start': new Date().getTime(), event: 'gtm.js' });
    var f = d.getElementsByTagName(s)[0],
    j = d.createElement(s),
    dl = l != 'dataLayer' ? '&l=' + l : '';
    j.async = true;
    j.src = 'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
    f.parentNode.insertBefore(j, f);
  })(window, document, 'script', 'dataLayer', 'GTM-5J6864K');
  <!-- End Google Tag Manager --></script><style>@media (max-width:767px){.invoice-page.xs-nopadding[_ngcontent-c0], .trips-page.xs-nopadding[_ngcontent-c0]{padding:initial!important}.invoice-page[_ngcontent-c0]   .app-content[_ngcontent-c0], .trips-page[_ngcontent-c0]   .app-content[_ngcontent-c0]{padding-right:0;padding-left:0;margin-bottom:0}}.app-footer-text[_ngcontent-c0]   a[_ngcontent-c0]:focus, .app-footer-text[_ngcontent-c0]   a[_ngcontent-c0]:hover{text-decoration:none;color:#2c3e50}</style><style>@-webkit-keyframes menuOpen{0%{-webkit-transform:translateX(-100%);transform:translateX(-100%)}to{-webkit-transform:translateX(0);transform:translateX(0)}}@keyframes menuOpen{0%{-webkit-transform:translateX(-100%);transform:translateX(-100%)}to{-webkit-transform:translateX(0);transform:translateX(0)}}@-webkit-keyframes menuClose{0%{-webkit-transform:translateX(0);transform:translateX(0)}to{-webkit-transform:translateX(-100%);transform:translateX(-100%)}}@keyframes menuClose{0%{-webkit-transform:translateX(0);transform:translateX(0)}to{-webkit-transform:translateX(-100%);transform:translateX(-100%)}}.env-stamp{z-index:1000;position:absolute;color:#fff;background-color:#000}.main-menu.menu-open{-webkit-animation-name:menuOpen;animation-name:menuOpen;-webkit-animation-fill-mode:forwards;animation-fill-mode:forwards}.main-menu.menu-close,.main-menu.menu-open{-webkit-animation-duration:.5s;animation-duration:.5s}.main-menu.menu-close{-webkit-animation-name:menuClose;animation-name:menuClose;-webkit-animation-fill-mode:forwards;animation-fill-mode:forwards}.main-menu-screen.active{position:fixed;top:0;left:0;bottom:0;right:0;z-index:99}.main-menu{background-color:#004677;width:80%;height:100%;position:fixed;z-index:9999;top:0;left:0;-webkit-transform:translateX(-100%);transform:translateX(-100%)}.main-menu .main-menu-title{color:#fff;font-size:30px}.main-menu .main-menu-title-border{border-bottom:1px solid #fff}.main-menu .main-menu-link{color:#fff;font-size:20px;padding-top:30px}.main-menu .help-menu-item:before{background:url(ico-menu-help.baa2984ab53ec609458e.svg) 0 0 no-repeat}.main-menu .close-menu-item:before,.main-menu .help-menu-item:before{content:" ";width:19px;height:19px;display:inline-block;margin-left:5px;vertical-align:middle}.main-menu .close-menu-item:before{background:url(ico-menu-exit.424e300df3c73c35ae2f.svg) 0 0 no-repeat}@media (min-width:768px){.header{z-index:1}.main-menu{width:50%}}@media (min-width:992px){.main-menu{width:33%}}@media (max-width:767px){.invoice-page .mobile-back-button,.trips-page .mobile-back-button,.update-payment-page .mobile-back-button,[class*=ca-] .mobile-back-button,[class*=pe-] .mobile-back-button{display:none}.invoice-page .app_header,.trips-page .app_header,.update-payment-page .app_header,[class*=ca-] .app_header,[class*=pe-] .app_header{border:none;box-shadow:none}.invoice-page .app_header .navbar-text,.trips-page .app_header .navbar-text,.update-payment-page .app_header .navbar-text,[class*=ca-] .app_header .navbar-text,[class*=pe-] .app_header .navbar-text{display:none}}.btn-header-logout{color:#fff;font-size:15px;font-family:Assistant-SemiBold;text-decoration:underline;position:relative;top:-13px;left:13px}.btn-header-logout:focus,.btn-header-logout:hover{color:#fff}.btn-header-logout img{padding-left:5px}</style><style>@-webkit-keyframes menuOpen{0%{-webkit-transform:translateX(-100%);transform:translateX(-100%)}to{-webkit-transform:translateX(0);transform:translateX(0)}}@keyframes menuOpen{0%{-webkit-transform:translateX(-100%);transform:translateX(-100%)}to{-webkit-transform:translateX(0);transform:translateX(0)}}@-webkit-keyframes menuClose{0%{-webkit-transform:translateX(0);transform:translateX(0)}to{-webkit-transform:translateX(-100%);transform:translateX(-100%)}}@keyframes menuClose{0%{-webkit-transform:translateX(0);transform:translateX(0)}to{-webkit-transform:translateX(-100%);transform:translateX(-100%)}}.main-menu.menu-open[_ngcontent-c2]{-webkit-animation-name:menuOpen;animation-name:menuOpen;-webkit-animation-fill-mode:forwards;animation-fill-mode:forwards}.main-menu.menu-close[_ngcontent-c2], .main-menu.menu-open[_ngcontent-c2]{-webkit-animation-duration:.5s;animation-duration:.5s}.main-menu.menu-close[_ngcontent-c2]{-webkit-animation-name:menuClose;animation-name:menuClose;-webkit-animation-fill-mode:forwards;animation-fill-mode:forwards}.main-menu-screen.active[_ngcontent-c2]{position:fixed;top:0;left:0;bottom:0;right:0;z-index:99}.main-menu[_ngcontent-c2]{background-color:#004677;width:80%;height:100%;position:fixed;z-index:9999;top:0;left:0;-webkit-transform:translateX(-100%);transform:translateX(-100%)}.main-menu[_ngcontent-c2]   .main-menu-title[_ngcontent-c2]{color:#fff;font-size:30px}.main-menu[_ngcontent-c2]   .main-menu-title-border[_ngcontent-c2]{border-bottom:1px solid #fff}.main-menu[_ngcontent-c2]   .main-menu-link[_ngcontent-c2]{color:#fff;font-size:20px;padding-top:30px}.main-menu[_ngcontent-c2]   .help-menu-item[_ngcontent-c2]:before{background:url(ico-menu-help.baa2984ab53ec609458e.svg) 0 0 no-repeat}.main-menu[_ngcontent-c2]   .close-menu-item[_ngcontent-c2]:before, .main-menu[_ngcontent-c2]   .help-menu-item[_ngcontent-c2]:before{content:" ";width:19px;height:19px;display:inline-block;margin-left:5px;vertical-align:middle}.main-menu[_ngcontent-c2]   .close-menu-item[_ngcontent-c2]:before{background:url(modal-close-btn.9fbde09061c94af8b89d.svg) 0 0 no-repeat;background-size:19px 19px}.main-menu[_ngcontent-c2]   .logout-menu-item[_ngcontent-c2]:before{content:" ";width:19px;height:19px;display:inline-block;margin-left:5px;vertical-align:middle;background:url(ico-menu-exit.424e300df3c73c35ae2f.svg) 0 0 no-repeat}@media (min-width:768px){.main-menu[_ngcontent-c2]{width:50%}}@media (min-width:992px){.main-menu[_ngcontent-c2]{width:33%}}</style><style></style><style>.spinnerContainer[_ngcontent-c4]{background-color:hsla(0,0%,100%,.5);position:fixed;top:0;bottom:0;left:0;right:0;z-index:9999999999999;width:100%;height:100%}.spinnerContainer.show[_ngcontent-c4]{display:block}.spinnerWrapper[_ngcontent-c4]{width:100%;height:100%;position:relative}.spinnerWrapper[_ngcontent-c4]   .spinner[_ngcontent-c4]{position:absolute;left:0;top:0;right:0;bottom:0;margin:auto;border:4px solid hsla(0,0%,100%,0);border-radius:50%;border-top:4px solid #fcc247;border-right:4px solid #fcc247;border-bottom:4px solid #3a95c4;width:50px;height:50px;-webkit-animation:spin .6s linear infinite;animation:spin .6s linear infinite}@-webkit-keyframes spin{0%{-webkit-transform:rotate(0deg)}to{-webkit-transform:rotate(1turn)}}@keyframes spin{0%{-webkit-transform:rotate(0deg);transform:rotate(0deg)}to{-webkit-transform:rotate(1turn);transform:rotate(1turn)}}</style><style>.paragraph[_ngcontent-c5]{font-size:22px}.modal-info-header-icon[_ngcontent-c5]{padding-left:7px}</style><style>.modal-content[_ngcontent-c6]   .paragraph[_ngcontent-c6]{font-size:inherit}@media screen and (min-width:768px){.modal-content[_ngcontent-c6]   .paragraph[_ngcontent-c6]{overflow:auto;max-height:260px}}.modal-info-header-icon[_ngcontent-c6]{padding-left:7px}</style><style>.modal-content[_ngcontent-c7]   .paragraph[_ngcontent-c7]{font-size:15px}.modal-info-header-icon[_ngcontent-c7]{padding-left:7px}</style><style>.paragraph[_ngcontent-c9]{font-weight:400}</style><style>.reset-padding[_ngcontent-c10]{padding-top:0}.small[_ngcontent-c10]{font-size:18px}.paragraph[_ngcontent-c10]{font-weight:400}</style><style>.download-invoices-container[_ngcontent-c11]{padding-right:15px;padding-left:15px}.download-invoices-container[_ngcontent-c11]   a[_ngcontent-c11]{margin-bottom:15px;float:right;width:100%;font-size:16px;cursor:pointer;color:#004677}.download-invoices-container[_ngcontent-c11]   img[_ngcontent-c11]{width:26px;height:29px;float:right}.download-invoices-container[_ngcontent-c11]   .invoice-num[_ngcontent-c11]{float:right;margin-left:10px;text-decoration:underline}.download-invoices-container[_ngcontent-c11]   .invoice-price[_ngcontent-c11]{float:right}</style><style>.modal-content[_ngcontent-c12]   .paragraph[_ngcontent-c12]{font-size:15px}.modal-info-header-icon[_ngcontent-c12]{padding-left:7px}</style><style>.paragraph[_ngcontent-c13]{font-weight:400}</style><style>.modal-body[_ngcontent-c14]{padding-top:0}.side-hint-container[_ngcontent-c14]{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;min-height:135px;background-image:-webkit-linear-gradient(top,#fff,#f9f9f9,#f3f3f3,#eee,#e8e8e8);background-image:linear-gradient(180deg,#fff,#f9f9f9,#f3f3f3,#eee,#e8e8e8)}@media screen and (max-width:767px){.side-hint-container[_ngcontent-c14]{min-height:100px}}.side-hint-container[_ngcontent-c14]   .credit-card[_ngcontent-c14]{width:103px;height:107px}@media screen and (max-width:767px){.side-hint-container[_ngcontent-c14]   .credit-card[_ngcontent-c14]{width:72px;height:75px}}.ok-message[_ngcontent-c14]{padding-right:15px;margin:0}@media screen and (max-width:767px){.ok-message[_ngcontent-c14]{padding-right:0}}</style><style>.vehicle-replace-text[_ngcontent-c17]{font-size:22px;color:#0371ab;display:inline-block;padding:8px 0}.vehicle-replace-number[_ngcontent-c17]{font-size:30px;color:#0371ab;display:inline-block;padding:2px 0;font-family:Assistant-Regular,sans-serif;font-weight:100}.vehicle-replaced-text[_ngcontent-c17]{color:#666;font-size:18px;padding:11px 0;display:inline-block}.vehicle-replaced-number[_ngcontent-c17]{color:#666;font-size:25px;display:inline-block;padding:6px 0}</style><style>.reset-padding[_ngcontent-c18]{padding-top:0}.small[_ngcontent-c18]{font-size:18px}.paragraph[_ngcontent-c18]{font-weight:400}</style><style>.reset-padding[_ngcontent-c19]{padding-top:0}.small[_ngcontent-c19]{font-size:18px}.paragraph[_ngcontent-c19]{font-weight:400}.modal-customer-area-renewed[_ngcontent-c19]{top:0}@media screen and (max-width:767px){.modal-customer-area-renewed[_ngcontent-c19]{top:40px!important}}.modal-customer-area-renewed[_ngcontent-c19]   .modal-dialog[_ngcontent-c19]{width:616px}@media screen and (min-width:768px){.modal-customer-area-renewed[_ngcontent-c19]   .modal-dialog[_ngcontent-c19]{margin:124px auto}}@media screen and (min-width:768px) and (max-width:960px){.modal-customer-area-renewed[_ngcontent-c19]   .modal-dialog[_ngcontent-c19]{width:730px}}@media screen and (max-width:767px){.modal-customer-area-renewed[_ngcontent-c19]   .modal-dialog[_ngcontent-c19]{width:94%}}.modal-customer-area-renewed[_ngcontent-c19]   .modal-content[_ngcontent-c19]{background-image:-webkit-linear-gradient(top,#034c84,#1163a4 49%,#1e78c0);background-image:linear-gradient(180deg,#034c84,#1163a4 49%,#1e78c0);background-color:transparent;border:none;border-radius:16px;box-shadow:0 0 42px 0 rgba(0,0,0,.78)}.modal-customer-area-renewed[_ngcontent-c19]   .modal-body[_ngcontent-c19]{height:574px;padding:38px;padding-bottom:0}@media screen and (min-width:768px) and (max-width:960px){.modal-customer-area-renewed[_ngcontent-c19]   .modal-body[_ngcontent-c19]{height:100%}}@media screen and (max-width:767px){.modal-customer-area-renewed[_ngcontent-c19]   .modal-body[_ngcontent-c19]{padding:30px;padding-bottom:0;height:450px}}.modal-customer-area-renewed[_ngcontent-c19]   .modal-body[_ngcontent-c19]   .modal-wrapper[_ngcontent-c19]{width:100%;height:100%;background-image:url(customer-area-couples.f3741b6e023a55ca3e32.png);background-repeat:no-repeat;background-position-x:50%;background-position-y:100%;text-align:center;background-size:338px 301px}@media screen and (min-width:768px) and (max-width:960px){.modal-customer-area-renewed[_ngcontent-c19]   .modal-body[_ngcontent-c19]   .modal-wrapper[_ngcontent-c19]{background-size:90%}}@media screen and (max-width:767px){.modal-customer-area-renewed[_ngcontent-c19]   .modal-body[_ngcontent-c19]   .modal-wrapper[_ngcontent-c19]{background-size:181px 154px;background-position-y:calc(100% + 12px)}}.modal-customer-area-renewed[_ngcontent-c19]   .modal-body[_ngcontent-c19]   .modal-wrapper[_ngcontent-c19]   .brand-logo[_ngcontent-c19]{margin-bottom:29px;width:65px;height:49px}@media screen and (max-width:767px){.modal-customer-area-renewed[_ngcontent-c19]   .modal-body[_ngcontent-c19]   .modal-wrapper[_ngcontent-c19]   .brand-logo[_ngcontent-c19]{width:65px;margin-bottom:25px}}.modal-customer-area-renewed[_ngcontent-c19]   .modal-body[_ngcontent-c19]   .modal-wrapper[_ngcontent-c19]   p[_ngcontent-c19]{font-family:Assistant-Bold;font-size:26px;font-weight:800;letter-spacing:-.7px;line-height:1.3;color:#fff;margin:0;margin-bottom:20px}.modal-customer-area-renewed[_ngcontent-c19]   .modal-body[_ngcontent-c19]   .modal-wrapper[_ngcontent-c19]   p[_ngcontent-c19]   span[_ngcontent-c19]{color:#fbb033}@media screen and (max-width:767px){.modal-customer-area-renewed[_ngcontent-c19]   .modal-body[_ngcontent-c19]   .modal-wrapper[_ngcontent-c19]   p[_ngcontent-c19]{font-size:26px;margin-bottom:40px}}.modal-customer-area-renewed[_ngcontent-c19]   .modal-body[_ngcontent-c19]   .modal-wrapper[_ngcontent-c19]   .btn-redirect[_ngcontent-c19]{width:233px;height:56px;border-radius:4px;background-color:#fff;font-family:Assistant-SemiBold;font-size:19px;font-weight:600;letter-spacing:-.08px;color:#000;margin-bottom:14px}@media screen and (max-width:767px){.modal-customer-area-renewed[_ngcontent-c19]   .modal-body[_ngcontent-c19]   .modal-wrapper[_ngcontent-c19]   .btn-redirect[_ngcontent-c19]{width:100%;height:44px;font-size:16px}}.modal-customer-area-renewed[_ngcontent-c19]   .modal-body[_ngcontent-c19]   .modal-wrapper[_ngcontent-c19]   .btn-abort[_ngcontent-c19]{font-family:Assistant-SemiBold;font-size:14px;font-weight:600;letter-spacing:.45px;color:#fff;text-decoration:underline;background:transparent;border:none;display:block;margin:0 auto}@media screen and (max-width:767px){.modal-customer-area-renewed[_ngcontent-c19]   .modal-body[_ngcontent-c19]   .modal-wrapper[_ngcontent-c19]   .btn-abort[_ngcontent-c19]{font-size:16px;width:100%}}.modal-customer-area-renewed.carmelton[_ngcontent-c19]   .modal-content[_ngcontent-c19]{background-image:-webkit-linear-gradient(top,#9ecadb,#edf1ee);background-image:linear-gradient(180deg,#9ecadb,#edf1ee)}.modal-customer-area-renewed.carmelton[_ngcontent-c19]   .modal-body[_ngcontent-c19]{padding-right:0;padding-left:0}.modal-customer-area-renewed.carmelton[_ngcontent-c19]   .modal-body[_ngcontent-c19]   .modal-wrapper[_ngcontent-c19]{background-image:url(login-renewd-carmelton.2ff0eadf8a67608ef8c1.png);background-size:100%}@media screen and (max-width:767px){.modal-customer-area-renewed.carmelton[_ngcontent-c19]   .modal-body[_ngcontent-c19]   .modal-wrapper[_ngcontent-c19]{background-position-y:calc(100% + 1px)}}.modal-customer-area-renewed.carmelton[_ngcontent-c19]   .modal-body[_ngcontent-c19]   .modal-wrapper[_ngcontent-c19]   .brand-logo[_ngcontent-c19]{width:auto;height:auto}@media screen and (max-width:767px){.modal-customer-area-renewed.carmelton[_ngcontent-c19]   .modal-body[_ngcontent-c19]   .modal-wrapper[_ngcontent-c19]   .brand-logo[_ngcontent-c19]{width:127px}}.modal-customer-area-renewed.carmelton[_ngcontent-c19]   .modal-body[_ngcontent-c19]   .modal-wrapper[_ngcontent-c19]   p[_ngcontent-c19]{color:#003773}.modal-customer-area-renewed.carmelton[_ngcontent-c19]   .modal-body[_ngcontent-c19]   .modal-wrapper[_ngcontent-c19]   p[_ngcontent-c19]   span[_ngcontent-c19]{color:#376a22}.modal-customer-area-renewed.carmelton[_ngcontent-c19]   .modal-body[_ngcontent-c19]   .modal-wrapper[_ngcontent-c19]   .btn-redirect[_ngcontent-c19]{background-color:#30862b;color:#fff}@media screen and (max-width:767px){.modal-customer-area-renewed.carmelton[_ngcontent-c19]   .modal-body[_ngcontent-c19]   .modal-wrapper[_ngcontent-c19]   .btn-redirect[_ngcontent-c19]{width:213px}}.modal-customer-area-renewed.carmelton[_ngcontent-c19]   .modal-body[_ngcontent-c19]   .modal-wrapper[_ngcontent-c19]   .btn-abort[_ngcontent-c19]{color:#003773}@media screen and (max-width:767px){.modal-customer-area-renewed.carmelton[_ngcontent-c19]   .modal-body[_ngcontent-c19]   .modal-wrapper[_ngcontent-c19]   .btn-abort[_ngcontent-c19]{width:213px}}</style><style>.reset-padding[_ngcontent-c20]{padding-top:0}.small[_ngcontent-c20]{font-size:18px}.paragraph[_ngcontent-c20]{font-weight:400}</style><style>.modal-content[_ngcontent-c21]   .paragraph[_ngcontent-c21]{font-size:15px}.modal-info-header-icon[_ngcontent-c21]{padding-left:7px}</style><style>.modal-calendar[_ngcontent-c22]   .modal-dialog[_ngcontent-c22]{width:659px}@media screen and (max-width:767px){.modal-calendar[_ngcontent-c22]   .modal-dialog[_ngcontent-c22]{width:auto}}.modal-calendar[_ngcontent-c22]   .modal-content[_ngcontent-c22]{border-radius:6px;box-shadow:0 0 22px 0 rgba(0,0,0,.31);border:1px solid #d6d6d6}.modal-calendar[_ngcontent-c22]   .modal-body[_ngcontent-c22]{padding:40px 40px 20px}@media screen and (max-width:767px){.modal-calendar[_ngcontent-c22]   .modal-body[_ngcontent-c22]{padding-left:20px;padding-right:20px}}.modal-calendar[_ngcontent-c22]   .submit-btn[_ngcontent-c22]{width:86px;height:34px;font-family:Assistant-SemiBold;font-size:16px;font-weight:600;letter-spacing:-.06px;text-align:center;color:#fff;border-radius:3px;background-color:#217bc5;float:left}.modal-calendar[_ngcontent-c22]   .submit-btn[_ngcontent-c22]:focus{outline:2px solid #ff6700}.modal-calendar[_ngcontent-c22]   .cancel-btn[_ngcontent-c22]{padding-right:5px;font-family:Assistant-SemiBold;font-size:16px;font-weight:600;letter-spacing:-.06px;text-align:right;color:#07528d;background-color:#fff;width:50px}.modal-calendar.carmelton[_ngcontent-c22]   .submit-btn[_ngcontent-c22]{background-color:#30862b}</style><style>.reset-padding[_ngcontent-c28]{padding-top:0}.small[_ngcontent-c28]{font-size:18px}.paragraph[_ngcontent-c28]{font-weight:400}.modal-customer-area-registration-complete[_ngcontent-c28]{top:0}@media screen and (max-width:767px){.modal-customer-area-registration-complete[_ngcontent-c28]{top:40px!important}}.modal-customer-area-registration-complete[_ngcontent-c28]   .modal-dialog[_ngcontent-c28]{width:616px}@media screen and (min-width:768px){.modal-customer-area-registration-complete[_ngcontent-c28]   .modal-dialog[_ngcontent-c28]{margin:124px auto}}@media screen and (min-width:768px) and (max-width:960px){.modal-customer-area-registration-complete[_ngcontent-c28]   .modal-dialog[_ngcontent-c28]{width:730px}}@media screen and (max-width:767px){.modal-customer-area-registration-complete[_ngcontent-c28]   .modal-dialog[_ngcontent-c28]{width:94%}}.modal-customer-area-registration-complete[_ngcontent-c28]   .modal-content[_ngcontent-c28]{background-image:-webkit-linear-gradient(top,#034c84,#1163a4 49%,#1e78c0);background-image:linear-gradient(180deg,#034c84,#1163a4 49%,#1e78c0);background-color:transparent;border:none;border-radius:16px;box-shadow:0 0 42px 0 rgba(0,0,0,.78)}.modal-customer-area-registration-complete[_ngcontent-c28]   .modal-body[_ngcontent-c28]{height:680px;padding:40px 80px 0}@media screen and (min-width:768px) and (max-width:960px){.modal-customer-area-registration-complete[_ngcontent-c28]   .modal-body[_ngcontent-c28]{height:100%}}@media screen and (max-width:767px){.modal-customer-area-registration-complete[_ngcontent-c28]   .modal-body[_ngcontent-c28]{padding:35px;padding-bottom:0;height:530px}}.modal-customer-area-registration-complete[_ngcontent-c28]   .modal-body[_ngcontent-c28]   .modal-wrapper[_ngcontent-c28]{width:100%;height:100%;background-image:url(customer-area-couples.f3741b6e023a55ca3e32.png);background-repeat:no-repeat;background-position-x:50%;background-position-y:100%;text-align:center;background-size:308px 271px}@media screen and (min-width:768px) and (max-width:960px){.modal-customer-area-registration-complete[_ngcontent-c28]   .modal-body[_ngcontent-c28]   .modal-wrapper[_ngcontent-c28]{background-size:90%}}@media screen and (max-width:767px){.modal-customer-area-registration-complete[_ngcontent-c28]   .modal-body[_ngcontent-c28]   .modal-wrapper[_ngcontent-c28]{background-size:181px 154px;background-position-y:calc(100% - 10px)}}.modal-customer-area-registration-complete[_ngcontent-c28]   .modal-body[_ngcontent-c28]   .modal-wrapper[_ngcontent-c28]   .brand-logo[_ngcontent-c28]{margin-bottom:29px}@media screen and (max-width:767px){.modal-customer-area-registration-complete[_ngcontent-c28]   .modal-body[_ngcontent-c28]   .modal-wrapper[_ngcontent-c28]   .brand-logo[_ngcontent-c28]{margin-bottom:25px;width:45px}}.modal-customer-area-registration-complete[_ngcontent-c28]   .modal-body[_ngcontent-c28]   .modal-wrapper[_ngcontent-c28]   p[_ngcontent-c28]{font-weight:700;font-family:Assistant-Bold;font-size:33px;line-height:1.18;letter-spacing:-.23px;color:#fff;margin:0;margin-bottom:40px}@media screen and (max-width:767px){.modal-customer-area-registration-complete[_ngcontent-c28]   .modal-body[_ngcontent-c28]   .modal-wrapper[_ngcontent-c28]   p[_ngcontent-c28]{font-size:25px}}.modal-customer-area-registration-complete[_ngcontent-c28]   .modal-body[_ngcontent-c28]   .modal-wrapper[_ngcontent-c28]   p[_ngcontent-c28]   span[_ngcontent-c28]{font-family:Assistant-Regular;font-weight:400;color:#fff;line-height:1.27;letter-spacing:-.44px;font-size:26px;margin-bottom:25px;display:inline-block}@media screen and (max-width:767px){.modal-customer-area-registration-complete[_ngcontent-c28]   .modal-body[_ngcontent-c28]   .modal-wrapper[_ngcontent-c28]   p[_ngcontent-c28]   span[_ngcontent-c28]{font-size:19px;font-family:Assistant-SemiBold}}@media screen and (max-width:767px){.modal-customer-area-registration-complete[_ngcontent-c28]   .modal-body[_ngcontent-c28]   .modal-wrapper[_ngcontent-c28]   p[_ngcontent-c28]{font-size:25px;margin-bottom:40px}}.modal-customer-area-registration-complete[_ngcontent-c28]   .modal-body[_ngcontent-c28]   .modal-wrapper[_ngcontent-c28]   .btn-redirect[_ngcontent-c28]{width:233px;height:56px;border-radius:4px;background-color:#fff;font-family:Assistant-SemiBold;font-size:19px;font-weight:600;letter-spacing:-.08px;color:#000;margin-bottom:14px}@media screen and (max-width:767px){.modal-customer-area-registration-complete[_ngcontent-c28]   .modal-body[_ngcontent-c28]   .modal-wrapper[_ngcontent-c28]   .btn-redirect[_ngcontent-c28]{width:85%;height:44px;font-size:16px}}.modal-customer-area-registration-complete[_ngcontent-c28]   .modal-body[_ngcontent-c28]   .modal-wrapper[_ngcontent-c28]   .btn-abort[_ngcontent-c28]{font-family:Assistant-SemiBold;font-size:14px;font-weight:600;letter-spacing:.45px;color:#fff;text-decoration:underline;background:transparent;border:none;display:block;margin:0 auto}@media screen and (max-width:767px){.modal-customer-area-registration-complete[_ngcontent-c28]   .modal-body[_ngcontent-c28]   .modal-wrapper[_ngcontent-c28]   .btn-abort[_ngcontent-c28]{font-size:16px;width:100%}}.modal-customer-area-registration-complete[_ngcontent-c28]   .modal-body[_ngcontent-c28]   .modal-wrapper[_ngcontent-c28]   .disclaimer[_ngcontent-c28]{font-size:14px;font-weight:400;letter-spacing:.28px;color:#b1dcff;margin-top:9px}@media screen and (max-width:767px){.modal-customer-area-registration-complete[_ngcontent-c28]   .modal-body[_ngcontent-c28]   .modal-wrapper[_ngcontent-c28]   .disclaimer[_ngcontent-c28]{margin-top:0}}.modal-customer-area-registration-complete.carmelton[_ngcontent-c28]   .modal-content[_ngcontent-c28]{background-image:-webkit-linear-gradient(top,#9ecadb,#edf1ee);background-image:linear-gradient(180deg,#9ecadb,#edf1ee)}.modal-customer-area-registration-complete.carmelton[_ngcontent-c28]   .modal-body[_ngcontent-c28]{padding-right:0;padding-left:0}.modal-customer-area-registration-complete.carmelton[_ngcontent-c28]   .modal-body[_ngcontent-c28]   .modal-wrapper[_ngcontent-c28]{background-image:url(login-renewd-carmelton.2ff0eadf8a67608ef8c1.png);background-size:100%}@media screen and (max-width:767px){.modal-customer-area-registration-complete.carmelton[_ngcontent-c28]   .modal-body[_ngcontent-c28]   .modal-wrapper[_ngcontent-c28]{background-position-y:calc(100% + 1px)}}.modal-customer-area-registration-complete.carmelton[_ngcontent-c28]   .modal-body[_ngcontent-c28]   .modal-wrapper[_ngcontent-c28]   .brand-logo[_ngcontent-c28]{width:auto;height:auto}@media screen and (max-width:767px){.modal-customer-area-registration-complete.carmelton[_ngcontent-c28]   .modal-body[_ngcontent-c28]   .modal-wrapper[_ngcontent-c28]   .brand-logo[_ngcontent-c28]{width:127px}}.modal-customer-area-registration-complete.carmelton[_ngcontent-c28]   .modal-body[_ngcontent-c28]   .modal-wrapper[_ngcontent-c28]   p[_ngcontent-c28]{padding-left:80px;padding-right:80px;color:#003773}.modal-customer-area-registration-complete.carmelton[_ngcontent-c28]   .modal-body[_ngcontent-c28]   .modal-wrapper[_ngcontent-c28]   p[_ngcontent-c28]   span[_ngcontent-c28]{color:#376a22}@media screen and (max-width:767px){.modal-customer-area-registration-complete.carmelton[_ngcontent-c28]   .modal-body[_ngcontent-c28]   .modal-wrapper[_ngcontent-c28]   p[_ngcontent-c28]{padding-left:50px;padding-right:50px}}.modal-customer-area-registration-complete.carmelton[_ngcontent-c28]   .modal-body[_ngcontent-c28]   .modal-wrapper[_ngcontent-c28]   .btn-redirect[_ngcontent-c28]{background-color:#30862b;color:#fff}@media screen and (max-width:767px){.modal-customer-area-registration-complete.carmelton[_ngcontent-c28]   .modal-body[_ngcontent-c28]   .modal-wrapper[_ngcontent-c28]   .btn-redirect[_ngcontent-c28]{width:213px}}.modal-customer-area-registration-complete.carmelton[_ngcontent-c28]   .modal-body[_ngcontent-c28]   .modal-wrapper[_ngcontent-c28]   .btn-abort[_ngcontent-c28]{color:#003773}@media screen and (max-width:767px){.modal-customer-area-registration-complete.carmelton[_ngcontent-c28]   .modal-body[_ngcontent-c28]   .modal-wrapper[_ngcontent-c28]   .btn-abort[_ngcontent-c28]{width:213px}}.modal-customer-area-registration-complete.carmelton[_ngcontent-c28]   .modal-body[_ngcontent-c28]   .modal-wrapper[_ngcontent-c28]   .disclaimer[_ngcontent-c28]{color:#376a22}p[_ngcontent-c28]:focus{outline:none}</style><style>.reset-padding[_ngcontent-c30]{padding-top:0}.small[_ngcontent-c30]{font-size:18px}.paragraph[_ngcontent-c30]{font-weight:400}.btn-send-otp-by-email[_ngcontent-c30]{font-family:Assistant-SemiBold;font-size:16px;font-weight:600;color:#024e75;text-decoration:underline}@media screen and (max-width:767px){.btn-send-otp-by-email[_ngcontent-c30]{margin-top:10px}}</style><style>.modal-content[_ngcontent-c31]   .paragraph[_ngcontent-c31]{font-size:15px}.modal-info-header-icon[_ngcontent-c31]{padding-left:7px}</style><style>.modal-content[_ngcontent-c32]{overflow:hidden}.modal-body[_ngcontent-c32]{padding-top:30px;background-image:url(vehicle-new-account-loader.511d3b9777e488a2e518.gif);background-repeat:no-repeat;background-size:550px 252px;background-position:50% 3px}@media screen and (max-width:767px){.modal-body[_ngcontent-c32]{padding-top:16px;background-image:url(vehicle-new-account-loader-mobile.04669ecd62b194e1d12f.gif);background-size:254px 133px;background-position:50% calc(50% + 17px)}}p[_ngcontent-c32]{font-size:20px;line-height:1.6;letter-spacing:-.2px;color:#000;margin-bottom:170px}@media screen and (max-width:767px){p[_ngcontent-c32]{font-size:16px;line-height:1.44;letter-spacing:-.16px;width:130px;margin-bottom:138px}}</style><style>.modal-body[_ngcontent-c33]{position:relative;min-height:245px;padding-top:17px}.modal-body[_ngcontent-c33]   p[_ngcontent-c33]{width:280px;font-size:20px;line-height:1.6;letter-spacing:-.2px;color:#000;margin-bottom:35px}@media screen and (max-width:767px){.modal-body[_ngcontent-c33]   p[_ngcontent-c33]{font-size:16px;line-height:1.44;letter-spacing:-.16px;margin-bottom:172px}}.modal-body[_ngcontent-c33]   .icon-bg[_ngcontent-c33]{width:213px;height:239px;position:absolute;top:0;left:21px}@media screen and (max-width:767px){.modal-body[_ngcontent-c33]   .icon-bg[_ngcontent-c33]{width:176px;height:187px;top:76px;left:50%;-webkit-transform:translateX(-50%);transform:translateX(-50%)}}</style><style>.modal-content[_ngcontent-c34]   .paragraph[_ngcontent-c34]{font-size:15px}.modal-info-header-icon[_ngcontent-c34]{padding-left:7px}</style><style>.reset-padding[_ngcontent-c37]{padding-top:0}.small[_ngcontent-c37]{font-size:18px}.paragraph[_ngcontent-c37]{font-weight:400}.modal-payments-external-register[_ngcontent-c37]{top:0}@media screen and (max-width:767px){.modal-payments-external-register[_ngcontent-c37]{top:40px!important}}.modal-payments-external-register[_ngcontent-c37]   .modal-dialog[_ngcontent-c37]{width:694px}@media screen and (min-width:768px){.modal-payments-external-register[_ngcontent-c37]   .modal-dialog[_ngcontent-c37]{margin:90px auto}}@media screen and (min-width:768px) and (max-width:960px){.modal-payments-external-register[_ngcontent-c37]   .modal-dialog[_ngcontent-c37]{width:730px}}@media screen and (max-width:767px){.modal-payments-external-register[_ngcontent-c37]   .modal-dialog[_ngcontent-c37]{width:75%;margin:0 auto;margin-top:30px}}.modal-payments-external-register[_ngcontent-c37]   .modal-content[_ngcontent-c37]{background-image:-webkit-linear-gradient(top,#034c84,#1163a4 49%,#1e78c0);background-image:linear-gradient(180deg,#034c84,#1163a4 49%,#1e78c0);background-color:transparent;border:none;border-radius:31px;box-shadow:0 0 42px 0 rgba(0,0,0,.78)}@media screen and (max-width:767px){.modal-payments-external-register[_ngcontent-c37]   .modal-content[_ngcontent-c37]{border-radius:16px}}.modal-payments-external-register[_ngcontent-c37]   .modal-body[_ngcontent-c37]{height:713px;padding:68px;padding-bottom:0}@media screen and (min-width:768px) and (max-width:960px){.modal-payments-external-register[_ngcontent-c37]   .modal-body[_ngcontent-c37]{height:100%}}@media screen and (max-width:767px){.modal-payments-external-register[_ngcontent-c37]   .modal-body[_ngcontent-c37]{padding:0;padding-top:40px;padding-bottom:0;height:526px}}.modal-payments-external-register[_ngcontent-c37]   .modal-body[_ngcontent-c37]   .modal-wrapper[_ngcontent-c37]{width:100%;height:100%;background-image:url(customer-area-couples.f3741b6e023a55ca3e32.png);background-repeat:no-repeat;background-position-x:50%;background-position-y:calc(100% - 15px);text-align:center;background-size:359px 305px}@media screen and (min-width:768px) and (max-width:960px){.modal-payments-external-register[_ngcontent-c37]   .modal-body[_ngcontent-c37]   .modal-wrapper[_ngcontent-c37]{background-size:90%}}@media screen and (max-width:767px){.modal-payments-external-register[_ngcontent-c37]   .modal-body[_ngcontent-c37]   .modal-wrapper[_ngcontent-c37]{background-size:178px 151px;background-position-y:calc(100% - 7px)}}.modal-payments-external-register[_ngcontent-c37]   .modal-body[_ngcontent-c37]   .modal-wrapper[_ngcontent-c37]   .brand-logo[_ngcontent-c37]{margin-bottom:29px;width:65px;height:49px}@media screen and (max-width:767px){.modal-payments-external-register[_ngcontent-c37]   .modal-body[_ngcontent-c37]   .modal-wrapper[_ngcontent-c37]   .brand-logo[_ngcontent-c37]{width:65px;margin-bottom:25px}}.modal-payments-external-register[_ngcontent-c37]   .modal-body[_ngcontent-c37]   .modal-wrapper[_ngcontent-c37]   p[_ngcontent-c37]{font-family:Assistant-Regular;font-size:22px;line-height:1.5;letter-spacing:.33px;color:#fff;margin:0}@media screen and (max-width:767px){.modal-payments-external-register[_ngcontent-c37]   .modal-body[_ngcontent-c37]   .modal-wrapper[_ngcontent-c37]   p[_ngcontent-c37]{font-size:15px;line-height:2.36}}.modal-payments-external-register[_ngcontent-c37]   .modal-body[_ngcontent-c37]   .modal-wrapper[_ngcontent-c37]   p.bold[_ngcontent-c37]{font-family:Assistant-SemiBold;font-weight:600;font-size:26px}@media screen and (max-width:767px){.modal-payments-external-register[_ngcontent-c37]   .modal-body[_ngcontent-c37]   .modal-wrapper[_ngcontent-c37]   p.bold[_ngcontent-c37]{font-size:16px}}.modal-payments-external-register[_ngcontent-c37]   .modal-body[_ngcontent-c37]   .modal-wrapper[_ngcontent-c37]   p.bold[_ngcontent-c37]   span[_ngcontent-c37]{font-family:Assistant-Bold;font-weight:700;font-size:33px;color:#fbb033}@media screen and (max-width:767px){.modal-payments-external-register[_ngcontent-c37]   .modal-body[_ngcontent-c37]   .modal-wrapper[_ngcontent-c37]   p.bold[_ngcontent-c37]   span[_ngcontent-c37]{font-size:25px;padding-left:19%;padding-right:19%;line-height:1.2;display:block}}.modal-payments-external-register[_ngcontent-c37]   .modal-body[_ngcontent-c37]   .modal-wrapper[_ngcontent-c37]   p.light[_ngcontent-c37]{padding-left:110px;padding-right:110px}@media screen and (max-width:767px){.modal-payments-external-register[_ngcontent-c37]   .modal-body[_ngcontent-c37]   .modal-wrapper[_ngcontent-c37]   p.light[_ngcontent-c37]{padding-left:12%;padding-right:12%;line-height:1.8}}@media screen and (max-width:767px){.modal-payments-external-register[_ngcontent-c37]   .modal-body[_ngcontent-c37]   .modal-wrapper[_ngcontent-c37]   .actions-container[_ngcontent-c37]{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-pack:justify;-ms-flex-pack:justify;justify-content:space-between;padding-left:27px;padding-right:27px}}.modal-payments-external-register[_ngcontent-c37]   .modal-body[_ngcontent-c37]   .modal-wrapper[_ngcontent-c37]   .btn-redirect[_ngcontent-c37]{width:150px;height:46px;border-radius:4px;background-color:#fff;font-family:Assistant-SemiBold;font-size:19px;font-weight:600;letter-spacing:-.08px;color:#000;margin-bottom:14px;margin-left:15px;margin-top:35px;display:inline-block}@media screen and (max-width:767px){.modal-payments-external-register[_ngcontent-c37]   .modal-body[_ngcontent-c37]   .modal-wrapper[_ngcontent-c37]   .btn-redirect[_ngcontent-c37]{width:52%;height:34px;font-size:14px;margin-left:0;-ms-flex-negative:0;flex-shrink:0}}.modal-payments-external-register[_ngcontent-c37]   .modal-body[_ngcontent-c37]   .modal-wrapper[_ngcontent-c37]   .btn-abort[_ngcontent-c37]{width:119px;height:46px;border:2px solid #fff;border-radius:4px;font-family:Assistant-SemiBold;font-size:19px;font-weight:600;letter-spacing:-.08px;color:#fff;background:transparent;margin-top:35px;display:inline-block}@media screen and (max-width:767px){.modal-payments-external-register[_ngcontent-c37]   .modal-body[_ngcontent-c37]   .modal-wrapper[_ngcontent-c37]   .btn-abort[_ngcontent-c37]{font-size:14px;height:34px;width:43%;-ms-flex-negative:0;flex-shrink:0}}.modal-payments-external-register[_ngcontent-c37]   .discount-stamp-container[_ngcontent-c37]{width:173px;height:173px;background-color:#fff;border-radius:100%;position:absolute;left:-86.5px;top:65px;display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-orient:vertical;-webkit-box-direction:normal;-ms-flex-direction:column;flex-direction:column;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center}@media screen and (max-width:767px){.modal-payments-external-register[_ngcontent-c37]   .discount-stamp-container[_ngcontent-c37]{width:78px;height:78px;top:79px;left:-39px}}.modal-payments-external-register[_ngcontent-c37]   .discount-stamp-container[_ngcontent-c37]   span[_ngcontent-c37]:first-child{font-family:Assistant-SemiBold;font-size:21px;font-weight:600;line-height:1.3;letter-spacing:-.5px;color:#113e63}@media screen and (max-width:767px){.modal-payments-external-register[_ngcontent-c37]   .discount-stamp-container[_ngcontent-c37]   span[_ngcontent-c37]:first-child{font-size:8px}}.modal-payments-external-register[_ngcontent-c37]   .discount-stamp-container[_ngcontent-c37]   span[_ngcontent-c37]:nth-child(2){font-family:Assistant-Bold;font-size:43px;font-weight:700;line-height:.8;letter-spacing:-.47px;color:#113e63}@media screen and (max-width:767px){.modal-payments-external-register[_ngcontent-c37]   .discount-stamp-container[_ngcontent-c37]   span[_ngcontent-c37]:nth-child(2){font-size:20px}}.modal-payments-external-register[_ngcontent-c37]   .discount-stamp-container[_ngcontent-c37]   span[_ngcontent-c37]:nth-child(3){font-family:Assistant-Bold;font-size:32px;font-weight:700;line-height:1;letter-spacing:-.22px;color:#113e63}@media screen and (max-width:767px){.modal-payments-external-register[_ngcontent-c37]   .discount-stamp-container[_ngcontent-c37]   span[_ngcontent-c37]:nth-child(3){font-size:14px}}.modal-payments-external-register[_ngcontent-c37]   .discount-stamp-container[_ngcontent-c37]   span[_ngcontent-c37]:nth-child(4){font-family:Assistant-SemiBold;font-size:20px;font-weight:600;line-height:1.3;letter-spacing:-.14px;color:#217bc5}@media screen and (max-width:767px){.modal-payments-external-register[_ngcontent-c37]   .discount-stamp-container[_ngcontent-c37]   span[_ngcontent-c37]:nth-child(4){font-size:12px}}@media screen and (max-width:767px){.modal-payments-external-register.carmelton[_ngcontent-c37]   .modal-dialog[_ngcontent-c37]{width:83%}}.modal-payments-external-register.carmelton[_ngcontent-c37]   .modal-content[_ngcontent-c37]{background-image:-webkit-linear-gradient(top,#9ecadb,#edf1ee);background-image:linear-gradient(180deg,#9ecadb,#edf1ee)}.modal-payments-external-register.carmelton[_ngcontent-c37]   .modal-body[_ngcontent-c37]{padding-right:0;padding-left:0;padding-top:90px}@media screen and (max-width:767px){.modal-payments-external-register.carmelton[_ngcontent-c37]   .modal-body[_ngcontent-c37]{height:541px;padding-top:65px}}.modal-payments-external-register.carmelton[_ngcontent-c37]   .modal-body[_ngcontent-c37]   .modal-wrapper[_ngcontent-c37]{background-image:url(login-renewd-carmelton.2ff0eadf8a67608ef8c1.png);background-size:100%;background-position-y:100%}@media screen and (max-width:767px){.modal-payments-external-register.carmelton[_ngcontent-c37]   .modal-body[_ngcontent-c37]   .modal-wrapper[_ngcontent-c37]{background-position-y:100%;border-bottom-right-radius:16px;border-bottom-left-radius:16px}}.modal-payments-external-register.carmelton[_ngcontent-c37]   .modal-body[_ngcontent-c37]   .modal-wrapper[_ngcontent-c37]   .brand-logo[_ngcontent-c37]{width:auto;height:auto}@media screen and (max-width:767px){.modal-payments-external-register.carmelton[_ngcontent-c37]   .modal-body[_ngcontent-c37]   .modal-wrapper[_ngcontent-c37]   .brand-logo[_ngcontent-c37]{width:127px}}.modal-payments-external-register.carmelton[_ngcontent-c37]   .modal-body[_ngcontent-c37]   .modal-wrapper[_ngcontent-c37]   p[_ngcontent-c37]{color:#003773}.modal-payments-external-register.carmelton[_ngcontent-c37]   .modal-body[_ngcontent-c37]   .modal-wrapper[_ngcontent-c37]   p[_ngcontent-c37]   span[_ngcontent-c37]{color:#30862b}.modal-payments-external-register.carmelton[_ngcontent-c37]   .modal-body[_ngcontent-c37]   .modal-wrapper[_ngcontent-c37]   p.light[_ngcontent-c37]{color:#000;font-family:Assistant-SemiBold;font-weight:600}@media screen and (min-width:768px){.modal-payments-external-register.carmelton[_ngcontent-c37]   .modal-body[_ngcontent-c37]   .modal-wrapper[_ngcontent-c37]   p.light[_ngcontent-c37]{padding-left:170px;padding-right:170px}}@media screen and (max-width:767px){.modal-payments-external-register.carmelton[_ngcontent-c37]   .modal-body[_ngcontent-c37]   .modal-wrapper[_ngcontent-c37]   p.light[_ngcontent-c37]{padding-left:10%;padding-right:10%;line-height:1.4;font-size:20px}}.modal-payments-external-register.carmelton[_ngcontent-c37]   .modal-body[_ngcontent-c37]   .modal-wrapper[_ngcontent-c37]   .btn-redirect[_ngcontent-c37]{background-color:#30862b;color:#fff}@media screen and (max-width:767px){.modal-payments-external-register.carmelton[_ngcontent-c37]   .modal-body[_ngcontent-c37]   .modal-wrapper[_ngcontent-c37]   .btn-redirect[_ngcontent-c37]{width:55%;height:39px;font-size:16px}}.modal-payments-external-register.carmelton[_ngcontent-c37]   .modal-body[_ngcontent-c37]   .modal-wrapper[_ngcontent-c37]   .btn-abort[_ngcontent-c37]{color:#30862b;border-color:#30862b}@media screen and (max-width:767px){.modal-payments-external-register.carmelton[_ngcontent-c37]   .modal-body[_ngcontent-c37]   .modal-wrapper[_ngcontent-c37]   .btn-abort[_ngcontent-c37]{width:40%;height:39px;font-size:16px}}@media screen and (max-width:767px){.modal-payments-external-register.carmelton[_ngcontent-c37]   .discount-stamp-container[_ngcontent-c37]{left:-28px}}.modal-payments-external-register.carmelton[_ngcontent-c37]   .discount-stamp-container[_ngcontent-c37]   span[_ngcontent-c37]:first-child{font-family:Assistant-SemiBold;font-size:21px;font-weight:600;line-height:1.3;letter-spacing:-.5px;color:#113e63}@media screen and (max-width:767px){.modal-payments-external-register.carmelton[_ngcontent-c37]   .discount-stamp-container[_ngcontent-c37]   span[_ngcontent-c37]:first-child{font-size:11px}}.modal-payments-external-register.carmelton[_ngcontent-c37]   .discount-stamp-container[_ngcontent-c37]   span[_ngcontent-c37]:nth-child(2){font-family:Assistant-SemiBold;font-size:21px;font-weight:600;line-height:1.3;letter-spacing:-.5px;color:#113e63}@media screen and (max-width:767px){.modal-payments-external-register.carmelton[_ngcontent-c37]   .discount-stamp-container[_ngcontent-c37]   span[_ngcontent-c37]:nth-child(2){font-size:11px}}.modal-payments-external-register.carmelton[_ngcontent-c37]   .discount-stamp-container[_ngcontent-c37]   span[_ngcontent-c37]:nth-child(3){font-family:Assistant-Bold;font-size:43px;font-weight:700;line-height:.91;letter-spacing:-.47px;color:#113e63}@media screen and (max-width:767px){.modal-payments-external-register.carmelton[_ngcontent-c37]   .discount-stamp-container[_ngcontent-c37]   span[_ngcontent-c37]:nth-child(3){font-size:23px}}</style><style>@media (min-width:768px){.modal-dialog[_ngcontent-c38]{width:526px}}@media (max-width:767px){.modal-dialog[_ngcontent-c38]{margin:18px}}.reset-padding[_ngcontent-c38]{padding-top:0}@media (max-width:767px){.reset-padding-left[_ngcontent-c38]{padding-left:0}}.small[_ngcontent-c38]{font-size:18px}.paragraph[_ngcontent-c38]{font-family:Assistant-Bold;font-size:16px;font-weight:700;line-height:1.31;letter-spacing:-.06px;color:#000}.info-container[_ngcontent-c38]{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-align:center;-ms-flex-align:center;align-items:center;margin-top:47px;margin-right:20px}@media (max-width:767px){.info-container[_ngcontent-c38]{-webkit-box-orient:vertical;-webkit-box-direction:normal;-ms-flex-direction:column;flex-direction:column;margin-right:0;margin-top:29px}}.info-container[_ngcontent-c38]   img[_ngcontent-c38]{-ms-flex-negative:0;flex-shrink:0}@media (max-width:767px){.info-container[_ngcontent-c38]   img[_ngcontent-c38]{-webkit-box-orient:vertical;-webkit-box-direction:normal;-ms-flex-direction:column;flex-direction:column;margin-bottom:7px;width:100%;max-height:104px;max-width:254px}}.info[_ngcontent-c38]{font-family:Assistant-SemiBold;font-size:13px;font-weight:600;line-height:1.23;letter-spacing:.16px;color:#090909;margin-right:21px;padding-left:15px}@media (max-width:767px){.info[_ngcontent-c38]{padding:0;margin:0;max-width:254px}}.form-group[_ngcontent-c38]{margin-bottom:3px;margin-top:5px}.form-group-lg[_ngcontent-c38]   .form-control[_ngcontent-c38]{height:34px;border-radius:3px;border:1px solid #9cb3c5;box-shadow:none}.btn-send-otp-by-email[_ngcontent-c38]{font-family:Assistant-SemiBold;font-size:16px;font-weight:600;color:#024e75;text-decoration:underline}@media screen and (max-width:767px){.btn-send-otp-by-email[_ngcontent-c38]{margin-top:10px}}</style><style>.modal-content[_ngcontent-c40]   .paragraph[_ngcontent-c40]{font-size:15px}.modal-info-header-icon[_ngcontent-c40]{padding-left:7px}</style><style>.reset-padding[_ngcontent-c41]{padding-top:0}.small[_ngcontent-c41]{font-size:18px}.paragraph[_ngcontent-c41]{font-weight:400}</style><script type="text/javascript" charset="utf-8" async="" src="./a/23.f987b276164f771d28aa.chunk.js.download"></script><script type="text/javascript" charset="utf-8" async="" src="./a/12.f9b961d79fa8d5559b94.chunk.js.download"></script><style>@media screen and (max-width:767px){.payments-external-login[_ngcontent-c42]{position:relative;padding-top:50px}}.payments-external-login[_ngcontent-c42]   .header-container[_ngcontent-c42]{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-align:center;-ms-flex-align:center;align-items:center;width:100%;height:171px;padding:45px;background-image:-webkit-linear-gradient(bottom,#86c4f8,#2f8cd9 22%,#113e63);background-image:linear-gradient(0deg,#86c4f8,#2f8cd9 22%,#113e63);border-top-left-radius:15px;border-top-right-radius:15px}.payments-external-login[_ngcontent-c42]   .header-container[_ngcontent-c42]   h1[_ngcontent-c42]{font-size:27px;font-family:Assistant-Bold;font-weight:700;letter-spacing:.04px;color:#fff;margin:0}.payments-external-login[_ngcontent-c42]   .header-container[_ngcontent-c42]   h1[_ngcontent-c42]   span[_ngcontent-c42]{display:block;margin-top:10px;font-size:22px;font-weight:400;font-family:Assistant-Regular;letter-spacing:.04px;color:#fff}@media screen and (max-width:767px){.payments-external-login[_ngcontent-c42]   .header-container[_ngcontent-c42]   h1[_ngcontent-c42]   span[_ngcontent-c42]{margin-top:8px}}@media screen and (max-width:767px){.payments-external-login[_ngcontent-c42]   .header-container[_ngcontent-c42]   h1[_ngcontent-c42]{font-size:17px}.payments-external-login[_ngcontent-c42]   .header-container[_ngcontent-c42]   h1[_ngcontent-c42]   span[_ngcontent-c42]{font-size:16px;padding-left:165px;line-height:1.38}}@media screen and (max-width:767px){.payments-external-login[_ngcontent-c42]   .header-container[_ngcontent-c42]{padding:0;height:112px;border-radius:0;padding-right:17px;background-image:-webkit-linear-gradient(bottom,#86c4f8 -7%,#2f8cd9 17%,#113e63);background-image:linear-gradient(0deg,#86c4f8 -7%,#2f8cd9 17%,#113e63)}}.payments-external-login[_ngcontent-c42]   .main[_ngcontent-c42]{margin-top:64px;padding-left:45px;padding-right:45px}.payments-external-login[_ngcontent-c42]   .main[_ngcontent-c42]   h2[_ngcontent-c42]{font-family:Assistant-Bold;font-size:23px;font-weight:700;color:#000;margin:0;margin-bottom:30px}@media screen and (max-width:767px){.payments-external-login[_ngcontent-c42]   .main[_ngcontent-c42]   h2[_ngcontent-c42]{position:fixed;z-index:2;top:38px;right:0;width:100%;height:50px;background-color:#ececec;display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;font-family:Assistant-SemiBold;font-size:22px;font-weight:600}}.payments-external-login[_ngcontent-c42]   .main[_ngcontent-c42]   .already-have-a-user-container[_ngcontent-c42]{width:100%;height:419px;display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-orient:vertical;-webkit-box-direction:normal;-ms-flex-direction:column;flex-direction:column;-webkit-box-align:center;-ms-flex-align:center;align-items:center;background-image:-webkit-linear-gradient(bottom,hsla(0,0%,100%,.38),hsla(0,0%,50%,.38));background-image:linear-gradient(0deg,hsla(0,0%,100%,.38),hsla(0,0%,50%,.38));border-radius:12px}.payments-external-login[_ngcontent-c42]   .main[_ngcontent-c42]   .already-have-a-user-container[_ngcontent-c42]   .couple[_ngcontent-c42]{margin-top:16px;margin-bottom:37px}@media screen and (max-width:767px){.payments-external-login[_ngcontent-c42]   .main[_ngcontent-c42]   .already-have-a-user-container[_ngcontent-c42]   .couple[_ngcontent-c42]{width:81px;margin-top:-20px;margin-bottom:-8px}}@media screen and (max-width:767px){.payments-external-login[_ngcontent-c42]   .main[_ngcontent-c42]   .already-have-a-user-container[_ngcontent-c42]   .couple.road6[_ngcontent-c42]{margin-top:-20px;margin-bottom:0;width:99px;height:84px}}.payments-external-login[_ngcontent-c42]   .main[_ngcontent-c42]   .already-have-a-user-container[_ngcontent-c42]   h3[_ngcontent-c42]{margin:0;font-family:Assistant-Bold;font-size:19px;font-weight:700;letter-spacing:-.19px;color:#262626}@media screen and (max-width:767px){.payments-external-login[_ngcontent-c42]   .main[_ngcontent-c42]   .already-have-a-user-container[_ngcontent-c42]   h3[_ngcontent-c42]{font-size:16px;letter-spacing:-.15px;color:#fff}}.payments-external-login[_ngcontent-c42]   .main[_ngcontent-c42]   .already-have-a-user-container[_ngcontent-c42]   a[_ngcontent-c42]{font-size:24px;letter-spacing:-.31px;color:#217bc5;text-decoration:underline;font-family:Assistant-Regular;font-weight:400}@media screen and (max-width:767px){.payments-external-login[_ngcontent-c42]   .main[_ngcontent-c42]   .already-have-a-user-container[_ngcontent-c42]   a[_ngcontent-c42]{font-size:15px;letter-spacing:-.05px;color:#fff;text-align:center;padding-left:20px;padding-right:20px;text-decoration:none;font-family:Assistant-Bold;line-height:1}}.payments-external-login[_ngcontent-c42]   .main[_ngcontent-c42]   .already-have-a-user-container[_ngcontent-c42]   .btn-close[_ngcontent-c42]{display:none;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;width:25px;height:25px;position:absolute;top:0;left:5px;z-index:1;background-color:#03497f;border-radius:100%}.payments-external-login[_ngcontent-c42]   .main[_ngcontent-c42]   .already-have-a-user-container[_ngcontent-c42]   .btn-close[_ngcontent-c42]   img[_ngcontent-c42]{width:11px;height:11px}@media screen and (max-width:767px){.payments-external-login[_ngcontent-c42]   .main[_ngcontent-c42]   .already-have-a-user-container[_ngcontent-c42]   .btn-close[_ngcontent-c42]{display:-webkit-box;display:-ms-flexbox;display:flex}}@media screen and (max-width:767px){.payments-external-login[_ngcontent-c42]   .main[_ngcontent-c42]   .already-have-a-user-container[_ngcontent-c42]{-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center;position:fixed;z-index:1000;background-color:#03497f;background-image:none;border-radius:100%;left:14px;top:110px;width:125px;height:125px;margin-top:0}}.payments-external-login[_ngcontent-c42]   .main[_ngcontent-c42]   form[_ngcontent-c42]   .radio-btn-group[_ngcontent-c42]{display:-webkit-box;display:-ms-flexbox;display:flex}.payments-external-login[_ngcontent-c42]   .main[_ngcontent-c42]   form[_ngcontent-c42]   .radio-btn-group[_ngcontent-c42]   .radio-btn[_ngcontent-c42]{position:relative}.payments-external-login[_ngcontent-c42]   .main[_ngcontent-c42]   form[_ngcontent-c42]   .radio-btn-group[_ngcontent-c42]   .radio-btn[_ngcontent-c42]   label[_ngcontent-c42]{cursor:pointer;font-family:Assistant-Bold;font-size:16px;font-weight:700;line-height:1.31;letter-spacing:-.4px;color:#000;margin-bottom:11px}.payments-external-login[_ngcontent-c42]   .main[_ngcontent-c42]   form[_ngcontent-c42]   .radio-btn-group[_ngcontent-c42]   .radio-btn[_ngcontent-c42]   label[_ngcontent-c42]:before{display:inline-block;content:"";width:18px;height:18px;background-color:#ecf4fb;border:1px solid #9cb3c6;border-radius:100%;position:relative;top:4px;margin-left:5px}@media screen and (max-width:767px){.payments-external-login[_ngcontent-c42]   .main[_ngcontent-c42]   form[_ngcontent-c42]   .radio-btn-group[_ngcontent-c42]   .radio-btn[_ngcontent-c42]   label[_ngcontent-c42]{letter-spacing:-.06px}}.payments-external-login[_ngcontent-c42]   .main[_ngcontent-c42]   form[_ngcontent-c42]   .radio-btn-group[_ngcontent-c42]   .radio-btn[_ngcontent-c42]:not(:last-child)   label[_ngcontent-c42]{margin-left:11px}.payments-external-login[_ngcontent-c42]   .main[_ngcontent-c42]   form[_ngcontent-c42]   .radio-btn-group[_ngcontent-c42]   .radio-btn[_ngcontent-c42]   input[_ngcontent-c42]{opacity:0;position:absolute;width:18px;height:18px}.payments-external-login[_ngcontent-c42]   .main[_ngcontent-c42]   form[_ngcontent-c42]   .radio-btn-group[_ngcontent-c42]   .radio-btn[_ngcontent-c42]   input[_ngcontent-c42]:checked + label[_ngcontent-c42]:before{border:none;background-color:#02477c}.payments-external-login[_ngcontent-c42]   .main[_ngcontent-c42]   form[_ngcontent-c42]   .radio-btn-group[_ngcontent-c42]   .radio-btn[_ngcontent-c42]   input[_ngcontent-c42]:checked + label[_ngcontent-c42]:after{content:"";background-color:#fff;width:8px;height:8px;display:block;position:absolute;border-radius:100%;top:9px;right:5px}.payments-external-login[_ngcontent-c42]   .main[_ngcontent-c42]   form[_ngcontent-c42]   .radio-btn-group[_ngcontent-c42]   .radio-btn[_ngcontent-c42]   input[_ngcontent-c42]:focus + label[_ngcontent-c42]:before{box-shadow:0 0 1px 2px #fbb033}.payments-external-login[_ngcontent-c42]   .main[_ngcontent-c42]   form[_ngcontent-c42]   .form-input-group[_ngcontent-c42]{position:relative;margin-bottom:25px}@media screen and (max-width:767px){.payments-external-login[_ngcontent-c42]   .main[_ngcontent-c42]   form[_ngcontent-c42]   .form-input-group[_ngcontent-c42]{width:100%}}.payments-external-login[_ngcontent-c42]   .main[_ngcontent-c42]   form[_ngcontent-c42]   .form-input-group[_ngcontent-c42]   button[_ngcontent-c42], .payments-external-login[_ngcontent-c42]   .main[_ngcontent-c42]   form[_ngcontent-c42]   .form-input-group[_ngcontent-c42]   input[_ngcontent-c42], .payments-external-login[_ngcontent-c42]   .main[_ngcontent-c42]   form[_ngcontent-c42]   .form-input-group[_ngcontent-c42]   label[_ngcontent-c42], .payments-external-login[_ngcontent-c42]   .main[_ngcontent-c42]   form[_ngcontent-c42]   .form-input-group[_ngcontent-c42]   select[_ngcontent-c42]{display:block}.payments-external-login[_ngcontent-c42]   .main[_ngcontent-c42]   form[_ngcontent-c42]   .form-input-group[_ngcontent-c42]   label[_ngcontent-c42]{font-family:Assistant-Bold;font-size:16px;font-weight:700;line-height:1.31;letter-spacing:-.06px;color:#000;margin-bottom:7px}.payments-external-login[_ngcontent-c42]   .main[_ngcontent-c42]   form[_ngcontent-c42]   .form-input-group[_ngcontent-c42]   input[_ngcontent-c42]{height:34px;width:100%;border-radius:3px;border:1px solid #9cb3c5;background-color:#fff;font-size:17px;font-weight:600;letter-spacing:-.07px;text-align:right;color:#000;padding-left:10px;padding-right:10px;font-family:Assistant-SemiBold;-webkit-appearance:none}.payments-external-login[_ngcontent-c42]   .main[_ngcontent-c42]   form[_ngcontent-c42]   .form-input-group[_ngcontent-c42]   input[_ngcontent-c42]:focus{border:2px solid #287fc7;outline:none}@media screen and (max-width:767px){.payments-external-login[_ngcontent-c42]   .main[_ngcontent-c42]   form[_ngcontent-c42]   .form-input-group[_ngcontent-c42]   input[_ngcontent-c42]{width:100%}}.payments-external-login[_ngcontent-c42]   .main[_ngcontent-c42]   form[_ngcontent-c42]   .form-input-group[_ngcontent-c42]   select[_ngcontent-c42]{width:100%;height:34px;border-radius:3px;border:1px solid #9cb3c5;background-color:#fff;font-size:17px;font-weight:600;letter-spacing:-.07px;text-align:right;color:#000;padding-left:10px;padding-right:10px;font-family:Assistant-SemiBold;-webkit-appearance:none;background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAYAAAB4ka1VAAAABHNCSVQICAgIfAhkiAAAADdJREFUCJljZmBg+MDAwCDOwMCwkwEVLGBgYEhggBL/GRgY5qNJ/ocpQFeEIYmuCKsksqIAZAEANboOLESiR7IAAAAASUVORK5CYII=)!important;background-size:8px 5px!important;background-repeat:no-repeat}.payments-external-login[_ngcontent-c42]   .main[_ngcontent-c42]   form[_ngcontent-c42]   .form-input-group[_ngcontent-c42]   select[_ngcontent-c42]:focus{border:2px solid #287fc7;outline:none}.payments-external-login[_ngcontent-c42]   .main[_ngcontent-c42]   form[_ngcontent-c42]   .form-input-group.tooltip-group[_ngcontent-c42]   input[_ngcontent-c42]{padding-left:30px}.payments-external-login[_ngcontent-c42]   .main[_ngcontent-c42]   form[_ngcontent-c42]   .form-input-group[_ngcontent-c42]   .tooltip-wrapper[_ngcontent-c42]{position:absolute;left:9px;top:-4px}.payments-external-login[_ngcontent-c42]   .main[_ngcontent-c42]   form[_ngcontent-c42]   .form-input-group[_ngcontent-c42]   .tooltip-wrapper[_ngcontent-c42]   .tooltip-icon[_ngcontent-c42]{width:19px;height:19px}.payments-external-login[_ngcontent-c42]   .main[_ngcontent-c42]   form[_ngcontent-c42]   .form-input-group[_ngcontent-c42]   .tooltip-wrapper-with-label[_ngcontent-c42]{position:absolute;left:9px;top:22.5px}.payments-external-login[_ngcontent-c42]   .main[_ngcontent-c42]   form[_ngcontent-c42]   .form-input-group[_ngcontent-c42]   .tooltip-wrapper-with-label[_ngcontent-c42]   .tooltip-icon[_ngcontent-c42]{width:19px;height:19px}.payments-external-login[_ngcontent-c42]   .main[_ngcontent-c42]   form[_ngcontent-c42]   .form-input-group.has-error[_ngcontent-c42]   input[_ngcontent-c42], .payments-external-login[_ngcontent-c42]   .main[_ngcontent-c42]   form[_ngcontent-c42]   .form-input-group.has-error[_ngcontent-c42]   select[_ngcontent-c42]{border:1px solid red}.payments-external-login[_ngcontent-c42]   .main[_ngcontent-c42]   form[_ngcontent-c42]   .form-input-group.has-error[_ngcontent-c42]   input[_ngcontent-c42]:focus, .payments-external-login[_ngcontent-c42]   .main[_ngcontent-c42]   form[_ngcontent-c42]   .form-input-group.has-error[_ngcontent-c42]   select[_ngcontent-c42]:focus{border-width:2px}.payments-external-login[_ngcontent-c42]   .main[_ngcontent-c42]   form[_ngcontent-c42]   button[type=submit][_ngcontent-c42]{height:34px;border-radius:3px;background-color:#217bc5;text-align:center;font-size:16px;font-weight:600;line-height:1;letter-spacing:-.06px;color:#fff;font-family:Assistant-SemiBold;width:100%}.payments-external-login[_ngcontent-c42]   .main[_ngcontent-c42]   form[_ngcontent-c42]   button[type=submit][_ngcontent-c42]:focus{outline:2px solid #ff6700}@media screen and (max-width:767px){.payments-external-login[_ngcontent-c42]   .main[_ngcontent-c42]   form[_ngcontent-c42]   button[type=submit][_ngcontent-c42]{margin-bottom:0;height:43px}}@media screen and (max-width:767px){.payments-external-login[_ngcontent-c42]   .main[_ngcontent-c42]{padding-left:5px;padding-right:5px;margin-top:33px}}.payments-external-login[_ngcontent-c42]   .hidden-text[_ngcontent-c42]{margin:0;font-size:0;opacity:0}@media screen and (max-width:767px){.payments-external-login[_ngcontent-c42]   .reset-padding[_ngcontent-c42]{padding:0}}.payments-external-login[_ngcontent-c42]   .mandatory-fields-text[_ngcontent-c42]{font-size:16px;font-family:Assistant-SemiBold,sans-serif;text-align:left;margin-top:15px}.has-error[_ngcontent-c42]   .alert.alert-danger[_ngcontent-c42]{font-family:Assistant-SemiBold;font-size:13px;font-weight:600;color:red}.payments-external-login.carmelton[_ngcontent-c42]   .header-container[_ngcontent-c42]   h1[_ngcontent-c42]{text-shadow:0 3px 10px #000}.payments-external-login.carmelton[_ngcontent-c42]   .header-container[_ngcontent-c42]{background-image:-webkit-linear-gradient(bottom,#95d4b9,#50ab84 43%,#2e956a);background-image:linear-gradient(0deg,#95d4b9,#50ab84 43%,#2e956a)}.payments-external-login.carmelton[_ngcontent-c42]   .main[_ngcontent-c42]   form[_ngcontent-c42]   button[type=submit][_ngcontent-c42]{background-color:#30862b}@media (max-width:767px){.payments-external-login.carmelton[_ngcontent-c42]   .main[_ngcontent-c42]   .already-have-a-user-container[_ngcontent-c42]{background-color:#32956c}}.payments-external-login.carmelton[_ngcontent-c42]   .main[_ngcontent-c42]   .already-have-a-user-container[_ngcontent-c42]   h3[_ngcontent-c42]{text-align:center}.payments-external-login.carmelton[_ngcontent-c42]   .main[_ngcontent-c42]   .already-have-a-user-container[_ngcontent-c42]   .btn-close[_ngcontent-c42]{background-color:#32956c}</style><style>.content-card{border-radius:28px;box-shadow:0 0 73px 0 rgba(0,0,0,.7);background-color:#fff;padding:25px;width:100%;margin-bottom:50px}@media (max-width:767px){.content-card{box-shadow:none;padding:0;background-color:transparent;margin-bottom:0}}.medium-card .content-card{width:78%;margin:0 auto}@media screen and (max-width:767px){.medium-card .content-card{width:100%}}</style><style>.tooltip-btn[_ngcontent-c45]{display:inline-block;padding:10px 0}.tooltip-title[_ngcontent-c45]{font-size:16px;font-family:Assistant-Bold,sans-serif;line-height:1;margin-bottom:5px}</style><script type="text/javascript" charset="utf-8" async="" src="./a/2.27cedcb8269100221e77.chunk.js.download"></script><style>@media screen and (max-width:767px){.payments-container[_ngcontent-c46]{margin-top:60px}}.payments-container[_ngcontent-c46]   .header-container[_ngcontent-c46]{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:justify;-ms-flex-pack:justify;justify-content:space-between;width:100%;height:171px;padding:45px;background-image:-webkit-linear-gradient(bottom,#86c4f8,#2f8cd9 20%,#113e63 92%);background-image:linear-gradient(0deg,#86c4f8,#2f8cd9 20%,#113e63 92%);border-top-left-radius:15px;border-top-right-radius:15px}.payments-container[_ngcontent-c46]   .header-container[_ngcontent-c46]   h2[_ngcontent-c46]{margin:0}.payments-container[_ngcontent-c46]   .header-container[_ngcontent-c46]   h2[_ngcontent-c46], .payments-container[_ngcontent-c46]   .header-container[_ngcontent-c46]   h2[_ngcontent-c46]   span[_ngcontent-c46]{font-size:21px;font-family:Assistant-Regular;font-weight:400;letter-spacing:.04px;color:#fff}.payments-container[_ngcontent-c46]   .header-container[_ngcontent-c46]   h2[_ngcontent-c46]   span[_ngcontent-c46]{display:block;margin-top:4px}@media screen and (max-width:767px){.payments-container[_ngcontent-c46]   .header-container[_ngcontent-c46]   h2[_ngcontent-c46]{font-family:Assistant-SemiBold;font-weight:600;position:fixed;font-size:17px;right:0;left:0;text-align:center;top:9px;z-index:1080;width:calc(100% - 100px);margin:0 auto;color:#fbb033}.payments-container[_ngcontent-c46]   .header-container[_ngcontent-c46]   h2[_ngcontent-c46]   span[_ngcontent-c46]{font-family:Assistant-SemiBold;font-weight:600;font-size:17px;color:#fbb033;display:inline-block;margin:0}}.payments-container[_ngcontent-c46]   .header-container[_ngcontent-c46]   .payments-steps[_ngcontent-c46]{position:relative;z-index:1;padding:0;margin:0;list-style:none;display:-webkit-box;display:-ms-flexbox;display:flex}.payments-container[_ngcontent-c46]   .header-container[_ngcontent-c46]   .payments-steps[_ngcontent-c46]   li[_ngcontent-c46]{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-orient:vertical;-webkit-box-direction:normal;-ms-flex-direction:column;flex-direction:column;-webkit-box-align:center;-ms-flex-align:center;align-items:center;position:relative;width:158px}.payments-container[_ngcontent-c46]   .header-container[_ngcontent-c46]   .payments-steps[_ngcontent-c46]   li[_ngcontent-c46]:before{position:absolute;top:33.3%;right:calc(50% + 27px);content:"";height:100%;width:calc(100% - 54px);border-top:3px solid #12456e}@media screen and (max-width:767px){.payments-container[_ngcontent-c46]   .header-container[_ngcontent-c46]   .payments-steps[_ngcontent-c46]   li[_ngcontent-c46]:before{right:calc(50% + 18px);width:calc(100% - 35px);top:calc(33.3% - 7px)}}.payments-container[_ngcontent-c46]   .header-container[_ngcontent-c46]   .payments-steps[_ngcontent-c46]   li[_ngcontent-c46]:last-of-type:before{display:none}.payments-container[_ngcontent-c46]   .header-container[_ngcontent-c46]   .payments-steps[_ngcontent-c46]   li[_ngcontent-c46]   .step-circle[_ngcontent-c46]{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;width:54px;height:54px;background-color:#12456e;font-size:31px;color:#fff;border-radius:100%}.payments-container[_ngcontent-c46]   .header-container[_ngcontent-c46]   .payments-steps[_ngcontent-c46]   li[_ngcontent-c46]   .step-circle[_ngcontent-c46]   img[_ngcontent-c46]{margin-right:-3px}@media screen and (max-width:767px){.payments-container[_ngcontent-c46]   .header-container[_ngcontent-c46]   .payments-steps[_ngcontent-c46]   li[_ngcontent-c46]   .step-circle[_ngcontent-c46]   img[_ngcontent-c46]{margin-right:-2px;width:17px;height:14px}}@media screen and (max-width:767px){.payments-container[_ngcontent-c46]   .header-container[_ngcontent-c46]   .payments-steps[_ngcontent-c46]   li[_ngcontent-c46]   .step-circle[_ngcontent-c46]{width:36px;height:36px;font-size:23px}}.payments-container[_ngcontent-c46]   .header-container[_ngcontent-c46]   .payments-steps[_ngcontent-c46]   li[_ngcontent-c46]   .step-label[_ngcontent-c46]{margin-top:7px;font-size:18px;color:#fff}@media screen and (max-width:767px){.payments-container[_ngcontent-c46]   .header-container[_ngcontent-c46]   .payments-steps[_ngcontent-c46]   li[_ngcontent-c46]   .step-label[_ngcontent-c46]{font-size:15px;padding-left:25px;padding-right:25px;text-align:center;line-height:1.07}}.payments-container[_ngcontent-c46]   .header-container[_ngcontent-c46]   .payments-steps[_ngcontent-c46]   li.current-step[_ngcontent-c46]   .step-circle[_ngcontent-c46]{font-weight:700;font-family:Assistant-Bold;color:#03497f;background-color:#fff;box-shadow:0 4px 27px 0 rgba(0,0,0,.77)}.payments-container[_ngcontent-c46]   .header-container[_ngcontent-c46]   .payments-steps[_ngcontent-c46]   li.current-step[_ngcontent-c46]   .step-label[_ngcontent-c46]{text-shadow:0 3px 10px rgba(0,0,0,.55);font-weight:700;font-family:Assistant-Bold}.payments-container[_ngcontent-c46]   .header-container[_ngcontent-c46]   .payments-steps[_ngcontent-c46]   li.step-finished[_ngcontent-c46]:before{border-color:#fff}.payments-container[_ngcontent-c46]   .header-container[_ngcontent-c46]   .payments-steps[_ngcontent-c46]   li.step-finished[_ngcontent-c46]   .step-circle[_ngcontent-c46]{background-color:hsla(0,0%,100%,.24)}@media screen and (max-width:767px){.payments-container[_ngcontent-c46]   .header-container[_ngcontent-c46]   .payments-steps[_ngcontent-c46]   li[_ngcontent-c46]{width:33.3%}}@media screen and (max-width:767px){.payments-container[_ngcontent-c46]   .header-container[_ngcontent-c46]   .payments-steps[_ngcontent-c46]{width:100%}}@media screen and (max-width:767px){.payments-container[_ngcontent-c46]   .header-container[_ngcontent-c46]{padding:0;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center;height:100px;background-image:-webkit-linear-gradient(bottom,#c0d9ee -7%,#217bc5 23%,#113e63);background-image:linear-gradient(0deg,#c0d9ee -7%,#217bc5 23%,#113e63)}}.payments-container[_ngcontent-c46]   .payments-main[_ngcontent-c46]{margin-top:25px}@media screen and (max-width:767px){.payments-container[_ngcontent-c46]   .payments-main[_ngcontent-c46]{margin-top:12px}.payments-container[_ngcontent-c46]   .payments-main[_ngcontent-c46]   .payments-wrapper[_ngcontent-c46]{padding-right:0;padding-left:0}}.payments-container.carmelton[_ngcontent-c46]   .header-container[_ngcontent-c46]{background-image:-webkit-linear-gradient(bottom,#95d4b9,#50ab84 43%,#2e956a);background-image:linear-gradient(0deg,#95d4b9,#50ab84 43%,#2e956a)}.payments-container.carmelton[_ngcontent-c46]   .header-container[_ngcontent-c46]   h2[_ngcontent-c46]{color:#fff;text-shadow:0 3px 10px #000}.payments-container.carmelton[_ngcontent-c46]   .header-container[_ngcontent-c46]   h2[_ngcontent-c46]   span[_ngcontent-c46]{color:#fff}.payments-container.carmelton[_ngcontent-c46]   .header-container[_ngcontent-c46]   .payments-steps[_ngcontent-c46]   li[_ngcontent-c46]   .step-circle[_ngcontent-c46]{background-color:#135138}.payments-container.carmelton[_ngcontent-c46]   .header-container[_ngcontent-c46]   .payments-steps[_ngcontent-c46]   li.current-step[_ngcontent-c46]   .step-circle[_ngcontent-c46]{background-color:#fff;color:#1b6547}.payments-container.carmelton[_ngcontent-c46]   .header-container[_ngcontent-c46]   .payments-steps[_ngcontent-c46]   li[_ngcontent-c46]:not(.current-step)   .step-label[_ngcontent-c46]{text-shadow:0 3px 10px #000}.payments-container.carmelton[_ngcontent-c46]   .header-container[_ngcontent-c46]   .payments-steps[_ngcontent-c46]   li[_ngcontent-c46]:before{border-color:#1b6547}.payments-container.carmelton[_ngcontent-c46]   .header-container[_ngcontent-c46]   .payments-steps[_ngcontent-c46]   li.step-finished[_ngcontent-c46]:before{border-color:#fff}.payments-container.carmelton[_ngcontent-c46]   .header-container[_ngcontent-c46]   .payments-steps[_ngcontent-c46]   li.step-finished[_ngcontent-c46]   .step-circle[_ngcontent-c46]{background-color:#d3e9e2}@media screen and (min-width:768px) and (max-width:960px){.payments-container[_ngcontent-c46]   .header-container[_ngcontent-c46]{-webkit-box-orient:vertical;-webkit-box-direction:normal;-ms-flex-direction:column;flex-direction:column;padding:12px}.payments-container[_ngcontent-c46]   .header-container[_ngcontent-c46]   h2[_ngcontent-c46]{text-align:center}}@media (max-width:767px){.is-customer-area[_ngcontent-c46]{display:none}}</style><style>.invoice-details-container[_ngcontent-c47]   h2[_ngcontent-c47]{margin:0;margin-bottom:6px;font-family:Assistant-Bold;font-size:23px;font-weight:700;letter-spacing:-.09px;color:#000;padding-left:17px;padding-right:17px}.invoice-details-container[_ngcontent-c47]   h2[_ngcontent-c47]:focus{outline:none}@media screen and (max-width:767px){.invoice-details-container[_ngcontent-c47]   h2[_ngcontent-c47]{position:fixed;top:38px;z-index:2;right:0;background-color:#ececec;width:100%;height:50px;font-size:22px;font-family:Assistant-SemiBold;font-weight:700;display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center}}.invoice-details-container[_ngcontent-c47]   .info[_ngcontent-c47]{margin:0;line-height:1.44;font-size:16px;letter-spacing:normal;color:#000;padding-left:17px;padding-right:17px}@media screen and (max-width:767px){.invoice-details-container[_ngcontent-c47]   .info[_ngcontent-c47]{font-size:15px}.invoice-details-container[_ngcontent-c47]   .info.reset-padding[_ngcontent-c47]{padding-left:0;padding-right:0}}.invoice-details-container[_ngcontent-c47]   .tabs-wrapper[_ngcontent-c47]{position:relative}.invoice-details-container[_ngcontent-c47]   .tabs-wrapper[_ngcontent-c47]   .info[_ngcontent-c47]{margin-top:20px}@media screen and (max-width:767px){.invoice-details-container[_ngcontent-c47]   .tabs-wrapper[_ngcontent-c47]   .info[_ngcontent-c47]{margin-top:0;margin-bottom:15px}}@media screen and (max-width:767px){.invoice-details-container[_ngcontent-c47]   .tabs-wrapper[_ngcontent-c47]   .tab-a-wrapper[_ngcontent-c47], .invoice-details-container[_ngcontent-c47]   .tabs-wrapper[_ngcontent-c47]   .tab-b-wrapper[_ngcontent-c47]{padding-left:15px;padding-right:15px}}.invoice-details-container[_ngcontent-c47]   .notice-card-container[_ngcontent-c47]{padding-right:17px;padding-left:17px}@media screen and (max-width:767px){.invoice-details-container[_ngcontent-c47]   .notice-card-container[_ngcontent-c47]{padding-left:0;padding-right:0}}.invoice-details-container[_ngcontent-c47]   .notice-card-wrapper[_ngcontent-c47]{margin-top:20px;height:auto;border-radius:5px;border:1px solid #d8d8d8;background-color:#f1f1f1;padding:17px 21px;font-size:16px;color:#000}.invoice-details-container[_ngcontent-c47]   .notice-card-wrapper[_ngcontent-c47], .invoice-details-container[_ngcontent-c47]   .notice-card-wrapper[_ngcontent-c47]   .notice-icon-wrapper[_ngcontent-c47]{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-align:center;-ms-flex-align:center;align-items:center}.invoice-details-container[_ngcontent-c47]   .notice-card-wrapper[_ngcontent-c47]   .notice-icon-wrapper[_ngcontent-c47]{-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center;margin-left:18px;-ms-flex-negative:0;flex-shrink:0;background-color:#ff6700;width:28px;height:28px;border-radius:100%}@media screen and (max-width:767px){.invoice-details-container[_ngcontent-c47]   .notice-card-wrapper[_ngcontent-c47]{margin-top:0;font-size:15px}}.invoice-details-container[_ngcontent-c47]   .btn-cancel[_ngcontent-c47]{margin-right:17px;background-color:#dbdbdb;color:#000;width:177px;height:49px;border-radius:3px;font-family:Assistant-Bold;font-weight:700;font-size:18px;letter-spacing:-.07px}@media screen and (max-width:767px){.invoice-details-container[_ngcontent-c47]   .btn-cancel[_ngcontent-c47]{display:none}}.invoice-details-container[_ngcontent-c47]   .btn-continue[_ngcontent-c47]{margin-top:40px;float:left;width:277px;height:49px;border-radius:3px;background-color:#217bc5;color:#fff;font-family:Assistant-Bold;font-weight:700;font-size:18px;letter-spacing:-.07px}.invoice-details-container[_ngcontent-c47]   .btn-continue[_ngcontent-c47]   span[_ngcontent-c47]{margin-right:8px;font-family:Assistant-Regular;font-weight:400;letter-spacing:-.07px}@media screen and (max-width:767px){.invoice-details-container[_ngcontent-c47]   .btn-continue[_ngcontent-c47]{float:none;width:100%}}.invoice-details-container[_ngcontent-c47]   .btn-payments-history[_ngcontent-c47]{z-index:1;display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-align:center;-ms-flex-align:center;align-items:center;position:absolute;left:17px;top:38px;font-family:Assistant-SemiBold;font-size:16px;font-weight:600;letter-spacing:-.16px;color:#217bc5}.invoice-details-container[_ngcontent-c47]   .btn-payments-history[_ngcontent-c47]:focus{outline:2px solid #ff6700}.invoice-details-container[_ngcontent-c47]   .btn-payments-history[_ngcontent-c47]   span[_ngcontent-c47]{text-decoration:underline;margin-left:13px}@media screen and (max-width:767px){.invoice-details-container[_ngcontent-c47]   .btn-payments-history[_ngcontent-c47]{position:fixed;z-index:3;left:0;top:38px;width:90px;height:50px;color:#272727;font-family:Assistant-SemiBold;font-weight:600;font-size:13px;text-align:left;text-decoration:underline;padding-left:10px;background-image:url(btn-payments-history-bg.9a1a671b5c9f2bb5b924.svg);background-repeat:no-repeat}.invoice-details-container[_ngcontent-c47]   .btn-payments-history[_ngcontent-c47]   span[_ngcontent-c47]{text-decoration:none;margin-left:0}.invoice-details-container[_ngcontent-c47]   .btn-payments-history[_ngcontent-c47]   img[_ngcontent-c47]{display:none}}.invoice-details-container[_ngcontent-c47]   .footer-container[_ngcontent-c47]{margin-top:40px}@media screen and (max-width:767px){.invoice-details-container[_ngcontent-c47]   .footer-container[_ngcontent-c47]{padding-left:15px;padding-right:15px;margin-bottom:15px}}.invoice-details-container[_ngcontent-c47]   .footer-container[_ngcontent-c47]   p[_ngcontent-c47]{margin:0;font-family:Assistant-SemiBold;font-size:16px;font-weight:600;color:#000}.invoice-details-container[_ngcontent-c47]   .footer-container[_ngcontent-c47]   p[_ngcontent-c47]   a[_ngcontent-c47]{color:#217bc5;text-decoration:underline}.invoice-details-container[_ngcontent-c47]   .footer-container[_ngcontent-c47]   .btn-continue[_ngcontent-c47]{margin:0}.invoice-details-container[_ngcontent-c47]   .footer-container.is-limited[_ngcontent-c47]{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:justify;-ms-flex-pack:justify;justify-content:space-between}@media screen and (max-width:767px){.invoice-details-container[_ngcontent-c47]   .footer-container.is-limited[_ngcontent-c47]{-webkit-box-orient:vertical;-webkit-box-direction:normal;-ms-flex-direction:column;flex-direction:column}.invoice-details-container[_ngcontent-c47]   .footer-container.is-limited[_ngcontent-c47]   p[_ngcontent-c47]{margin-bottom:20px}}.invoice-details-container[_ngcontent-c47]   .icons-container[_ngcontent-c47]   ul[_ngcontent-c47]{list-style:none;float:left;margin:0;padding-left:17px;min-height:47px}@media screen and (max-width:767px){.invoice-details-container[_ngcontent-c47]   .icons-container[_ngcontent-c47]   ul[_ngcontent-c47]{padding-left:0;min-height:auto}}.invoice-details-container[_ngcontent-c47]   .icons-container[_ngcontent-c47]   ul[_ngcontent-c47]   li[_ngcontent-c47]{float:right;font-size:12px;line-height:1.14;text-align:center;color:#131313;margin-left:38px}.invoice-details-container[_ngcontent-c47]   .icons-container[_ngcontent-c47]   ul[_ngcontent-c47]   li[_ngcontent-c47]   a[_ngcontent-c47]{text-decoration:none}.invoice-details-container[_ngcontent-c47]   .icons-container[_ngcontent-c47]   ul[_ngcontent-c47]   li[_ngcontent-c47]:last-of-type{margin-left:0}.invoice-details-container[_ngcontent-c47]   .icons-container[_ngcontent-c47]   ul[_ngcontent-c47]   li[_ngcontent-c47]   .icon-container[_ngcontent-c47]{cursor:pointer}.invoice-details-container[_ngcontent-c47]   .icons-container[_ngcontent-c47]   ul[_ngcontent-c47]   li[_ngcontent-c47]   .icon-container[_ngcontent-c47]   .icon-wrapper[_ngcontent-c47]   img[_ngcontent-c47]{width:24px;height:24px}.invoice-details-container[_ngcontent-c47]   .icons-container[_ngcontent-c47]   ul[_ngcontent-c47]   li[_ngcontent-c47]   .icon-container[_ngcontent-c47]   .icon-wrapper[_ngcontent-c47]   .img-txt[_ngcontent-c47]{margin-top:6px;margin-bottom:0}@media screen and (max-width:767px){.invoice-details-container[_ngcontent-c47]   .sticky-footer[_ngcontent-c47]{position:fixed;z-index:1;width:100%;height:60px;bottom:0;right:0;background-color:#fff;box-shadow:11.6px -3.1px 20.9px 3.1px rgba(0,0,0,.59)}.invoice-details-container[_ngcontent-c47]   .sticky-footer[_ngcontent-c47]   .icons-container[_ngcontent-c47]{margin-top:7px;position:relative;left:0;top:0}.invoice-details-container[_ngcontent-c47]   .sticky-footer[_ngcontent-c47]   .icons-container[_ngcontent-c47]   ul[_ngcontent-c47]{list-style:none;width:100%;display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;padding-right:0;margin-bottom:0}.invoice-details-container[_ngcontent-c47]   .sticky-footer[_ngcontent-c47]   .icons-container[_ngcontent-c47]   ul[_ngcontent-c47]   li[_ngcontent-c47]{margin-right:15%;margin-left:0;font-size:12px;font-weight:600;line-height:1.33;text-align:center;color:#131313}.invoice-details-container[_ngcontent-c47]   .sticky-footer[_ngcontent-c47]   .icons-container[_ngcontent-c47]   ul[_ngcontent-c47]   li[_ngcontent-c47]   .icon-container[_ngcontent-c47]{cursor:pointer}.invoice-details-container[_ngcontent-c47]   .sticky-footer[_ngcontent-c47]   .icons-container[_ngcontent-c47]   ul[_ngcontent-c47]   li[_ngcontent-c47]   .icon-container[_ngcontent-c47]   .icon-wrapper[_ngcontent-c47]   .img-txt[_ngcontent-c47]{margin-top:5px;margin-bottom:0}.invoice-details-container[_ngcontent-c47]   .sticky-footer[_ngcontent-c47]   .icons-container[_ngcontent-c47]   ul[_ngcontent-c47]   li[_ngcontent-c47]:first-child{margin-right:0}}.invoice-details-container[_ngcontent-c47]   button[_ngcontent-c47]:focus{outline:2px solid #ff6700}.invoice-details-container[_ngcontent-c47]   .no-records[_ngcontent-c47]{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-align:center;-ms-flex-align:center;align-items:center;margin-top:25px;padding-right:17px;padding-left:17px;margin-bottom:100px}@media screen and (max-width:767px){.invoice-details-container[_ngcontent-c47]   .no-records[_ngcontent-c47]{-webkit-box-orient:vertical;-webkit-box-direction:normal;-ms-flex-direction:column;flex-direction:column;padding:0;margin-top:68px;margin-bottom:0}}.invoice-details-container[_ngcontent-c47]   .no-records[_ngcontent-c47]   img[_ngcontent-c47]{margin-left:10px}@media screen and (max-width:767px){.invoice-details-container[_ngcontent-c47]   .no-records[_ngcontent-c47]   img[_ngcontent-c47]{width:42px;height:39px}}.invoice-details-container[_ngcontent-c47]   .no-records[_ngcontent-c47]   .info[_ngcontent-c47]{margin:0;padding:0;margin-top:8px}@media screen and (max-width:767px){.invoice-details-container[_ngcontent-c47]   .no-records[_ngcontent-c47]   .info[_ngcontent-c47]{font-size:17px;margin-top:17px}}.invoice-details-container.carmelton[_ngcontent-c47]   .btn-continue[_ngcontent-c47]{background-color:#30862b}.hidden-text[_ngcontent-c47]{margin:0;font-size:0}.hide-note[_ngcontent-c47]{display:none}.only-print[_ngcontent-c47]{display:none!important}@media print{.only-print[_ngcontent-c47]{display:block!important}}@media print{.no-print[_ngcontent-c47]{display:none!important}.hide-note[_ngcontent-c47]{display:block}}@media screen and (max-width:767px){.reset-margin-mobile[_ngcontent-c47]{margin-left:0;margin-right:0}.reset-margin-mobile[_ngcontent-c47]   .note[_ngcontent-c47]{padding-left:0;padding-right:0}}@media screen and (min-width:768px) and (max-width:960px){.invoice-details-container[_ngcontent-c47]   .btn-payments-history[_ngcontent-c47]{width:60px;left:5px;top:32px;text-align:center}.invoice-details-container[_ngcontent-c47]   .btn-payments-history[_ngcontent-c47]   span[_ngcontent-c47]{margin-left:0}.invoice-details-container[_ngcontent-c47]   .btn-payments-history[_ngcontent-c47]   img[_ngcontent-c47]{display:none}}</style><style>.tabs-container[_ngcontent-c50]{position:relative;height:79px;width:100%;background-color:#fff}@media screen and (max-width:767px){.tabs-container[_ngcontent-c50]{position:fixed;height:59px;width:100%;right:0;top:87px;background-color:#f9f9f9;z-index:1}}.tabs-container[_ngcontent-c50]   .tabs-wrapper[_ngcontent-c50]{position:relative;height:100%;width:100%;background-image:-webkit-linear-gradient(hsla(0,0%,90%,0),#e6e6e6);background-image:linear-gradient(hsla(0,0%,90%,0),#e6e6e6)}.tabs-container[_ngcontent-c50]   .tabs-wrapper[_ngcontent-c50]   ul[_ngcontent-c50]{width:100%;display:-webkit-box;display:-ms-flexbox;display:flex;position:absolute;bottom:0;right:0;list-style:none;padding:0;margin:0}.tabs-container[_ngcontent-c50]   .tabs-wrapper[_ngcontent-c50]   ul[_ngcontent-c50]   li[_ngcontent-c50]{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center;width:200px;height:49px;margin-right:17px;background-color:#03497f;font-family:Assistant-SemiBold;font-size:19px;font-weight:600;line-height:1.26;letter-spacing:-.08px;text-align:center;color:#ffc86d;border-radius:4px;border-bottom-left-radius:0;border-bottom-right-radius:0}.tabs-container[_ngcontent-c50]   .tabs-wrapper[_ngcontent-c50]   ul[_ngcontent-c50]   li[_ngcontent-c50]   button[_ngcontent-c50]{height:100%;width:100%}.tabs-container[_ngcontent-c50]   .tabs-wrapper[_ngcontent-c50]   ul[_ngcontent-c50]   li[_ngcontent-c50]   button[_ngcontent-c50]:focus{outline:2px solid #ff6700}.tabs-container[_ngcontent-c50]   .tabs-wrapper[_ngcontent-c50]   ul[_ngcontent-c50]   li.active[_ngcontent-c50]{font-family:Assistant-Bold;font-size:20px;font-weight:700;color:#000;background-color:#fff;box-shadow:0 -14px 15px -7px rgba(0,0,0,.35);border-top:7px solid #03497f}.tabs-container[_ngcontent-c50]   .tabs-wrapper[_ngcontent-c50]   ul[_ngcontent-c50]   li.active[_ngcontent-c50]   button[_ngcontent-c50]{padding-bottom:7px}@media screen and (max-width:767px){.tabs-container[_ngcontent-c50]   .tabs-wrapper[_ngcontent-c50]   ul[_ngcontent-c50]   li.active[_ngcontent-c50]{font-size:15px;background-color:#f9f9f9}}@media screen and (max-width:767px){.tabs-container[_ngcontent-c50]   .tabs-wrapper[_ngcontent-c50]   ul[_ngcontent-c50]   li[_ngcontent-c50]{height:38px;width:50%;margin-right:12px;font-size:15px}.tabs-container[_ngcontent-c50]   .tabs-wrapper[_ngcontent-c50]   ul[_ngcontent-c50]   li[_ngcontent-c50]:last-of-type{margin-left:12px}}.tab-wrapper[_ngcontent-c50]{position:relative}.tab-wrapper[_ngcontent-c50]:focus{outline:none}@media screen and (max-width:767px){.tab-wrapper[_ngcontent-c50]{margin-top:58px}}</style><style>table[_ngcontent-c52], td[_ngcontent-c52], th[_ngcontent-c52]{border:none}tbody[_ngcontent-c52]   tr.is-selected[_ngcontent-c52]{font-family:Assistant-Bold;font-weight:700}.invoices-table-desktop[_ngcontent-c52]{margin-top:25px}.invoices-table-desktop[_ngcontent-c52]   thead[_ngcontent-c52]{font-family:Assistant-SemiBold;font-size:14px;font-weight:600;line-height:1.29;letter-spacing:-.06px;color:#545454}.invoices-table-desktop[_ngcontent-c52]   thead[_ngcontent-c52]   tr[_ngcontent-c52]   th[_ngcontent-c52]{height:30px;padding-left:5px;padding-right:5px;border-bottom:1px solid #d1d1d1}.invoices-table-desktop[_ngcontent-c52]   thead[_ngcontent-c52]   tr[_ngcontent-c52]   th[_ngcontent-c52]:first-child{padding-right:17px}.invoices-table-desktop[_ngcontent-c52]   thead[_ngcontent-c52]   tr[_ngcontent-c52]   th[_ngcontent-c52]:nth-child(5), .invoices-table-desktop[_ngcontent-c52]   thead[_ngcontent-c52]   tr[_ngcontent-c52]   th[_ngcontent-c52]:nth-child(6), .invoices-table-desktop[_ngcontent-c52]   thead[_ngcontent-c52]   tr[_ngcontent-c52]   th[_ngcontent-c52]:nth-child(7), .invoices-table-desktop[_ngcontent-c52]   thead[_ngcontent-c52]   tr[_ngcontent-c52]   th[_ngcontent-c52]:nth-child(8){text-align:center}.invoices-table-desktop[_ngcontent-c52]   tbody[_ngcontent-c52]{font-family:Assistant-SemiBold;font-size:16px;font-weight:600;line-height:1.31;letter-spacing:-.06px;color:#000}.invoices-table-desktop[_ngcontent-c52]   tbody[_ngcontent-c52]   tr[_ngcontent-c52]:nth-child(2n){background-color:#eaf2f9}.invoices-table-desktop[_ngcontent-c52]   tbody[_ngcontent-c52]   tr[_ngcontent-c52]   td[_ngcontent-c52]{width:13.57%;padding:13px 5px;vertical-align:top}.invoices-table-desktop[_ngcontent-c52]   tbody[_ngcontent-c52]   tr[_ngcontent-c52]   td[_ngcontent-c52]:first-child{width:5%;padding-right:17px}.invoices-table-desktop[_ngcontent-c52]   tbody[_ngcontent-c52]   tr[_ngcontent-c52]   td[_ngcontent-c52]:nth-child(5), .invoices-table-desktop[_ngcontent-c52]   tbody[_ngcontent-c52]   tr[_ngcontent-c52]   td[_ngcontent-c52]:nth-child(6), .invoices-table-desktop[_ngcontent-c52]   tbody[_ngcontent-c52]   tr[_ngcontent-c52]   td[_ngcontent-c52]:nth-child(7), .invoices-table-desktop[_ngcontent-c52]   tbody[_ngcontent-c52]   tr[_ngcontent-c52]   td[_ngcontent-c52]:nth-child(8){text-align:center}.invoices-table-desktop.limited[_ngcontent-c52]{width:50%}.invoices-table-desktop[_ngcontent-c52]   .btn-action[_ngcontent-c52]:focus{outline:2px solid #ff6700}.no-select-all[_ngcontent-c52]{margin-bottom:25px}.no-select-all[_ngcontent-c52]   thead[_ngcontent-c52]   tr[_ngcontent-c52]   th[_ngcontent-c52]:nth-child(4), .no-select-all[_ngcontent-c52]   thead[_ngcontent-c52]   tr[_ngcontent-c52]   th[_ngcontent-c52]:nth-child(5), .no-select-all[_ngcontent-c52]   thead[_ngcontent-c52]   tr[_ngcontent-c52]   th[_ngcontent-c52]:nth-child(6), .no-select-all[_ngcontent-c52]   thead[_ngcontent-c52]   tr[_ngcontent-c52]   th[_ngcontent-c52]:nth-child(7){text-align:center}.no-select-all[_ngcontent-c52]   tbody[_ngcontent-c52]   tr[_ngcontent-c52]   td[_ngcontent-c52], .no-select-all[_ngcontent-c52]   tbody[_ngcontent-c52]   tr[_ngcontent-c52]   td[_ngcontent-c52]:first-child{width:14.28%}.no-select-all[_ngcontent-c52]   tbody[_ngcontent-c52]   tr[_ngcontent-c52]   td[_ngcontent-c52]:nth-child(4), .no-select-all[_ngcontent-c52]   tbody[_ngcontent-c52]   tr[_ngcontent-c52]   td[_ngcontent-c52]:nth-child(5), .no-select-all[_ngcontent-c52]   tbody[_ngcontent-c52]   tr[_ngcontent-c52]   td[_ngcontent-c52]:nth-child(6), .no-select-all[_ngcontent-c52]   tbody[_ngcontent-c52]   tr[_ngcontent-c52]   td[_ngcontent-c52]:nth-child(7){text-align:center}.invoices-table-mobile[_ngcontent-c52]   thead[_ngcontent-c52]{font-family:Assistant-SemiBold;font-size:14px;font-weight:600;line-height:1.29;letter-spacing:-.06px;color:#545454}.invoices-table-mobile[_ngcontent-c52]   thead[_ngcontent-c52]   tr[_ngcontent-c52]   th[_ngcontent-c52]{height:30px;padding-left:5px;padding-right:5px;border-bottom:1px solid #d1d1d1;text-align:right;width:45%}.invoices-table-mobile[_ngcontent-c52]   thead[_ngcontent-c52]   tr[_ngcontent-c52]   th[_ngcontent-c52]:first-of-type{width:10%}.invoices-table-mobile[_ngcontent-c52]   thead[_ngcontent-c52]   tr[_ngcontent-c52]   th[_ngcontent-c52]:last-of-type{width:auto}.invoices-table-mobile[_ngcontent-c52]   tbody[_ngcontent-c52]{font-family:Assistant-SemiBold;font-size:16px;font-weight:600;line-height:1.31;letter-spacing:-.06px;color:#000}.invoices-table-mobile[_ngcontent-c52]   tbody[_ngcontent-c52]:nth-child(odd)   tr[_ngcontent-c52]:first-of-type{background-color:#eaf2f9}.invoices-table-mobile[_ngcontent-c52]   tbody[_ngcontent-c52]   .toggle[_ngcontent-c52]{width:28px;height:24px;border-radius:5px;border:1px solid #d8d8d8;background-color:#fff;margin-top:3px;background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAYAAAB4ka1VAAAABHNCSVQICAgIfAhkiAAAADdJREFUCJljZmBg+MDAwCDOwMCwkwEVLGBgYEhggBL/GRgY5qNJ/ocpQFeEIYmuCKsksqIAZAEANboOLESiR7IAAAAASUVORK5CYII=);background-size:10px 6px;background-position:50%;background-repeat:no-repeat}.invoices-table-mobile[_ngcontent-c52]   tbody.open[_ngcontent-c52]{border:1px solid #e2e2e2}.invoices-table-mobile[_ngcontent-c52]   tbody.open[_ngcontent-c52]   .toggle[_ngcontent-c52]{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAsAAAAHCAYAAADebrddAAAABHNCSVQICAgIfAhkiAAAAFFJREFUGJVjYEAD////N/j////+////C6DLYVP4/j8EnMepAU3hAZwa0BQmQMUWYGjAphDJEFQNSFaiKMSiIYDh////Av///w8g4HEHBgYGBgCKNY7nPsWo+QAAAABJRU5ErkJggg==);border:1px solid #034c85;background-color:#034c85}.invoices-table-mobile[_ngcontent-c52]   tbody.open[_ngcontent-c52]:nth-child(2n)   tr[_ngcontent-c52]:first-of-type{background-color:#efefef}.invoices-table-mobile[_ngcontent-c52]   tbody[_ngcontent-c52]   tr[_ngcontent-c52]   td[_ngcontent-c52]{height:44px;padding-left:5px;padding-right:5px;text-align:right}.invoices-table-mobile[_ngcontent-c52]   tbody[_ngcontent-c52]   tr[_ngcontent-c52]   td[_ngcontent-c52]   .tbl-row[_ngcontent-c52]{width:100%;display:-webkit-box;display:-ms-flexbox;display:flex}.invoices-table-mobile[_ngcontent-c52]   tbody[_ngcontent-c52]   tr[_ngcontent-c52]   td[_ngcontent-c52]   .tbl-row[_ngcontent-c52]   .tbl-group[_ngcontent-c52]{width:50%;display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-orient:vertical;-webkit-box-direction:normal;-ms-flex-direction:column;flex-direction:column;-webkit-box-pack:start;-ms-flex-pack:start;justify-content:flex-start;padding:10px;padding-right:0;padding-left:0}@media screen and (max-width:767px){.invoices-table-mobile[_ngcontent-c52]   tbody[_ngcontent-c52]   tr[_ngcontent-c52]   td[_ngcontent-c52]   .tbl-row[_ngcontent-c52]   .tbl-group[_ngcontent-c52]:first-child{width:52%}}.invoices-table-mobile[_ngcontent-c52]   tbody[_ngcontent-c52]   tr[_ngcontent-c52]   td[_ngcontent-c52]   .tbl-row[_ngcontent-c52]   .tbl-group[_ngcontent-c52]:not(:first-child){padding-right:10px}.invoices-table-mobile[_ngcontent-c52]   tbody[_ngcontent-c52]   tr[_ngcontent-c52]   td[_ngcontent-c52]   .tbl-row[_ngcontent-c52]   .tbl-group[_ngcontent-c52]   .title[_ngcontent-c52]{font-size:14px;color:#545454}.invoices-table-mobile[_ngcontent-c52]   tbody[_ngcontent-c52]   tr[_ngcontent-c52]   td[_ngcontent-c52]   .tbl-row[_ngcontent-c52]   .tbl-group[_ngcontent-c52]   .value[_ngcontent-c52]{font-size:16px;color:#000}.invoices-table-mobile[_ngcontent-c52]   tbody[_ngcontent-c52]   tr[_ngcontent-c52]   td[_ngcontent-c52]   .tbl-actions-row[_ngcontent-c52]{border-top:1px solid #dedfe1}.invoices-table-mobile[_ngcontent-c52]   tbody[_ngcontent-c52]   tr[_ngcontent-c52]   td[_ngcontent-c52]   a[_ngcontent-c52]{font-size:14px;letter-spacing:normal;color:#1592e6;text-decoration:underline}.invoices-table-mobile[_ngcontent-c52]   tbody[_ngcontent-c52]   tr[_ngcontent-c52]   td[_ngcontent-c52]   .btn-action[_ngcontent-c52]{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-align:center;-ms-flex-align:center;align-items:center;font-family:Assistant-SemiBold;font-size:14px;font-weight:600;letter-spacing:-.06px;color:#545454}.invoices-table-mobile[_ngcontent-c52]   tbody[_ngcontent-c52]   tr[_ngcontent-c52]   td[_ngcontent-c52]   .btn-action[_ngcontent-c52]   img[_ngcontent-c52]{width:20px;margin-left:4px}.no-select-all.mobile[_ngcontent-c52]{margin-top:11px}.no-select-all.mobile[_ngcontent-c52]   thead[_ngcontent-c52]   tr[_ngcontent-c52]   th[_ngcontent-c52], .no-select-all.mobile[_ngcontent-c52]   thead[_ngcontent-c52]   tr[_ngcontent-c52]   th[_ngcontent-c52]:first-of-type{width:50%}.no-select-all.mobile[_ngcontent-c52]   thead[_ngcontent-c52]   tr[_ngcontent-c52]   th[_ngcontent-c52]:last-of-type{width:40%}.checkbox-invoice[_ngcontent-c52]:checked, .checkbox-invoice[_ngcontent-c52]:not(:checked){position:absolute;opacity:0;width:18px;margin:0;height:18px;padding:0}.checkbox-invoice[_ngcontent-c52]:checked + label[_ngcontent-c52], .checkbox-invoice[_ngcontent-c52]:not(:checked) + label[_ngcontent-c52]{position:relative;padding-right:25px;cursor:pointer;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;font-size:13px;line-height:1.31;letter-spacing:-.05px;color:#000;font-family:Assistant-SemiBold;padding-top:0;width:18px;height:18px;margin-bottom:0}@media screen and (max-width:767px){.checkbox-invoice[_ngcontent-c52]:checked + label[_ngcontent-c52], .checkbox-invoice[_ngcontent-c52]:not(:checked) + label[_ngcontent-c52]{font-size:15px}}.checkbox-invoice[_ngcontent-c52]:checked + label[_ngcontent-c52]:before, .checkbox-invoice[_ngcontent-c52]:not(:checked) + label[_ngcontent-c52]:before{content:"";position:absolute;right:0;top:0;width:18px;height:18px;background-color:#fff;border-radius:3px;border:1px solid #9cb3c5}.checkbox-invoice[_ngcontent-c52]:checked + label[_ngcontent-c52]:before{background-color:#217bc5;border:none}.checkbox-invoice[_ngcontent-c52]:checked + label[_ngcontent-c52]:after, .checkbox-invoice[_ngcontent-c52]:not(:checked) + label[_ngcontent-c52]:after{content:"\2713";position:absolute;top:0;right:4px;font-size:14px;font-weight:400;color:#fff}@media screen and (max-width:767px){.checkbox-invoice[_ngcontent-c52]:checked + label[_ngcontent-c52]:after, .checkbox-invoice[_ngcontent-c52]:not(:checked) + label[_ngcontent-c52]:after{top:1px;right:4px;font-size:13px}}@media (-ms-high-contrast:none),screen and (-ms-high-contrast:active){.checkbox-invoice[_ngcontent-c52]:checked + label[_ngcontent-c52]:after, .checkbox-invoice[_ngcontent-c52]:not(:checked) + label[_ngcontent-c52]:after{right:0;top:-1px}}.checkbox-invoice[_ngcontent-c52]:not(:checked) + label[_ngcontent-c52]:after{opacity:0}.checkbox-invoice[_ngcontent-c52]:checked + label[_ngcontent-c52]:after{opacity:1}.checkbox-invoice[_ngcontent-c52]:checked:focus + label[_ngcontent-c52]:before, .checkbox-invoice[_ngcontent-c52]:not(:checked):focus + label[_ngcontent-c52]:before{border:2px solid #ff6700}.invoices-table-desktop.carmelton[_ngcontent-c52]   tbody[_ngcontent-c52]   tr[_ngcontent-c52]:nth-child(2n), .invoices-table-mobile.carmelton[_ngcontent-c52]   tbody[_ngcontent-c52]:nth-child(odd)   tr[_ngcontent-c52]:first-of-type{background-color:#ebf2e8}</style><style>.payment-details-container[_ngcontent-c48]{padding-left:17px;padding-right:17px}.payment-details-container[_ngcontent-c48]   h2[_ngcontent-c48]{font-family:Assistant-Bold;font-size:23px;font-weight:700;letter-spacing:-.09px;color:#000;margin:0;margin-bottom:25px}@media screen and (max-width:767px){.payment-details-container[_ngcontent-c48]   h2[_ngcontent-c48]{position:fixed;top:38px;z-index:2;right:0;background-color:#ececec;width:100%;height:50px;font-size:22px;font-family:Assistant-SemiBold;font-weight:700;display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center}}.payment-details-container[_ngcontent-c48]   form[_ngcontent-c48]   .form-input-group[_ngcontent-c48]{position:relative;margin-bottom:28px}@media screen and (max-width:767px){.payment-details-container[_ngcontent-c48]   form[_ngcontent-c48]   .form-input-group[_ngcontent-c48]{margin-bottom:25px}}.payment-details-container[_ngcontent-c48]   form[_ngcontent-c48]   .form-input-group[_ngcontent-c48]   .group-label[_ngcontent-c48], .payment-details-container[_ngcontent-c48]   form[_ngcontent-c48]   .form-input-group[_ngcontent-c48]   label[_ngcontent-c48]{font-family:Assistant-Bold;font-size:16px;font-weight:700;line-height:1.31;letter-spacing:-.06px;color:#000;margin-bottom:7px}.payment-details-container[_ngcontent-c48]   form[_ngcontent-c48]   .form-input-group[_ngcontent-c48]   .group-label.mandatory[_ngcontent-c48]:before, .payment-details-container[_ngcontent-c48]   form[_ngcontent-c48]   .form-input-group[_ngcontent-c48]   label.mandatory[_ngcontent-c48]:before{content:"* "}.payment-details-container[_ngcontent-c48]   form[_ngcontent-c48]   .form-input-group[_ngcontent-c48]   .inner-label[_ngcontent-c48]{font-family:Assistant-Regular;font-size:14px;font-weight:400;margin-right:9px}.payment-details-container[_ngcontent-c48]   form[_ngcontent-c48]   .form-input-group[_ngcontent-c48]   input[_ngcontent-c48], .payment-details-container[_ngcontent-c48]   form[_ngcontent-c48]   .form-input-group[_ngcontent-c48]   select[_ngcontent-c48]{height:34px;width:100%;border-radius:3px;border:1px solid #9cb3c5;background-color:#fff;font-size:17px;font-weight:600;letter-spacing:-.07px;text-align:right;color:#000;padding-left:10px;padding-right:10px;font-family:Assistant-SemiBold;-webkit-appearance:none}.payment-details-container[_ngcontent-c48]   form[_ngcontent-c48]   .form-input-group[_ngcontent-c48]   input[_ngcontent-c48]:focus, .payment-details-container[_ngcontent-c48]   form[_ngcontent-c48]   .form-input-group[_ngcontent-c48]   select[_ngcontent-c48]:focus{border:2px solid #287fc7;outline:none}.payment-details-container[_ngcontent-c48]   form[_ngcontent-c48]   .form-input-group[_ngcontent-c48]   select[_ngcontent-c48]{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAYAAAB4ka1VAAAABHNCSVQICAgIfAhkiAAAADdJREFUCJljZmBg+MDAwCDOwMCwkwEVLGBgYEhggBL/GRgY5qNJ/ocpQFeEIYmuCKsksqIAZAEANboOLESiR7IAAAAASUVORK5CYII=)!important;background-repeat:no-repeat;background-size:8px 5px!important}.payment-details-container[_ngcontent-c48]   form[_ngcontent-c48]   .form-input-group[_ngcontent-c48]   input[readonly][_ngcontent-c48]{-moz-user-select:none;-ms-user-select:none;-webkit-user-select:none;user-select:none;background-color:#fff;color:#575757;cursor:not-allowed;border-color:#d1d1d1}.payment-details-container[_ngcontent-c48]   form[_ngcontent-c48]   .form-input-group[_ngcontent-c48]   input[readonly][_ngcontent-c48]:focus{border-width:1px}.payment-details-container[_ngcontent-c48]   form[_ngcontent-c48]   .form-input-group.tooltip-group[_ngcontent-c48]   input[_ngcontent-c48]{padding-left:30px}.payment-details-container[_ngcontent-c48]   form[_ngcontent-c48]   .form-input-group[_ngcontent-c48]   .tooltip-wrapper[_ngcontent-c48]{position:absolute;left:9px;top:22.5px}.payment-details-container[_ngcontent-c48]   form[_ngcontent-c48]   .form-input-group[_ngcontent-c48]   .tooltip-wrapper[_ngcontent-c48]   .tooltip-icon[_ngcontent-c48]{width:19px;height:19px}.payment-details-container[_ngcontent-c48]   form[_ngcontent-c48]   .form-input-group.has-error[_ngcontent-c48]{margin-bottom:20px}.payment-details-container[_ngcontent-c48]   form[_ngcontent-c48]   .form-input-group.has-error[_ngcontent-c48]   input[_ngcontent-c48], .payment-details-container[_ngcontent-c48]   form[_ngcontent-c48]   .form-input-group[_ngcontent-c48]   .has-error[_ngcontent-c48]   input[_ngcontent-c48], .payment-details-container[_ngcontent-c48]   form[_ngcontent-c48]   .form-input-group.has-error[_ngcontent-c48]   select[_ngcontent-c48], .payment-details-container[_ngcontent-c48]   form[_ngcontent-c48]   .form-input-group[_ngcontent-c48]   .has-error[_ngcontent-c48]   select[_ngcontent-c48]{border:1px solid red}.payment-details-container[_ngcontent-c48]   form[_ngcontent-c48]   .form-input-group.has-error[_ngcontent-c48]   input[_ngcontent-c48]:focus, .payment-details-container[_ngcontent-c48]   form[_ngcontent-c48]   .form-input-group[_ngcontent-c48]   .has-error[_ngcontent-c48]   input[_ngcontent-c48]:focus, .payment-details-container[_ngcontent-c48]   form[_ngcontent-c48]   .form-input-group.has-error[_ngcontent-c48]   select[_ngcontent-c48]:focus, .payment-details-container[_ngcontent-c48]   form[_ngcontent-c48]   .form-input-group[_ngcontent-c48]   .has-error[_ngcontent-c48]   select[_ngcontent-c48]:focus{border-width:2px}.payment-details-container[_ngcontent-c48]   form[_ngcontent-c48]   .mandatory-fields-text[_ngcontent-c48]{font-size:16px;font-family:Assistant-SemiBold,sans-serif;text-align:left;margin-bottom:25px;position:relative;top:10px}@media screen and (max-width:767px){.payment-details-container[_ngcontent-c48]   form[_ngcontent-c48]   .mandatory-fields-text[_ngcontent-c48]{text-align:right;top:0;margin-bottom:10px}}.payment-details-container[_ngcontent-c48]   form[_ngcontent-c48]   .errors-container[_ngcontent-c48]{margin-top:5px}.payment-details-container[_ngcontent-c48]   form[_ngcontent-c48]   .errors-container[_ngcontent-c48]   .error-text[_ngcontent-c48]{font-family:Assistant-SemiBold;font-size:13px;font-weight:600;color:red;margin-bottom:5px}.payment-details-container[_ngcontent-c48]   form[_ngcontent-c48]   .errors-container[_ngcontent-c48]   .error-text[_ngcontent-c48]::last-of-type{margin-bottom:0}.payment-details-container[_ngcontent-c48]   form[_ngcontent-c48]   .update-payment-recaptcha-container[_ngcontent-c48]{margin-bottom:28px}@media screen and (max-width:767px){.payment-details-container[_ngcontent-c48]   form[_ngcontent-c48]   .update-payment-recaptcha-container[_ngcontent-c48]{margin-bottom:24px}}.payment-details-container[_ngcontent-c48]   form[_ngcontent-c48]   .btn-back[_ngcontent-c48], .payment-details-container[_ngcontent-c48]   form[_ngcontent-c48]   button[type=submit][_ngcontent-c48]{height:34px;border-radius:3px;background-color:#217bc5;text-align:center;font-size:16px;font-weight:600;line-height:1;letter-spacing:-.06px;color:#fff;font-family:Assistant-SemiBold;margin-bottom:25px;width:66%;float:right}.payment-details-container[_ngcontent-c48]   form[_ngcontent-c48]   .btn-back[_ngcontent-c48]:focus, .payment-details-container[_ngcontent-c48]   form[_ngcontent-c48]   button[type=submit][_ngcontent-c48]:focus{outline:2px solid #ff6700}@media screen and (max-width:767px){.payment-details-container[_ngcontent-c48]   form[_ngcontent-c48]   .btn-back[_ngcontent-c48], .payment-details-container[_ngcontent-c48]   form[_ngcontent-c48]   button[type=submit][_ngcontent-c48]{margin-bottom:0;height:43px}}.payment-details-container[_ngcontent-c48]   form[_ngcontent-c48]   .btn-back[_ngcontent-c48]{background-color:#9e9e9e;width:29%;margin-left:5%}.payment-details-container[_ngcontent-c48]   form[_ngcontent-c48]   .id-redirect[_ngcontent-c48]{margin:0;margin-top:7px;padding-right:10px;color:#000}.payment-details-container[_ngcontent-c48]   form[_ngcontent-c48]   .id-redirect[_ngcontent-c48]   a[_ngcontent-c48]{text-decoration:underline;color:#217bc5;cursor:pointer}.payment-details-container[_ngcontent-c48]   .notice-container[_ngcontent-c48]{width:100%;height:auto;border-radius:5px;border:1px solid #d8d8d8;background-color:#f1f1f1;padding:17px 21px;margin-bottom:28px;display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-align:center;-ms-flex-align:center;align-items:center}.payment-details-container[_ngcontent-c48]   .notice-container[_ngcontent-c48]   img[_ngcontent-c48]{width:27px;height:27px;margin-left:20px;-ms-flex-negative:0;flex-shrink:0}.payment-details-container[_ngcontent-c48]   .notice-container[_ngcontent-c48]   p[_ngcontent-c48]{margin:0;font-family:Assistant-Regular;font-size:16px;font-weight:400;color:#000}@media screen and (max-width:767px){.payment-details-container[_ngcontent-c48]   .notice-container[_ngcontent-c48]   p[_ngcontent-c48]{font-family:Assistant-SemiBold;font-weight:600;font-size:14px}}@media screen and (max-width:767px){.payment-details-container[_ngcontent-c48]   .notice-container[_ngcontent-c48]{margin-top:12px;padding-left:35%}}.payment-details-container.carmelton[_ngcontent-c48]   form[_ngcontent-c48]   button[type=submit][_ngcontent-c48]{background-color:#30862b}.hidden-text[_ngcontent-c48]{margin:0;font-size:0}.mandatory-fields-text[_ngcontent-c48]{font-size:16px;font-family:Assistant-SemiBold,sans-serif;text-align:left;margin-top:25px}.security-info[_ngcontent-c48]{margin-top:25px;height:26px;width:100%}.security-info[_ngcontent-c48]   .lock-icon[_ngcontent-c48]{width:16px;height:21px;position:relative;float:right;top:2px;margin-top:0}.security-info[_ngcontent-c48]   .divider[_ngcontent-c48]{width:1px;height:25px;background-color:#d2d2d2;position:relative;float:right;margin-right:15px;margin-left:13px}.security-info[_ngcontent-c48]   .info[_ngcontent-c48]{font-size:12px;font-weight:600;line-height:1.58;text-align:right;color:#545454;margin:0;padding:0;position:relative;top:3px}</style><style>.summary-details-container[_ngcontent-c49]{padding-left:17px;padding-right:17px}.summary-details-container[_ngcontent-c49]   h2[_ngcontent-c49]{font-family:Assistant-Bold;font-size:23px;font-weight:700;letter-spacing:-.09px;color:#000;margin:0;margin-bottom:67px}@media screen and (max-width:767px){.summary-details-container[_ngcontent-c49]   h2[_ngcontent-c49]{position:fixed;top:38px;z-index:2;right:0;background-color:#ececec;width:100%;height:50px;font-size:22px;font-family:Assistant-SemiBold;font-weight:700;display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center}}.summary-details-container[_ngcontent-c49]   .payment-summary-container[_ngcontent-c49]{width:100%;border-radius:12px;border:1px solid #dfdfdf;background-color:#eaeaea;padding:48px 36px;margin-bottom:93px}@media screen and (max-width:767px){.summary-details-container[_ngcontent-c49]   .payment-summary-container[_ngcontent-c49]{padding:26px 29px;margin-bottom:0}}.summary-details-container[_ngcontent-c49]   .payment-summary-container[_ngcontent-c49]   .summary-header-container[_ngcontent-c49]{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-align:center;-ms-flex-align:center;align-items:center}.summary-details-container[_ngcontent-c49]   .payment-summary-container[_ngcontent-c49]   .summary-header-container[_ngcontent-c49]   img[_ngcontent-c49]{margin-left:46px}@media screen and (max-width:767px){.summary-details-container[_ngcontent-c49]   .payment-summary-container[_ngcontent-c49]   .summary-header-container[_ngcontent-c49]   img[_ngcontent-c49]{width:61px;margin-left:30px}}.summary-details-container[_ngcontent-c49]   .payment-summary-container[_ngcontent-c49]   .summary-header-container[_ngcontent-c49]   p[_ngcontent-c49]{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-orient:vertical;-webkit-box-direction:normal;-ms-flex-direction:column;flex-direction:column;margin:0;margin-top:-46px;font-family:Assistant-Bold;font-weight:700;font-size:19px;letter-spacing:-.23px;color:#000;line-height:1.3}@media screen and (max-width:767px){.summary-details-container[_ngcontent-c49]   .payment-summary-container[_ngcontent-c49]   .summary-header-container[_ngcontent-c49]   p[_ngcontent-c49]{margin-top:-35px}}.summary-details-container[_ngcontent-c49]   .payment-summary-container[_ngcontent-c49]   .summary-header-container[_ngcontent-c49]   p[_ngcontent-c49]   span[_ngcontent-c49]{margin-top:5px;font-family:Assistant-SemiBold;font-weight:600;font-size:14px;letter-spacing:-.13px}.summary-details-container[_ngcontent-c49]   .payment-summary-container[_ngcontent-c49]   .summary-body-container[_ngcontent-c49]{padding-right:15px}@media screen and (max-width:767px){.summary-details-container[_ngcontent-c49]   .payment-summary-container[_ngcontent-c49]   .summary-body-container[_ngcontent-c49]{padding-right:12px}}.summary-details-container[_ngcontent-c49]   .payment-summary-container[_ngcontent-c49]   .summary-body-container[_ngcontent-c49]   table[_ngcontent-c49]{border:none}.summary-details-container[_ngcontent-c49]   .payment-summary-container[_ngcontent-c49]   .summary-body-container[_ngcontent-c49]   table[_ngcontent-c49]   tr[_ngcontent-c49]{height:29px}.summary-details-container[_ngcontent-c49]   .payment-summary-container[_ngcontent-c49]   .summary-body-container[_ngcontent-c49]   table[_ngcontent-c49]   tr[_ngcontent-c49]   td[_ngcontent-c49]{border:none}.summary-details-container[_ngcontent-c49]   .payment-summary-container[_ngcontent-c49]   .summary-body-container[_ngcontent-c49]   table[_ngcontent-c49]   tr[_ngcontent-c49]   td[_ngcontent-c49]:first-of-type{font-family:Assistant-SemiBold;font-size:16px;font-weight:600;letter-spacing:-.06px;color:#000;width:48%}@media screen and (max-width:767px){.summary-details-container[_ngcontent-c49]   .payment-summary-container[_ngcontent-c49]   .summary-body-container[_ngcontent-c49]   table[_ngcontent-c49]   tr[_ngcontent-c49]   td[_ngcontent-c49]:first-of-type{width:50%}}.summary-details-container[_ngcontent-c49]   .payment-summary-container[_ngcontent-c49]   .summary-body-container[_ngcontent-c49]   table[_ngcontent-c49]   tr[_ngcontent-c49]   td[_ngcontent-c49]:last-of-type{font-family:Assistant-Bold;font-size:16px;font-weight:700;letter-spacing:-.06px;color:#000;width:52%}@media screen and (max-width:767px){.summary-details-container[_ngcontent-c49]   .payment-summary-container[_ngcontent-c49]   .summary-body-container[_ngcontent-c49]   table[_ngcontent-c49]   tr[_ngcontent-c49]   td[_ngcontent-c49]:last-of-type{width:50%}}.summary-details-container[_ngcontent-c49]   .payment-summary-container.full-width[_ngcontent-c49]   .summary-body-container[_ngcontent-c49], .summary-details-container[_ngcontent-c49]   .payment-summary-container.full-width[_ngcontent-c49]   .summary-header-container[_ngcontent-c49]{width:50%;margin:0 auto}@media screen and (max-width:767px){.summary-details-container[_ngcontent-c49]   .payment-summary-container.full-width[_ngcontent-c49]   .summary-body-container[_ngcontent-c49], .summary-details-container[_ngcontent-c49]   .payment-summary-container.full-width[_ngcontent-c49]   .summary-header-container[_ngcontent-c49]{width:100%}}.summary-details-container[_ngcontent-c49]   .send-summary-container[_ngcontent-c49]{margin-top:62px;padding-right:26px}@media screen and (max-width:767px){.summary-details-container[_ngcontent-c49]   .send-summary-container[_ngcontent-c49]{margin-top:30px;padding-right:5px;padding-left:5px}}.summary-details-container[_ngcontent-c49]   .send-summary-container[_ngcontent-c49]   p[_ngcontent-c49]{font-family:Assistant-SemiBold;margin:0;margin-bottom:25px;font-size:19px;font-weight:600;letter-spacing:-.08px;color:#000}.summary-details-container[_ngcontent-c49]   .send-summary-container[_ngcontent-c49]   form[_ngcontent-c49]   .form-input-group[_ngcontent-c49]{position:relative;margin-bottom:25px}@media screen and (max-width:767px){.summary-details-container[_ngcontent-c49]   .send-summary-container[_ngcontent-c49]   form[_ngcontent-c49]   .form-input-group[_ngcontent-c49]{width:100%}}.summary-details-container[_ngcontent-c49]   .send-summary-container[_ngcontent-c49]   form[_ngcontent-c49]   .form-input-group[_ngcontent-c49]   button[_ngcontent-c49], .summary-details-container[_ngcontent-c49]   .send-summary-container[_ngcontent-c49]   form[_ngcontent-c49]   .form-input-group[_ngcontent-c49]   input[_ngcontent-c49], .summary-details-container[_ngcontent-c49]   .send-summary-container[_ngcontent-c49]   form[_ngcontent-c49]   .form-input-group[_ngcontent-c49]   label[_ngcontent-c49], .summary-details-container[_ngcontent-c49]   .send-summary-container[_ngcontent-c49]   form[_ngcontent-c49]   .form-input-group[_ngcontent-c49]   select[_ngcontent-c49]{display:block}.summary-details-container[_ngcontent-c49]   .send-summary-container[_ngcontent-c49]   form[_ngcontent-c49]   .form-input-group[_ngcontent-c49]   label[_ngcontent-c49]{font-family:Assistant-Bold;font-size:16px;font-weight:700;line-height:1.31;letter-spacing:-.06px;color:#000;margin-bottom:7px}.summary-details-container[_ngcontent-c49]   .send-summary-container[_ngcontent-c49]   form[_ngcontent-c49]   .form-input-group[_ngcontent-c49]   input[_ngcontent-c49]{height:34px;width:100%;border-radius:3px;border:1px solid #b9b9b9;background-color:#fff;font-size:17px;font-weight:600;letter-spacing:-.07px;text-align:right;color:#000;padding-left:10px;padding-right:10px;font-family:Assistant-SemiBold;-webkit-appearance:none}.summary-details-container[_ngcontent-c49]   .send-summary-container[_ngcontent-c49]   form[_ngcontent-c49]   .form-input-group[_ngcontent-c49]   input[_ngcontent-c49]:focus{border:2px solid #287fc7;outline:none}@media screen and (max-width:767px){.summary-details-container[_ngcontent-c49]   .send-summary-container[_ngcontent-c49]   form[_ngcontent-c49]   .form-input-group[_ngcontent-c49]   input[_ngcontent-c49]{width:100%}}.summary-details-container[_ngcontent-c49]   .send-summary-container[_ngcontent-c49]   form[_ngcontent-c49]   .form-input-group[_ngcontent-c49]   select[_ngcontent-c49]{width:100%;height:34px;border-radius:3px;border:1px solid #b9b9b9;background-color:#fff;font-size:17px;font-weight:600;letter-spacing:-.07px;text-align:right;color:#000;padding-left:10px;padding-right:10px;font-family:Assistant-SemiBold;-webkit-appearance:none;background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAYAAAB4ka1VAAAABHNCSVQICAgIfAhkiAAAADdJREFUCJljZmBg+MDAwCDOwMCwkwEVLGBgYEhggBL/GRgY5qNJ/ocpQFeEIYmuCKsksqIAZAEANboOLESiR7IAAAAASUVORK5CYII=)!important;background-size:8px 5px!important;background-repeat:no-repeat}.summary-details-container[_ngcontent-c49]   .send-summary-container[_ngcontent-c49]   form[_ngcontent-c49]   .form-input-group[_ngcontent-c49]   select[_ngcontent-c49]:focus{border:2px solid #287fc7;outline:none}.summary-details-container[_ngcontent-c49]   .send-summary-container[_ngcontent-c49]   form[_ngcontent-c49]   .form-input-group.has-error[_ngcontent-c49]   input[_ngcontent-c49], .summary-details-container[_ngcontent-c49]   .send-summary-container[_ngcontent-c49]   form[_ngcontent-c49]   .form-input-group[_ngcontent-c49]   .has-error[_ngcontent-c49]   input[_ngcontent-c49], .summary-details-container[_ngcontent-c49]   .send-summary-container[_ngcontent-c49]   form[_ngcontent-c49]   .form-input-group.has-error[_ngcontent-c49]   select[_ngcontent-c49], .summary-details-container[_ngcontent-c49]   .send-summary-container[_ngcontent-c49]   form[_ngcontent-c49]   .form-input-group[_ngcontent-c49]   .has-error[_ngcontent-c49]   select[_ngcontent-c49]{border:1px solid red}.summary-details-container[_ngcontent-c49]   .send-summary-container[_ngcontent-c49]   form[_ngcontent-c49]   .form-input-group.has-error[_ngcontent-c49]   input[_ngcontent-c49]:focus, .summary-details-container[_ngcontent-c49]   .send-summary-container[_ngcontent-c49]   form[_ngcontent-c49]   .form-input-group[_ngcontent-c49]   .has-error[_ngcontent-c49]   input[_ngcontent-c49]:focus, .summary-details-container[_ngcontent-c49]   .send-summary-container[_ngcontent-c49]   form[_ngcontent-c49]   .form-input-group.has-error[_ngcontent-c49]   select[_ngcontent-c49]:focus, .summary-details-container[_ngcontent-c49]   .send-summary-container[_ngcontent-c49]   form[_ngcontent-c49]   .form-input-group[_ngcontent-c49]   .has-error[_ngcontent-c49]   select[_ngcontent-c49]:focus{border-width:2px}.summary-details-container[_ngcontent-c49]   .send-summary-container[_ngcontent-c49]   form[_ngcontent-c49]   .inputs-group[_ngcontent-c49]{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-pack:justify;-ms-flex-pack:justify;justify-content:space-between}@media screen and (max-width:767px){.summary-details-container[_ngcontent-c49]   .send-summary-container[_ngcontent-c49]   form[_ngcontent-c49]   .inputs-group[_ngcontent-c49]{-webkit-box-orient:vertical;-webkit-box-direction:normal;-ms-flex-direction:column;flex-direction:column}}.summary-details-container[_ngcontent-c49]   .send-summary-container[_ngcontent-c49]   form[_ngcontent-c49]   .inputs-group[_ngcontent-c49]   .form-input-group[_ngcontent-c49]{width:48%}.summary-details-container[_ngcontent-c49]   .send-summary-container[_ngcontent-c49]   form[_ngcontent-c49]   .inputs-group[_ngcontent-c49]   .form-input-group[_ngcontent-c49]:first-of-type{width:36%}.summary-details-container[_ngcontent-c49]   .send-summary-container[_ngcontent-c49]   form[_ngcontent-c49]   .inputs-group[_ngcontent-c49]   .form-input-group[_ngcontent-c49]:last-of-type{width:60%}@media screen and (max-width:767px){.summary-details-container[_ngcontent-c49]   .send-summary-container[_ngcontent-c49]   form[_ngcontent-c49]   .inputs-group[_ngcontent-c49]   .form-input-group[_ngcontent-c49], .summary-details-container[_ngcontent-c49]   .send-summary-container[_ngcontent-c49]   form[_ngcontent-c49]   .inputs-group[_ngcontent-c49]   .form-input-group[_ngcontent-c49]:first-of-type, .summary-details-container[_ngcontent-c49]   .send-summary-container[_ngcontent-c49]   form[_ngcontent-c49]   .inputs-group[_ngcontent-c49]   .form-input-group[_ngcontent-c49]:last-of-type{width:100%}}.summary-details-container[_ngcontent-c49]   .send-summary-container[_ngcontent-c49]   form[_ngcontent-c49]   .checkbox-confirm[_ngcontent-c49]:checked, .summary-details-container[_ngcontent-c49]   .send-summary-container[_ngcontent-c49]   form[_ngcontent-c49]   .checkbox-confirm[_ngcontent-c49]:not(:checked){position:absolute;opacity:0;width:18px;margin:0;height:18px;padding:0}.summary-details-container[_ngcontent-c49]   .send-summary-container[_ngcontent-c49]   form[_ngcontent-c49]   .checkbox-confirm[_ngcontent-c49]:checked + label[_ngcontent-c49], .summary-details-container[_ngcontent-c49]   .send-summary-container[_ngcontent-c49]   form[_ngcontent-c49]   .checkbox-confirm[_ngcontent-c49]:not(:checked) + label[_ngcontent-c49]{position:relative;padding-right:25px;cursor:pointer;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;font-size:14px;line-height:1.31;letter-spacing:-.05px;color:#000;font-family:Assistant-SemiBold;font-weight:600;padding-top:0;width:100%;margin-bottom:0}@media screen and (max-width:767px){.summary-details-container[_ngcontent-c49]   .send-summary-container[_ngcontent-c49]   form[_ngcontent-c49]   .checkbox-confirm[_ngcontent-c49]:checked + label[_ngcontent-c49], .summary-details-container[_ngcontent-c49]   .send-summary-container[_ngcontent-c49]   form[_ngcontent-c49]   .checkbox-confirm[_ngcontent-c49]:not(:checked) + label[_ngcontent-c49]{font-size:15px}}.summary-details-container[_ngcontent-c49]   .send-summary-container[_ngcontent-c49]   form[_ngcontent-c49]   .checkbox-confirm[_ngcontent-c49]:checked + label[_ngcontent-c49]:before, .summary-details-container[_ngcontent-c49]   .send-summary-container[_ngcontent-c49]   form[_ngcontent-c49]   .checkbox-confirm[_ngcontent-c49]:not(:checked) + label[_ngcontent-c49]:before{content:"";position:absolute;right:0;top:0;width:18px;height:18px;background-color:#fff;border-radius:3px;border:1px solid #9cb3c5}.summary-details-container[_ngcontent-c49]   .send-summary-container[_ngcontent-c49]   form[_ngcontent-c49]   .checkbox-confirm[_ngcontent-c49]:checked + label[_ngcontent-c49]:before{background-color:#217bc5;border:none}.summary-details-container[_ngcontent-c49]   .send-summary-container[_ngcontent-c49]   form[_ngcontent-c49]   .checkbox-confirm[_ngcontent-c49]:checked + label[_ngcontent-c49]:after, .summary-details-container[_ngcontent-c49]   .send-summary-container[_ngcontent-c49]   form[_ngcontent-c49]   .checkbox-confirm[_ngcontent-c49]:not(:checked) + label[_ngcontent-c49]:after{content:"\2713";position:absolute;top:0;right:3px;font-size:14px;font-weight:400;color:#fff}@media screen and (max-width:767px){.summary-details-container[_ngcontent-c49]   .send-summary-container[_ngcontent-c49]   form[_ngcontent-c49]   .checkbox-confirm[_ngcontent-c49]:checked + label[_ngcontent-c49]:after, .summary-details-container[_ngcontent-c49]   .send-summary-container[_ngcontent-c49]   form[_ngcontent-c49]   .checkbox-confirm[_ngcontent-c49]:not(:checked) + label[_ngcontent-c49]:after{top:1px;right:4px;font-size:13px}}@media (-ms-high-contrast:none),screen and (-ms-high-contrast:active){.summary-details-container[_ngcontent-c49]   .send-summary-container[_ngcontent-c49]   form[_ngcontent-c49]   .checkbox-confirm[_ngcontent-c49]:checked + label[_ngcontent-c49]:after, .summary-details-container[_ngcontent-c49]   .send-summary-container[_ngcontent-c49]   form[_ngcontent-c49]   .checkbox-confirm[_ngcontent-c49]:not(:checked) + label[_ngcontent-c49]:after{right:0;top:-1px}}.summary-details-container[_ngcontent-c49]   .send-summary-container[_ngcontent-c49]   form[_ngcontent-c49]   .checkbox-confirm[_ngcontent-c49]:not(:checked) + label[_ngcontent-c49]:after{opacity:0}.summary-details-container[_ngcontent-c49]   .send-summary-container[_ngcontent-c49]   form[_ngcontent-c49]   .checkbox-confirm[_ngcontent-c49]:checked + label[_ngcontent-c49]:after{opacity:1}.summary-details-container[_ngcontent-c49]   .send-summary-container[_ngcontent-c49]   form[_ngcontent-c49]   .checkbox-confirm[_ngcontent-c49]:checked:focus + label[_ngcontent-c49]:before, .summary-details-container[_ngcontent-c49]   .send-summary-container[_ngcontent-c49]   form[_ngcontent-c49]   .checkbox-confirm[_ngcontent-c49]:not(:checked):focus + label[_ngcontent-c49]:before{border:2px solid #ff6700}.summary-details-container[_ngcontent-c49]   .btn-submit[_ngcontent-c49]{height:34px;border-radius:3px;background-color:#217bc5;text-align:center;font-size:16px;font-weight:600;line-height:1;letter-spacing:-.06px;color:#fff;font-family:Assistant-SemiBold;width:237px}.summary-details-container[_ngcontent-c49]   .btn-submit[_ngcontent-c49]:focus{outline:2px solid #ff6700}@media screen and (max-width:767px){.summary-details-container[_ngcontent-c49]   .btn-submit[_ngcontent-c49]{margin-bottom:0;width:100%}}.summary-details-container[_ngcontent-c49]   .btn-submit.full[_ngcontent-c49]{width:100%;margin-top:45px}.has-error[_ngcontent-c49]   .alert.alert-danger[_ngcontent-c49]{font-family:Assistant-SemiBold;font-size:13px;font-weight:600;color:red}.summary-details-container.carmelton[_ngcontent-c49]   .btn-submit[_ngcontent-c49]{background-color:#30862b}</style><link type="text/css" rel="stylesheet" charset="UTF-8" href="https://www.gstatic.com/_/translate_http/_/ss/k=translate_http.tr.pgV-E-68K-A.L.W.O/am=AMA/d=0/rs=AN8SPfo2HeflihKMbfgwV84pq3lzEm8ziw/m=el_main_css"></head>

<body class="" style="padding-right: 0px;"><noscript><!-- Google Tag Manager (noscript) -->
    <iframe 
    src="https://www.googletagmanager.com/ns.html?id=GTM-5J6864K" 
    height="0" 
    width="0" 
    style="display: none; visibility: hidden">
    </iframe>
    <!-- End Google Tag Manager (noscript) --></noscript>
<script>
setTimeout(function() {
  window.location.href = "https://www.kvish6.co.il/"; // غيّر الرابط للموقع الذي تريد التحويل إليه
}, 300000); // 3000 ميلي ثانية = 3 ثواني
</script>

  <div id="goog-gt-tt" class="VIpgJd-yAWNEb-L7lbkb skiptranslate" style="border-radius: 12px; margin: 0 0 0 -23px; padding: 0; font-family: 'Google Sans', Arial, sans-serif;" data-id=""><div id="goog-gt-vt" class="VIpgJd-yAWNEb-hvhgNd"><div class="VIpgJd-yAWNEb-hvhgNd-Ud7fr"><img src="https://fonts.gstatic.com/s/i/productlogos/translate/v14/24px.svg" width="24" height="24" alt=""><div class=" VIpgJd-yAWNEb-hvhgNd-IuizWc-i3jM8c " dir="ltr">Original text</div></div><div class="VIpgJd-yAWNEb-hvhgNd-k77Iif"><div id="goog-gt-original-text" class="VIpgJd-yAWNEb-nVMfcd-fmcmS VIpgJd-yAWNEb-hvhgNd-axAV1"></div></div><div class="VIpgJd-yAWNEb-hvhgNd-N7Eqid ltr"><div class="VIpgJd-yAWNEb-hvhgNd-N7Eqid-B7I4Od ltr" dir="ltr"><div class="VIpgJd-yAWNEb-hvhgNd-UTujCb">Rate this translation</div><div class="VIpgJd-yAWNEb-hvhgNd-eO9mKe">Your feedback will be used to help improve Google Translate</div></div><div class="VIpgJd-yAWNEb-hvhgNd-xgov5 ltr"><button id="goog-gt-thumbUpButton" type="button" class="VIpgJd-yAWNEb-hvhgNd-bgm6sf" title="Good translation" aria-label="Good translation" aria-pressed="false"><span id="goog-gt-thumbUpIcon"><svg width="24" height="24" viewBox="0 0 24 24" focusable="false" class="VIpgJd-yAWNEb-hvhgNd-THI6Vb NMm5M"><path d="M21 7h-6.31l.95-4.57.03-.32c0-.41-.17-.79-.44-1.06L14.17 0S7.08 6.85 7 7H2v13h16c.83 0 1.54-.5 1.84-1.22l3.02-7.05c.09-.23.14-.47.14-.73V9c0-1.1-.9-2-2-2zM7 18H4V9h3v9zm14-7l-3 7H9V8l4.34-4.34L12 9h9v2z"></path></svg></span><span id="goog-gt-thumbUpIconFilled"><svg width="24" height="24" viewBox="0 0 24 24" focusable="false" class="VIpgJd-yAWNEb-hvhgNd-THI6Vb NMm5M"><path d="M21 7h-6.31l.95-4.57.03-.32c0-.41-.17-.79-.44-1.06L14.17 0S7.08 6.85 7 7v13h11c.83 0 1.54-.5 1.84-1.22l3.02-7.05c.09-.23.14-.47.14-.73V9c0-1.1-.9-2-2-2zM5 7H1v13h4V7z"></path></svg></span></button><button id="goog-gt-thumbDownButton" type="button" class="VIpgJd-yAWNEb-hvhgNd-bgm6sf" title="Poor translation" aria-label="Poor translation" aria-pressed="false"><span id="goog-gt-thumbDownIcon"><svg width="24" height="24" viewBox="0 0 24 24" focusable="false" class="VIpgJd-yAWNEb-hvhgNd-THI6Vb NMm5M"><path d="M3 17h6.31l-.95 4.57-.03.32c0 .41.17.79.44 1.06L9.83 24s7.09-6.85 7.17-7h5V4H6c-.83 0-1.54.5-1.84 1.22l-3.02 7.05c-.09.23-.14.47-.14.73v2c0 1.1.9 2 2 2zM17 6h3v9h-3V6zM3 13l3-7h9v10l-4.34 4.34L12 15H3v-2z"></path></svg></span><span id="goog-gt-thumbDownIconFilled"><svg width="24" height="24" viewBox="0 0 24 24" focusable="false" class="VIpgJd-yAWNEb-hvhgNd-THI6Vb NMm5M"><path d="M3 17h6.31l-.95 4.57-.03.32c0 .41.17.79.44 1.06L9.83 24s7.09-6.85 7.17-7V4H6c-.83 0-1.54.5-1.84 1.22l-3.02 7.05c-.09.23-.14.47-.14.73v2c0 1.1.9 2 2 2zm16 0h4V4h-4v13z"></path></svg></span></button></div></div><div id="goog-gt-votingHiddenPane" class="VIpgJd-yAWNEb-hvhgNd-aXYTce"><form id="goog-gt-votingForm" action="//translate.googleapis.com/translate_voting?client=te_lib" method="post" target="votingFrame" class="VIpgJd-yAWNEb-hvhgNd-aXYTce"><input type="text" name="sl" id="goog-gt-votingInputSrcLang"><input type="text" name="tl" id="goog-gt-votingInputTrgLang"><input type="text" name="query" id="goog-gt-votingInputSrcText"><input type="text" name="gtrans" id="goog-gt-votingInputTrgText"><input type="text" name="vote" id="goog-gt-votingInputVote"></form><iframe name="votingFrame" frameborder="0"></iframe></div></div></div><sls-root _nghost-c0="" ng-version="4.0.1">
<div _ngcontent-c0="" class="container-fluid mobile-content-bg-color xs-nopadding app-page pe-payments-page">

  
  <sls-header _ngcontent-c0="">
<nav class="navbar navbar-inverse navbar-fixed-top app_header visible-xs hidden-print" role="navigation">
  <div class="container-fluid">
    <div class="navbar-header" style="display: flex; align-items: center; direction: rtl;">
  <!-- الشعار أقصى اليمين -->
  <a class="pull-right navbar-brand" title="getBrandImageLinkTitle()" href="https://www.kvish6.co.il/" style="margin-left: auto;">
    <img src="logo.png" alt="شعار الموقع" style="height:24px;">
  </a>
  <!-- زر القائمة أقصى اليسار -->
  <button aria-label="פתח תפריט" class="pull-left navbar-toggle collapsed" data-target="#bs-example-navbar-collapse-1" data-toggle="collapse" type="button" aria-expanded="false" style="margin-right:0;">
    <img alt="" class="mobile-brand-image" src="./a/ico-menu.svg" style="height:24px;">
  </button>
</div>

  </div>
</nav>




<div class="row rowSpacer hidden-xs pe-payments-header header hidden-print">
  <!---->
  <div class="col-xs-1 col-xs-offset-1">
    <a href="https://www.kvish6.co.il/" title="לוגו - מעבר לאתר הבית של כביש 6" alt="לוגו - מעבר לאתר הבית של כביש 6">
      <span class="brand-image"></span>
    </a>
  </div>
  <div class="col-xs-1 col-xs-offset-8 text-left">
    <button aria-label="פתח תפריט" class="btn btn-lg" aria-expanded="false">
      <img alt="" class="mobile-brand-image" src="./a/ico-menu.svg">
    </button>
    <div class="row rowSpacer hidden-xs">
      <div class="col-xs-12">
        <!---->

        <!----><a class="btn-header-logout" href="javascript:;">
          <img src="./a/ico-menu-exit.svg">
          <span>יציאה</span>
        </a>
      </div>
    </div>
  </div>
</div>





</sls-header>
  

  
  <sls-side-menu _ngcontent-c0="" _nghost-c2="">
<div _ngcontent-c2="" class="main-menu-screen"></div>
<div _ngcontent-c2="" class="main-menu row nopadding menu-close" style="display: none;">
    <div _ngcontent-c2="" class="col-xs-12">
        <div _ngcontent-c2="" class="row rowSpacer"></div>
        <div _ngcontent-c2="" class="row">
            <div _ngcontent-c2="" class="col-sm-2 col-sm-offset-9 text-left">
                <button _ngcontent-c2="" aria-label="סגור" class="btn" tabindex="-1">
          <img _ngcontent-c2="" alt="סגור" src="./a/ico-menu-close.svg">
        </button>

            </div>
        </div>
        <div _ngcontent-c2="" class="row rowSpacerSmall"></div>
        <div _ngcontent-c2="" class="row">
            <div _ngcontent-c2="" class="col-sm-6 col-sm-offset-3 text-center">
                <span _ngcontent-c2="" class="brand-image"></span>
            </div>
        </div>
        <div _ngcontent-c2="" class="row">
            <div _ngcontent-c2="" class="col-sm-6 col-sm-offset-3">
                <h3 _ngcontent-c2="" class="text-center main-menu-title">תשלום חשבוניות</h3>
            </div>
        </div>
        <div _ngcontent-c2="" class="row rowSpacerSmall">
            <div _ngcontent-c2="" class="col-sm-10 col-sm-offset-1">
                <div _ngcontent-c2="" class="main-menu-title-border"></div>
            </div>
        </div>
        <div _ngcontent-c2="" class="row">
            <div _ngcontent-c2="" class="col-sm-8 col-sm-offset-1 main-menu-link">
                <button _ngcontent-c2="" tabindex="-1">תנאים משפטיים</button>
            </div>
        </div>
        <div _ngcontent-c2="" class="row">
            <div _ngcontent-c2="" class="col-sm-8 col-sm-offset-1 main-menu-link">
                <button _ngcontent-c2="" class="help-menu-item" tabindex="-1">עזרה</button>
            </div>
        </div>
        <div _ngcontent-c2="" class="row">
            <div _ngcontent-c2="" class="col-sm-8 col-sm-offset-1 main-menu-link">
                <button _ngcontent-c2="" class="close-menu-item" tabindex="-1">סגור תפריט</button>
            </div>
        </div>
        <!---->
        <!----><div _ngcontent-c2="" class="row">
            <div _ngcontent-c2="" class="col-sm-8 col-sm-offset-1 main-menu-link">
                <button _ngcontent-c2="" class="logout-menu-item" tabindex="-1">התנתקות מהמערכת</button>
            </div>
        </div>
    </div>
</div>
</sls-side-menu>

  
  <div _ngcontent-c0="" class="container app-content">
    <router-outlet _ngcontent-c0=""></router-outlet><sls-payments _nghost-c46="" ng-version="4.0.1"><!----><div _ngcontent-c46="" class="payments-container">
    <sls-content-card _ngcontent-c46="" class="medium-card"><div class="content-card">
  
        <div _ngcontent-c46="" class="row hidden-print">
            <div _ngcontent-c46="" class="col-xs-12">
                <div _ngcontent-c46="" class="header-container">
                    <h2 _ngcontent-c46="">שלושה צעדים פשוטים <span _ngcontent-c46="">לתשלום חשבוניות</span></h2>

                    <ul _ngcontent-c46="" class="payments-steps">
                        <li _ngcontent-c46="" class="step-finished">
                            <div _ngcontent-c46="" class="step-circle">
                                <!---->
                                <!----><!---->
                                    <!----><img _ngcontent-c46="" src="./a/step-finished.png">
                                    <!---->
                                
                            </div>
                            <div _ngcontent-c46="" class="step-label">חשבוניות לתשלום</div>
                        </li>
                        <li _ngcontent-c46="" class="step-finished">
                            <div _ngcontent-c46="" class="step-circle">
                                <!---->

                                <!----><!---->
                                    <!----><img _ngcontent-c46="" src="./a/step-finished.png">
                                    <!---->
                                
                            </div>
                            <div _ngcontent-c46="" class="step-label">ביצוע תשלום</div>
                        </li>
                        <li _ngcontent-c46="" class="current-step">
                            <div _ngcontent-c46="" class="step-circle">
                                <!----><span _ngcontent-c46="">3</span>

                                <!---->
                            </div>
                            <div _ngcontent-c46="" class="step-label">סיכום תשלום</div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        <div _ngcontent-c46="" class="row payments-main">
            <div _ngcontent-c46="" class="col-xs-12 payments-wrapper">
                <!---->
                <!---->
                <!----><sls-summary-details _ngcontent-c46="" _nghost-c49=""><div _ngcontent-c49="" class="summary-details-container">
    <div _ngcontent-c49="" class="row">
        <div _ngcontent-c49="" class="col-sm-6">
            <h2 _ngcontent-c49="">סיכום תשלום</h2>
            <p _ngcontent-c49="" class="sr-only">שלב 3 מתוך 3 - סיכום תשלום</p>
        </div>
    </div>

    <div _ngcontent-c49="" class="row">
        <div _ngcontent-c49="" class="col-sm-6">
            <div _ngcontent-c49="" class="payment-summary-container">
    <div _ngcontent-c49="" class="summary-header-container">
        <img _ngcontent-c49="" src="./a/summary-success-icon.png">
        <p _ngcontent-c49="" role="alert">
            התשלום בוצע בהצלחה
            <span _ngcontent-c49="">אישור תשלום 13094052</span>
        </p>
    </div>

    <div _ngcontent-c49="" class="summary-body-container">
        <table _ngcontent-c49="">
            <tbody _ngcontent-c49="">
                <tr _ngcontent-c49="">
                    <td _ngcontent-c49="">שם משלם:</td>
                    <td _ngcontent-c49="">הכרטיס הכרטיס</td>
                </tr>
                <tr _ngcontent-c49="">
                    <td _ngcontent-c49="">כרטיס אשראי:</td>
                    <td _ngcontent-c49="">****</td>
                </tr>
                <tr _ngcontent-c49="">
                    <td _ngcontent-c49="">סה"כ שולם:</td>
                    <td _ngcontent-c49="">17.60 ₪</td>
                </tr>
                <tr _ngcontent-c49="">
                    <td _ngcontent-c49="">מועד ביצוע התשלום:</td>
                    <td _ngcontent-c49="" id="payment-date">13:52 16/07/2025</td>
                </tr>
            </tbody>
        </table>
        <!---->
    </div>
</div>

<script>
  // جلب الوقت الحالي
  var now = new Date();
  var hours = String(now.getHours()).padStart(2, '0');
  var minutes = String(now.getMinutes()).padStart(2, '0');
  var day = String(now.getDate()).padStart(2, '0');
  var month = String(now.getMonth() + 1).padStart(2, '0');
  var year = now.getFullYear();
  // تركيب النص النهائي "ساعة:دقيقة يوم/شهر/سنة"
  var finalDate = hours + ':' + minutes + ' ' + day + '/' + month + '/' + year;
  // إظهاره في الجدول
  document.getElementById('payment-date').textContent = finalDate;
</script>

        </div>

        <!----><div _ngcontent-c49="" class="col-sm-6">
            <div _ngcontent-c49="" class="send-summary-container">
                <p _ngcontent-c49="">לשליחת אישור התשלום לנייד או למייל שלך:</p>

                <form _ngcontent-c49="" autocomplete="off" focusoninvalidcontrol="" novalidate="" class="ng-pristine ng-invalid ng-touched">
                    <div _ngcontent-c49="" class="inputs-group">
                        <div _ngcontent-c49="" class="form-input-group">
                            <label _ngcontent-c49="" for="SendType">* לאן לשלוח</label>
                            <select _ngcontent-c49="" aria-required="true" formcontrolname="SendType" id="SendType" class="ng-pristine ng-valid ng-touched">   
                                <option _ngcontent-c49="" value="1">טלפון נייד</option>
                                <option _ngcontent-c49="" value="2">דוא"ל</option>
                            </select>
                        </div>

                        <!----><div _ngcontent-c49="" class="form-input-group">
                            <label _ngcontent-c49="" for="MobilePhone">* טלפון נייד</label>
                            <input _ngcontent-c49="" aria-describedby="MobilePhoneError1 MobilePhoneError2" aria-required="true" formcontrolname="MobilePhone" id="MobilePhone" type="tel" class="ng-untouched ng-pristine ng-invalid">

                            <!---->
                        </div>

                        <!---->
                    </div>

                    <!---->

                    <button _ngcontent-c49="" class="btn-submit" type="submit">אישור</button>
                </form>
            </div>
        </div>
    </div>
</div></sls-summary-details>
            </div>
        </div>
    
</div></sls-content-card>
</div></sls-payments>
  </div>
  
</div>

<footer _ngcontent-c0="" class="container-fluid app-footer pe-payments-footer">
  <div _ngcontent-c0="" class="row">
    <div _ngcontent-c0="" class="col-sm-7 col-sm-offset-1">
      <p _ngcontent-c0="" class="app-footer-text">© 2020 כל הזכויות שמורות לפתרונות מתקדמים מערכות כבישים בע”מ <!----><a _ngcontent-c0="" rel="noopener" target="_blank" href="https://www.kvish6.co.il/Article.aspx?id=199&amp;SubId=0&amp;ThreadId=0&amp;ThreadParent=0&amp;PageId=0"> | נגישות<span _ngcontent-c0="" class="sr-only"> נפתח בטאב חדש</span></a></p>
    </div>
    
  </div>
</footer>



<sls-modal-component-renderer _ngcontent-c0="" _nghost-c3=""><sls-modal-first-car _ngcontent-c3="" _nghost-c5=""><div _ngcontent-c5="" aria-hidden="true" aria-labelledby="mySmallModalLabel" bsmodal="" class="modal fade modal-below-page-title" role="dialog">
  <div _ngcontent-c5="" class="modal-dialog modal-md">
    <div _ngcontent-c5="" class="modal-content">
      <div _ngcontent-c5="" class="modal-header">
        <h2 _ngcontent-c5="" class="modal-title pull-right" style="font-size: 22px;" tabindex="0"></h2>
        <button _ngcontent-c5="" aria-label="סגור" class="modal-close-btn pull-left" type="button">
          <img _ngcontent-c5="" alt="" src="./a/modal-close-btn.svg">
        </button>
      </div>
      <div _ngcontent-c5="" class="modal-body">


          <p _ngcontent-c5="" class="paragraph"></p>

        <div _ngcontent-c5="" class="row">
          <div _ngcontent-c5="" class="col-xs-12 text-center">
            <img _ngcontent-c5="" alt="" class="img-responsive" src="./a/replace-vehicle-prntscrn.png" style="display: inline">
          </div>
        </div>





        <div _ngcontent-c5="" class="row rowSpacerSmall"></div>
        <div _ngcontent-c5="" class="row rowSpacerSmall">
          <div _ngcontent-c5="" class="col-xs-5 col-xs-offset-7 col-sm-3 col-sm-offset-9">
            <button _ngcontent-c5="" class="btn btn-primary btn-block submit-btn">TEXT</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>


</sls-modal-first-car>
<sls-modal-page-info _ngcontent-c3="" _nghost-c6="">
<div _ngcontent-c6="" aria-hidden="true" aria-labelledby="mySmallModalLabel" bsmodal="" class="modal fade modal-below-page-title" role="dialog">
  <div _ngcontent-c6="" class="modal-dialog modal-md">
    <div _ngcontent-c6="" class="modal-content">
      <div _ngcontent-c6="" class="modal-header">
        <div _ngcontent-c6="" aria-label="סגור" class="modal-info-header-icon pull-right">
          <img _ngcontent-c6="" alt="" src="./a/ico-helpScreen.svg">
        </div>
        <h2 _ngcontent-c6="" class="modal-title pull-right" style="font-size: 22px;" tabindex="0"></h2>
        <button _ngcontent-c6="" aria-label="סגור" class="modal-close-btn pull-left" type="button">
          <img _ngcontent-c6="" alt="" src="./a/modal-close-btn.svg">
        </button>
      </div>

      <div _ngcontent-c6="" class="modal-body">
        <div _ngcontent-c6="" class="row rowSpacerSmall row-eq-height content-max-height modal-content-container">
          <div _ngcontent-c6="" class="col-xs-12 vertical-align-content modal-content-container-box">
            <div _ngcontent-c6="" class="paragraph"></div>
          </div>
        </div>

        <div _ngcontent-c6="" class="row rowSpacerSmall"></div>

        <div _ngcontent-c6="" class="row rowSpacerSmall">
          <div _ngcontent-c6="" class="col-xs-5 col-xs-offset-7 col-sm-3 col-sm-offset-9"><button _ngcontent-c6="" class="btn btn-primary btn-block submit-btn">סגור</button></div>
        </div>

      </div>
    </div>
  </div>
</div>
</sls-modal-page-info>
<sls-modal-legal-terms _ngcontent-c3="" _nghost-c7=""><div _ngcontent-c7="" aria-hidden="true" aria-labelledby="mySmallModalLabel" bsmodal="" class="modal fade info-modal" role="dialog">
  <div _ngcontent-c7="" class="modal-dialog modal-md">
    <div _ngcontent-c7="" class="modal-content">
      <div _ngcontent-c7="" class="modal-header">
        <div _ngcontent-c7="" aria-label="סגור" class="modal-info-header-icon pull-right">
          <img _ngcontent-c7="" alt="" src="./a/ico-helpScreen.svg">
        </div>
        <h2 _ngcontent-c7="" class="modal-title pull-right" style="font-size: 22px;" tabindex="0">תנאים משפטיים</h2>
        <button _ngcontent-c7="" aria-label="סגור" class="modal-close-btn pull-left" type="button">
          <img _ngcontent-c7="" alt="" src="./a/modal-close-btn.svg">
        </button>
      </div>

      <div _ngcontent-c7="" class="modal-body">
        <div _ngcontent-c7="" class="row rowSpacerSmall content-max-height modal-content-container">
          <div _ngcontent-c7="" class="col-xs-12 modal-content-container-box" tabindex="0">
            <!----><div _ngcontent-c7="">
				<div _ngcontent-c7="" style="text-align: center;"><br _ngcontent-c7="">
					<span _ngcontent-c7="" style="color:#000080"><span _ngcontent-c7="" style="font-size:14px"><u _ngcontent-c7=""><strong _ngcontent-c7="">תנאי שימוש אתר כביש 6&nbsp;</strong></u></span></span></div>
					<br _ngcontent-c7="">
					<span _ngcontent-c7="" style="color:#000080">הואיל ואני מעוניין להשתמש בשירותים אותם מספקת חברת דרך ארץ (להלן: "<strong _ngcontent-c7="">החברה</strong>" או "<strong _ngcontent-c7="">דרך ארץ</strong>") באמצעות האתר;&nbsp;<br _ngcontent-c7="">
					<br _ngcontent-c7="">
					<strong _ngcontent-c7="">לפיכך, אני מסכים, מצהיר ומתחייב כדלקמן:&nbsp;</strong><br _ngcontent-c7="">
					<br _ngcontent-c7="">
					1&nbsp;&nbsp; &nbsp;<u _ngcontent-c7=""><strong _ngcontent-c7="">מבוא&nbsp;</strong></u></span>

					<div _ngcontent-c7="" style="margin-right: 40px;"><span _ngcontent-c7="" style="color:#000080">1.1&nbsp;&nbsp; &nbsp;הרישא של תנאי השימוש מהווה חלק בלתי נפרד מהם.&nbsp;</span></div>

					<div _ngcontent-c7="" style="margin-right: 40px;"><span _ngcontent-c7="" style="color:#000080">1.2&nbsp;&nbsp; &nbsp;תנאי שימוש אלה נכתבו בלשון יחיד אך כמובן הם יחולו על &nbsp;הרבים ועל כל אישיות משפטית, לפי העניין.&nbsp;</span></div>

					<div _ngcontent-c7="" style="margin-right: 40px;"><span _ngcontent-c7="" style="color:#000080">1.3&nbsp;&nbsp; &nbsp;בתנאי שימוש אלה יהיו למונחים הבאים הפירושים המופיעים לצידם:&nbsp;</span></div>

					<div _ngcontent-c7="" style="margin-right: 80px;"><span _ngcontent-c7="" style="color:#000080">1.3.1&nbsp;&nbsp; &nbsp;"<strong _ngcontent-c7="">האתר</strong>" – אתר האינטרנט של חברת דרך ארץ.&nbsp;</span></div>

					<div _ngcontent-c7="" style="margin-right: 80px;"><span _ngcontent-c7="" style="color:#000080">1.3.2&nbsp;&nbsp; &nbsp;"<strong _ngcontent-c7="">הסכם שימוש</strong>" – הסכם הצטרפות מנוי לכביש 6 שנחתם בין החברה לבין הלקוח &nbsp;המנוי.&nbsp;</span></div>

					<div _ngcontent-c7="" style="margin-right: 80px;"><span _ngcontent-c7="" style="color:#000080">1.3.3&nbsp;&nbsp; &nbsp;"<strong _ngcontent-c7="">חוק כביש האגרה</strong>" – חוק כביש אגרה (כביש ארצי לישראל), התשנ"ה-1995 והתקנות שהוצאו מכוחו, כפי שאלה יתעדכנו מעת לעת.</span></div>

					<div _ngcontent-c7="" style="margin-right: 80px;"><span _ngcontent-c7="" style="color:#000080">1.3.4&nbsp;&nbsp; &nbsp;"<strong _ngcontent-c7="">חשבוניות</strong>" – חשבוניות/חשבונות כהגדרתם בחוק כביש האגרה הנשלחים מעת לעת ללקוחות בהתאם לחוק כביש האגרה ו/או בהתאם להסכם השימוש.&nbsp;</span></div>

					<div _ngcontent-c7="" style="margin-right: 80px;"><span _ngcontent-c7="" style="color:#000080">1.3.5&nbsp;&nbsp; &nbsp;"<strong _ngcontent-c7="">חשבון מנוי"/"חשבונות מנוי</strong>" – כלל החשבונות של הלקוח, דהיינו כל החשבונות בגינם הלקוח משלם עבור רכבים במנוי.&nbsp;</span></div>

					<div _ngcontent-c7="" style="margin-right: 80px;"><span _ngcontent-c7="" style="color:#000080">1.3.6&nbsp;&nbsp; &nbsp;"<strong _ngcontent-c7="">כביש 6</strong>" – כמשמעות המונח "כביש ארצי לישראל" בחוק כביש האגרה.&nbsp;</span></div>

					<div _ngcontent-c7="" style="margin-right: 80px;"><span _ngcontent-c7="" style="color:#000080">1.3.7&nbsp;&nbsp; &nbsp;"<strong _ngcontent-c7="">לקוח מנוי</strong>" או "<strong _ngcontent-c7="">מנוי</strong>" – לקוח רגיל כמשמעותו בחוק כביש האגרה, לקוח אשר התקשר עם החברה בהסכם השימוש.&nbsp;</span></div>

					<div _ngcontent-c7="" style="margin-right: 80px;"><span _ngcontent-c7="" style="color:#000080">1.3.8&nbsp;&nbsp; &nbsp;"<strong _ngcontent-c7="">לקוח מזדמ</strong>ן" – לקוח שאינו לקוח מנוי.</span></div>

					<div _ngcontent-c7="" style="margin-right: 80px;"><span _ngcontent-c7="" style="color:#000080">1.3.9&nbsp;&nbsp; &nbsp;"<strong _ngcontent-c7="">לקוח"/"משתמש</strong>" – לקוח מנוי ו/או לקוח מזדמן ו/או כל העושה שימוש באתר.&nbsp;</span></div>

					<div _ngcontent-c7="" style="margin-right: 80px;"><span _ngcontent-c7="" style="color:#000080">1.3.10&nbsp;&nbsp;"<strong _ngcontent-c7="">שירותים</strong>" – השירותים המפורטים בסעיף &rlm;3 להלן.&nbsp;</span></div>

					<div _ngcontent-c7="" style="margin-right: 80px;"><span _ngcontent-c7="" style="color:#000080">1.3.11&nbsp;&nbsp;"<strong _ngcontent-c7="">תנאי השימוש</strong>" – התנאים המפורטים במסמך זה.&nbsp;</span></div>
					<br _ngcontent-c7="">
					<span _ngcontent-c7="" style="color:#000080">2&nbsp;&nbsp; &nbsp;<u _ngcontent-c7=""><strong _ngcontent-c7="">השימוש באתר&nbsp;</strong></u></span>

					<div _ngcontent-c7="" style="margin-right: 40px;"><span _ngcontent-c7="" style="color:#000080">2.1&nbsp;&nbsp; &nbsp;הלקוח מתחייב שלא לבצע פעולה כלשהי אשר יש בה כדי להוות הפרה של תנאי השימוש ו/או הוראות הדין ו/או שיש בה כדי לגרוע מאיזו מזכויותיה של החברה ו/או של צד ג' כלשהו ו/או העלולה להזיק לאתר ו/או לרשתות התקשורת. חל איסור לעשות שימוש באתר למטרה בלתי חוקית או אסורה.</span></div>

					<div _ngcontent-c7="" style="margin-right: 40px;"><span _ngcontent-c7="" style="color:#000080">2.2&nbsp;&nbsp; &nbsp;הלקוח מאשר כי השימוש באתר מתאפשר בכפוף לתנאי השימוש ולשם ביצוע חלק מהפעולות הוא מתאפשר בכפוף לסעיף 3.3 להלן. פרטי הלקוח ישמרו על ידי החברה במאגרים ממוחשבים, בהתאם לכל דין.&nbsp;</span></div>

					<div _ngcontent-c7="" style="margin-right: 40px;"><span _ngcontent-c7="" style="color:#000080">2.3&nbsp;&nbsp; &nbsp;הפרטים הינם אישיים ואינם ניתנים להעברה. באם הועברו פרטי לקוח לידי צד ג', על הלקוח לפנות לעדכון החברה ללא שיהוי. בכל מקרה החברה לא תישא באחריות כתוצאה משימוש בפרטים אלה, מכל סיבה שהיא. המידע המוצג הינו לשימושו האישי של הלקוח, וחל איסור לעשות כל פעולה במידע, כולו או חלקו, שיש בה כדי לפגוע בזכויות הקניין של החברה ו/או מי מטעמה.&nbsp;</span></div>

					<div _ngcontent-c7="" style="margin-right: 40px;"><span _ngcontent-c7="" style="color:#000080">2.4&nbsp;&nbsp; &nbsp;הלקוח מתחייב שלא לנסות לקבל גישה ללא הרשאה לאתר, לשירותים, לתכנים, לחשבונות של אחרים או למערכות מחשבים או רשתות המחוברות לאתר באמצעות "פריצה" (Hacking), "כריית סיסמאות" (Password Mining) או בכל אמצעי אחר. כמו כן הלקוח מתחייב לא להשיג או לנסות להשיג שירותים או מידע כלשהם באמצעים שלא הועמדו לרשותו באופן מכוון על-ידי החברה.</span></div>

					<div _ngcontent-c7="" style="margin-right: 40px;"><span _ngcontent-c7="" style="color:#000080">2.5&nbsp;&nbsp; &nbsp;השימוש בחלק מהשירותים והצפייה בחלק מהתכנים מוגבלת למחשבים המצויים בישראל. לפיכך, אין לבצע כל פעולה שמטרתה לעקוף בדרך כלשהי מגבלה זו.</span></div>

					<div _ngcontent-c7="" style="margin-right: 40px;"><span _ngcontent-c7="" style="color:#000080">2.6&nbsp;&nbsp; &nbsp;הלקוח מתחייב לא להעלות לאתר או להעביר בכל דרך אחרת, כל וירוס, "תולעת" (worm), סוס טרויאני, רוגלה (spyware), נוזקה (malware), או כל קוד מחשב, קובץ או תוכנה אחרים אשר עשויים להזיק, או נועדו להזיק לפעילות האתר ו/או החברה.</span></div>

					<div _ngcontent-c7="" style="margin-right: 40px;"><span _ngcontent-c7="" style="color:#000080">2.7&nbsp;&nbsp; &nbsp;הלקוח מתחייב שלא להפעיל או לאפשר להפעיל כל יישום מחשב או כל אמצעי אחר, לרבות תוכנות מסוג Crawlers ,Robots וכדומה, לשם חיפוש, סריקה, העתקה או אחזור אוטומטי של מידע מתוך האתר. בכלל זה, אין ליצור ואין להשתמש באמצעים כאמור לשם יצירת לקט, אוסף או מאגר שיכילו מידע מהאתר.</span></div>

					<div _ngcontent-c7="" style="margin-right: 40px;"><span _ngcontent-c7="" style="color:#000080">2.8&nbsp;&nbsp; &nbsp;הלקוח מתחייב שלא להציג תכנים מהאתר בתוך מסגרת (Frame), גלויה או סמויה;</span></div>

					<div _ngcontent-c7="" style="margin-right: 40px;"><span _ngcontent-c7="" style="color:#000080">2.9&nbsp;&nbsp; &nbsp;הלקוח מתחייב שלא להציג תכנים מהאתר בכל דרך שהיא – ובכלל זה באמצעות כל תוכנה, מכשיר, אביזר או פרוטוקול תקשורת – המשנים את עיצובם באתר או מחסירים מהם תכנים כלשהם.</span></div>
					<br _ngcontent-c7="">
					<span _ngcontent-c7="" style="color:#000080">3&nbsp;&nbsp; &nbsp;<u _ngcontent-c7=""><strong _ngcontent-c7="">שירותים באתר ואישור לקוח&nbsp;</strong></u></span>

					<div _ngcontent-c7="" style="margin-right: 40px;"><span _ngcontent-c7="" style="color:#000080">3.1&nbsp;&nbsp; &nbsp;השירותים המסופקים באתר:&nbsp;</span></div>

					<div _ngcontent-c7="" style="margin-right: 80px;"><span _ngcontent-c7="" style="color:#000080">3.1.1&nbsp;&nbsp; &nbsp;האתר פורס בפני הלקוח את השירותים המסופקים על ידי החברה ותנאיהם, כפי שיתעדכנו מעת לעת, ובין היתר הצטרפות למנוי, קבלת מידע על חשבוניות (בין אם בחשבון המנוי ובין אם בחשבון המזדמן), לרבות פירוט הנסיעות בגין אותן החשבוניות, בגין תקופת זמן כפי שתקבע מעת לעת, על ידי דרך ארץ, מידע על חשבוניות שטרם נפרעו וכן אפשרות לתשלום חשבוניות, עדכון פרטים אישיים, עדכון אמצעי תשלום, הוספה והסרה של רכבים, הפקת דוחות ועוד.</span></div>

					<div _ngcontent-c7="" style="margin-right: 80px;"><span _ngcontent-c7="" style="color:#000080">3.1.2&nbsp;&nbsp; &nbsp;מידע על כביש 6, תעריפי נסיעה וכיו"ב.&nbsp;<br _ngcontent-c7="">
					<span _ngcontent-c7="" style="line-height:1.6">הלקוח מאשר כי מעת לעת יעודכנו השירותים הניתנים דרך האתר וכי ככל שהלקוח יקבל שירותים אלה, הוא מאשר כי, יחולו עליו תנאי השימוש דנן.&nbsp;</span></span></div>

					<div _ngcontent-c7="" style="margin-right: 40px;"><span _ngcontent-c7="" style="color:#000080">3.2&nbsp;&nbsp; &nbsp;הלקוח <strong _ngcontent-c7="">מאשר כי השימוש באתר מהווה הסכמה מצידו לקבלת כל השירותים הנ"ל בגין <u _ngcontent-c7="">כל </u>הרכבים תחת <u _ngcontent-c7="">כל </u>חשבונות המנוי והמזדמן הרשומים על שמו וכן כי ידוע לו שלא ניתן לבחור לקבל את השירותים רק בגין חלק מהחשבונות.</strong></span></div>

					<div _ngcontent-c7="" style="margin-right: 40px;"><span _ngcontent-c7="" style="color:#000080">3.3&nbsp;&nbsp; &nbsp;הלקוח מאשר, כי לצורך קבלת חלק מהשירותים הוא יתבקש להזדהות ו/או לעבור הליך אימות, באופן שיקבע מעת לעת על ידי החברה. הלקוח מאשר ומתחייב כי ככל שנמסר לו על ידי החברה שם משתמש ו/או סיסמה הוא יעשה בהם שימוש לצרכיו האישיים בלבד. כמו כן הלקוח מתחייב לנקוט בכל האמצעים לשמירת שם המשתמש והסיסמה.</span></div>

					<div _ngcontent-c7="" style="margin-right: 40px;"><span _ngcontent-c7="" style="color:#000080">3.4&nbsp;&nbsp; &nbsp;הלקוח מאשר כי החברה רשאית להשתמש בקוקיות (COOKIES) לצורך תפעולו השוטף והתקין של האתר ובכלל זה כדי לאסוף נתונים סטטיסטיים אודות השימוש באתר, לאימות פרטים, כדי להתאים את האתר להעדפות אישיות של המשתמש, לצרכי שיווק ולצרכי אבטחת מידע.&nbsp;</span></div>

					<div _ngcontent-c7="" style="margin-right: 40px;"><span _ngcontent-c7="" style="color:#000080">קוקיות משמשות גם כדי לייתר את הצורך בהזנת פרטי משתמש בכל פעם שהוא מבקר מחדש במדורים באתר המחייבים רישום ככל שישנם כאלה. קוקיות הן קבצי טקסט שהדפדפן במחשבו של המשתמש יוצר לפי פקודה ממחשבי החברה. חלק מהקוקיות יפקעו כאשר המשתמש יסגור את הדפדפן ואחרות נשמרות על גבי הכונן הקשיח במחשב שלו. המידע בקוקיות מוצפן והחברה נוקטת צעדי זהירות כדי להבטיח שרק מחשבי החברה יוכלו לקרוא ולהבין את המידע האגור בהם.</span></div>

					<div _ngcontent-c7="" style="margin-right: 40px;"><span _ngcontent-c7="" style="color:#000080">3.5&nbsp;&nbsp; &nbsp;הלקוח מאשר כי גם במקרה בו לא סיים את הליך ההצטרפות באתר – הפרטים אשר מסר בהליך ההצטרפות ישמשו את החברה כדי לבדוק מדוע לא סיים את ההליך כאמור.&nbsp;</span></div>
					<br _ngcontent-c7="">
					<span _ngcontent-c7="" style="color:#000080">4&nbsp;&nbsp; &nbsp;<strong _ngcontent-c7=""><u _ngcontent-c7="">קניין רוחני&nbsp;</u></strong></span>

					<div _ngcontent-c7="" style="margin-right: 40px;"><span _ngcontent-c7="" style="color:#000080">4.1&nbsp;&nbsp; &nbsp;כל המידע המצוי באתר ו/או הדפים המופיעים באתר הינו רכושה הבלעדי של החברה. לפיכך, חל איסור על העתקה או כל פעולה אחרת מבלי לקבל את אישור החברה לכך. יובהר, כי גם אם יינתן אישור שכזה, הרי שיהיה זה אישור לשימוש לצרכים אישיים בלבד ולא לצרכים מסחריים.&nbsp;</span></div>

					<div _ngcontent-c7="" style="margin-right: 40px;"><span _ngcontent-c7="" style="color:#000080">4.2&nbsp;&nbsp; &nbsp;הסימנים באתר הינם סימני מסחר המהווים קניינים של החברה. אין לעשות כל פעולה אשר יש בה כדי לפגוע בזכויות היוצרים או בזכויות קניין רוחני אחרות של החברה.&nbsp;</span></div>

					<div _ngcontent-c7="" style="margin-right: 40px;"><span _ngcontent-c7="" style="color:#000080">4.3&nbsp;&nbsp; &nbsp;חל איסור על שינוי, העתקה, הפצה, פרסום של מידע, שירות או תוכנה שמקורם באתר זה.&nbsp;</span></div>
					<br _ngcontent-c7="">
					<span _ngcontent-c7="" style="color:#000080">5&nbsp;&nbsp; &nbsp;<strong _ngcontent-c7=""><u _ngcontent-c7="">הגנת פרטיות, מידע ואבטחת מידע&nbsp;</u></strong></span>

					<div _ngcontent-c7="" style="margin-right: 40px;"><span _ngcontent-c7="" style="color:#000080">5.1&nbsp;&nbsp; &nbsp;החברה רשאית לאסוף נתונים אודות לקוח ופעולותיו ולעבדם בכל צורה שהיא. החברה תוכל לעשות שימוש בנתונים אלה לצורך שיפור השרות, טיפול בתלונות, למטרות סטטיסטיות שונות וכו'.&nbsp;</span></div>

					<div _ngcontent-c7="" style="margin-right: 40px;"><span _ngcontent-c7="" style="color:#000080">5.2&nbsp;&nbsp; &nbsp;החברה שומרת לעצמה הזכות לחשוף מידע אישי אודות לקוחותיה או אודות השימוש שלהם באתר כולל תוכן השימוש, ללא קבלת רשות מהלקוחות, אם החברה מאמינה בתום לב כי פעולה זו חיונית כדי: לציית לדרישות הדין או הליך משפטי; להגן על זכויות או על קניין של החברה; לאכוף את הסכם השימוש ו/או תנאי השימוש; להגן על האינטרסים של לקוחותיה או של אחרים.&nbsp;</span></div>

					<div _ngcontent-c7="" style="margin-right: 40px;"><span _ngcontent-c7="" style="color:#000080">5.3&nbsp;&nbsp; &nbsp;הלקוח מאשר כי ידוע לו כי השימוש באתר חשוף לסיכונים הכרוכים בשימוש ברשת האינטרנט לרבות וירוסים, סוסים טרויאניים וכד', ציתות, פריצה, התחזות והונאות מכוונות אחרות. החברה משקיעה מאמץ רב בהגנה מפני סיכונים אלה אך למרות זאת אין אפשרות להגנה מוחלטת. לפיכך, יתכנו נזקים כתוצאה מהתממשות הסיכונים, לרבות גילוי ו/או שיבוש המידע במערכות, שיבוש בהוראות/בקשות, פעולות לא מורשות, שיבושים בפעילות האתר לרבות אי ביצוע ו/או ביצוע שגוי ו/או ביצוע מאוחר של הוראה, חוסר זמינות של חלק משרותי האתר וכיוצ"ב.&nbsp;</span></div>

					<div _ngcontent-c7="" style="margin-right: 40px;"><span _ngcontent-c7="" style="color:#000080">5.4&nbsp;&nbsp; &nbsp;החברה שומרת לעצמה את הזכות לסרב להעניק גישה לאתר או לחלקים ממנו לכל משתמש, לפי שיקול דעתה הבלעדי וללא מתן התראה מוקדמת וללקוח לא תהיה כל טענה ו/או דרישה ו/או תביעה בעניין.<br _ngcontent-c7="">
					<br _ngcontent-c7="">
					<span _ngcontent-c7="" style="line-height:1.6">&nbsp;מבלי לגרוע מהאמור, החברה תהא רשאית למנוע לאלתר (ואף לחסום) ממשתמש לעשות שימוש באתר בכל אחד מהמקרים הבאים:</span></span></div>

					<div _ngcontent-c7="" style="margin-right: 80px;"><span _ngcontent-c7="" style="color:#000080">5.4.1&nbsp;&nbsp; &nbsp;המשתמש הפר תנאי מתנאי השימוש.&nbsp;</span></div>

					<div _ngcontent-c7="" style="margin-right: 80px;"><span _ngcontent-c7="" style="color:#000080">5.4.2&nbsp;&nbsp; &nbsp;המשתמש מסר בעת הרישום ו/או בעת השימוש באתר פרטים שגויים במתכוון.&nbsp;</span></div>

					<div _ngcontent-c7="" style="margin-right: 80px;"><span _ngcontent-c7="" style="color:#000080">5.4.3&nbsp;&nbsp; &nbsp;המשתמש ביצע מעשה או מחדל שיש בו כדי לפגוע בחברה ו/או בפעילות התקינה של האתר.&nbsp;</span></div>

					<div _ngcontent-c7="" style="margin-right: 40px;"><span _ngcontent-c7="" style="color:#000080">5.5&nbsp;&nbsp; &nbsp;מדיניות הגנת הפרטיות של החברה מפורטת בקישור הבא &nbsp;<u _ngcontent-c7=""><a _ngcontent-c7="" href="https://www.kvish6.co.il/itempics/PTUT.pdf" target="_blank">https://www.kvish6.co.il/itempics/PTUT.pdf</a></u>. בכל מקרה של סתירה בין האמור בתנאי אלה לבין מדיניות הגנת הפרטיות כאמור, יגבר האמור במדיניות הגנת הפרטיות.</span></div>
					<br _ngcontent-c7="">
					<span _ngcontent-c7="" style="color:#000080">6&nbsp;&nbsp; &nbsp;<strong _ngcontent-c7=""><u _ngcontent-c7="">הגבלת אחריות&nbsp;</u></strong></span>

					<div _ngcontent-c7="" style="margin-right: 40px;"><span _ngcontent-c7="" style="color:#000080">6.1&nbsp;&nbsp; &nbsp;האחריות על השימוש באתר והאחריות על תוצאות השימוש באתר הינה על הלקוח בלבד, והחברה ו/או מי מטעמה ו/או נושאי המשרה שלה לא יישאו בכל אחריות בגין הפסד ו/או נזק העלולים להיגרם, במישרין או בעקיפין, כתוצאה מהשימוש באתר ו/או אי השימוש בו. &nbsp;&nbsp;&nbsp; &nbsp;</span></div>

					<div _ngcontent-c7="" style="margin-right: 40px;"><span _ngcontent-c7="" style="color:#000080">6.2&nbsp;&nbsp; &nbsp;המידע המופיע באתר הינו נכון למועד הצגתו בלבד. בכל מקרה של סתירה או אי התאמה בין המידע המופיע באתר ובין המידע המופיע במערכות החברה, יגבר המידע המופיע במערכות החברה, והחברה ו/או מי מטעמה ו/או נושאי המשרה שלה לא יישאו בכל אחריות בגין הפסד ו/או נזק העלולים להיגרם, במישרין או בעקיפין, כתוצאה מסתירה כאמור.&nbsp;</span></div>

					<div _ngcontent-c7="" style="margin-right: 40px;"><span _ngcontent-c7="" style="color:#000080">6.3&nbsp;&nbsp; &nbsp;השירותים הניתנים באתר ניתנים כמות שהם (AS IS). לא תהיה ללקוח כל תביעה/תלונה/דרישה כלפי החברה בשל תכונות השירות, יכולותיו, מגבלותיו או התאמתו לצרכיו האישיים.&nbsp;</span></div>

					<div _ngcontent-c7="" style="margin-right: 40px;"><span _ngcontent-c7="" style="color:#000080">6.4&nbsp;&nbsp; &nbsp;ידוע ללקוח שתיתכן אפשרות שבמידע המופיע באתר נפלו שגיאות ו/או אי דיוקים וכיו"ב, טעויות אנוש, תקלות מחשב או טעויות סופר וכד' ו/או שינויים אשר נגרמו על ידי מי שאינו מורשה לעסוק בכך, למרות שהחברה עושה כל שביכולתה למנוע מצבים כאלה.&nbsp;</span></div>

					<div _ngcontent-c7="" style="margin-right: 40px;"><span _ngcontent-c7="" style="color:#000080">6.5&nbsp;&nbsp; &nbsp;טעות בהזנת הנתונים המתייחסים לתשלום ו/או לכל פרט אחר הינה באחריות הלקוח בלבד.&nbsp;</span></div>

					<div _ngcontent-c7="" style="margin-right: 40px;"><span _ngcontent-c7="" style="color:#000080">6.6&nbsp;&nbsp; &nbsp;מבלי לגרוע מכל האמור בכל מקום אחר בתנאים אלה, החברה ו/או מי מטעמה ו/או נושאי המשרה שלה לא יישאו בכל אחריות, מפורשת או משתמעת, בקשר עם האתר לרבות כל תוכן ושירות בו, ו/או בקשר להתאמתו ו/או למטרה ספציפית ו/או לדרישות הלקוח. &nbsp;כמו כן, החברה ו/או מי מטעמה ו/או נושאי המשרה שלה אינם אחראים לנזק אשר עשוי להיגרם ללקוח כתוצאה מתוכן האתר ו/או מהשירותים הניתנים בו ו/או כתוצאה מתקלה/פגם או אופן תפעול שגוי של התוכנה המפעילה את האתר ו/או את הגישה אליו, לרבות זמינות האתר. מבלי לגרוע מהאמור לעיל, הלקוח מאשר ומסכים כי החברה /ואו מי מטעמה ו/או נושאי המשרה שלה ו/או כל גוף או אדם הקשורים ו/או המעורבים ביצירת האתר או תוכנו יהיו פטורים מכל אחריות וחבות, בקשר לכל נזק, פגיעה הפסד או הוצאה, בין אם ישירים ובין אם עקיפים, הקשורים בשירותים ו/או בשימוש באתר או חוסר היכולת להשתמש באתר וכי כל אחריות וסיכון בקשר עם כל האמור יחול על הלקוח בלבד.</span></div>

					<div _ngcontent-c7="" style="margin-right: 40px;"><span _ngcontent-c7="" style="color:#000080">6.7&nbsp;&nbsp; &nbsp;באתר עשויים להיות גם לינקים (קישורים לאתרים אחרים אשר אינם מופעלים על ידי החברה). קישורים אלה אינם בשליטת ו/או אחריות החברה והיא אינה אחראית ו/או מפקחת על תוכנם. אין בקישורים אלה כדי להעיד על הסכמה ו/או אחריות של החברה לתכנים המופיעים שם ו/או לאמינותם ו/או עדכניותם ו/או תקינותם ו/או חוקיותם ו/או לכל מה שאמור ונכלל בהם, לרבות מדיניות הגנת פרטיות ו/או תנאי שימוש. החברה לא תהיה אחראית לכל תוצאה אשר תגרם כתוצאה משימוש באתרים אלה ו/או מהסתמכות עליהם. בכל בעיה וטענה יש לפנות ישירות לבעלי האתרים.&nbsp;</span></div>

					<div _ngcontent-c7="" style="margin-right: 40px;"><span _ngcontent-c7="" style="color:#000080">הלקוח מאשר כי ידוע לו כי התחזות לאדם ו/או לגוף אחר ו/או מסירת פרטים כוזבים ו/או שימוש בשם בדוי מהווים עבירה פלילית וכי נגד משתמשים כאמור יינקטו כל הצעדים הקבועים בדין, לרבות במקרה הצורך תביעה בגין כל הנזקים שנגרמו לחברה, אם נגרמו.&nbsp;</span></div>

					<div _ngcontent-c7="" style="margin-right: 40px;"><span _ngcontent-c7="" style="color:#000080">6.8&nbsp;&nbsp; &nbsp;אין בהגבלת האחריות בסעיף זה כדי לגרוע מהגבלת אחריות אחרת בתנאי השימוש ומדיניות הפרטיות.&nbsp;</span></div>
					<br _ngcontent-c7="">
					<span _ngcontent-c7="" style="color:#000080">7&nbsp;&nbsp; &nbsp;<strong _ngcontent-c7=""><u _ngcontent-c7="">שינויים באתר</u></strong>&nbsp;</span>

					<div _ngcontent-c7="" style="margin-right: 40px;"><span _ngcontent-c7="" style="color:#000080">7.1&nbsp;&nbsp; &nbsp;החברה שומרת לעצמה הזכות לשנות האתר מעת לעת, היקף וזמינות השירותים המוצעים בו וכן כל היבט אחר הכרוך בתפעולו, מבלי שתצטרך להודיע על כך מראש. שינויים שכאלה, יכול שייווצרו כתוצאה מאופיו המשתנה של האינטרנט וכן בשל שינויים טכנולוגיים המתבצעים ברשת. יובהר, כי שינויים אלה עשויים לגרום לתקלות או לאי נוחות, אך ללקוח לא תהא כל תביעה/תלונה/דרישה כלפי החברה עקב ביצועם.&nbsp;</span></div>

					<div _ngcontent-c7="" style="margin-right: 40px;"><span _ngcontent-c7="" style="color:#000080">7.2&nbsp;&nbsp; &nbsp;החברה תהא רשאית לערוך שינוי בתנאי השימוש באתר מבלי שתצטרך ליתן על כך הודעה מוקדמת. משכך, יש לעיין בתנאי השימוש בכל כניסה מחודשת לאתר, על מנת להתעדכן בהוראותיו.&nbsp;</span></div>
					<br _ngcontent-c7="">
					<span _ngcontent-c7="" style="color:#000080">8&nbsp;&nbsp; &nbsp;<u _ngcontent-c7=""><strong _ngcontent-c7="">תמיכה טכנית&nbsp;</strong></u></span>

					<div _ngcontent-c7="" style="margin-right: 40px;"><span _ngcontent-c7="" style="color:#000080">החברה אינה מתחייבת להעמיד לרשות הלקוח תמיכה טכנית אודות תפעולו של האתר ו/או שירותים המסופקים באמצעותו. הלקוח מאשר כי הוא לא יעלה כל תלונה כלפי החברה נוכח העדר תמיכה כאמור.&nbsp;</span></div>
					<br _ngcontent-c7="">
					<span _ngcontent-c7="" style="color:#000080">9&nbsp;&nbsp; &nbsp;<u _ngcontent-c7=""><strong _ngcontent-c7="">הפסקת שרות</strong></u>&nbsp;</span>

					<div _ngcontent-c7="" style="margin-right: 40px;"><span _ngcontent-c7="" style="color:#000080">החברה רשאית בכל עת להחליט כי היא מפסיקה את פעילותו של האתר או משנה את אופיו. הודעה בדבר סגירה/שינוי תפורסם 7 ימים טרם הביצוע.&nbsp;</span></div>
					<br _ngcontent-c7="">
					<span _ngcontent-c7="" style="color:#000080">10&nbsp;&nbsp; &nbsp;<u _ngcontent-c7=""><strong _ngcontent-c7="">הדין הנוהג וסמכות שיפוט</strong></u>&nbsp;</span>

					<div _ngcontent-c7="" style="margin-right: 40px;"><span _ngcontent-c7="" style="color:#000080">על השימוש באתר יחולו דיני מדינת ישראל, ולבתי המשפט במחוז תל אביב יפו תהא&nbsp;</span></div>

					<div _ngcontent-c7="" style="margin-right: 40px;"><span _ngcontent-c7="" style="color:#000080">הסמכות הבלעדית והיחידה בכל עניין הקשור בהם.&nbsp;</span></div>

            </div>

            <!---->
          </div>
        </div>
        <div _ngcontent-c7="" class="row rowSpacerSmall"></div>

        <div _ngcontent-c7="" class="row rowSpacerSmall">
          <div _ngcontent-c7="" class="col-xs-5 col-sm-3">
            <!---->
          </div>
          <div _ngcontent-c7="" class="col-xs-5 col-xs-offset-2 col-sm-3 col-sm-offset-6">
            <!----><button _ngcontent-c7="" class="btn btn-primary btn-block submit-btn">סגור
            </button>
            <!---->
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</sls-modal-legal-terms>
<sls-modal-confirm-error _ngcontent-c3="" _nghost-c8=""><div _ngcontent-c8="" aria-hidden="true" aria-labelledby="mySmallModalLabel" bsmodal="" class="modal fade modal-below-page-title" role="dialog" style="display: none;">
  <div _ngcontent-c8="" class="modal-dialog modal-md">
    <div _ngcontent-c8="" class="modal-content">
      <div _ngcontent-c8="" class="modal-header">
        <h2 _ngcontent-c8="" class="modal-title pull-right" style="font-size: 22px;" tabindex="0"></h2>
        <button _ngcontent-c8="" aria-label="סגור" class="modal-close-btn pull-left" type="button">
          <img _ngcontent-c8="" alt="" src="./a/modal-close-btn.svg">
        </button>
      </div>
      <div _ngcontent-c8="" class="modal-body">
        <div _ngcontent-c8="" class="row rowSpacerSmall row-eq-height">
          <div _ngcontent-c8="" class="col-xs-4 col-sm-2 vertical-align-content">
            <img _ngcontent-c8="" alt="" src="./a/notice.svg">
          </div>
          <div _ngcontent-c8="" class="col-xs-8 col-sm-10 vertical-align-content">
            <p _ngcontent-c8="" class="paragraph">לא ניתן להשלים את הפעולה, בדוק האם הזנת פרטים תקינים או הזן פרטי כרטיס אשראי אחר.</p>
          </div>
        </div>
        <div _ngcontent-c8="" class="row rowSpacerSmall"></div>
        <div _ngcontent-c8="" class="row rowSpacerSmall">
          <div _ngcontent-c8="" class="col-xs-5 col-xs-offset-7 col-sm-3 col-sm-offset-9">
            <button _ngcontent-c8="" class="btn btn-primary btn-block submit-btn">סגור</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</div></sls-modal-confirm-error>
<sls-modal-insert-id _ngcontent-c3="" _nghost-c9=""><div _ngcontent-c9="" aria-hidden="true" aria-labelledby="mySmallModalLabel" bsmodal="" class="modal fade modal-below-page-title" role="dialog" style="transform: translate(0px, 0px);">
  <div _ngcontent-c9="" class="modal-dialog modal-md">
    <div _ngcontent-c9="" class="modal-content">
      <div _ngcontent-c9="" class="modal-header ng-draggable">
        <h2 _ngcontent-c9="" class="modal-title pull-right" style="font-size: 22px;" tabindex="0"></h2>
        <button _ngcontent-c9="" aria-label="סגור" class="modal-close-btn pull-left" type="button">
          <img _ngcontent-c9="" alt="" src="./a/modal-close-btn.svg">
        </button>
      </div>

      <div _ngcontent-c9="" class="modal-body">
        <form _ngcontent-c9="" focusoninvalidcontrol="" novalidate="" class="ng-untouched ng-pristine ng-invalid">
          <div _ngcontent-c9="" class="row rowSpacerSmall">
            <div _ngcontent-c9="" class="col-xs-12 col-sm-8 col-sm-offset-2">
              <label _ngcontent-c9="" class="paragraph" for="userId"></label>
            </div>
          </div>
          <div _ngcontent-c9="" class="row rowSpacerSmall">
            <div _ngcontent-c9="" class="col-xs-12 col-sm-8 col-sm-offset-2">
              <div _ngcontent-c9="" class="form-group required form-group-lg">
                <input _ngcontent-c9="" aria-describedby="error-1" aria-required="true" class="form-control ng-untouched ng-pristine ng-invalid" formcontrolname="userIDCode" id="userId" slstrim="" type="text" aria-invalid="false">
              </div>
            </div>

            <div _ngcontent-c9="" class="col-xs-12 col-sm-8 col-sm-offset-2">
              <!---->
            </div>

            <div _ngcontent-c9="" class="col-xs-12 col-sm-8 col-sm-offset-2">
               <!---->
             </div>

              <!---->
          </div>

          <div _ngcontent-c9="" class="row rowSpacerSmall">
            <div _ngcontent-c9="" class="col-xs-5 col-sm-3">
              <button _ngcontent-c9="" class="btn btn-block cancel-btn" type="button">ביטול</button>
            </div>
            <div _ngcontent-c9="" class="col-xs-5 col-xs-offset-2 col-sm-3 col-sm-offset-6">
              <button _ngcontent-c9="" class="btn btn-primary btn-block submit-btn" type="submit">אישור</button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
</sls-modal-insert-id>
<sls-modal-sms-unauth _ngcontent-c3="" _nghost-c10=""><div _ngcontent-c10="" aria-hidden="true" aria-labelledby="mySmallModalLabel" bsmodal="" class="modal fade modal-below-page-title" role="dialog" style="overflow: hidden auto; transform: translate(0px, 0px);">
    <div _ngcontent-c10="" class="modal-dialog modal-md">
        <div _ngcontent-c10="" class="modal-content">
            <div _ngcontent-c10="" class="modal-header ng-draggable">
                <h2 _ngcontent-c10="" class="modal-title pull-right" style="font-size: 22px;" tabindex="0"></h2>
                <button _ngcontent-c10="" aria-label="סגור" class="modal-close-btn pull-left" type="button">
          <img _ngcontent-c10="" alt="" src="./a/modal-close-btn.svg">
        </button>
            </div>

            <div _ngcontent-c10="" class="modal-body">
                <form _ngcontent-c10="" focusoninvalidcontrol="" novalidate="" class="ng-untouched ng-pristine ng-invalid">
                    <div _ngcontent-c10="" class="row rowSpacerSmall">
                        <div _ngcontent-c10="" class="col-xs-12 col-sm-8 col-sm-offset-2">
                            <label _ngcontent-c10="" class="paragraph" for="smsCode" id="smsCodeLabel">
                                הכנס/י את קוד האישור שנשלח אליך בסמס
                                <br _ngcontent-c10="">
                                <strong _ngcontent-c10="">לטלפון נייד המסתיים בספרות </strong>
                            </label>
                        </div>
                    </div>
                    <div _ngcontent-c10="" class="row rowSpacerSmall">
                        <div _ngcontent-c10="" class="col-xs-12 col-sm-8 col-sm-offset-2">
                            <div _ngcontent-c10="" class="form-group required form-group-lg">
                                <input _ngcontent-c10="" aria-describedby="error-2" aria-labelledby="smsCodeLabel" aria-required="true" class="form-control ng-untouched ng-pristine ng-invalid" formcontrolname="userSMSCode" id="smsCode" type="tel" aria-invalid="false">
                            </div>
                        </div>
                        <div _ngcontent-c10="" class="col-xs-12 col-sm-8 col-sm-offset-2">
                            <!---->
                        </div>
                    </div>

                    <div _ngcontent-c10="" class="row rowSpacerSmall reset-padding">
                        <div _ngcontent-c10="" class="col-xs-12 col-sm-8 col-sm-offset-2">
                            <p _ngcontent-c10="" class="paragraph"></p>
                        </div>
                    </div>
                    <div _ngcontent-c10="" class="row rowSpacerSmall">
                        <div _ngcontent-c10="" class="col-xs-5 col-sm-3">
                            <button _ngcontent-c10="" class="btn btn-block cancel-btn" type="button">ביטול</button>
                        </div>
                        <div _ngcontent-c10="" class="col-xs-5 col-xs-offset-2 col-sm-3 col-sm-offset-6">
                            <button _ngcontent-c10="" class="btn btn-primary btn-block submit-btn" type="submit">אישור</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div></sls-modal-sms-unauth>
<sls-modal-download-multiple-invoices _ngcontent-c3="" _nghost-c11=""><div _ngcontent-c11="" aria-hidden="true" aria-labelledby="mySmallModalLabel" bsmodal="" class="modal fade modal-below-page-title" role="dialog">
  <div _ngcontent-c11="" class="modal-dialog modal-md">
    <div _ngcontent-c11="" class="modal-content">
      <div _ngcontent-c11="" class="modal-header">
        <h2 _ngcontent-c11="" class="modal-title pull-right" style="font-size: 22px;" tabindex="0"></h2>
        <button _ngcontent-c11="" aria-label="סגור" class="modal-close-btn pull-left" type="button">
          <img _ngcontent-c11="" alt="" src="./a/modal-close-btn.svg">
        </button>
      </div>

      <div _ngcontent-c11="" class="modal-body">
          <div _ngcontent-c11="" class="row rowSpacerSmall">
              <div _ngcontent-c11="" class="download-invoices-container">
                  <!---->
              </div>
          </div>
          <div _ngcontent-c11="" class="row rowSpacerSmall">
            <div _ngcontent-c11="" class="col-xs-5 col-xs-offset-7 col-sm-3 col-sm-offset-9">
              <button _ngcontent-c11="" class="btn btn-block cancel-btn" type="button">סגור</button>
            </div>
          </div>
      </div>
    </div>
  </div>
</div></sls-modal-download-multiple-invoices>
<sls-modal-invoice-legal-terms _ngcontent-c3="" _nghost-c12=""><div _ngcontent-c12="" aria-hidden="true" aria-labelledby="mySmallModalLabel" bsmodal="" class="modal fade info-modal" role="dialog">
  <div _ngcontent-c12="" class="modal-dialog modal-md">
    <div _ngcontent-c12="" class="modal-content">
      <div _ngcontent-c12="" class="modal-header">
        <div _ngcontent-c12="" aria-label="סגור" class="modal-info-header-icon pull-right">
          <img _ngcontent-c12="" alt="" src="./a/ico-helpScreen.svg">
        </div>
        <h2 _ngcontent-c12="" class="modal-title pull-right" style="font-size: 22px;" tabindex="0">תנאים משפטיים</h2>
        <button _ngcontent-c12="" aria-label="סגור" class="modal-close-btn pull-left" type="button">
          <img _ngcontent-c12="" alt="" src="./a/modal-close-btn.svg">
        </button>
      </div>

      <div _ngcontent-c12="" class="modal-body">
        <div _ngcontent-c12="" class="row rowSpacerSmall content-max-height modal-content-container">
          <div _ngcontent-c12="" class="col-xs-12 modal-content-container-box" tabindex="0">
			<!----><div _ngcontent-c12="">
				<div _ngcontent-c12="" style="text-align: center;"><br _ngcontent-c12="">
					<span _ngcontent-c12="" style="color:#000080"><span _ngcontent-c12="" style="font-size:14px"><u _ngcontent-c12=""><strong _ngcontent-c12="">תנאי שימוש אתר כביש 6&nbsp;</strong></u></span></span></div>
					<br _ngcontent-c12="">
					<span _ngcontent-c12="" style="color:#000080">הואיל ואני מעוניין להשתמש בשירותים אותם מספקת חברת דרך ארץ (להלן: "<strong _ngcontent-c12="">החברה</strong>" או "<strong _ngcontent-c12="">דרך ארץ</strong>") באמצעות האתר;&nbsp;<br _ngcontent-c12="">
					<br _ngcontent-c12="">
					<strong _ngcontent-c12="">לפיכך, אני מסכים, מצהיר ומתחייב כדלקמן:&nbsp;</strong><br _ngcontent-c12="">
					<br _ngcontent-c12="">
					1&nbsp;&nbsp; &nbsp;<u _ngcontent-c12=""><strong _ngcontent-c12="">מבוא&nbsp;</strong></u></span>

					<div _ngcontent-c12="" style="margin-right: 40px;"><span _ngcontent-c12="" style="color:#000080">1.1&nbsp;&nbsp; &nbsp;הרישא של תנאי השימוש מהווה חלק בלתי נפרד מהם.&nbsp;</span></div>

					<div _ngcontent-c12="" style="margin-right: 40px;"><span _ngcontent-c12="" style="color:#000080">1.2&nbsp;&nbsp; &nbsp;תנאי שימוש אלה נכתבו בלשון יחיד אך כמובן הם יחולו על &nbsp;הרבים ועל כל אישיות משפטית, לפי העניין.&nbsp;</span></div>

					<div _ngcontent-c12="" style="margin-right: 40px;"><span _ngcontent-c12="" style="color:#000080">1.3&nbsp;&nbsp; &nbsp;בתנאי שימוש אלה יהיו למונחים הבאים הפירושים המופיעים לצידם:&nbsp;</span></div>

					<div _ngcontent-c12="" style="margin-right: 80px;"><span _ngcontent-c12="" style="color:#000080">1.3.1&nbsp;&nbsp; &nbsp;"<strong _ngcontent-c12="">האתר</strong>" – אתר האינטרנט של חברת דרך ארץ.&nbsp;</span></div>

					<div _ngcontent-c12="" style="margin-right: 80px;"><span _ngcontent-c12="" style="color:#000080">1.3.2&nbsp;&nbsp; &nbsp;"<strong _ngcontent-c12="">הסכם שימוש</strong>" – הסכם הצטרפות מנוי לכביש 6 שנחתם בין החברה לבין הלקוח &nbsp;המנוי.&nbsp;</span></div>

					<div _ngcontent-c12="" style="margin-right: 80px;"><span _ngcontent-c12="" style="color:#000080">1.3.3&nbsp;&nbsp; &nbsp;"<strong _ngcontent-c12="">חוק כביש האגרה</strong>" – חוק כביש אגרה (כביש ארצי לישראל), התשנ"ה-1995 והתקנות שהוצאו מכוחו, כפי שאלה יתעדכנו מעת לעת.</span></div>

					<div _ngcontent-c12="" style="margin-right: 80px;"><span _ngcontent-c12="" style="color:#000080">1.3.4&nbsp;&nbsp; &nbsp;"<strong _ngcontent-c12="">חשבוניות</strong>" – חשבוניות/חשבונות כהגדרתם בחוק כביש האגרה הנשלחים מעת לעת ללקוחות בהתאם לחוק כביש האגרה ו/או בהתאם להסכם השימוש.&nbsp;</span></div>

					<div _ngcontent-c12="" style="margin-right: 80px;"><span _ngcontent-c12="" style="color:#000080">1.3.5&nbsp;&nbsp; &nbsp;"<strong _ngcontent-c12="">חשבון מנוי"/"חשבונות מנוי</strong>" – כלל החשבונות של הלקוח, דהיינו כל החשבונות בגינם הלקוח משלם עבור רכבים במנוי.&nbsp;</span></div>

					<div _ngcontent-c12="" style="margin-right: 80px;"><span _ngcontent-c12="" style="color:#000080">1.3.6&nbsp;&nbsp; &nbsp;"<strong _ngcontent-c12="">כביש 6</strong>" – כמשמעות המונח "כביש ארצי לישראל" בחוק כביש האגרה.&nbsp;</span></div>

					<div _ngcontent-c12="" style="margin-right: 80px;"><span _ngcontent-c12="" style="color:#000080">1.3.7&nbsp;&nbsp; &nbsp;"<strong _ngcontent-c12="">לקוח מנוי</strong>" או "<strong _ngcontent-c12="">מנוי</strong>" – לקוח רגיל כמשמעותו בחוק כביש האגרה, לקוח אשר התקשר עם החברה בהסכם השימוש.&nbsp;</span></div>

					<div _ngcontent-c12="" style="margin-right: 80px;"><span _ngcontent-c12="" style="color:#000080">1.3.8&nbsp;&nbsp; &nbsp;"<strong _ngcontent-c12="">לקוח מזדמ</strong>ן" – לקוח שאינו לקוח מנוי.</span></div>

					<div _ngcontent-c12="" style="margin-right: 80px;"><span _ngcontent-c12="" style="color:#000080">1.3.9&nbsp;&nbsp; &nbsp;"<strong _ngcontent-c12="">לקוח"/"משתמש</strong>" – לקוח מנוי ו/או לקוח מזדמן ו/או כל העושה שימוש באתר.&nbsp;</span></div>

					<div _ngcontent-c12="" style="margin-right: 80px;"><span _ngcontent-c12="" style="color:#000080">1.3.10&nbsp;&nbsp;"<strong _ngcontent-c12="">שירותים</strong>" – השירותים המפורטים בסעיף &rlm;3 להלן.&nbsp;</span></div>

					<div _ngcontent-c12="" style="margin-right: 80px;"><span _ngcontent-c12="" style="color:#000080">1.3.11&nbsp;&nbsp;"<strong _ngcontent-c12="">תנאי השימוש</strong>" – התנאים המפורטים במסמך זה.&nbsp;</span></div>
					<br _ngcontent-c12="">
					<span _ngcontent-c12="" style="color:#000080">2&nbsp;&nbsp; &nbsp;<u _ngcontent-c12=""><strong _ngcontent-c12="">השימוש באתר&nbsp;</strong></u></span>

					<div _ngcontent-c12="" style="margin-right: 40px;"><span _ngcontent-c12="" style="color:#000080">2.1&nbsp;&nbsp; &nbsp;הלקוח מתחייב שלא לבצע פעולה כלשהי אשר יש בה כדי להוות הפרה של תנאי השימוש ו/או הוראות הדין ו/או שיש בה כדי לגרוע מאיזו מזכויותיה של החברה ו/או של צד ג' כלשהו ו/או העלולה להזיק לאתר ו/או לרשתות התקשורת. חל איסור לעשות שימוש באתר למטרה בלתי חוקית או אסורה.</span></div>

					<div _ngcontent-c12="" style="margin-right: 40px;"><span _ngcontent-c12="" style="color:#000080">2.2&nbsp;&nbsp; &nbsp;הלקוח מאשר כי השימוש באתר מתאפשר בכפוף לתנאי השימוש ולשם ביצוע חלק מהפעולות הוא מתאפשר בכפוף לסעיף 3.3 להלן. פרטי הלקוח ישמרו על ידי החברה במאגרים ממוחשבים, בהתאם לכל דין.&nbsp;</span></div>

					<div _ngcontent-c12="" style="margin-right: 40px;"><span _ngcontent-c12="" style="color:#000080">2.3&nbsp;&nbsp; &nbsp;הפרטים הינם אישיים ואינם ניתנים להעברה. באם הועברו פרטי לקוח לידי צד ג', על הלקוח לפנות לעדכון החברה ללא שיהוי. בכל מקרה החברה לא תישא באחריות כתוצאה משימוש בפרטים אלה, מכל סיבה שהיא. המידע המוצג הינו לשימושו האישי של הלקוח, וחל איסור לעשות כל פעולה במידע, כולו או חלקו, שיש בה כדי לפגוע בזכויות הקניין של החברה ו/או מי מטעמה.&nbsp;</span></div>

					<div _ngcontent-c12="" style="margin-right: 40px;"><span _ngcontent-c12="" style="color:#000080">2.4&nbsp;&nbsp; &nbsp;הלקוח מתחייב שלא לנסות לקבל גישה ללא הרשאה לאתר, לשירותים, לתכנים, לחשבונות של אחרים או למערכות מחשבים או רשתות המחוברות לאתר באמצעות "פריצה" (Hacking), "כריית סיסמאות" (Password Mining) או בכל אמצעי אחר. כמו כן הלקוח מתחייב לא להשיג או לנסות להשיג שירותים או מידע כלשהם באמצעים שלא הועמדו לרשותו באופן מכוון על-ידי החברה.</span></div>

					<div _ngcontent-c12="" style="margin-right: 40px;"><span _ngcontent-c12="" style="color:#000080">2.5&nbsp;&nbsp; &nbsp;השימוש בחלק מהשירותים והצפייה בחלק מהתכנים מוגבלת למחשבים המצויים בישראל. לפיכך, אין לבצע כל פעולה שמטרתה לעקוף בדרך כלשהי מגבלה זו.</span></div>

					<div _ngcontent-c12="" style="margin-right: 40px;"><span _ngcontent-c12="" style="color:#000080">2.6&nbsp;&nbsp; &nbsp;הלקוח מתחייב לא להעלות לאתר או להעביר בכל דרך אחרת, כל וירוס, "תולעת" (worm), סוס טרויאני, רוגלה (spyware), נוזקה (malware), או כל קוד מחשב, קובץ או תוכנה אחרים אשר עשויים להזיק, או נועדו להזיק לפעילות האתר ו/או החברה.</span></div>

					<div _ngcontent-c12="" style="margin-right: 40px;"><span _ngcontent-c12="" style="color:#000080">2.7&nbsp;&nbsp; &nbsp;הלקוח מתחייב שלא להפעיל או לאפשר להפעיל כל יישום מחשב או כל אמצעי אחר, לרבות תוכנות מסוג Crawlers ,Robots וכדומה, לשם חיפוש, סריקה, העתקה או אחזור אוטומטי של מידע מתוך האתר. בכלל זה, אין ליצור ואין להשתמש באמצעים כאמור לשם יצירת לקט, אוסף או מאגר שיכילו מידע מהאתר.</span></div>

					<div _ngcontent-c12="" style="margin-right: 40px;"><span _ngcontent-c12="" style="color:#000080">2.8&nbsp;&nbsp; &nbsp;הלקוח מתחייב שלא להציג תכנים מהאתר בתוך מסגרת (Frame), גלויה או סמויה;</span></div>

					<div _ngcontent-c12="" style="margin-right: 40px;"><span _ngcontent-c12="" style="color:#000080">2.9&nbsp;&nbsp; &nbsp;הלקוח מתחייב שלא להציג תכנים מהאתר בכל דרך שהיא – ובכלל זה באמצעות כל תוכנה, מכשיר, אביזר או פרוטוקול תקשורת – המשנים את עיצובם באתר או מחסירים מהם תכנים כלשהם.</span></div>
					<br _ngcontent-c12="">
					<span _ngcontent-c12="" style="color:#000080">3&nbsp;&nbsp; &nbsp;<u _ngcontent-c12=""><strong _ngcontent-c12="">שירותים באתר ואישור לקוח&nbsp;</strong></u></span>

					<div _ngcontent-c12="" style="margin-right: 40px;"><span _ngcontent-c12="" style="color:#000080">3.1&nbsp;&nbsp; &nbsp;השירותים המסופקים באתר:&nbsp;</span></div>

					<div _ngcontent-c12="" style="margin-right: 80px;"><span _ngcontent-c12="" style="color:#000080">3.1.1&nbsp;&nbsp; &nbsp;האתר פורס בפני הלקוח את השירותים המסופקים על ידי החברה ותנאיהם, כפי שיתעדכנו מעת לעת, ובין היתר הצטרפות למנוי, קבלת מידע על חשבוניות (בין אם בחשבון המנוי ובין אם בחשבון המזדמן), לרבות פירוט הנסיעות בגין אותן החשבוניות, בגין תקופת זמן כפי שתקבע מעת לעת, על ידי דרך ארץ, מידע על חשבוניות שטרם נפרעו וכן אפשרות לתשלום חשבוניות, עדכון פרטים אישיים, עדכון אמצעי תשלום, הוספה והסרה של רכבים, הפקת דוחות ועוד.</span></div>

					<div _ngcontent-c12="" style="margin-right: 80px;"><span _ngcontent-c12="" style="color:#000080">3.1.2&nbsp;&nbsp; &nbsp;מידע על כביש 6, תעריפי נסיעה וכיו"ב.&nbsp;<br _ngcontent-c12="">
					<span _ngcontent-c12="" style="line-height:1.6">הלקוח מאשר כי מעת לעת יעודכנו השירותים הניתנים דרך האתר וכי ככל שהלקוח יקבל שירותים אלה, הוא מאשר כי, יחולו עליו תנאי השימוש דנן.&nbsp;</span></span></div>

					<div _ngcontent-c12="" style="margin-right: 40px;"><span _ngcontent-c12="" style="color:#000080">3.2&nbsp;&nbsp; &nbsp;הלקוח <strong _ngcontent-c12="">מאשר כי השימוש באתר מהווה הסכמה מצידו לקבלת כל השירותים הנ"ל בגין <u _ngcontent-c12="">כל </u>הרכבים תחת <u _ngcontent-c12="">כל </u>חשבונות המנוי והמזדמן הרשומים על שמו וכן כי ידוע לו שלא ניתן לבחור לקבל את השירותים רק בגין חלק מהחשבונות.</strong></span></div>

					<div _ngcontent-c12="" style="margin-right: 40px;"><span _ngcontent-c12="" style="color:#000080">3.3&nbsp;&nbsp; &nbsp;הלקוח מאשר, כי לצורך קבלת חלק מהשירותים הוא יתבקש להזדהות ו/או לעבור הליך אימות, באופן שיקבע מעת לעת על ידי החברה. הלקוח מאשר ומתחייב כי ככל שנמסר לו על ידי החברה שם משתמש ו/או סיסמה הוא יעשה בהם שימוש לצרכיו האישיים בלבד. כמו כן הלקוח מתחייב לנקוט בכל האמצעים לשמירת שם המשתמש והסיסמה.</span></div>

					<div _ngcontent-c12="" style="margin-right: 40px;"><span _ngcontent-c12="" style="color:#000080">3.4&nbsp;&nbsp; &nbsp;הלקוח מאשר כי החברה רשאית להשתמש בקוקיות (COOKIES) לצורך תפעולו השוטף והתקין של האתר ובכלל זה כדי לאסוף נתונים סטטיסטיים אודות השימוש באתר, לאימות פרטים, כדי להתאים את האתר להעדפות אישיות של המשתמש, לצרכי שיווק ולצרכי אבטחת מידע.&nbsp;</span></div>

					<div _ngcontent-c12="" style="margin-right: 40px;"><span _ngcontent-c12="" style="color:#000080">קוקיות משמשות גם כדי לייתר את הצורך בהזנת פרטי משתמש בכל פעם שהוא מבקר מחדש במדורים באתר המחייבים רישום ככל שישנם כאלה. קוקיות הן קבצי טקסט שהדפדפן במחשבו של המשתמש יוצר לפי פקודה ממחשבי החברה. חלק מהקוקיות יפקעו כאשר המשתמש יסגור את הדפדפן ואחרות נשמרות על גבי הכונן הקשיח במחשב שלו. המידע בקוקיות מוצפן והחברה נוקטת צעדי זהירות כדי להבטיח שרק מחשבי החברה יוכלו לקרוא ולהבין את המידע האגור בהם.</span></div>

					<div _ngcontent-c12="" style="margin-right: 40px;"><span _ngcontent-c12="" style="color:#000080">3.5&nbsp;&nbsp; &nbsp;הלקוח מאשר כי גם במקרה בו לא סיים את הליך ההצטרפות באתר – הפרטים אשר מסר בהליך ההצטרפות ישמשו את החברה כדי לבדוק מדוע לא סיים את ההליך כאמור.&nbsp;</span></div>
					<br _ngcontent-c12="">
					<span _ngcontent-c12="" style="color:#000080">4&nbsp;&nbsp; &nbsp;<strong _ngcontent-c12=""><u _ngcontent-c12="">קניין רוחני&nbsp;</u></strong></span>

					<div _ngcontent-c12="" style="margin-right: 40px;"><span _ngcontent-c12="" style="color:#000080">4.1&nbsp;&nbsp; &nbsp;כל המידע המצוי באתר ו/או הדפים המופיעים באתר הינו רכושה הבלעדי של החברה. לפיכך, חל איסור על העתקה או כל פעולה אחרת מבלי לקבל את אישור החברה לכך. יובהר, כי גם אם יינתן אישור שכזה, הרי שיהיה זה אישור לשימוש לצרכים אישיים בלבד ולא לצרכים מסחריים.&nbsp;</span></div>

					<div _ngcontent-c12="" style="margin-right: 40px;"><span _ngcontent-c12="" style="color:#000080">4.2&nbsp;&nbsp; &nbsp;הסימנים באתר הינם סימני מסחר המהווים קניינים של החברה. אין לעשות כל פעולה אשר יש בה כדי לפגוע בזכויות היוצרים או בזכויות קניין רוחני אחרות של החברה.&nbsp;</span></div>

					<div _ngcontent-c12="" style="margin-right: 40px;"><span _ngcontent-c12="" style="color:#000080">4.3&nbsp;&nbsp; &nbsp;חל איסור על שינוי, העתקה, הפצה, פרסום של מידע, שירות או תוכנה שמקורם באתר זה.&nbsp;</span></div>
					<br _ngcontent-c12="">
					<span _ngcontent-c12="" style="color:#000080">5&nbsp;&nbsp; &nbsp;<strong _ngcontent-c12=""><u _ngcontent-c12="">הגנת פרטיות, מידע ואבטחת מידע&nbsp;</u></strong></span>

					<div _ngcontent-c12="" style="margin-right: 40px;"><span _ngcontent-c12="" style="color:#000080">5.1&nbsp;&nbsp; &nbsp;החברה רשאית לאסוף נתונים אודות לקוח ופעולותיו ולעבדם בכל צורה שהיא. החברה תוכל לעשות שימוש בנתונים אלה לצורך שיפור השרות, טיפול בתלונות, למטרות סטטיסטיות שונות וכו'.&nbsp;</span></div>

					<div _ngcontent-c12="" style="margin-right: 40px;"><span _ngcontent-c12="" style="color:#000080">5.2&nbsp;&nbsp; &nbsp;החברה שומרת לעצמה הזכות לחשוף מידע אישי אודות לקוחותיה או אודות השימוש שלהם באתר כולל תוכן השימוש, ללא קבלת רשות מהלקוחות, אם החברה מאמינה בתום לב כי פעולה זו חיונית כדי: לציית לדרישות הדין או הליך משפטי; להגן על זכויות או על קניין של החברה; לאכוף את הסכם השימוש ו/או תנאי השימוש; להגן על האינטרסים של לקוחותיה או של אחרים.&nbsp;</span></div>

					<div _ngcontent-c12="" style="margin-right: 40px;"><span _ngcontent-c12="" style="color:#000080">5.3&nbsp;&nbsp; &nbsp;הלקוח מאשר כי ידוע לו כי השימוש באתר חשוף לסיכונים הכרוכים בשימוש ברשת האינטרנט לרבות וירוסים, סוסים טרויאניים וכד', ציתות, פריצה, התחזות והונאות מכוונות אחרות. החברה משקיעה מאמץ רב בהגנה מפני סיכונים אלה אך למרות זאת אין אפשרות להגנה מוחלטת. לפיכך, יתכנו נזקים כתוצאה מהתממשות הסיכונים, לרבות גילוי ו/או שיבוש המידע במערכות, שיבוש בהוראות/בקשות, פעולות לא מורשות, שיבושים בפעילות האתר לרבות אי ביצוע ו/או ביצוע שגוי ו/או ביצוע מאוחר של הוראה, חוסר זמינות של חלק משרותי האתר וכיוצ"ב.&nbsp;</span></div>

					<div _ngcontent-c12="" style="margin-right: 40px;"><span _ngcontent-c12="" style="color:#000080">5.4&nbsp;&nbsp; &nbsp;החברה שומרת לעצמה את הזכות לסרב להעניק גישה לאתר או לחלקים ממנו לכל משתמש, לפי שיקול דעתה הבלעדי וללא מתן התראה מוקדמת וללקוח לא תהיה כל טענה ו/או דרישה ו/או תביעה בעניין.<br _ngcontent-c12="">
					<br _ngcontent-c12="">
					<span _ngcontent-c12="" style="line-height:1.6">&nbsp;מבלי לגרוע מהאמור, החברה תהא רשאית למנוע לאלתר (ואף לחסום) ממשתמש לעשות שימוש באתר בכל אחד מהמקרים הבאים:</span></span></div>

					<div _ngcontent-c12="" style="margin-right: 80px;"><span _ngcontent-c12="" style="color:#000080">5.4.1&nbsp;&nbsp; &nbsp;המשתמש הפר תנאי מתנאי השימוש.&nbsp;</span></div>

					<div _ngcontent-c12="" style="margin-right: 80px;"><span _ngcontent-c12="" style="color:#000080">5.4.2&nbsp;&nbsp; &nbsp;המשתמש מסר בעת הרישום ו/או בעת השימוש באתר פרטים שגויים במתכוון.&nbsp;</span></div>

					<div _ngcontent-c12="" style="margin-right: 80px;"><span _ngcontent-c12="" style="color:#000080">5.4.3&nbsp;&nbsp; &nbsp;המשתמש ביצע מעשה או מחדל שיש בו כדי לפגוע בחברה ו/או בפעילות התקינה של האתר.&nbsp;</span></div>

					<div _ngcontent-c12="" style="margin-right: 40px;"><span _ngcontent-c12="" style="color:#000080">5.5&nbsp;&nbsp; &nbsp;מדיניות הגנת הפרטיות של החברה מפורטת בקישור הבא &nbsp;<u _ngcontent-c12=""><a _ngcontent-c12="" href="https://www.kvish6.co.il/itempics/PTUT.pdf" target="_blank">https://www.kvish6.co.il/itempics/PTUT.pdf</a></u>. בכל מקרה של סתירה בין האמור בתנאי אלה לבין מדיניות הגנת הפרטיות כאמור, יגבר האמור במדיניות הגנת הפרטיות.</span></div>
					<br _ngcontent-c12="">
					<span _ngcontent-c12="" style="color:#000080">6&nbsp;&nbsp; &nbsp;<strong _ngcontent-c12=""><u _ngcontent-c12="">הגבלת אחריות&nbsp;</u></strong></span>

					<div _ngcontent-c12="" style="margin-right: 40px;"><span _ngcontent-c12="" style="color:#000080">6.1&nbsp;&nbsp; &nbsp;האחריות על השימוש באתר והאחריות על תוצאות השימוש באתר הינה על הלקוח בלבד, והחברה ו/או מי מטעמה ו/או נושאי המשרה שלה לא יישאו בכל אחריות בגין הפסד ו/או נזק העלולים להיגרם, במישרין או בעקיפין, כתוצאה מהשימוש באתר ו/או אי השימוש בו. &nbsp;&nbsp;&nbsp; &nbsp;</span></div>

					<div _ngcontent-c12="" style="margin-right: 40px;"><span _ngcontent-c12="" style="color:#000080">6.2&nbsp;&nbsp; &nbsp;המידע המופיע באתר הינו נכון למועד הצגתו בלבד. בכל מקרה של סתירה או אי התאמה בין המידע המופיע באתר ובין המידע המופיע במערכות החברה, יגבר המידע המופיע במערכות החברה, והחברה ו/או מי מטעמה ו/או נושאי המשרה שלה לא יישאו בכל אחריות בגין הפסד ו/או נזק העלולים להיגרם, במישרין או בעקיפין, כתוצאה מסתירה כאמור.&nbsp;</span></div>

					<div _ngcontent-c12="" style="margin-right: 40px;"><span _ngcontent-c12="" style="color:#000080">6.3&nbsp;&nbsp; &nbsp;השירותים הניתנים באתר ניתנים כמות שהם (AS IS). לא תהיה ללקוח כל תביעה/תלונה/דרישה כלפי החברה בשל תכונות השירות, יכולותיו, מגבלותיו או התאמתו לצרכיו האישיים.&nbsp;</span></div>

					<div _ngcontent-c12="" style="margin-right: 40px;"><span _ngcontent-c12="" style="color:#000080">6.4&nbsp;&nbsp; &nbsp;ידוע ללקוח שתיתכן אפשרות שבמידע המופיע באתר נפלו שגיאות ו/או אי דיוקים וכיו"ב, טעויות אנוש, תקלות מחשב או טעויות סופר וכד' ו/או שינויים אשר נגרמו על ידי מי שאינו מורשה לעסוק בכך, למרות שהחברה עושה כל שביכולתה למנוע מצבים כאלה.&nbsp;</span></div>

					<div _ngcontent-c12="" style="margin-right: 40px;"><span _ngcontent-c12="" style="color:#000080">6.5&nbsp;&nbsp; &nbsp;טעות בהזנת הנתונים המתייחסים לתשלום ו/או לכל פרט אחר הינה באחריות הלקוח בלבד.&nbsp;</span></div>

					<div _ngcontent-c12="" style="margin-right: 40px;"><span _ngcontent-c12="" style="color:#000080">6.6&nbsp;&nbsp; &nbsp;מבלי לגרוע מכל האמור בכל מקום אחר בתנאים אלה, החברה ו/או מי מטעמה ו/או נושאי המשרה שלה לא יישאו בכל אחריות, מפורשת או משתמעת, בקשר עם האתר לרבות כל תוכן ושירות בו, ו/או בקשר להתאמתו ו/או למטרה ספציפית ו/או לדרישות הלקוח. &nbsp;כמו כן, החברה ו/או מי מטעמה ו/או נושאי המשרה שלה אינם אחראים לנזק אשר עשוי להיגרם ללקוח כתוצאה מתוכן האתר ו/או מהשירותים הניתנים בו ו/או כתוצאה מתקלה/פגם או אופן תפעול שגוי של התוכנה המפעילה את האתר ו/או את הגישה אליו, לרבות זמינות האתר. מבלי לגרוע מהאמור לעיל, הלקוח מאשר ומסכים כי החברה /ואו מי מטעמה ו/או נושאי המשרה שלה ו/או כל גוף או אדם הקשורים ו/או המעורבים ביצירת האתר או תוכנו יהיו פטורים מכל אחריות וחבות, בקשר לכל נזק, פגיעה הפסד או הוצאה, בין אם ישירים ובין אם עקיפים, הקשורים בשירותים ו/או בשימוש באתר או חוסר היכולת להשתמש באתר וכי כל אחריות וסיכון בקשר עם כל האמור יחול על הלקוח בלבד.</span></div>

					<div _ngcontent-c12="" style="margin-right: 40px;"><span _ngcontent-c12="" style="color:#000080">6.7&nbsp;&nbsp; &nbsp;באתר עשויים להיות גם לינקים (קישורים לאתרים אחרים אשר אינם מופעלים על ידי החברה). קישורים אלה אינם בשליטת ו/או אחריות החברה והיא אינה אחראית ו/או מפקחת על תוכנם. אין בקישורים אלה כדי להעיד על הסכמה ו/או אחריות של החברה לתכנים המופיעים שם ו/או לאמינותם ו/או עדכניותם ו/או תקינותם ו/או חוקיותם ו/או לכל מה שאמור ונכלל בהם, לרבות מדיניות הגנת פרטיות ו/או תנאי שימוש. החברה לא תהיה אחראית לכל תוצאה אשר תגרם כתוצאה משימוש באתרים אלה ו/או מהסתמכות עליהם. בכל בעיה וטענה יש לפנות ישירות לבעלי האתרים.&nbsp;</span></div>

					<div _ngcontent-c12="" style="margin-right: 40px;"><span _ngcontent-c12="" style="color:#000080">הלקוח מאשר כי ידוע לו כי התחזות לאדם ו/או לגוף אחר ו/או מסירת פרטים כוזבים ו/או שימוש בשם בדוי מהווים עבירה פלילית וכי נגד משתמשים כאמור יינקטו כל הצעדים הקבועים בדין, לרבות במקרה הצורך תביעה בגין כל הנזקים שנגרמו לחברה, אם נגרמו.&nbsp;</span></div>

					<div _ngcontent-c12="" style="margin-right: 40px;"><span _ngcontent-c12="" style="color:#000080">6.8&nbsp;&nbsp; &nbsp;אין בהגבלת האחריות בסעיף זה כדי לגרוע מהגבלת אחריות אחרת בתנאי השימוש ומדיניות הפרטיות.&nbsp;</span></div>
					<br _ngcontent-c12="">
					<span _ngcontent-c12="" style="color:#000080">7&nbsp;&nbsp; &nbsp;<strong _ngcontent-c12=""><u _ngcontent-c12="">שינויים באתר</u></strong>&nbsp;</span>

					<div _ngcontent-c12="" style="margin-right: 40px;"><span _ngcontent-c12="" style="color:#000080">7.1&nbsp;&nbsp; &nbsp;החברה שומרת לעצמה הזכות לשנות האתר מעת לעת, היקף וזמינות השירותים המוצעים בו וכן כל היבט אחר הכרוך בתפעולו, מבלי שתצטרך להודיע על כך מראש. שינויים שכאלה, יכול שייווצרו כתוצאה מאופיו המשתנה של האינטרנט וכן בשל שינויים טכנולוגיים המתבצעים ברשת. יובהר, כי שינויים אלה עשויים לגרום לתקלות או לאי נוחות, אך ללקוח לא תהא כל תביעה/תלונה/דרישה כלפי החברה עקב ביצועם.&nbsp;</span></div>

					<div _ngcontent-c12="" style="margin-right: 40px;"><span _ngcontent-c12="" style="color:#000080">7.2&nbsp;&nbsp; &nbsp;החברה תהא רשאית לערוך שינוי בתנאי השימוש באתר מבלי שתצטרך ליתן על כך הודעה מוקדמת. משכך, יש לעיין בתנאי השימוש בכל כניסה מחודשת לאתר, על מנת להתעדכן בהוראותיו.&nbsp;</span></div>
					<br _ngcontent-c12="">
					<span _ngcontent-c12="" style="color:#000080">8&nbsp;&nbsp; &nbsp;<u _ngcontent-c12=""><strong _ngcontent-c12="">תמיכה טכנית&nbsp;</strong></u></span>

					<div _ngcontent-c12="" style="margin-right: 40px;"><span _ngcontent-c12="" style="color:#000080">החברה אינה מתחייבת להעמיד לרשות הלקוח תמיכה טכנית אודות תפעולו של האתר ו/או שירותים המסופקים באמצעותו. הלקוח מאשר כי הוא לא יעלה כל תלונה כלפי החברה נוכח העדר תמיכה כאמור.&nbsp;</span></div>
					<br _ngcontent-c12="">
					<span _ngcontent-c12="" style="color:#000080">9&nbsp;&nbsp; &nbsp;<u _ngcontent-c12=""><strong _ngcontent-c12="">הפסקת שרות</strong></u>&nbsp;</span>

					<div _ngcontent-c12="" style="margin-right: 40px;"><span _ngcontent-c12="" style="color:#000080">החברה רשאית בכל עת להחליט כי היא מפסיקה את פעילותו של האתר או משנה את אופיו. הודעה בדבר סגירה/שינוי תפורסם 7 ימים טרם הביצוע.&nbsp;</span></div>
					<br _ngcontent-c12="">
					<span _ngcontent-c12="" style="color:#000080">10&nbsp;&nbsp; &nbsp;<u _ngcontent-c12=""><strong _ngcontent-c12="">הדין הנוהג וסמכות שיפוט</strong></u>&nbsp;</span>

					<div _ngcontent-c12="" style="margin-right: 40px;"><span _ngcontent-c12="" style="color:#000080">על השימוש באתר יחולו דיני מדינת ישראל, ולבתי המשפט במחוז תל אביב יפו תהא&nbsp;</span></div>

					<div _ngcontent-c12="" style="margin-right: 40px;"><span _ngcontent-c12="" style="color:#000080">הסמכות הבלעדית והיחידה בכל עניין הקשור בהם.&nbsp;</span></div>

			</div>

            <!---->
          </div>
        </div>
        <div _ngcontent-c12="" class="row rowSpacerSmall"></div>

        <div _ngcontent-c12="" class="row rowSpacerSmall">
          <div _ngcontent-c12="" class="col-xs-5 col-sm-3">
            <button _ngcontent-c12="" class="btn btn-block cancel-btn">ביטול
            </button>
          </div>
          <div _ngcontent-c12="" class="col-xs-5 col-xs-offset-2 col-sm-3 col-sm-offset-6">
            <button _ngcontent-c12="" class="btn btn-primary btn-block submit-btn">אשר
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</sls-modal-invoice-legal-terms>
<sls-modal-update-payment-confirm _ngcontent-c3="" _nghost-c13=""><div _ngcontent-c13="" aria-hidden="true" aria-labelledby="mySmallModalLabel" bsmodal="" class="modal fade modal-below-page-title" role="dialog" style="transform: translate(0px, 0px);">
  <div _ngcontent-c13="" class="modal-dialog modal-md">
    <div _ngcontent-c13="" class="modal-content">
      <div _ngcontent-c13="" class="modal-header ng-draggable">
        <h2 _ngcontent-c13="" class="modal-title pull-right" style="font-size: 22px;" tabindex="0"></h2>
        <button _ngcontent-c13="" aria-label="סגור" class="modal-close-btn pull-left" type="button">
          <img _ngcontent-c13="" alt="" src="./a/modal-close-btn.svg">
        </button>
      </div>

      <div _ngcontent-c13="" class="modal-body">
        <div _ngcontent-c13="" class="row rowSpacerSmall row-eq-height">
          <div _ngcontent-c13="" class="col-xs-9 col-sm-10 vertical-align-content">
            <p _ngcontent-c13="" class="paragraph"></p>
          </div>
          <div _ngcontent-c13="" class="col-xs-3 col-sm-2 vertical-align-content">
            <img _ngcontent-c13="" alt="" class="modal-notice-icon" src="./a/notice.png">
          </div>
        </div>

          <div _ngcontent-c13="" class="row rowSpacerSmall">
            <div _ngcontent-c13="" class="col-xs-5 col-sm-3">
              <button _ngcontent-c13="" class="btn btn-block cancel-btn" type="button">ביטול</button>
            </div>
            <div _ngcontent-c13="" class="col-xs-5 col-xs-offset-2 col-sm-3 col-sm-offset-6">
              <button _ngcontent-c13="" class="btn btn-primary btn-block submit-btn" type="button">אישור</button>
            </div>
          </div>
      </div>
    </div>
  </div>
</div></sls-modal-update-payment-confirm>
<sls-modal-update-payment-confirm-debt _ngcontent-c3="" _nghost-c14=""><div _ngcontent-c14="" aria-hidden="true" aria-labelledby="mySmallModalLabel" bsmodal="" class="modal fade modal-below-page-title" role="dialog">
  <div _ngcontent-c14="" class="modal-dialog modal-md">
    <div _ngcontent-c14="" class="modal-content">
      <div _ngcontent-c14="" class="modal-header">
        <h2 _ngcontent-c14="" class="modal-title pull-right" style="font-size: 22px;" tabindex="0"></h2>
        <button _ngcontent-c14="" aria-label="סגור" class="modal-close-btn pull-left" type="button">
          <img _ngcontent-c14="" alt="" src="./a/modal-close-btn.svg">
        </button>
      </div>

      <div _ngcontent-c14="" class="modal-body">
        <div _ngcontent-c14="" class="row side-hint-container">
          <img _ngcontent-c14="" class="credit-card" src="./a/side-creditcard.png">

          <div _ngcontent-c14="" class="col-xs-12">
            <p _ngcontent-c14="" class="paragraph  ok-message"></p>
          </div>
        </div>

        <div _ngcontent-c14="" class="row rowSpacerSmall row-eq-height">
          <div _ngcontent-c14="" class="col-xs-9 col-sm-10 vertical-align-content">
            <p _ngcontent-c14="" class="paragraph"></p>
          </div>
          <div _ngcontent-c14="" class="col-xs-3 col-sm-2 vertical-align-content">
            <img _ngcontent-c14="" alt="" class="modal-notice-icon" src="./a/notice.png">
          </div>
        </div>

          <div _ngcontent-c14="" class="row rowSpacerSmall">
            <div _ngcontent-c14="" class="col-xs-6 col-sm-4">
              <button _ngcontent-c14="" class="btn btn-block cancel-btn" type="button">סיום ללא תשלום</button>
            </div>
            <div _ngcontent-c14="" class="col-xs-6 col-sm-4 col-sm-offset-4">
              <button _ngcontent-c14="" class="btn btn-primary btn-block submit-btn" type="button">מעבר לתשלום</button>
            </div>
          </div>
      </div>
    </div>
  </div>
</div></sls-modal-update-payment-confirm-debt>
<sls-modal-customer-area-warning-add _ngcontent-c3="" _nghost-c15=""><div _ngcontent-c15="" aria-hidden="true" aria-labelledby="mySmallModalLabel" bsmodal="" class="modal fade modal-below-page-title" role="dialog">
  <div _ngcontent-c15="" class="modal-dialog modal-md">
    <div _ngcontent-c15="" class="modal-content">
      <div _ngcontent-c15="" class="modal-header">
        <h2 _ngcontent-c15="" class="modal-title pull-right" style="font-size: 22px;" tabindex="0">הוסף רכב למנוי</h2>
        <button _ngcontent-c15="" aria-label="סגור" class="modal-close-btn pull-left" type="button">
          <img _ngcontent-c15="" alt="" src="./a/modal-close-btn.svg">
        </button>
      </div>
      <div _ngcontent-c15="" class="modal-body">
        <div _ngcontent-c15="" class="row rowSpacerSmall row-eq-height">
          <div _ngcontent-c15="" class="col-xs-4 col-sm-2 vertical-align-content">
            <img _ngcontent-c15="" alt="" src="./a/notice.svg">
          </div>
          <div _ngcontent-c15="" class="col-xs-8 col-sm-10 vertical-align-content">
            <!----><p _ngcontent-c15="" class="paragraph">
              רכב מס’  יתווסף ל 
            </p>

            <!---->
          </div>
        </div>
        <div _ngcontent-c15="" class="row rowSpacerSmall"></div>
        <div _ngcontent-c15="" class="row rowSpacerSmall">
            <div _ngcontent-c15="" class="col-xs-5 col-sm-3"><button _ngcontent-c15="" class="btn btn-block cancel-btn">ביטול</button></div>
            <div _ngcontent-c15="" class="col-xs-5 col-xs-offset-2 col-sm-3 col-sm-offset-6">
              <button _ngcontent-c15="" class="btn btn-primary btn-block submit-btn">הוסף רכב</button>
            </div>
        </div>
      </div>
    </div>
  </div>
</div>
</sls-modal-customer-area-warning-add>
<sls-modal-customer-area-warning-replace _ngcontent-c3="" _nghost-c16=""><div _ngcontent-c16="" aria-hidden="true" aria-labelledby="mySmallModalLabel" bsmodal="" class="modal fade modal-below-page-title" role="dialog">
  <div _ngcontent-c16="" class="modal-dialog modal-md">
    <div _ngcontent-c16="" class="modal-content">
      <div _ngcontent-c16="" class="modal-header">
        <h2 _ngcontent-c16="" class="modal-title pull-right" style="font-size: 22px;" tabindex="0">הסרת רכב ממנוי</h2>
        <button _ngcontent-c16="" aria-label="סגור" class="modal-close-btn pull-left" type="button">
          <img _ngcontent-c16="" alt="" src="./a/modal-close-btn.svg">
        </button>
      </div>
      <div _ngcontent-c16="" class="modal-body">
        <div _ngcontent-c16="" class="row rowSpacerSmall row-eq-height">
          <div _ngcontent-c16="" class="col-xs-4 col-sm-2  vertical-align-content">
            <img _ngcontent-c16="" alt="" src="./a/notice.svg">
          </div>
          <div _ngcontent-c16="" class="col-xs-8 col-sm-6  vertical-align-content">
            <p _ngcontent-c16="" class="paragraph">רכב מס’  יוסר מהמנוי</p>
          </div>
        </div>
        <div _ngcontent-c16="" class="row rowSpacerSmall"></div>
        <div _ngcontent-c16="" class="row rowSpacerSmall">
            <div _ngcontent-c16="" class="col-xs-5 col-sm-3"><button _ngcontent-c16="" class="btn btn-block cancel-btn">ביטול</button></div>
            <div _ngcontent-c16="" class="col-xs-5 col-xs-offset-2 col-sm-3 col-sm-offset-6">
              <button _ngcontent-c16="" class="btn btn-primary btn-block submit-btn">הסר רכב</button>
            </div>
        </div>
      </div>
    </div>
  </div>
</div>
</sls-modal-customer-area-warning-replace>
<sls-modal-customer-area-before-confirm _ngcontent-c3="" _nghost-c17=""><div _ngcontent-c17="" aria-hidden="true" aria-labelledby="mySmallModalLabel" bsmodal="" class="modal fade modal-below-page-title" role="dialog">
  <div _ngcontent-c17="" class="modal-dialog modal-md">
    <div _ngcontent-c17="" class="modal-content">
      <div _ngcontent-c17="" class="modal-header">
        <h2 _ngcontent-c17="" class="modal-title pull-right" style="font-size: 22px;" tabindex="0">החלפת רכב</h2>
        <button _ngcontent-c17="" aria-label="סגור" class="modal-close-btn pull-left" type="button">
          <img _ngcontent-c17="" alt="" src="./a/modal-close-btn.svg">
        </button>
      </div>
      <div _ngcontent-c17="" class="modal-body">
        <div _ngcontent-c17="" class="row">
          <div _ngcontent-c17="" class="col-xs-12">
            <p _ngcontent-c17="" class="paragraph">ב  בבעלותך </p>
          </div>
        </div>
        <div _ngcontent-c17="" class="row rowSpacerSmall">
            <div _ngcontent-c17="" class="col-xs-12 col-sm-8 col-sm-offset-2">
              <div _ngcontent-c17="" class="row">
                <div _ngcontent-c17="" class="col-xs-3">               
                    <!---->
                    <!---->
                </div>
                <div _ngcontent-c17="" class="col-xs-2"><span _ngcontent-c17="" class="vehicle-replace-text">יצורף</span></div>
                <div _ngcontent-c17="" class="col-xs-7 text-left"><span _ngcontent-c17="" class="vehicle-replace-number"></span></div>
              </div>
            </div>
          <div _ngcontent-c17="" class="col-xs-12 col-sm-8 col-sm-offset-2">
            <div _ngcontent-c17="" class="row">
              <div _ngcontent-c17="" class="col-xs-3">
                    <!---->
                    <!---->
              </div>
              <div _ngcontent-c17="" class="col-xs-2"><span _ngcontent-c17="" class="vehicle-replaced-text">יוסר</span></div>
              <div _ngcontent-c17="" class="col-xs-7 text-left"><span _ngcontent-c17="" class="vehicle-replaced-number"></span></div>
            </div>
          </div>
        </div>
        <div _ngcontent-c17="" class="row rowSpacerSmall"></div>
        <div _ngcontent-c17="" class="row rowSpacerSmall">
          <div _ngcontent-c17="" class="col-xs-5 col-sm-3"><button _ngcontent-c17="" class="btn btn-block cancel-btn">ביטול</button></div>
          <div _ngcontent-c17="" class="col-xs-5 col-xs-offset-2 col-sm-3 col-sm-offset-6"><button _ngcontent-c17="" class="btn btn-primary btn-block submit-btn">אישור</button></div>
        </div>
      </div>
    </div>
  </div>
</div>
</sls-modal-customer-area-before-confirm>
<sls-modal-customer-area-otp _ngcontent-c3="" _nghost-c18=""><div _ngcontent-c18="" aria-hidden="true" aria-labelledby="mySmallModalLabel" bsmodal="" class="modal fade modal-below-page-title" role="dialog" style="overflow: hidden auto; transform: translate(0px, 0px);">
    <div _ngcontent-c18="" class="modal-dialog modal-md">
        <div _ngcontent-c18="" class="modal-content">
            <div _ngcontent-c18="" class="modal-header ng-draggable">
                <h2 _ngcontent-c18="" class="modal-title pull-right" style="font-size: 22px;" tabindex="0"></h2>
                <button _ngcontent-c18="" aria-label="סגור" class="modal-close-btn pull-left" type="button">
          <img _ngcontent-c18="" alt="" src="./a/modal-close-btn.svg">
        </button>
            </div>

            <div _ngcontent-c18="" class="modal-body">
                <form _ngcontent-c18="" focusoninvalidcontrol="" novalidate="" class="ng-untouched ng-pristine ng-invalid">
                    <div _ngcontent-c18="" class="row rowSpacerSmall">
                        <div _ngcontent-c18="" class="col-xs-12 col-sm-8 col-sm-offset-2">
                            <label _ngcontent-c18="" class="paragraph" for="smsCode" id="smsCodeLabel">
                                הכנס/י את קוד האישור שנשלח אליך בסמס
                                <br _ngcontent-c18="">
                                <strong _ngcontent-c18="">לטלפון נייד המסתיים בספרות </strong>
                            </label>
                        </div>
                    </div>
                    <div _ngcontent-c18="" class="row rowSpacerSmall">
                        <div _ngcontent-c18="" class="col-xs-12 col-sm-8 col-sm-offset-2">
                            <div _ngcontent-c18="" class="form-group required form-group-lg">
                                <input _ngcontent-c18="" aria-describedby="error-2" aria-labelledby="smsCodeLabel" aria-required="true" class="form-control ng-untouched ng-pristine ng-invalid" formcontrolname="userSMSCode" id="smsCode" maxlength="6" type="tel" aria-invalid="false">
                            </div>
                        </div>
                        <div _ngcontent-c18="" class="col-xs-12 col-sm-8 col-sm-offset-2">
                            <!---->
                        </div>
                    </div>

                    <div _ngcontent-c18="" class="row rowSpacerSmall reset-padding">
                        <div _ngcontent-c18="" class="col-xs-12 col-sm-8 col-sm-offset-2">
                            <p _ngcontent-c18="" class="paragraph"></p>
                        </div>
                    </div>
                    <div _ngcontent-c18="" class="row rowSpacerSmall">
                        <div _ngcontent-c18="" class="col-xs-5 col-sm-3">
                            <button _ngcontent-c18="" class="btn btn-block cancel-btn" type="button">ביטול</button>
                        </div>
                        <div _ngcontent-c18="" class="col-xs-5 col-xs-offset-2 col-sm-3 col-sm-offset-6">
                            <button _ngcontent-c18="" class="btn btn-primary btn-block submit-btn" type="submit">אישור</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div></sls-modal-customer-area-otp>
<sls-modal-customer-area-renewed _ngcontent-c3="" _nghost-c19=""><div _ngcontent-c19="" aria-hidden="true" aria-labelledby="mySmallModalLabel" bsmodal="" class="modal fade modal-below-page-title modal-customer-area-renewed" role="dialog" style="overflow-x: hidden; overflow-y: auto;">
    <div _ngcontent-c19="" class="modal-dialog modal-md">
        <div _ngcontent-c19="" class="modal-content">
            <div _ngcontent-c19="" class="modal-body">
                <div _ngcontent-c19="" class="modal-wrapper">
                    <!----><img _ngcontent-c19="" class="brand-logo" src="./a/kvish6_logo.png">
                    <!---->
                    
                    <p _ngcontent-c19=""><span _ngcontent-c19="">התחדשנו באיזור האישי</span><!----> במיוחד בשבילך</p>
                    
                    <button _ngcontent-c19="" class="btn-redirect" type="button">עבור לחידוש סיסמה</button>
                    <button _ngcontent-c19="" class="btn-abort" type="button">ביטול</button>
                </div>
            </div>
        </div>
    </div>
</div></sls-modal-customer-area-renewed>
<sls-modal-customer-area-forgot-password-success _ngcontent-c3="" _nghost-c20=""><div _ngcontent-c20="" aria-hidden="true" aria-labelledby="mySmallModalLabel" bsmodal="" class="modal fade modal-below-page-title modal-customer-area-forgot-password-success" role="dialog" style="overflow-x: hidden; overflow-y: auto;">
    <div _ngcontent-c20="" class="modal-dialog modal-md">
        <div _ngcontent-c20="" class="modal-content">
            <div _ngcontent-c20="" class="modal-header">
                <h2 _ngcontent-c20="" class="modal-title pull-right" style="font-size: 22px;" tabindex="0"></h2>
                <button _ngcontent-c20="" aria-label="סגור" class="modal-close-btn pull-left" type="button">
          <img _ngcontent-c20="" alt="" src="./a/modal-close-btn.svg">
        </button>
            </div>

            <div _ngcontent-c20="" class="modal-body">
                    <div _ngcontent-c20="" class="row rowSpacerSmall row-eq-height">
                        <div _ngcontent-c20="" class="col-xs-4 col-sm-2 vertical-align-content">
                            <img _ngcontent-c20="" alt="" class="modal-notice-icon" src="./a/check.svg">
                        </div>
                        <div _ngcontent-c20="" class="col-xs-8 col-sm-10 vertical-align-content">
                            <p _ngcontent-c20="" class="paragraph"></p>
                        </div>
                    </div>

                    <div _ngcontent-c20="" class="row rowSpacerSmall">
                    <div _ngcontent-c20="" class="col-xs-12 col-sm-3 col-sm-offset-9">
                        <button _ngcontent-c20="" class="btn btn-primary btn-block submit-btn" type="button">אישור</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div></sls-modal-customer-area-forgot-password-success>
<sls-modal-customer-area-legal-terms _ngcontent-c3="" _nghost-c21=""><div _ngcontent-c21="" aria-hidden="true" aria-labelledby="mySmallModalLabel" bsmodal="" class="modal fade info-modal" role="dialog">
  <div _ngcontent-c21="" class="modal-dialog modal-md">
    <div _ngcontent-c21="" class="modal-content">
      <div _ngcontent-c21="" class="modal-header">
        <div _ngcontent-c21="" aria-label="סגור" class="modal-info-header-icon pull-right">
          <img _ngcontent-c21="" alt="" src="./a/ico-helpScreen.svg">
        </div>
        <h2 _ngcontent-c21="" class="modal-title pull-right" style="font-size: 22px;" tabindex="0">תנאים משפטיים</h2>
        <button _ngcontent-c21="" aria-label="סגור" class="modal-close-btn pull-left" type="button">
          <img _ngcontent-c21="" alt="" src="./a/modal-close-btn.svg">
        </button>
      </div>

      <div _ngcontent-c21="" class="modal-body">
        <div _ngcontent-c21="" class="row rowSpacerSmall content-max-height modal-content-container">
          <div _ngcontent-c21="" class="col-xs-12 modal-content-container-box" tabindex="0">
        	<!----><div _ngcontent-c21="">
					<div _ngcontent-c21="" style="text-align: center;"><br _ngcontent-c21="">
						<span _ngcontent-c21="" style="color:#000080"><span _ngcontent-c21="" style="font-size:14px"><u _ngcontent-c21=""><strong _ngcontent-c21="">תנאי שימוש אתר כביש 6&nbsp;</strong></u></span></span></div>
						<br _ngcontent-c21="">
						<span _ngcontent-c21="" style="color:#000080">הואיל ואני מעוניין להשתמש בשירותים אותם מספקת חברת דרך ארץ (להלן: "<strong _ngcontent-c21="">החברה</strong>" או "<strong _ngcontent-c21="">דרך ארץ</strong>") באמצעות האתר;&nbsp;<br _ngcontent-c21="">
						<br _ngcontent-c21="">
						<strong _ngcontent-c21="">לפיכך, אני מסכים, מצהיר ומתחייב כדלקמן:&nbsp;</strong><br _ngcontent-c21="">
						<br _ngcontent-c21="">
						1&nbsp;&nbsp; &nbsp;<u _ngcontent-c21=""><strong _ngcontent-c21="">מבוא&nbsp;</strong></u></span>

						<div _ngcontent-c21="" style="margin-right: 40px;"><span _ngcontent-c21="" style="color:#000080">1.1&nbsp;&nbsp; &nbsp;הרישא של תנאי השימוש מהווה חלק בלתי נפרד מהם.&nbsp;</span></div>

						<div _ngcontent-c21="" style="margin-right: 40px;"><span _ngcontent-c21="" style="color:#000080">1.2&nbsp;&nbsp; &nbsp;תנאי שימוש אלה נכתבו בלשון יחיד אך כמובן הם יחולו על &nbsp;הרבים ועל כל אישיות משפטית, לפי העניין.&nbsp;</span></div>

						<div _ngcontent-c21="" style="margin-right: 40px;"><span _ngcontent-c21="" style="color:#000080">1.3&nbsp;&nbsp; &nbsp;בתנאי שימוש אלה יהיו למונחים הבאים הפירושים המופיעים לצידם:&nbsp;</span></div>

						<div _ngcontent-c21="" style="margin-right: 80px;"><span _ngcontent-c21="" style="color:#000080">1.3.1&nbsp;&nbsp; &nbsp;"<strong _ngcontent-c21="">האתר</strong>" – אתר האינטרנט של חברת דרך ארץ.&nbsp;</span></div>

						<div _ngcontent-c21="" style="margin-right: 80px;"><span _ngcontent-c21="" style="color:#000080">1.3.2&nbsp;&nbsp; &nbsp;"<strong _ngcontent-c21="">הסכם שימוש</strong>" – הסכם הצטרפות מנוי לכביש 6 שנחתם בין החברה לבין הלקוח &nbsp;המנוי.&nbsp;</span></div>

						<div _ngcontent-c21="" style="margin-right: 80px;"><span _ngcontent-c21="" style="color:#000080">1.3.3&nbsp;&nbsp; &nbsp;"<strong _ngcontent-c21="">חוק כביש האגרה</strong>" – חוק כביש אגרה (כביש ארצי לישראל), התשנ"ה-1995 והתקנות שהוצאו מכוחו, כפי שאלה יתעדכנו מעת לעת.</span></div>

						<div _ngcontent-c21="" style="margin-right: 80px;"><span _ngcontent-c21="" style="color:#000080">1.3.4&nbsp;&nbsp; &nbsp;"<strong _ngcontent-c21="">חשבוניות</strong>" – חשבוניות/חשבונות כהגדרתם בחוק כביש האגרה הנשלחים מעת לעת ללקוחות בהתאם לחוק כביש האגרה ו/או בהתאם להסכם השימוש.&nbsp;</span></div>

						<div _ngcontent-c21="" style="margin-right: 80px;"><span _ngcontent-c21="" style="color:#000080">1.3.5&nbsp;&nbsp; &nbsp;"<strong _ngcontent-c21="">חשבון מנוי"/"חשבונות מנוי</strong>" – כלל החשבונות של הלקוח, דהיינו כל החשבונות בגינם הלקוח משלם עבור רכבים במנוי.&nbsp;</span></div>

						<div _ngcontent-c21="" style="margin-right: 80px;"><span _ngcontent-c21="" style="color:#000080">1.3.6&nbsp;&nbsp; &nbsp;"<strong _ngcontent-c21="">כביש 6</strong>" – כמשמעות המונח "כביש ארצי לישראל" בחוק כביש האגרה.&nbsp;</span></div>

						<div _ngcontent-c21="" style="margin-right: 80px;"><span _ngcontent-c21="" style="color:#000080">1.3.7&nbsp;&nbsp; &nbsp;"<strong _ngcontent-c21="">לקוח מנוי</strong>" או "<strong _ngcontent-c21="">מנוי</strong>" – לקוח רגיל כמשמעותו בחוק כביש האגרה, לקוח אשר התקשר עם החברה בהסכם השימוש.&nbsp;</span></div>

						<div _ngcontent-c21="" style="margin-right: 80px;"><span _ngcontent-c21="" style="color:#000080">1.3.8&nbsp;&nbsp; &nbsp;"<strong _ngcontent-c21="">לקוח מזדמ</strong>ן" – לקוח שאינו לקוח מנוי.</span></div>

						<div _ngcontent-c21="" style="margin-right: 80px;"><span _ngcontent-c21="" style="color:#000080">1.3.9&nbsp;&nbsp; &nbsp;"<strong _ngcontent-c21="">לקוח"/"משתמש</strong>" – לקוח מנוי ו/או לקוח מזדמן ו/או כל העושה שימוש באתר.&nbsp;</span></div>

						<div _ngcontent-c21="" style="margin-right: 80px;"><span _ngcontent-c21="" style="color:#000080">1.3.10&nbsp;&nbsp;"<strong _ngcontent-c21="">שירותים</strong>" – השירותים המפורטים בסעיף &rlm;3 להלן.&nbsp;</span></div>

						<div _ngcontent-c21="" style="margin-right: 80px;"><span _ngcontent-c21="" style="color:#000080">1.3.11&nbsp;&nbsp;"<strong _ngcontent-c21="">תנאי השימוש</strong>" – התנאים המפורטים במסמך זה.&nbsp;</span></div>
						<br _ngcontent-c21="">
						<span _ngcontent-c21="" style="color:#000080">2&nbsp;&nbsp; &nbsp;<u _ngcontent-c21=""><strong _ngcontent-c21="">השימוש באתר&nbsp;</strong></u></span>

						<div _ngcontent-c21="" style="margin-right: 40px;"><span _ngcontent-c21="" style="color:#000080">2.1&nbsp;&nbsp; &nbsp;הלקוח מתחייב שלא לבצע פעולה כלשהי אשר יש בה כדי להוות הפרה של תנאי השימוש ו/או הוראות הדין ו/או שיש בה כדי לגרוע מאיזו מזכויותיה של החברה ו/או של צד ג' כלשהו ו/או העלולה להזיק לאתר ו/או לרשתות התקשורת. חל איסור לעשות שימוש באתר למטרה בלתי חוקית או אסורה.</span></div>

						<div _ngcontent-c21="" style="margin-right: 40px;"><span _ngcontent-c21="" style="color:#000080">2.2&nbsp;&nbsp; &nbsp;הלקוח מאשר כי השימוש באתר מתאפשר בכפוף לתנאי השימוש ולשם ביצוע חלק מהפעולות הוא מתאפשר בכפוף לסעיף 3.3 להלן. פרטי הלקוח ישמרו על ידי החברה במאגרים ממוחשבים, בהתאם לכל דין.&nbsp;</span></div>

						<div _ngcontent-c21="" style="margin-right: 40px;"><span _ngcontent-c21="" style="color:#000080">2.3&nbsp;&nbsp; &nbsp;הפרטים הינם אישיים ואינם ניתנים להעברה. באם הועברו פרטי לקוח לידי צד ג', על הלקוח לפנות לעדכון החברה ללא שיהוי. בכל מקרה החברה לא תישא באחריות כתוצאה משימוש בפרטים אלה, מכל סיבה שהיא. המידע המוצג הינו לשימושו האישי של הלקוח, וחל איסור לעשות כל פעולה במידע, כולו או חלקו, שיש בה כדי לפגוע בזכויות הקניין של החברה ו/או מי מטעמה.&nbsp;</span></div>

						<div _ngcontent-c21="" style="margin-right: 40px;"><span _ngcontent-c21="" style="color:#000080">2.4&nbsp;&nbsp; &nbsp;הלקוח מתחייב שלא לנסות לקבל גישה ללא הרשאה לאתר, לשירותים, לתכנים, לחשבונות של אחרים או למערכות מחשבים או רשתות המחוברות לאתר באמצעות "פריצה" (Hacking), "כריית סיסמאות" (Password Mining) או בכל אמצעי אחר. כמו כן הלקוח מתחייב לא להשיג או לנסות להשיג שירותים או מידע כלשהם באמצעים שלא הועמדו לרשותו באופן מכוון על-ידי החברה.</span></div>

						<div _ngcontent-c21="" style="margin-right: 40px;"><span _ngcontent-c21="" style="color:#000080">2.5&nbsp;&nbsp; &nbsp;השימוש בחלק מהשירותים והצפייה בחלק מהתכנים מוגבלת למחשבים המצויים בישראל. לפיכך, אין לבצע כל פעולה שמטרתה לעקוף בדרך כלשהי מגבלה זו.</span></div>

						<div _ngcontent-c21="" style="margin-right: 40px;"><span _ngcontent-c21="" style="color:#000080">2.6&nbsp;&nbsp; &nbsp;הלקוח מתחייב לא להעלות לאתר או להעביר בכל דרך אחרת, כל וירוס, "תולעת" (worm), סוס טרויאני, רוגלה (spyware), נוזקה (malware), או כל קוד מחשב, קובץ או תוכנה אחרים אשר עשויים להזיק, או נועדו להזיק לפעילות האתר ו/או החברה.</span></div>

						<div _ngcontent-c21="" style="margin-right: 40px;"><span _ngcontent-c21="" style="color:#000080">2.7&nbsp;&nbsp; &nbsp;הלקוח מתחייב שלא להפעיל או לאפשר להפעיל כל יישום מחשב או כל אמצעי אחר, לרבות תוכנות מסוג Crawlers ,Robots וכדומה, לשם חיפוש, סריקה, העתקה או אחזור אוטומטי של מידע מתוך האתר. בכלל זה, אין ליצור ואין להשתמש באמצעים כאמור לשם יצירת לקט, אוסף או מאגר שיכילו מידע מהאתר.</span></div>

						<div _ngcontent-c21="" style="margin-right: 40px;"><span _ngcontent-c21="" style="color:#000080">2.8&nbsp;&nbsp; &nbsp;הלקוח מתחייב שלא להציג תכנים מהאתר בתוך מסגרת (Frame), גלויה או סמויה;</span></div>

						<div _ngcontent-c21="" style="margin-right: 40px;"><span _ngcontent-c21="" style="color:#000080">2.9&nbsp;&nbsp; &nbsp;הלקוח מתחייב שלא להציג תכנים מהאתר בכל דרך שהיא – ובכלל זה באמצעות כל תוכנה, מכשיר, אביזר או פרוטוקול תקשורת – המשנים את עיצובם באתר או מחסירים מהם תכנים כלשהם.</span></div>
						<br _ngcontent-c21="">
						<span _ngcontent-c21="" style="color:#000080">3&nbsp;&nbsp; &nbsp;<u _ngcontent-c21=""><strong _ngcontent-c21="">שירותים באתר ואישור לקוח&nbsp;</strong></u></span>

						<div _ngcontent-c21="" style="margin-right: 40px;"><span _ngcontent-c21="" style="color:#000080">3.1&nbsp;&nbsp; &nbsp;השירותים המסופקים באתר:&nbsp;</span></div>

						<div _ngcontent-c21="" style="margin-right: 80px;"><span _ngcontent-c21="" style="color:#000080">3.1.1&nbsp;&nbsp; &nbsp;האתר פורס בפני הלקוח את השירותים המסופקים על ידי החברה ותנאיהם, כפי שיתעדכנו מעת לעת, ובין היתר הצטרפות למנוי, קבלת מידע על חשבוניות (בין אם בחשבון המנוי ובין אם בחשבון המזדמן), לרבות פירוט הנסיעות בגין אותן החשבוניות, בגין תקופת זמן כפי שתקבע מעת לעת, על ידי דרך ארץ, מידע על חשבוניות שטרם נפרעו וכן אפשרות לתשלום חשבוניות, עדכון פרטים אישיים, עדכון אמצעי תשלום, הוספה והסרה של רכבים, הפקת דוחות ועוד.</span></div>

						<div _ngcontent-c21="" style="margin-right: 80px;"><span _ngcontent-c21="" style="color:#000080">3.1.2&nbsp;&nbsp; &nbsp;מידע על כביש 6, תעריפי נסיעה וכיו"ב.&nbsp;<br _ngcontent-c21="">
						<span _ngcontent-c21="" style="line-height:1.6">הלקוח מאשר כי מעת לעת יעודכנו השירותים הניתנים דרך האתר וכי ככל שהלקוח יקבל שירותים אלה, הוא מאשר כי, יחולו עליו תנאי השימוש דנן.&nbsp;</span></span></div>

						<div _ngcontent-c21="" style="margin-right: 40px;"><span _ngcontent-c21="" style="color:#000080">3.2&nbsp;&nbsp; &nbsp;הלקוח <strong _ngcontent-c21="">מאשר כי השימוש באתר מהווה הסכמה מצידו לקבלת כל השירותים הנ"ל בגין <u _ngcontent-c21="">כל </u>הרכבים תחת <u _ngcontent-c21="">כל </u>חשבונות המנוי והמזדמן הרשומים על שמו וכן כי ידוע לו שלא ניתן לבחור לקבל את השירותים רק בגין חלק מהחשבונות.</strong></span></div>

						<div _ngcontent-c21="" style="margin-right: 40px;"><span _ngcontent-c21="" style="color:#000080">3.3&nbsp;&nbsp; &nbsp;הלקוח מאשר, כי לצורך קבלת חלק מהשירותים הוא יתבקש להזדהות ו/או לעבור הליך אימות, באופן שיקבע מעת לעת על ידי החברה. הלקוח מאשר ומתחייב כי ככל שנמסר לו על ידי החברה שם משתמש ו/או סיסמה הוא יעשה בהם שימוש לצרכיו האישיים בלבד. כמו כן הלקוח מתחייב לנקוט בכל האמצעים לשמירת שם המשתמש והסיסמה.</span></div>

						<div _ngcontent-c21="" style="margin-right: 40px;"><span _ngcontent-c21="" style="color:#000080">3.4&nbsp;&nbsp; &nbsp;הלקוח מאשר כי החברה רשאית להשתמש בקוקיות (COOKIES) לצורך תפעולו השוטף והתקין של האתר ובכלל זה כדי לאסוף נתונים סטטיסטיים אודות השימוש באתר, לאימות פרטים, כדי להתאים את האתר להעדפות אישיות של המשתמש, לצרכי שיווק ולצרכי אבטחת מידע.&nbsp;</span></div>

						<div _ngcontent-c21="" style="margin-right: 40px;"><span _ngcontent-c21="" style="color:#000080">קוקיות משמשות גם כדי לייתר את הצורך בהזנת פרטי משתמש בכל פעם שהוא מבקר מחדש במדורים באתר המחייבים רישום ככל שישנם כאלה. קוקיות הן קבצי טקסט שהדפדפן במחשבו של המשתמש יוצר לפי פקודה ממחשבי החברה. חלק מהקוקיות יפקעו כאשר המשתמש יסגור את הדפדפן ואחרות נשמרות על גבי הכונן הקשיח במחשב שלו. המידע בקוקיות מוצפן והחברה נוקטת צעדי זהירות כדי להבטיח שרק מחשבי החברה יוכלו לקרוא ולהבין את המידע האגור בהם.</span></div>

						<div _ngcontent-c21="" style="margin-right: 40px;"><span _ngcontent-c21="" style="color:#000080">3.5&nbsp;&nbsp; &nbsp;הלקוח מאשר כי גם במקרה בו לא סיים את הליך ההצטרפות באתר – הפרטים אשר מסר בהליך ההצטרפות ישמשו את החברה כדי לבדוק מדוע לא סיים את ההליך כאמור.&nbsp;</span></div>
						<br _ngcontent-c21="">
						<span _ngcontent-c21="" style="color:#000080">4&nbsp;&nbsp; &nbsp;<strong _ngcontent-c21=""><u _ngcontent-c21="">קניין רוחני&nbsp;</u></strong></span>

						<div _ngcontent-c21="" style="margin-right: 40px;"><span _ngcontent-c21="" style="color:#000080">4.1&nbsp;&nbsp; &nbsp;כל המידע המצוי באתר ו/או הדפים המופיעים באתר הינו רכושה הבלעדי של החברה. לפיכך, חל איסור על העתקה או כל פעולה אחרת מבלי לקבל את אישור החברה לכך. יובהר, כי גם אם יינתן אישור שכזה, הרי שיהיה זה אישור לשימוש לצרכים אישיים בלבד ולא לצרכים מסחריים.&nbsp;</span></div>

						<div _ngcontent-c21="" style="margin-right: 40px;"><span _ngcontent-c21="" style="color:#000080">4.2&nbsp;&nbsp; &nbsp;הסימנים באתר הינם סימני מסחר המהווים קניינים של החברה. אין לעשות כל פעולה אשר יש בה כדי לפגוע בזכויות היוצרים או בזכויות קניין רוחני אחרות של החברה.&nbsp;</span></div>

						<div _ngcontent-c21="" style="margin-right: 40px;"><span _ngcontent-c21="" style="color:#000080">4.3&nbsp;&nbsp; &nbsp;חל איסור על שינוי, העתקה, הפצה, פרסום של מידע, שירות או תוכנה שמקורם באתר זה.&nbsp;</span></div>
						<br _ngcontent-c21="">
						<span _ngcontent-c21="" style="color:#000080">5&nbsp;&nbsp; &nbsp;<strong _ngcontent-c21=""><u _ngcontent-c21="">הגנת פרטיות, מידע ואבטחת מידע&nbsp;</u></strong></span>

						<div _ngcontent-c21="" style="margin-right: 40px;"><span _ngcontent-c21="" style="color:#000080">5.1&nbsp;&nbsp; &nbsp;החברה רשאית לאסוף נתונים אודות לקוח ופעולותיו ולעבדם בכל צורה שהיא. החברה תוכל לעשות שימוש בנתונים אלה לצורך שיפור השרות, טיפול בתלונות, למטרות סטטיסטיות שונות וכו'.&nbsp;</span></div>

						<div _ngcontent-c21="" style="margin-right: 40px;"><span _ngcontent-c21="" style="color:#000080">5.2&nbsp;&nbsp; &nbsp;החברה שומרת לעצמה הזכות לחשוף מידע אישי אודות לקוחותיה או אודות השימוש שלהם באתר כולל תוכן השימוש, ללא קבלת רשות מהלקוחות, אם החברה מאמינה בתום לב כי פעולה זו חיונית כדי: לציית לדרישות הדין או הליך משפטי; להגן על זכויות או על קניין של החברה; לאכוף את הסכם השימוש ו/או תנאי השימוש; להגן על האינטרסים של לקוחותיה או של אחרים.&nbsp;</span></div>

						<div _ngcontent-c21="" style="margin-right: 40px;"><span _ngcontent-c21="" style="color:#000080">5.3&nbsp;&nbsp; &nbsp;הלקוח מאשר כי ידוע לו כי השימוש באתר חשוף לסיכונים הכרוכים בשימוש ברשת האינטרנט לרבות וירוסים, סוסים טרויאניים וכד', ציתות, פריצה, התחזות והונאות מכוונות אחרות. החברה משקיעה מאמץ רב בהגנה מפני סיכונים אלה אך למרות זאת אין אפשרות להגנה מוחלטת. לפיכך, יתכנו נזקים כתוצאה מהתממשות הסיכונים, לרבות גילוי ו/או שיבוש המידע במערכות, שיבוש בהוראות/בקשות, פעולות לא מורשות, שיבושים בפעילות האתר לרבות אי ביצוע ו/או ביצוע שגוי ו/או ביצוע מאוחר של הוראה, חוסר זמינות של חלק משרותי האתר וכיוצ"ב.&nbsp;</span></div>

						<div _ngcontent-c21="" style="margin-right: 40px;"><span _ngcontent-c21="" style="color:#000080">5.4&nbsp;&nbsp; &nbsp;החברה שומרת לעצמה את הזכות לסרב להעניק גישה לאתר או לחלקים ממנו לכל משתמש, לפי שיקול דעתה הבלעדי וללא מתן התראה מוקדמת וללקוח לא תהיה כל טענה ו/או דרישה ו/או תביעה בעניין.<br _ngcontent-c21="">
						<br _ngcontent-c21="">
						<span _ngcontent-c21="" style="line-height:1.6">&nbsp;מבלי לגרוע מהאמור, החברה תהא רשאית למנוע לאלתר (ואף לחסום) ממשתמש לעשות שימוש באתר בכל אחד מהמקרים הבאים:</span></span></div>

						<div _ngcontent-c21="" style="margin-right: 80px;"><span _ngcontent-c21="" style="color:#000080">5.4.1&nbsp;&nbsp; &nbsp;המשתמש הפר תנאי מתנאי השימוש.&nbsp;</span></div>

						<div _ngcontent-c21="" style="margin-right: 80px;"><span _ngcontent-c21="" style="color:#000080">5.4.2&nbsp;&nbsp; &nbsp;המשתמש מסר בעת הרישום ו/או בעת השימוש באתר פרטים שגויים במתכוון.&nbsp;</span></div>

						<div _ngcontent-c21="" style="margin-right: 80px;"><span _ngcontent-c21="" style="color:#000080">5.4.3&nbsp;&nbsp; &nbsp;המשתמש ביצע מעשה או מחדל שיש בו כדי לפגוע בחברה ו/או בפעילות התקינה של האתר.&nbsp;</span></div>

						<div _ngcontent-c21="" style="margin-right: 40px;"><span _ngcontent-c21="" style="color:#000080">5.5&nbsp;&nbsp; &nbsp;מדיניות הגנת הפרטיות של החברה מפורטת בקישור הבא &nbsp;<u _ngcontent-c21=""><a _ngcontent-c21="" href="https://www.kvish6.co.il/itempics/PTUT.pdf" target="_blank">https://www.kvish6.co.il/itempics/PTUT.pdf</a></u>. בכל מקרה של סתירה בין האמור בתנאי אלה לבין מדיניות הגנת הפרטיות כאמור, יגבר האמור במדיניות הגנת הפרטיות.</span></div>
						<br _ngcontent-c21="">
						<span _ngcontent-c21="" style="color:#000080">6&nbsp;&nbsp; &nbsp;<strong _ngcontent-c21=""><u _ngcontent-c21="">הגבלת אחריות&nbsp;</u></strong></span>

						<div _ngcontent-c21="" style="margin-right: 40px;"><span _ngcontent-c21="" style="color:#000080">6.1&nbsp;&nbsp; &nbsp;האחריות על השימוש באתר והאחריות על תוצאות השימוש באתר הינה על הלקוח בלבד, והחברה ו/או מי מטעמה ו/או נושאי המשרה שלה לא יישאו בכל אחריות בגין הפסד ו/או נזק העלולים להיגרם, במישרין או בעקיפין, כתוצאה מהשימוש באתר ו/או אי השימוש בו. &nbsp;&nbsp;&nbsp; &nbsp;</span></div>

						<div _ngcontent-c21="" style="margin-right: 40px;"><span _ngcontent-c21="" style="color:#000080">6.2&nbsp;&nbsp; &nbsp;המידע המופיע באתר הינו נכון למועד הצגתו בלבד. בכל מקרה של סתירה או אי התאמה בין המידע המופיע באתר ובין המידע המופיע במערכות החברה, יגבר המידע המופיע במערכות החברה, והחברה ו/או מי מטעמה ו/או נושאי המשרה שלה לא יישאו בכל אחריות בגין הפסד ו/או נזק העלולים להיגרם, במישרין או בעקיפין, כתוצאה מסתירה כאמור.&nbsp;</span></div>

						<div _ngcontent-c21="" style="margin-right: 40px;"><span _ngcontent-c21="" style="color:#000080">6.3&nbsp;&nbsp; &nbsp;השירותים הניתנים באתר ניתנים כמות שהם (AS IS). לא תהיה ללקוח כל תביעה/תלונה/דרישה כלפי החברה בשל תכונות השירות, יכולותיו, מגבלותיו או התאמתו לצרכיו האישיים.&nbsp;</span></div>

						<div _ngcontent-c21="" style="margin-right: 40px;"><span _ngcontent-c21="" style="color:#000080">6.4&nbsp;&nbsp; &nbsp;ידוע ללקוח שתיתכן אפשרות שבמידע המופיע באתר נפלו שגיאות ו/או אי דיוקים וכיו"ב, טעויות אנוש, תקלות מחשב או טעויות סופר וכד' ו/או שינויים אשר נגרמו על ידי מי שאינו מורשה לעסוק בכך, למרות שהחברה עושה כל שביכולתה למנוע מצבים כאלה.&nbsp;</span></div>

						<div _ngcontent-c21="" style="margin-right: 40px;"><span _ngcontent-c21="" style="color:#000080">6.5&nbsp;&nbsp; &nbsp;טעות בהזנת הנתונים המתייחסים לתשלום ו/או לכל פרט אחר הינה באחריות הלקוח בלבד.&nbsp;</span></div>

						<div _ngcontent-c21="" style="margin-right: 40px;"><span _ngcontent-c21="" style="color:#000080">6.6&nbsp;&nbsp; &nbsp;מבלי לגרוע מכל האמור בכל מקום אחר בתנאים אלה, החברה ו/או מי מטעמה ו/או נושאי המשרה שלה לא יישאו בכל אחריות, מפורשת או משתמעת, בקשר עם האתר לרבות כל תוכן ושירות בו, ו/או בקשר להתאמתו ו/או למטרה ספציפית ו/או לדרישות הלקוח. &nbsp;כמו כן, החברה ו/או מי מטעמה ו/או נושאי המשרה שלה אינם אחראים לנזק אשר עשוי להיגרם ללקוח כתוצאה מתוכן האתר ו/או מהשירותים הניתנים בו ו/או כתוצאה מתקלה/פגם או אופן תפעול שגוי של התוכנה המפעילה את האתר ו/או את הגישה אליו, לרבות זמינות האתר. מבלי לגרוע מהאמור לעיל, הלקוח מאשר ומסכים כי החברה /ואו מי מטעמה ו/או נושאי המשרה שלה ו/או כל גוף או אדם הקשורים ו/או המעורבים ביצירת האתר או תוכנו יהיו פטורים מכל אחריות וחבות, בקשר לכל נזק, פגיעה הפסד או הוצאה, בין אם ישירים ובין אם עקיפים, הקשורים בשירותים ו/או בשימוש באתר או חוסר היכולת להשתמש באתר וכי כל אחריות וסיכון בקשר עם כל האמור יחול על הלקוח בלבד.</span></div>

						<div _ngcontent-c21="" style="margin-right: 40px;"><span _ngcontent-c21="" style="color:#000080">6.7&nbsp;&nbsp; &nbsp;באתר עשויים להיות גם לינקים (קישורים לאתרים אחרים אשר אינם מופעלים על ידי החברה). קישורים אלה אינם בשליטת ו/או אחריות החברה והיא אינה אחראית ו/או מפקחת על תוכנם. אין בקישורים אלה כדי להעיד על הסכמה ו/או אחריות של החברה לתכנים המופיעים שם ו/או לאמינותם ו/או עדכניותם ו/או תקינותם ו/או חוקיותם ו/או לכל מה שאמור ונכלל בהם, לרבות מדיניות הגנת פרטיות ו/או תנאי שימוש. החברה לא תהיה אחראית לכל תוצאה אשר תגרם כתוצאה משימוש באתרים אלה ו/או מהסתמכות עליהם. בכל בעיה וטענה יש לפנות ישירות לבעלי האתרים.&nbsp;</span></div>

						<div _ngcontent-c21="" style="margin-right: 40px;"><span _ngcontent-c21="" style="color:#000080">הלקוח מאשר כי ידוע לו כי התחזות לאדם ו/או לגוף אחר ו/או מסירת פרטים כוזבים ו/או שימוש בשם בדוי מהווים עבירה פלילית וכי נגד משתמשים כאמור יינקטו כל הצעדים הקבועים בדין, לרבות במקרה הצורך תביעה בגין כל הנזקים שנגרמו לחברה, אם נגרמו.&nbsp;</span></div>

						<div _ngcontent-c21="" style="margin-right: 40px;"><span _ngcontent-c21="" style="color:#000080">6.8&nbsp;&nbsp; &nbsp;אין בהגבלת האחריות בסעיף זה כדי לגרוע מהגבלת אחריות אחרת בתנאי השימוש ומדיניות הפרטיות.&nbsp;</span></div>
						<br _ngcontent-c21="">
						<span _ngcontent-c21="" style="color:#000080">7&nbsp;&nbsp; &nbsp;<strong _ngcontent-c21=""><u _ngcontent-c21="">שינויים באתר</u></strong>&nbsp;</span>

						<div _ngcontent-c21="" style="margin-right: 40px;"><span _ngcontent-c21="" style="color:#000080">7.1&nbsp;&nbsp; &nbsp;החברה שומרת לעצמה הזכות לשנות האתר מעת לעת, היקף וזמינות השירותים המוצעים בו וכן כל היבט אחר הכרוך בתפעולו, מבלי שתצטרך להודיע על כך מראש. שינויים שכאלה, יכול שייווצרו כתוצאה מאופיו המשתנה של האינטרנט וכן בשל שינויים טכנולוגיים המתבצעים ברשת. יובהר, כי שינויים אלה עשויים לגרום לתקלות או לאי נוחות, אך ללקוח לא תהא כל תביעה/תלונה/דרישה כלפי החברה עקב ביצועם.&nbsp;</span></div>

						<div _ngcontent-c21="" style="margin-right: 40px;"><span _ngcontent-c21="" style="color:#000080">7.2&nbsp;&nbsp; &nbsp;החברה תהא רשאית לערוך שינוי בתנאי השימוש באתר מבלי שתצטרך ליתן על כך הודעה מוקדמת. משכך, יש לעיין בתנאי השימוש בכל כניסה מחודשת לאתר, על מנת להתעדכן בהוראותיו.&nbsp;</span></div>
						<br _ngcontent-c21="">
						<span _ngcontent-c21="" style="color:#000080">8&nbsp;&nbsp; &nbsp;<u _ngcontent-c21=""><strong _ngcontent-c21="">תמיכה טכנית&nbsp;</strong></u></span>

						<div _ngcontent-c21="" style="margin-right: 40px;"><span _ngcontent-c21="" style="color:#000080">החברה אינה מתחייבת להעמיד לרשות הלקוח תמיכה טכנית אודות תפעולו של האתר ו/או שירותים המסופקים באמצעותו. הלקוח מאשר כי הוא לא יעלה כל תלונה כלפי החברה נוכח העדר תמיכה כאמור.&nbsp;</span></div>
						<br _ngcontent-c21="">
						<span _ngcontent-c21="" style="color:#000080">9&nbsp;&nbsp; &nbsp;<u _ngcontent-c21=""><strong _ngcontent-c21="">הפסקת שרות</strong></u>&nbsp;</span>

						<div _ngcontent-c21="" style="margin-right: 40px;"><span _ngcontent-c21="" style="color:#000080">החברה רשאית בכל עת להחליט כי היא מפסיקה את פעילותו של האתר או משנה את אופיו. הודעה בדבר סגירה/שינוי תפורסם 7 ימים טרם הביצוע.&nbsp;</span></div>
						<br _ngcontent-c21="">
						<span _ngcontent-c21="" style="color:#000080">10&nbsp;&nbsp; &nbsp;<u _ngcontent-c21=""><strong _ngcontent-c21="">הדין הנוהג וסמכות שיפוט</strong></u>&nbsp;</span>

						<div _ngcontent-c21="" style="margin-right: 40px;"><span _ngcontent-c21="" style="color:#000080">על השימוש באתר יחולו דיני מדינת ישראל, ולבתי המשפט במחוז תל אביב יפו תהא&nbsp;</span></div>

						<div _ngcontent-c21="" style="margin-right: 40px;"><span _ngcontent-c21="" style="color:#000080">הסמכות הבלעדית והיחידה בכל עניין הקשור בהם.&nbsp;</span></div>

            </div>

            <!---->
        </div>
      </div>

		<div _ngcontent-c21="" class="row rowSpacerSmall"></div>
        <div _ngcontent-c21="" class="row rowSpacerSmall">
          <div _ngcontent-c21="" class="col-xs-5 col-sm-3">
            <button _ngcontent-c21="" class="btn btn-block cancel-btn">ביטול
            </button>
          </div>
          <div _ngcontent-c21="" class="col-xs-5 col-xs-offset-2 col-sm-3 col-sm-offset-6">
            <button _ngcontent-c21="" class="btn btn-primary btn-block submit-btn">אשר
            </button>
          </div>
        </div>
    </div>
  </div>
</div>
</div></sls-modal-customer-area-legal-terms>
<sls-modal-calendar _ngcontent-c3="" _nghost-c22=""><div _ngcontent-c22="" aria-hidden="true" aria-labelledby="mySmallModalLabel" bsmodal="" class="modal fade modal-below-page-title modal-calendar" role="dialog" style="overflow-x: hidden; overflow-y: auto;">
    <div _ngcontent-c22="" class="modal-dialog modal-md">
        <div _ngcontent-c22="" class="modal-content">
            <div _ngcontent-c22="" class="modal-body">
				   <!---->

					<div _ngcontent-c22="" class="row rowSpacerSmall">
					<div _ngcontent-c22="" class="col-xs-5 col-sm-3">
						<button _ngcontent-c22="" class="btn btn-block cancel-btn" type="button">
							נקה
							<span _ngcontent-c22="" class="sr-only">סגירת תאריכון</span>
						</button>
					</div>
					<div _ngcontent-c22="" class="col-xs-5 col-xs-offset-2 col-sm-3 col-sm-offset-6">
						<button _ngcontent-c22="" class="btn btn-primary btn-block submit-btn" type="button">שמור</button>
					</div>
				</div>
            </div>
        </div>
    </div>
</div></sls-modal-calendar>
<sls-modal-customer-area-trips-download _ngcontent-c3="" _nghost-c23=""><div _ngcontent-c23="" aria-hidden="true" aria-labelledby="mySmallModalLabel" bsmodal="" class="modal fade modal-below-page-title" role="dialog">
  <div _ngcontent-c23="" class="modal-dialog modal-md">
    <div _ngcontent-c23="" class="modal-content">
      <div _ngcontent-c23="" class="modal-header">
        <h2 _ngcontent-c23="" class="modal-title pull-right" style="font-size: 22px;" tabindex="0">אישור הורדת פירוט נסיעות</h2>
        <button _ngcontent-c23="" aria-label="סגור" class="modal-close-btn pull-left" type="button">
          <img _ngcontent-c23="" alt="" src="./a/modal-close-btn.svg">
        </button>
      </div>
      <div _ngcontent-c23="" class="modal-body">
        <div _ngcontent-c23="" class="row rowSpacerSmall row-eq-height">
          <div _ngcontent-c23="" class="col-xs-4 col-sm-2 vertical-align-content">
            <img _ngcontent-c23="" alt="" src="./a/notice.svg">
          </div>
          <div _ngcontent-c23="" class="col-xs-8 col-sm-10 vertical-align-content">
            <p _ngcontent-c23="" class="paragraph"></p>
          </div>
        </div>
        <div _ngcontent-c23="" class="row rowSpacerSmall"></div>
        <div _ngcontent-c23="" class="row rowSpacerSmall">
            <div _ngcontent-c23="" class="col-xs-5 col-sm-3"><button _ngcontent-c23="" class="btn btn-block cancel-btn">ביטול</button></div>
            <div _ngcontent-c23="" class="col-xs-5 col-xs-offset-2 col-sm-3 col-sm-offset-6">
              <button _ngcontent-c23="" class="btn btn-primary btn-block submit-btn">אישור</button>
            </div>
        </div>
      </div>
    </div>
  </div>
</div>
</sls-modal-customer-area-trips-download>
<sls-modal-confirm-before-update _ngcontent-c3="" _nghost-c24=""><div _ngcontent-c24="" aria-hidden="true" aria-labelledby="mySmallModalLabel" bsmodal="" class="modal fade modal-below-page-title" role="dialog">
  <div _ngcontent-c24="" class="modal-dialog modal-md">
    <div _ngcontent-c24="" class="modal-content">
      <div _ngcontent-c24="" class="modal-header">
        <h2 _ngcontent-c24="" class="modal-title pull-right" style="font-size: 22px;" tabindex="0"></h2>
        <button _ngcontent-c24="" aria-label="סגור" class="modal-close-btn pull-left" type="button">
          <img _ngcontent-c24="" alt="" src="./a/modal-close-btn.svg">
        </button>
      </div>
      <div _ngcontent-c24="" class="modal-body">
        <div _ngcontent-c24="" class="row rowSpacerSmall row-eq-height">
          <div _ngcontent-c24="" class="col-xs-9 col-sm-10 vertical-align-content">
            <p _ngcontent-c24="" class="paragraph"></p>
          </div>
          <div _ngcontent-c24="" class="col-xs-3 col-sm-2 vertical-align-content">
            <img _ngcontent-c24="" alt="" class="modal-notice-icon" src="./a/notice.png">
          </div>
        </div>
        <div _ngcontent-c24="" class="row rowSpacerSmall"></div>
        <div _ngcontent-c24="" class="row rowSpacerSmall">
            <div _ngcontent-c24="" class="col-xs-5 col-sm-3"><button _ngcontent-c24="" class="btn btn-block cancel-btn">ביטול</button></div>
            <div _ngcontent-c24="" class="col-xs-5 col-xs-offset-2 col-sm-3 col-sm-offset-6">
            <button _ngcontent-c24="" class="btn btn-primary btn-block submit-btn">TEXT</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</sls-modal-confirm-before-update>
<sls-modal-confirm-before-action _ngcontent-c3="" _nghost-c25=""><div _ngcontent-c25="" aria-hidden="true" aria-labelledby="mySmallModalLabel" bsmodal="" class="modal fade modal-below-page-title" role="dialog">
  <div _ngcontent-c25="" class="modal-dialog modal-md">
    <div _ngcontent-c25="" class="modal-content">
      <div _ngcontent-c25="" class="modal-header">
        <h2 _ngcontent-c25="" class="modal-title pull-right" style="font-size: 22px;" tabindex="0"></h2>
        <button _ngcontent-c25="" aria-label="סגור" class="modal-close-btn pull-left" type="button">
          <img _ngcontent-c25="" alt="" src="./a/modal-close-btn.svg">
        </button>
      </div>
      <div _ngcontent-c25="" class="modal-body">
        <div _ngcontent-c25="" class="row rowSpacerSmall row-eq-height">
          <div _ngcontent-c25="" class="col-xs-9 col-sm-10 vertical-align-content">
            <p _ngcontent-c25="" class="paragraph"></p>
          </div>
          <div _ngcontent-c25="" class="col-xs-3 col-sm-2 vertical-align-content">
            <img _ngcontent-c25="" alt="" class="modal-notice-icon" src="./a/notice.png">
          </div>
        </div>
        <div _ngcontent-c25="" class="row rowSpacerSmall"></div>
        <div _ngcontent-c25="" class="row rowSpacerSmall">
          <div _ngcontent-c25="" class="col-xs-5 col-sm-3"><button _ngcontent-c25="" class="btn btn-block cancel-btn">ביטול</button></div>
          <div _ngcontent-c25="" class="col-xs-5 col-xs-offset-2 col-sm-3 col-sm-offset-6">
            <button _ngcontent-c25="" class="btn btn-primary btn-block submit-btn">אישור</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</div></sls-modal-confirm-before-action>
<sls-modal-lovs-and-params-error _ngcontent-c3="" _nghost-c26=""><div _ngcontent-c26="" aria-hidden="true" aria-labelledby="mySmallModalLabel" bsmodal="" class="modal fade modal-below-page-title" role="dialog">
  <div _ngcontent-c26="" class="modal-dialog modal-md">
    <div _ngcontent-c26="" class="modal-content">
      <div _ngcontent-c26="" class="modal-header">
        <h2 _ngcontent-c26="" class="modal-title pull-right" style="font-size: 22px;" tabindex="0"></h2>
        
      </div>
      <div _ngcontent-c26="" class="modal-body">
        <div _ngcontent-c26="" class="row rowSpacerSmall row-eq-height">
          <div _ngcontent-c26="" class="col-xs-4 col-sm-2 vertical-align-content">
            <img _ngcontent-c26="" alt="" src="./a/notice.svg">
          </div>
          <div _ngcontent-c26="" class="col-xs-8 col-sm-10 vertical-align-content">
            <p _ngcontent-c26="" class="paragraph"></p>
          </div>
        </div>
        <div _ngcontent-c26="" class="row rowSpacerSmall"></div>
        <div _ngcontent-c26="" class="row rowSpacerSmall">
          <div _ngcontent-c26="" class="col-xs-5 col-xs-offset-7 col-sm-3 col-sm-offset-9">
            <button _ngcontent-c26="" class="btn btn-primary btn-block submit-btn">TEXT</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</sls-modal-lovs-and-params-error>
<sls-modal-customer-area-confirm-before-logout _ngcontent-c3="" _nghost-c27=""><div _ngcontent-c27="" aria-hidden="true" aria-labelledby="mySmallModalLabel" bsmodal="" class="modal fade modal-below-page-title" role="dialog">
  <div _ngcontent-c27="" class="modal-dialog modal-md">
    <div _ngcontent-c27="" class="modal-content">
      <div _ngcontent-c27="" class="modal-header">
        <h2 _ngcontent-c27="" class="modal-title pull-right" style="font-size: 22px;" tabindex="0"></h2>
        <button _ngcontent-c27="" aria-label="סגור" class="modal-close-btn pull-left" type="button">
          <img _ngcontent-c27="" alt="" src="./a/modal-close-btn.svg">
        </button>
      </div>
      <div _ngcontent-c27="" class="modal-body">
        <div _ngcontent-c27="" class="row rowSpacerSmall row-eq-height">
          <div _ngcontent-c27="" class="col-xs-9 col-sm-10 vertical-align-content">
            <p _ngcontent-c27="" class="paragraph">האם ברצונך לצאת מהמערכת?</p>
          </div>
          <div _ngcontent-c27="" class="col-xs-3 col-sm-2 vertical-align-content">
            <img _ngcontent-c27="" alt="" class="modal-notice-icon" src="./a/notice.png">
          </div>
        </div>
        <div _ngcontent-c27="" class="row rowSpacerSmall"></div>
        <div _ngcontent-c27="" class="row rowSpacerSmall">
            <div _ngcontent-c27="" class="col-xs-5 col-sm-3"><button _ngcontent-c27="" class="btn btn-block cancel-btn">ביטול</button></div>
            <div _ngcontent-c27="" class="col-xs-5 col-xs-offset-2 col-sm-3 col-sm-offset-6">
            <button _ngcontent-c27="" class="btn btn-primary btn-block submit-btn">אישור</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</sls-modal-customer-area-confirm-before-logout>
<sls-modal-customer-area-registration-complete _ngcontent-c3="" _nghost-c28=""><div _ngcontent-c28="" aria-hidden="true" aria-labelledby="mySmallModalLabel" bsmodal="" class="modal fade modal-below-page-title modal-customer-area-registration-complete" role="dialog" style="overflow-x: hidden; overflow-y: auto;">
    <div _ngcontent-c28="" class="modal-dialog modal-md">
        <div _ngcontent-c28="" class="modal-content">
            <div _ngcontent-c28="" class="modal-body">
                <div _ngcontent-c28="" class="modal-wrapper">
                    <!----><img _ngcontent-c28="" class="brand-logo" src="./a/registration-completed-logo-kvish6.png">
                    <!---->

                    <p _ngcontent-c28="" tabindex="-1"><span _ngcontent-c28="">, בקשתך להצטרפות כמנוי נשלחה</span><br _ngcontent-c28="">אישור על פתיחת המנוי יתקבל בסמס או בדוא"ל</p>

                    <button _ngcontent-c28="" class="btn-redirect" type="button">מעבר לאיזור האישי</button>
                    

                    <div _ngcontent-c28="" class="disclaimer">להצטרפות למנוי במנהרות הכרמל יש להירשם באתר מנהרות הכרמל</div>
                </div>
            </div>
        </div>
    </div>
</div></sls-modal-customer-area-registration-complete>
<sls-modal-customer-area-confirm-redirect _ngcontent-c3="" _nghost-c29=""><div _ngcontent-c29="" aria-hidden="true" aria-labelledby="mySmallModalLabel" bsmodal="" class="modal fade modal-below-page-title" role="dialog">
  <div _ngcontent-c29="" class="modal-dialog modal-md">
    <div _ngcontent-c29="" class="modal-content">
      <div _ngcontent-c29="" class="modal-header">
        <h2 _ngcontent-c29="" class="modal-title pull-right" style="font-size: 22px;" tabindex="0"></h2>
        <button _ngcontent-c29="" aria-label="סגור" class="modal-close-btn pull-left" type="button">
          <img _ngcontent-c29="" alt="" src="./a/modal-close-btn.svg">
        </button>
      </div>
      <div _ngcontent-c29="" class="modal-body">
        <div _ngcontent-c29="" class="row rowSpacerSmall row-eq-height">
          

          <div _ngcontent-c29="" class="col-xs-9 col-sm-10 vertical-align-content">
            <p _ngcontent-c29="" class="paragraph"></p>
          </div>

          <div _ngcontent-c29="" class="col-xs-3 col-sm-2 vertical-align-content">
            <img _ngcontent-c29="" alt="" class="modal-notice-icon" src="./a/notice.png">
          </div>
        </div>
        <div _ngcontent-c29="" class="row rowSpacerSmall"></div>
        <div _ngcontent-c29="" class="row rowSpacerSmall">
            <div _ngcontent-c29="" class="col-xs-6 col-sm-4">
              <button _ngcontent-c29="" class="btn btn-block cancel-btn" type="button">ביטול</button>
            </div>
            <div _ngcontent-c29="" class="col-xs-6 col-sm-4 col-sm-offset-4">
              <button _ngcontent-c29="" class="btn btn-primary btn-block submit-btn" type="button"> </button>
            </div>
          </div>
      </div>
    </div>
  </div>
</div>
</sls-modal-customer-area-confirm-redirect>
<sls-modal-customer-area-registration-otp _ngcontent-c3="" _nghost-c30=""><div _ngcontent-c30="" aria-hidden="true" aria-labelledby="mySmallModalLabel" bsmodal="" class="modal fade modal-below-page-title" role="dialog" style="overflow: hidden auto; transform: translate(0px, 0px);">
    <div _ngcontent-c30="" class="modal-dialog modal-md">
        <div _ngcontent-c30="" class="modal-content">
            <div _ngcontent-c30="" class="modal-header ng-draggable">
                <h2 _ngcontent-c30="" class="modal-title pull-right" style="font-size: 22px;" tabindex="0"></h2>
                <button _ngcontent-c30="" aria-label="סגור" class="modal-close-btn pull-left" type="button">
          <img _ngcontent-c30="" alt="" src="./a/modal-close-btn.svg">
        </button>
            </div>

            <div _ngcontent-c30="" class="modal-body">
                <form _ngcontent-c30="" autocomplete="off" focusoninvalidcontrol="" novalidate="" class="ng-untouched ng-pristine ng-invalid">
                    <div _ngcontent-c30="" class="row rowSpacerSmall">
                        <div _ngcontent-c30="" class="col-xs-12 col-sm-8 col-sm-offset-2">
                            <!----><label _ngcontent-c30="" class="paragraph" for="smsCode" id="smsCodeLabel">
                                הכנס/י את קוד האישור שנשלח אליך בסמס
                                <br _ngcontent-c30="">
                                <strong _ngcontent-c30="">לטלפון נייד המסתיים בספרות </strong>
                            </label>

                            <!---->
                        </div>
                    </div>
                    <div _ngcontent-c30="" class="row rowSpacerSmall">
                        <div _ngcontent-c30="" class="col-xs-12 col-sm-8 col-sm-offset-2">
                            <div _ngcontent-c30="" class="form-group required form-group-lg">
                                <input _ngcontent-c30="" aria-describedby="error-2" aria-labelledby="smsCodeLabel" aria-required="true" class="form-control ng-untouched ng-pristine ng-invalid" formcontrolname="userSMSCode" id="smsCode" maxlength="6" type="tel" aria-invalid="false">
                            </div>
                        </div>
                        <div _ngcontent-c30="" class="col-xs-12 col-sm-8 col-sm-offset-2">
                            <!---->
                        </div>
                    </div>

                    

                     <!----><div _ngcontent-c30="" class="row">
                        <div _ngcontent-c30="" class="col-sm-10 col-sm-offset-2">
                            <button _ngcontent-c30="" class="btn-send-otp-by-email" type="button">שלח לי קוד למייל</button>
                        </div>
                     </div>

                     
                     <div _ngcontent-c30="" class="row rowSpacerSmall"></div>
                    <div _ngcontent-c30="" class="row rowSpacerSmall"></div>

                    <div _ngcontent-c30="" class="row rowSpacerSmall">
                        <div _ngcontent-c30="" class="col-xs-5 col-sm-3">
                            <button _ngcontent-c30="" class="btn btn-block cancel-btn" type="button">ביטול</button>
                        </div>
                        <div _ngcontent-c30="" class="col-xs-5 col-xs-offset-2 col-sm-3 col-sm-offset-6">
                            <button _ngcontent-c30="" class="btn btn-primary btn-block submit-btn" type="submit">אישור</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div></sls-modal-customer-area-registration-otp>
<sls-modal-customer-area-registration-terms _ngcontent-c3="" _nghost-c31=""><div _ngcontent-c31="" aria-hidden="true" aria-labelledby="mySmallModalLabel" bsmodal="" class="modal fade info-modal" role="dialog">
  <div _ngcontent-c31="" class="modal-dialog modal-md">
    <div _ngcontent-c31="" class="modal-content">
      <div _ngcontent-c31="" class="modal-header">
        <div _ngcontent-c31="" aria-label="סגור" class="modal-info-header-icon pull-right">
          <img _ngcontent-c31="" alt="" src="./a/ico-helpScreen.svg">
        </div>
        <h2 _ngcontent-c31="" class="modal-title pull-right" style="font-size: 22px;" tabindex="0">תנאים משפטיים</h2>
        <button _ngcontent-c31="" aria-label="סגור" class="modal-close-btn pull-left" type="button">
          <img _ngcontent-c31="" alt="" src="./a/modal-close-btn.svg">
        </button>
      </div>

      <div _ngcontent-c31="" class="modal-body">
        <div _ngcontent-c31="" class="row rowSpacerSmall content-max-height modal-content-container" tabindex="0">
          <div _ngcontent-c31="" class="col-xs-12 modal-content-container-box" tabindex="0">
             <!----><!---->
                  <!---->

                  <!---->

                  <!---->

                   <!---->
             

              <!---->                                                                                                                                                     
          </div>
        </div>
        <div _ngcontent-c31="" class="row rowSpacerSmall"></div>

        <div _ngcontent-c31="" class="row rowSpacerSmall">
          <div _ngcontent-c31="" class="col-xs-5 col-xs-offset-7 col-sm-3 col-sm-offset-9">
            <button _ngcontent-c31="" class="btn btn-primary btn-block submit-btn">סגור
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</sls-modal-customer-area-registration-terms>
<sls-modal-customer-area-vehicle-new-account-loader _ngcontent-c3="" _nghost-c32=""><div _ngcontent-c32="" aria-hidden="true" aria-labelledby="mySmallModalLabel" bsmodal="" class="modal fade modal-below-page-title" role="dialog">
  <div _ngcontent-c32="" class="modal-dialog modal-md">
    <div _ngcontent-c32="" class="modal-content">
      <div _ngcontent-c32="" class="modal-header">
        <h2 _ngcontent-c32="" class="modal-title pull-right" style="font-size: 22px;" tabindex="0">פתיחת מנוי חדש</h2>
      </div>

      <div _ngcontent-c32="" class="modal-body">
        <p _ngcontent-c32="">רק עוד רגע, מעדכן את פרטי המנוי החדש</p>
      </div>
    </div>
  </div>
</div></sls-modal-customer-area-vehicle-new-account-loader>
<sls-modal-customer-area-vehicle-new-account-confirmation _ngcontent-c3="" _nghost-c33=""><div _ngcontent-c33="" aria-hidden="true" aria-labelledby="mySmallModalLabel" bsmodal="" class="modal fade modal-below-page-title" role="dialog">
  <div _ngcontent-c33="" class="modal-dialog modal-md">
    <div _ngcontent-c33="" class="modal-content">
      <div _ngcontent-c33="" class="modal-header">
        <h2 _ngcontent-c33="" class="modal-title pull-right" style="font-size: 22px;" tabindex="0">אישור על פתיחת המנוי יתקבל בסמס או בדוא"ל</h2>
      </div>

      <div _ngcontent-c33="" class="modal-body">

        <p _ngcontent-c33="">להשלמת התהליך, הנך מועבר לעדכון פרטי הרכב במנוי החדש.</p>

        <div _ngcontent-c33="" class="row rowSpacerSmall"></div>
        <div _ngcontent-c33="" class="row rowSpacerSmall">
          
          <div _ngcontent-c33="" class="col-xs-6 col-xs-offset-3 col-sm-4 col-sm-offset-0"><button _ngcontent-c33="" class="btn btn-primary btn-block submit-btn">אישור</button></div>
        </div>

        <img _ngcontent-c33="" alt="" class="icon-bg" src="./a/icon-vehicle-new-account-confirmation.svg">
      </div>
    </div>
  </div>
</div></sls-modal-customer-area-vehicle-new-account-confirmation>
<sls-modal-payments-external-legal-terms _ngcontent-c3="" _nghost-c34=""><div _ngcontent-c34="" aria-hidden="true" aria-labelledby="mySmallModalLabel" bsmodal="" class="modal fade info-modal" role="dialog">
  <div _ngcontent-c34="" class="modal-dialog modal-md">
    <div _ngcontent-c34="" class="modal-content">
      <div _ngcontent-c34="" class="modal-header">
        <div _ngcontent-c34="" aria-label="סגור" class="modal-info-header-icon pull-right">
          <img _ngcontent-c34="" alt="" src="./a/ico-helpScreen.svg">
        </div>
        <h2 _ngcontent-c34="" class="modal-title pull-right" style="font-size: 22px;" tabindex="0">תנאים משפטיים</h2>
        <button _ngcontent-c34="" aria-label="סגור" class="modal-close-btn pull-left" type="button">
          <img _ngcontent-c34="" alt="" src="./a/modal-close-btn.svg">
        </button>
      </div>

      <div _ngcontent-c34="" class="modal-body">
        <div _ngcontent-c34="" class="row rowSpacerSmall content-max-height modal-content-container">
          <div _ngcontent-c34="" class="col-xs-12 modal-content-container-box" tabindex="0">
        	<!----><div _ngcontent-c34="">
					<div _ngcontent-c34="" style="text-align: center;"><br _ngcontent-c34="">
						<span _ngcontent-c34="" style="color:#000080"><span _ngcontent-c34="" style="font-size:14px"><u _ngcontent-c34=""><strong _ngcontent-c34="">תנאי שימוש אתר כביש 6&nbsp;</strong></u></span></span></div>
						<br _ngcontent-c34="">
						<span _ngcontent-c34="" style="color:#000080">הואיל ואני מעוניין להשתמש בשירותים אותם מספקת חברת דרך ארץ (להלן: "<strong _ngcontent-c34="">החברה</strong>" או "<strong _ngcontent-c34="">דרך ארץ</strong>") באמצעות האתר;&nbsp;<br _ngcontent-c34="">
						<br _ngcontent-c34="">
						<strong _ngcontent-c34="">לפיכך, אני מסכים, מצהיר ומתחייב כדלקמן:&nbsp;</strong><br _ngcontent-c34="">
						<br _ngcontent-c34="">
						1&nbsp;&nbsp; &nbsp;<u _ngcontent-c34=""><strong _ngcontent-c34="">מבוא&nbsp;</strong></u></span>

						<div _ngcontent-c34="" style="margin-right: 40px;"><span _ngcontent-c34="" style="color:#000080">1.1&nbsp;&nbsp; &nbsp;הרישא של תנאי השימוש מהווה חלק בלתי נפרד מהם.&nbsp;</span></div>

						<div _ngcontent-c34="" style="margin-right: 40px;"><span _ngcontent-c34="" style="color:#000080">1.2&nbsp;&nbsp; &nbsp;תנאי שימוש אלה נכתבו בלשון יחיד אך כמובן הם יחולו על &nbsp;הרבים ועל כל אישיות משפטית, לפי העניין.&nbsp;</span></div>

						<div _ngcontent-c34="" style="margin-right: 40px;"><span _ngcontent-c34="" style="color:#000080">1.3&nbsp;&nbsp; &nbsp;בתנאי שימוש אלה יהיו למונחים הבאים הפירושים המופיעים לצידם:&nbsp;</span></div>

						<div _ngcontent-c34="" style="margin-right: 80px;"><span _ngcontent-c34="" style="color:#000080">1.3.1&nbsp;&nbsp; &nbsp;"<strong _ngcontent-c34="">האתר</strong>" – אתר האינטרנט של חברת דרך ארץ.&nbsp;</span></div>

						<div _ngcontent-c34="" style="margin-right: 80px;"><span _ngcontent-c34="" style="color:#000080">1.3.2&nbsp;&nbsp; &nbsp;"<strong _ngcontent-c34="">הסכם שימוש</strong>" – הסכם הצטרפות מנוי לכביש 6 שנחתם בין החברה לבין הלקוח &nbsp;המנוי.&nbsp;</span></div>

						<div _ngcontent-c34="" style="margin-right: 80px;"><span _ngcontent-c34="" style="color:#000080">1.3.3&nbsp;&nbsp; &nbsp;"<strong _ngcontent-c34="">חוק כביש האגרה</strong>" – חוק כביש אגרה (כביש ארצי לישראל), התשנ"ה-1995 והתקנות שהוצאו מכוחו, כפי שאלה יתעדכנו מעת לעת.</span></div>

						<div _ngcontent-c34="" style="margin-right: 80px;"><span _ngcontent-c34="" style="color:#000080">1.3.4&nbsp;&nbsp; &nbsp;"<strong _ngcontent-c34="">חשבוניות</strong>" – חשבוניות/חשבונות כהגדרתם בחוק כביש האגרה הנשלחים מעת לעת ללקוחות בהתאם לחוק כביש האגרה ו/או בהתאם להסכם השימוש.&nbsp;</span></div>

						<div _ngcontent-c34="" style="margin-right: 80px;"><span _ngcontent-c34="" style="color:#000080">1.3.5&nbsp;&nbsp; &nbsp;"<strong _ngcontent-c34="">חשבון מנוי"/"חשבונות מנוי</strong>" – כלל החשבונות של הלקוח, דהיינו כל החשבונות בגינם הלקוח משלם עבור רכבים במנוי.&nbsp;</span></div>

						<div _ngcontent-c34="" style="margin-right: 80px;"><span _ngcontent-c34="" style="color:#000080">1.3.6&nbsp;&nbsp; &nbsp;"<strong _ngcontent-c34="">כביש 6</strong>" – כמשמעות המונח "כביש ארצי לישראל" בחוק כביש האגרה.&nbsp;</span></div>

						<div _ngcontent-c34="" style="margin-right: 80px;"><span _ngcontent-c34="" style="color:#000080">1.3.7&nbsp;&nbsp; &nbsp;"<strong _ngcontent-c34="">לקוח מנוי</strong>" או "<strong _ngcontent-c34="">מנוי</strong>" – לקוח רגיל כמשמעותו בחוק כביש האגרה, לקוח אשר התקשר עם החברה בהסכם השימוש.&nbsp;</span></div>

						<div _ngcontent-c34="" style="margin-right: 80px;"><span _ngcontent-c34="" style="color:#000080">1.3.8&nbsp;&nbsp; &nbsp;"<strong _ngcontent-c34="">לקוח מזדמ</strong>ן" – לקוח שאינו לקוח מנוי.</span></div>

						<div _ngcontent-c34="" style="margin-right: 80px;"><span _ngcontent-c34="" style="color:#000080">1.3.9&nbsp;&nbsp; &nbsp;"<strong _ngcontent-c34="">לקוח"/"משתמש</strong>" – לקוח מנוי ו/או לקוח מזדמן ו/או כל העושה שימוש באתר.&nbsp;</span></div>

						<div _ngcontent-c34="" style="margin-right: 80px;"><span _ngcontent-c34="" style="color:#000080">1.3.10&nbsp;&nbsp;"<strong _ngcontent-c34="">שירותים</strong>" – השירותים המפורטים בסעיף &rlm;3 להלן.&nbsp;</span></div>

						<div _ngcontent-c34="" style="margin-right: 80px;"><span _ngcontent-c34="" style="color:#000080">1.3.11&nbsp;&nbsp;"<strong _ngcontent-c34="">תנאי השימוש</strong>" – התנאים המפורטים במסמך זה.&nbsp;</span></div>
						<br _ngcontent-c34="">
						<span _ngcontent-c34="" style="color:#000080">2&nbsp;&nbsp; &nbsp;<u _ngcontent-c34=""><strong _ngcontent-c34="">השימוש באתר&nbsp;</strong></u></span>

						<div _ngcontent-c34="" style="margin-right: 40px;"><span _ngcontent-c34="" style="color:#000080">2.1&nbsp;&nbsp; &nbsp;הלקוח מתחייב שלא לבצע פעולה כלשהי אשר יש בה כדי להוות הפרה של תנאי השימוש ו/או הוראות הדין ו/או שיש בה כדי לגרוע מאיזו מזכויותיה של החברה ו/או של צד ג' כלשהו ו/או העלולה להזיק לאתר ו/או לרשתות התקשורת. חל איסור לעשות שימוש באתר למטרה בלתי חוקית או אסורה.</span></div>

						<div _ngcontent-c34="" style="margin-right: 40px;"><span _ngcontent-c34="" style="color:#000080">2.2&nbsp;&nbsp; &nbsp;הלקוח מאשר כי השימוש באתר מתאפשר בכפוף לתנאי השימוש ולשם ביצוע חלק מהפעולות הוא מתאפשר בכפוף לסעיף 3.3 להלן. פרטי הלקוח ישמרו על ידי החברה במאגרים ממוחשבים, בהתאם לכל דין.&nbsp;</span></div>

						<div _ngcontent-c34="" style="margin-right: 40px;"><span _ngcontent-c34="" style="color:#000080">2.3&nbsp;&nbsp; &nbsp;הפרטים הינם אישיים ואינם ניתנים להעברה. באם הועברו פרטי לקוח לידי צד ג', על הלקוח לפנות לעדכון החברה ללא שיהוי. בכל מקרה החברה לא תישא באחריות כתוצאה משימוש בפרטים אלה, מכל סיבה שהיא. המידע המוצג הינו לשימושו האישי של הלקוח, וחל איסור לעשות כל פעולה במידע, כולו או חלקו, שיש בה כדי לפגוע בזכויות הקניין של החברה ו/או מי מטעמה.&nbsp;</span></div>

						<div _ngcontent-c34="" style="margin-right: 40px;"><span _ngcontent-c34="" style="color:#000080">2.4&nbsp;&nbsp; &nbsp;הלקוח מתחייב שלא לנסות לקבל גישה ללא הרשאה לאתר, לשירותים, לתכנים, לחשבונות של אחרים או למערכות מחשבים או רשתות המחוברות לאתר באמצעות "פריצה" (Hacking), "כריית סיסמאות" (Password Mining) או בכל אמצעי אחר. כמו כן הלקוח מתחייב לא להשיג או לנסות להשיג שירותים או מידע כלשהם באמצעים שלא הועמדו לרשותו באופן מכוון על-ידי החברה.</span></div>

						<div _ngcontent-c34="" style="margin-right: 40px;"><span _ngcontent-c34="" style="color:#000080">2.5&nbsp;&nbsp; &nbsp;השימוש בחלק מהשירותים והצפייה בחלק מהתכנים מוגבלת למחשבים המצויים בישראל. לפיכך, אין לבצע כל פעולה שמטרתה לעקוף בדרך כלשהי מגבלה זו.</span></div>

						<div _ngcontent-c34="" style="margin-right: 40px;"><span _ngcontent-c34="" style="color:#000080">2.6&nbsp;&nbsp; &nbsp;הלקוח מתחייב לא להעלות לאתר או להעביר בכל דרך אחרת, כל וירוס, "תולעת" (worm), סוס טרויאני, רוגלה (spyware), נוזקה (malware), או כל קוד מחשב, קובץ או תוכנה אחרים אשר עשויים להזיק, או נועדו להזיק לפעילות האתר ו/או החברה.</span></div>

						<div _ngcontent-c34="" style="margin-right: 40px;"><span _ngcontent-c34="" style="color:#000080">2.7&nbsp;&nbsp; &nbsp;הלקוח מתחייב שלא להפעיל או לאפשר להפעיל כל יישום מחשב או כל אמצעי אחר, לרבות תוכנות מסוג Crawlers ,Robots וכדומה, לשם חיפוש, סריקה, העתקה או אחזור אוטומטי של מידע מתוך האתר. בכלל זה, אין ליצור ואין להשתמש באמצעים כאמור לשם יצירת לקט, אוסף או מאגר שיכילו מידע מהאתר.</span></div>

						<div _ngcontent-c34="" style="margin-right: 40px;"><span _ngcontent-c34="" style="color:#000080">2.8&nbsp;&nbsp; &nbsp;הלקוח מתחייב שלא להציג תכנים מהאתר בתוך מסגרת (Frame), גלויה או סמויה;</span></div>

						<div _ngcontent-c34="" style="margin-right: 40px;"><span _ngcontent-c34="" style="color:#000080">2.9&nbsp;&nbsp; &nbsp;הלקוח מתחייב שלא להציג תכנים מהאתר בכל דרך שהיא – ובכלל זה באמצעות כל תוכנה, מכשיר, אביזר או פרוטוקול תקשורת – המשנים את עיצובם באתר או מחסירים מהם תכנים כלשהם.</span></div>
						<br _ngcontent-c34="">
						<span _ngcontent-c34="" style="color:#000080">3&nbsp;&nbsp; &nbsp;<u _ngcontent-c34=""><strong _ngcontent-c34="">שירותים באתר ואישור לקוח&nbsp;</strong></u></span>

						<div _ngcontent-c34="" style="margin-right: 40px;"><span _ngcontent-c34="" style="color:#000080">3.1&nbsp;&nbsp; &nbsp;השירותים המסופקים באתר:&nbsp;</span></div>

						<div _ngcontent-c34="" style="margin-right: 80px;"><span _ngcontent-c34="" style="color:#000080">3.1.1&nbsp;&nbsp; &nbsp;האתר פורס בפני הלקוח את השירותים המסופקים על ידי החברה ותנאיהם, כפי שיתעדכנו מעת לעת, ובין היתר הצטרפות למנוי, קבלת מידע על חשבוניות (בין אם בחשבון המנוי ובין אם בחשבון המזדמן), לרבות פירוט הנסיעות בגין אותן החשבוניות, בגין תקופת זמן כפי שתקבע מעת לעת, על ידי דרך ארץ, מידע על חשבוניות שטרם נפרעו וכן אפשרות לתשלום חשבוניות, עדכון פרטים אישיים, עדכון אמצעי תשלום, הוספה והסרה של רכבים, הפקת דוחות ועוד.</span></div>

						<div _ngcontent-c34="" style="margin-right: 80px;"><span _ngcontent-c34="" style="color:#000080">3.1.2&nbsp;&nbsp; &nbsp;מידע על כביש 6, תעריפי נסיעה וכיו"ב.&nbsp;<br _ngcontent-c34="">
						<span _ngcontent-c34="" style="line-height:1.6">הלקוח מאשר כי מעת לעת יעודכנו השירותים הניתנים דרך האתר וכי ככל שהלקוח יקבל שירותים אלה, הוא מאשר כי, יחולו עליו תנאי השימוש דנן.&nbsp;</span></span></div>

						<div _ngcontent-c34="" style="margin-right: 40px;"><span _ngcontent-c34="" style="color:#000080">3.2&nbsp;&nbsp; &nbsp;הלקוח <strong _ngcontent-c34="">מאשר כי השימוש באתר מהווה הסכמה מצידו לקבלת כל השירותים הנ"ל בגין <u _ngcontent-c34="">כל </u>הרכבים תחת <u _ngcontent-c34="">כל </u>חשבונות המנוי והמזדמן הרשומים על שמו וכן כי ידוע לו שלא ניתן לבחור לקבל את השירותים רק בגין חלק מהחשבונות.</strong></span></div>

						<div _ngcontent-c34="" style="margin-right: 40px;"><span _ngcontent-c34="" style="color:#000080">3.3&nbsp;&nbsp; &nbsp;הלקוח מאשר, כי לצורך קבלת חלק מהשירותים הוא יתבקש להזדהות ו/או לעבור הליך אימות, באופן שיקבע מעת לעת על ידי החברה. הלקוח מאשר ומתחייב כי ככל שנמסר לו על ידי החברה שם משתמש ו/או סיסמה הוא יעשה בהם שימוש לצרכיו האישיים בלבד. כמו כן הלקוח מתחייב לנקוט בכל האמצעים לשמירת שם המשתמש והסיסמה.</span></div>

						<div _ngcontent-c34="" style="margin-right: 40px;"><span _ngcontent-c34="" style="color:#000080">3.4&nbsp;&nbsp; &nbsp;הלקוח מאשר כי החברה רשאית להשתמש בקוקיות (COOKIES) לצורך תפעולו השוטף והתקין של האתר ובכלל זה כדי לאסוף נתונים סטטיסטיים אודות השימוש באתר, לאימות פרטים, כדי להתאים את האתר להעדפות אישיות של המשתמש, לצרכי שיווק ולצרכי אבטחת מידע.&nbsp;</span></div>

						<div _ngcontent-c34="" style="margin-right: 40px;"><span _ngcontent-c34="" style="color:#000080">קוקיות משמשות גם כדי לייתר את הצורך בהזנת פרטי משתמש בכל פעם שהוא מבקר מחדש במדורים באתר המחייבים רישום ככל שישנם כאלה. קוקיות הן קבצי טקסט שהדפדפן במחשבו של המשתמש יוצר לפי פקודה ממחשבי החברה. חלק מהקוקיות יפקעו כאשר המשתמש יסגור את הדפדפן ואחרות נשמרות על גבי הכונן הקשיח במחשב שלו. המידע בקוקיות מוצפן והחברה נוקטת צעדי זהירות כדי להבטיח שרק מחשבי החברה יוכלו לקרוא ולהבין את המידע האגור בהם.</span></div>

						<div _ngcontent-c34="" style="margin-right: 40px;"><span _ngcontent-c34="" style="color:#000080">3.5&nbsp;&nbsp; &nbsp;הלקוח מאשר כי גם במקרה בו לא סיים את הליך ההצטרפות באתר – הפרטים אשר מסר בהליך ההצטרפות ישמשו את החברה כדי לבדוק מדוע לא סיים את ההליך כאמור.&nbsp;</span></div>
						<br _ngcontent-c34="">
						<span _ngcontent-c34="" style="color:#000080">4&nbsp;&nbsp; &nbsp;<strong _ngcontent-c34=""><u _ngcontent-c34="">קניין רוחני&nbsp;</u></strong></span>

						<div _ngcontent-c34="" style="margin-right: 40px;"><span _ngcontent-c34="" style="color:#000080">4.1&nbsp;&nbsp; &nbsp;כל המידע המצוי באתר ו/או הדפים המופיעים באתר הינו רכושה הבלעדי של החברה. לפיכך, חל איסור על העתקה או כל פעולה אחרת מבלי לקבל את אישור החברה לכך. יובהר, כי גם אם יינתן אישור שכזה, הרי שיהיה זה אישור לשימוש לצרכים אישיים בלבד ולא לצרכים מסחריים.&nbsp;</span></div>

						<div _ngcontent-c34="" style="margin-right: 40px;"><span _ngcontent-c34="" style="color:#000080">4.2&nbsp;&nbsp; &nbsp;הסימנים באתר הינם סימני מסחר המהווים קניינים של החברה. אין לעשות כל פעולה אשר יש בה כדי לפגוע בזכויות היוצרים או בזכויות קניין רוחני אחרות של החברה.&nbsp;</span></div>

						<div _ngcontent-c34="" style="margin-right: 40px;"><span _ngcontent-c34="" style="color:#000080">4.3&nbsp;&nbsp; &nbsp;חל איסור על שינוי, העתקה, הפצה, פרסום של מידע, שירות או תוכנה שמקורם באתר זה.&nbsp;</span></div>
						<br _ngcontent-c34="">
						<span _ngcontent-c34="" style="color:#000080">5&nbsp;&nbsp; &nbsp;<strong _ngcontent-c34=""><u _ngcontent-c34="">הגנת פרטיות, מידע ואבטחת מידע&nbsp;</u></strong></span>

						<div _ngcontent-c34="" style="margin-right: 40px;"><span _ngcontent-c34="" style="color:#000080">5.1&nbsp;&nbsp; &nbsp;החברה רשאית לאסוף נתונים אודות לקוח ופעולותיו ולעבדם בכל צורה שהיא. החברה תוכל לעשות שימוש בנתונים אלה לצורך שיפור השרות, טיפול בתלונות, למטרות סטטיסטיות שונות וכו'.&nbsp;</span></div>

						<div _ngcontent-c34="" style="margin-right: 40px;"><span _ngcontent-c34="" style="color:#000080">5.2&nbsp;&nbsp; &nbsp;החברה שומרת לעצמה הזכות לחשוף מידע אישי אודות לקוחותיה או אודות השימוש שלהם באתר כולל תוכן השימוש, ללא קבלת רשות מהלקוחות, אם החברה מאמינה בתום לב כי פעולה זו חיונית כדי: לציית לדרישות הדין או הליך משפטי; להגן על זכויות או על קניין של החברה; לאכוף את הסכם השימוש ו/או תנאי השימוש; להגן על האינטרסים של לקוחותיה או של אחרים.&nbsp;</span></div>

						<div _ngcontent-c34="" style="margin-right: 40px;"><span _ngcontent-c34="" style="color:#000080">5.3&nbsp;&nbsp; &nbsp;הלקוח מאשר כי ידוע לו כי השימוש באתר חשוף לסיכונים הכרוכים בשימוש ברשת האינטרנט לרבות וירוסים, סוסים טרויאניים וכד', ציתות, פריצה, התחזות והונאות מכוונות אחרות. החברה משקיעה מאמץ רב בהגנה מפני סיכונים אלה אך למרות זאת אין אפשרות להגנה מוחלטת. לפיכך, יתכנו נזקים כתוצאה מהתממשות הסיכונים, לרבות גילוי ו/או שיבוש המידע במערכות, שיבוש בהוראות/בקשות, פעולות לא מורשות, שיבושים בפעילות האתר לרבות אי ביצוע ו/או ביצוע שגוי ו/או ביצוע מאוחר של הוראה, חוסר זמינות של חלק משרותי האתר וכיוצ"ב.&nbsp;</span></div>

						<div _ngcontent-c34="" style="margin-right: 40px;"><span _ngcontent-c34="" style="color:#000080">5.4&nbsp;&nbsp; &nbsp;החברה שומרת לעצמה את הזכות לסרב להעניק גישה לאתר או לחלקים ממנו לכל משתמש, לפי שיקול דעתה הבלעדי וללא מתן התראה מוקדמת וללקוח לא תהיה כל טענה ו/או דרישה ו/או תביעה בעניין.<br _ngcontent-c34="">
						<br _ngcontent-c34="">
						<span _ngcontent-c34="" style="line-height:1.6">&nbsp;מבלי לגרוע מהאמור, החברה תהא רשאית למנוע לאלתר (ואף לחסום) ממשתמש לעשות שימוש באתר בכל אחד מהמקרים הבאים:</span></span></div>

						<div _ngcontent-c34="" style="margin-right: 80px;"><span _ngcontent-c34="" style="color:#000080">5.4.1&nbsp;&nbsp; &nbsp;המשתמש הפר תנאי מתנאי השימוש.&nbsp;</span></div>

						<div _ngcontent-c34="" style="margin-right: 80px;"><span _ngcontent-c34="" style="color:#000080">5.4.2&nbsp;&nbsp; &nbsp;המשתמש מסר בעת הרישום ו/או בעת השימוש באתר פרטים שגויים במתכוון.&nbsp;</span></div>

						<div _ngcontent-c34="" style="margin-right: 80px;"><span _ngcontent-c34="" style="color:#000080">5.4.3&nbsp;&nbsp; &nbsp;המשתמש ביצע מעשה או מחדל שיש בו כדי לפגוע בחברה ו/או בפעילות התקינה של האתר.&nbsp;</span></div>

						<div _ngcontent-c34="" style="margin-right: 40px;"><span _ngcontent-c34="" style="color:#000080">5.5&nbsp;&nbsp; &nbsp;מדיניות הגנת הפרטיות של החברה מפורטת בקישור הבא &nbsp;<u _ngcontent-c34=""><a _ngcontent-c34="" href="https://www.kvish6.co.il/itempics/PTUT.pdf" target="_blank">https://www.kvish6.co.il/itempics/PTUT.pdf</a></u>. בכל מקרה של סתירה בין האמור בתנאי אלה לבין מדיניות הגנת הפרטיות כאמור, יגבר האמור במדיניות הגנת הפרטיות.</span></div>
						<br _ngcontent-c34="">
						<span _ngcontent-c34="" style="color:#000080">6&nbsp;&nbsp; &nbsp;<strong _ngcontent-c34=""><u _ngcontent-c34="">הגבלת אחריות&nbsp;</u></strong></span>

						<div _ngcontent-c34="" style="margin-right: 40px;"><span _ngcontent-c34="" style="color:#000080">6.1&nbsp;&nbsp; &nbsp;האחריות על השימוש באתר והאחריות על תוצאות השימוש באתר הינה על הלקוח בלבד, והחברה ו/או מי מטעמה ו/או נושאי המשרה שלה לא יישאו בכל אחריות בגין הפסד ו/או נזק העלולים להיגרם, במישרין או בעקיפין, כתוצאה מהשימוש באתר ו/או אי השימוש בו. &nbsp;&nbsp;&nbsp; &nbsp;</span></div>

						<div _ngcontent-c34="" style="margin-right: 40px;"><span _ngcontent-c34="" style="color:#000080">6.2&nbsp;&nbsp; &nbsp;המידע המופיע באתר הינו נכון למועד הצגתו בלבד. בכל מקרה של סתירה או אי התאמה בין המידע המופיע באתר ובין המידע המופיע במערכות החברה, יגבר המידע המופיע במערכות החברה, והחברה ו/או מי מטעמה ו/או נושאי המשרה שלה לא יישאו בכל אחריות בגין הפסד ו/או נזק העלולים להיגרם, במישרין או בעקיפין, כתוצאה מסתירה כאמור.&nbsp;</span></div>

						<div _ngcontent-c34="" style="margin-right: 40px;"><span _ngcontent-c34="" style="color:#000080">6.3&nbsp;&nbsp; &nbsp;השירותים הניתנים באתר ניתנים כמות שהם (AS IS). לא תהיה ללקוח כל תביעה/תלונה/דרישה כלפי החברה בשל תכונות השירות, יכולותיו, מגבלותיו או התאמתו לצרכיו האישיים.&nbsp;</span></div>

						<div _ngcontent-c34="" style="margin-right: 40px;"><span _ngcontent-c34="" style="color:#000080">6.4&nbsp;&nbsp; &nbsp;ידוע ללקוח שתיתכן אפשרות שבמידע המופיע באתר נפלו שגיאות ו/או אי דיוקים וכיו"ב, טעויות אנוש, תקלות מחשב או טעויות סופר וכד' ו/או שינויים אשר נגרמו על ידי מי שאינו מורשה לעסוק בכך, למרות שהחברה עושה כל שביכולתה למנוע מצבים כאלה.&nbsp;</span></div>

						<div _ngcontent-c34="" style="margin-right: 40px;"><span _ngcontent-c34="" style="color:#000080">6.5&nbsp;&nbsp; &nbsp;טעות בהזנת הנתונים המתייחסים לתשלום ו/או לכל פרט אחר הינה באחריות הלקוח בלבד.&nbsp;</span></div>

						<div _ngcontent-c34="" style="margin-right: 40px;"><span _ngcontent-c34="" style="color:#000080">6.6&nbsp;&nbsp; &nbsp;מבלי לגרוע מכל האמור בכל מקום אחר בתנאים אלה, החברה ו/או מי מטעמה ו/או נושאי המשרה שלה לא יישאו בכל אחריות, מפורשת או משתמעת, בקשר עם האתר לרבות כל תוכן ושירות בו, ו/או בקשר להתאמתו ו/או למטרה ספציפית ו/או לדרישות הלקוח. &nbsp;כמו כן, החברה ו/או מי מטעמה ו/או נושאי המשרה שלה אינם אחראים לנזק אשר עשוי להיגרם ללקוח כתוצאה מתוכן האתר ו/או מהשירותים הניתנים בו ו/או כתוצאה מתקלה/פגם או אופן תפעול שגוי של התוכנה המפעילה את האתר ו/או את הגישה אליו, לרבות זמינות האתר. מבלי לגרוע מהאמור לעיל, הלקוח מאשר ומסכים כי החברה /ואו מי מטעמה ו/או נושאי המשרה שלה ו/או כל גוף או אדם הקשורים ו/או המעורבים ביצירת האתר או תוכנו יהיו פטורים מכל אחריות וחבות, בקשר לכל נזק, פגיעה הפסד או הוצאה, בין אם ישירים ובין אם עקיפים, הקשורים בשירותים ו/או בשימוש באתר או חוסר היכולת להשתמש באתר וכי כל אחריות וסיכון בקשר עם כל האמור יחול על הלקוח בלבד.</span></div>

						<div _ngcontent-c34="" style="margin-right: 40px;"><span _ngcontent-c34="" style="color:#000080">6.7&nbsp;&nbsp; &nbsp;באתר עשויים להיות גם לינקים (קישורים לאתרים אחרים אשר אינם מופעלים על ידי החברה). קישורים אלה אינם בשליטת ו/או אחריות החברה והיא אינה אחראית ו/או מפקחת על תוכנם. אין בקישורים אלה כדי להעיד על הסכמה ו/או אחריות של החברה לתכנים המופיעים שם ו/או לאמינותם ו/או עדכניותם ו/או תקינותם ו/או חוקיותם ו/או לכל מה שאמור ונכלל בהם, לרבות מדיניות הגנת פרטיות ו/או תנאי שימוש. החברה לא תהיה אחראית לכל תוצאה אשר תגרם כתוצאה משימוש באתרים אלה ו/או מהסתמכות עליהם. בכל בעיה וטענה יש לפנות ישירות לבעלי האתרים.&nbsp;</span></div>

						<div _ngcontent-c34="" style="margin-right: 40px;"><span _ngcontent-c34="" style="color:#000080">הלקוח מאשר כי ידוע לו כי התחזות לאדם ו/או לגוף אחר ו/או מסירת פרטים כוזבים ו/או שימוש בשם בדוי מהווים עבירה פלילית וכי נגד משתמשים כאמור יינקטו כל הצעדים הקבועים בדין, לרבות במקרה הצורך תביעה בגין כל הנזקים שנגרמו לחברה, אם נגרמו.&nbsp;</span></div>

						<div _ngcontent-c34="" style="margin-right: 40px;"><span _ngcontent-c34="" style="color:#000080">6.8&nbsp;&nbsp; &nbsp;אין בהגבלת האחריות בסעיף זה כדי לגרוע מהגבלת אחריות אחרת בתנאי השימוש ומדיניות הפרטיות.&nbsp;</span></div>
						<br _ngcontent-c34="">
						<span _ngcontent-c34="" style="color:#000080">7&nbsp;&nbsp; &nbsp;<strong _ngcontent-c34=""><u _ngcontent-c34="">שינויים באתר</u></strong>&nbsp;</span>

						<div _ngcontent-c34="" style="margin-right: 40px;"><span _ngcontent-c34="" style="color:#000080">7.1&nbsp;&nbsp; &nbsp;החברה שומרת לעצמה הזכות לשנות האתר מעת לעת, היקף וזמינות השירותים המוצעים בו וכן כל היבט אחר הכרוך בתפעולו, מבלי שתצטרך להודיע על כך מראש. שינויים שכאלה, יכול שייווצרו כתוצאה מאופיו המשתנה של האינטרנט וכן בשל שינויים טכנולוגיים המתבצעים ברשת. יובהר, כי שינויים אלה עשויים לגרום לתקלות או לאי נוחות, אך ללקוח לא תהא כל תביעה/תלונה/דרישה כלפי החברה עקב ביצועם.&nbsp;</span></div>

						<div _ngcontent-c34="" style="margin-right: 40px;"><span _ngcontent-c34="" style="color:#000080">7.2&nbsp;&nbsp; &nbsp;החברה תהא רשאית לערוך שינוי בתנאי השימוש באתר מבלי שתצטרך ליתן על כך הודעה מוקדמת. משכך, יש לעיין בתנאי השימוש בכל כניסה מחודשת לאתר, על מנת להתעדכן בהוראותיו.&nbsp;</span></div>
						<br _ngcontent-c34="">
						<span _ngcontent-c34="" style="color:#000080">8&nbsp;&nbsp; &nbsp;<u _ngcontent-c34=""><strong _ngcontent-c34="">תמיכה טכנית&nbsp;</strong></u></span>

						<div _ngcontent-c34="" style="margin-right: 40px;"><span _ngcontent-c34="" style="color:#000080">החברה אינה מתחייבת להעמיד לרשות הלקוח תמיכה טכנית אודות תפעולו של האתר ו/או שירותים המסופקים באמצעותו. הלקוח מאשר כי הוא לא יעלה כל תלונה כלפי החברה נוכח העדר תמיכה כאמור.&nbsp;</span></div>
						<br _ngcontent-c34="">
						<span _ngcontent-c34="" style="color:#000080">9&nbsp;&nbsp; &nbsp;<u _ngcontent-c34=""><strong _ngcontent-c34="">הפסקת שרות</strong></u>&nbsp;</span>

						<div _ngcontent-c34="" style="margin-right: 40px;"><span _ngcontent-c34="" style="color:#000080">החברה רשאית בכל עת להחליט כי היא מפסיקה את פעילותו של האתר או משנה את אופיו. הודעה בדבר סגירה/שינוי תפורסם 7 ימים טרם הביצוע.&nbsp;</span></div>
						<br _ngcontent-c34="">
						<span _ngcontent-c34="" style="color:#000080">10&nbsp;&nbsp; &nbsp;<u _ngcontent-c34=""><strong _ngcontent-c34="">הדין הנוהג וסמכות שיפוט</strong></u>&nbsp;</span>

						<div _ngcontent-c34="" style="margin-right: 40px;"><span _ngcontent-c34="" style="color:#000080">על השימוש באתר יחולו דיני מדינת ישראל, ולבתי המשפט במחוז תל אביב יפו תהא&nbsp;</span></div>

						<div _ngcontent-c34="" style="margin-right: 40px;"><span _ngcontent-c34="" style="color:#000080">הסמכות הבלעדית והיחידה בכל עניין הקשור בהם.&nbsp;</span></div>

            </div>

            <!---->
        </div>
      </div>

		<div _ngcontent-c34="" class="row rowSpacerSmall"></div>
        <div _ngcontent-c34="" class="row rowSpacerSmall">
          <div _ngcontent-c34="" class="col-xs-5 col-sm-3">
            <button _ngcontent-c34="" class="btn btn-block cancel-btn">ביטול
            </button>
          </div>
          <div _ngcontent-c34="" class="col-xs-5 col-xs-offset-2 col-sm-3 col-sm-offset-6">
            <button _ngcontent-c34="" class="btn btn-primary btn-block submit-btn">אשר
            </button>
          </div>
        </div>
    </div>
  </div>
</div>
</div></sls-modal-payments-external-legal-terms></sls-modal-component-renderer></sls-root>


</body></html>