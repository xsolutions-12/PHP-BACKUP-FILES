<!DOCTYPE html>
<html>
<head>
	<title>Managing Trustee</title>
	<?php include_once 'include/css.php'; ?>
</head>
<body class="about-page">
	<div class="container">
		<div class="main-wrap">
			<?php include_once 'include/header.php'; ?>
			<div class="inner-page-sec">
				<div class="row">
					<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<div class="inner-page-sec">
							<h1 class="inner-title">EDUCATION FOR LIFE - THE NEED OF THE HOUR</h1>
						</div>
						<div class="row">
							<div class="col-lg-9 col-md-9">
								<h2 class="centr-qute">"Pursuing MCA in IISIT is for a gainful employment <br>and a good quality life".</h2>
								<p>"Education without character, commerce without morality, politics without principles, science without humanity, religion without love, culture without unity, administration without justice, knowledge without application, and patriotism without sacrifice are not only useless but positively dangerous"</p>

								<p>When the whole world is passing through an unprecedented crisis of immense magnitude, it is the future of education and education of the future that become interlinked just like the future of man and man of the future.</p>
								<h3 class="centr-qute2">"There are no under developed countries in the world, <br>there are only under managed ones"</h3>
							</div>
							<div class="col-lg-3 col-md-3">
								<div class="img-box">
									<img src="images/mt.png" class="img-fluid">
									<h5>K N Bhagat <span>(Managing Trustee)</span></h5>
								</div>
							</div>
							<div class="col-lg-12 col-md-12">
								<p>The destiny of the nation is decided in the classroom of educational institutions and therefore it becomes necessary to be realised that sooner the better; now or never; that this is time for reflection, reaction, resound.</p>
								<p class="text-center"><strong><i>"The need of the hour is to prepare qualified professionals"</i></strong></p>

								<h2 class="text-center">Mother India awaits your Selfless Service!</h2>
								<p>"Young men have to spring into the sphere of action and strive to the best for building up a resurgent India, and a happy peaceful world. They must shed the desire for power, the desire to uproot corruption and immortality, and the urge to work hard should firmly be implanted in the heart of every student. Mother India's future depends on them. Even as it is the duty of children to serve and please their mother, it is bounden duty of every child of mother India to make her happy. To serve the motherland selflessly should be the sacred ideal of one's life.</p>
							</div>
						</div>
					</div>
					<?php include_once 'include/footer.php'; ?>
				</div>
			</div>
		</div>
	</div>




	
	<?php include_once 'include/js.php'; ?>

</body>
</html>