<!DOCTYPE html>
<html>
<head>
	<title>Directors</title>
	<?php include_once 'include/css.php'; ?>
</head>
<body class="about-page">
	<div class="container">
		<div class="main-wrap">
			<?php include_once 'include/header.php'; ?>
			<div class="inner-page-sec">
				<div class="row">
					<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<div class="">
							<h1 class="inner-title">Directors</h1>
						</div>
						<div class="row align-items-center">
							<div class="col-lg-3 col-md-3 col-sm-3">
								<div class="img-box img-b-2">
									<img src="images/satapathy.gif" class="img-fluid">
									<h5>PROF. P.K. SATAPATHY <span>Director (Academics)</span></h5>
								</div>
							</div>
							<div class="col-lg-9 col-md-9 col-sm-9">
								<p>Graduated with Economic Honours, standing 2nd among the successful candidate of Utkal University. Prof. Satapathy completed his Master degree in Economics from Revensa College, Cuttack in 1957.</p>

								<p>He joined Orissa Education Service as a lecture in Economics in 1960 and promoted to grade of readir in 1972.</p>

								<p>On retirement from Orissa Education Service Prof. Satapathy joined as Director (Acdm.) of IISIT & BIMIT twin Institutes of OTTET, in August 1995 and is continuing as such.</p>
							</div>
						</div>

						<div class="row align-items-center">
							<div class="col-lg-3 col-md-3 col-sm-3">
								<div class="img-box img-b-2">
									<img src="images/dc_mishra.png" class="img-fluid">
									<h5>Director( Management Programme) <span>Prof. D.C Mishra</span></h5>
								</div>
							</div>
							<div class="col-lg-9 col-md-9 col-sm-9">
								<p>Prof. Debendra C. Misra, IAS(Rtd) In last 35 years of service in public sector RSP (72-75), H & UD Dept. Govt. of Orissa (75-95) and in IAS (95-07) have served as a catalyst for Urban Community Development, Rural Development and Management, Disaster Management (HRD), Relationship Management, Financial Operations.</p>
							</div>
						</div>
					</div>
					<?php include_once 'include/footer.php'; ?>
				</div>
			</div>
		</div>
	</div>




	
	<?php include_once 'include/js.php'; ?>

</body>
</html>