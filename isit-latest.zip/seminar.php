<!DOCTYPE html>
<html>
<head>
	<title>Seminar</title>
	<?php include_once 'include/css.php'; ?>
</head>
<body class="about-page">
	<div class="container">
		<div class="main-wrap">
			<?php include_once 'include/header.php'; ?>
			<div class="owl-carousel banner-slider">
				<div class="slider-item">
					<img src="images/seminar1.jpg" class="img-fluid">
				</div>
				<div class="slider-item">
					<img src="images/seminar2.jpg" class="img-fluid">
				</div>
				<div class="slider-item">
					<img src="images/seminar3.jpg" class="img-fluid">
				</div>
				<div class="slider-item">
					<img src="images/seminar4.jpg" class="img-fluid">
				</div>
			</div>
			<div class="inner-page-sec">
				<div class="row">
					<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<h1 class="inner-title">SEMINAR - FACE TO FACE WITH INDUSTRY AND ACADEMIA</h1>
						<p>Seminars, Group discussions and regular interactive sessions are conducted in the presence of experienced personnel from academia, industry and corporate to groom the students gain confidence in making them corporate friendly while polishing their communication skills and personality traits along with other behavioral nuances and converting their skills that is next to none. </p>

					<?php include_once 'include/footer.php'; ?>
				</div>
			</div>
		</div>
	</div>




	
	<?php include_once 'include/js.php'; ?>

</body>
</html>