<!DOCTYPE html>
<html>
<head>
	<title>Placement</title>
	<?php include_once 'include/css.php'; ?>
</head>
<body class="about-page">
	<div class="container">
		<div class="main-wrap">
			<?php include_once 'include/header.php'; ?>
			<div class="inner-page-sec">
				<div class="row">
					<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<h1 class="inner-title">BIMIT Placement Details</h1>
						<table border="0" cellspacing="1" cellpadding="0"  style="font-size: 13px;" width="825" height="204" align="center" bgcolor="#F8F4E9">
<tbody>
<tr style="background-color: #f5f5f5;">
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top"><strong>Sl No. </strong></td>
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top"><strong>Student Name </strong></td>
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top"><strong>Company</strong></td>
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top"><strong>Package(Rs Lac PA)</strong></td>
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top"><strong>Placement Period </strong></td>
</tr>
<tr style="background-color: #f5f5f5;">
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top">1.</td>
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top">Isha Tripathy</td>
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top">Kotak Securities Ltd</td>
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top">Rs.2. 5</td>
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top">Nov. 2010</td>
</tr>
<tr style="background-color: #f5f5f5;">
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top">2.</td>
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top">R. Kiran Kumar</td>
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top">Kotak Securities Ltd</td>
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top">Rs.2. 5</td>
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top">Nov. 2010</td>
</tr>
<tr style="background-color: #f5f5f5;">
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top">3.</td>
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top">Chandan Swain</td>
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top">Kotak Securities Ltd</td>
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top">Rs.1. 8</td>
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top">Nov. 2010</td>
</tr>
<tr style="background-color: #f5f5f5;">
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top">4.</td>
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top">Rosalin Padhi</td>
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top">Kotak Securities Ltd<strong>&nbsp;</strong></td>
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top">Rs.1,.8</td>
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top">Nov. 2010</td>
</tr>
<tr style="background-color: #f5f5f5;">
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top">5.</td>
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top">Panchanan Sahu</td>
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top">Kotak Securities Ltd</td>
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top">Rs.1. 8</td>
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top">Nov. 2010</td>
</tr>
<tr style="background-color: #f5f5f5;">
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top">6</td>
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top">Panchanan Sahu </td>
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top">SBI Life</td>
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top">2.5 lacs</td>
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top">Dec. 2010</td>
</tr>
<tr style="background-color: #f5f5f5;">
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top">7</td>
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top">Anindita Mishra </td>
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top">SBI Life</td>
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top">2.5 lacs</td>
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top">Dec. 2010</td>
</tr>
<tr style="background-color: #f5f5f5;">
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top">8</td>
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top">Babi Ranjan Sahoo </td>
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top">Ventura Security Ltd</td>
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top">1.2 to 1.92 lacs</td>
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top">Feb. 2011</td>
</tr>
<tr style="background-color: #f5f5f5;">
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top">9</td>
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top">Swarna Sarika Mohapatra </td>
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top">Ventura Security Ltd</td>
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top">1.2 to 1.92 lacs</td>
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top">Feb. 2011</td>
</tr>
<tr style="background-color: #f5f5f5;">
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top">10</td>
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top">Chinmayee Tripathy </td>
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top">Ventura Security Ltd</td>
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top">1.2 to 1.92 lacs</td>
<td style="background-color: #ffffff; padding: 3px" align="left" valign="top">Feb. 2011</td>
</tr>
</tbody>
</table>
						
					<?php include_once 'include/footer.php'; ?>
				</div>
			</div>
		</div>
	</div>




	
	<?php include_once 'include/js.php'; ?>

</body>
</html>