<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
	<p class="copy-rit">All Rights Reserved. © 2020</p>
</div>