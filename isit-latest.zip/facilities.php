<!DOCTYPE html>
<html>
<head>
	<title>Affiliation</title>
	<?php include_once 'include/css.php'; ?>
</head>
<body class="about-page">
	<div class="container">
		<div class="main-wrap">
			<?php include_once 'include/header.php'; ?>
			<div class="row">
				<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="inner-page-sec faciliti">
						<h1 class="inner-title">Facilities</h1>
						<div class="row">
							<div class="col-xl-3 col-lg-3 col-smd-3 col-sm-4 col-xs-12">
								<img src="images/hostel.png" class="img-fluid">
							</div>
							<div class="col-xl-9 col-lg-9 col-smd-9 col-sm-8 col-xs-12">
								<h4 class="inner-title2">HOSTEL</h4>
								<p>The Institute provides hostel facilities to the students by hiring the buildings. Each student is provided reasonably furnished room on sharing basis for facilitating development of understanding and mutual help.</p>

								<p>To facilitate comfortable stay and provide a feel happy environment the institute provides accommodation assistance.</p>

								<p>The Institute has two Girl’s Hostel and one Boy’s Hostel.</p>

								<p>The rooms in the hostel can accommodate one / two / three students in a single room who can avail the facilities provided by the institutes.</p>
							</div>
						</div>
						<div class="row">
							<div class="col-xl-3 col-lg-3 col-smd-3 col-sm-4 col-xs-12">
								<img src="images/facility2.png" class="img-fluid">
							</div>
							<div class="col-xl-9 col-lg-9 col-smd-9 col-sm-8 col-xs-12">
								<h4 class="inner-title2">TRANSPORTATION</h4>
								<p>The Institute has its own transportation facility since 2008-2009. Two buses are running in two different routes to pick up all the interested students covering almost all the junctions of Bhubaneswar city. This service is not only limited to academics but also extended for Industrial Tours and other important activities like Placement, Picnic etc.</p>
							</div>
						</div>
						<div class="row">
							<div class="col-xl-3 col-lg-3 col-smd-3 col-sm-4 col-xs-12">
								<img src="images/canteen_img.png" class="img-fluid">
							</div>
							<div class="col-xl-9 col-lg-9 col-smd-9 col-sm-8 col-xs-12">
								<h4 class="inner-title2">CANTEEN</h4>
								<p>The Institute has its own canteen facility for both staffs as well as students.</p>
								<p>It is providing healthy, hygienic and pure vegetarian food.</p>
							</div>
						</div>
						<div class="row">
							<div class="col-xl-3 col-lg-3 col-smd-3 col-sm-4 col-xs-12">
								<img src="images/medicine.png" class="img-fluid">
							</div>
							<div class="col-xl-9 col-lg-9 col-smd-9 col-sm-8 col-xs-12">
								<h4 class="inner-title2">FIRST AID</h4>
								<p>The Institute has an in house provision of First-Aid treatment for all the inhabitants. A Pharmacist takes care of the above throughout the working hours. The First-Aid kit presently contains near about 20 emergency medicines.</p>
							</div>
						</div>
					</div>
				</div>
				<?php include_once 'include/footer.php'; ?>
			</div>
		</div>
	</div>




	
	<?php include_once 'include/js.php'; ?>

</body>
</html>