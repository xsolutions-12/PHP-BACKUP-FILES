<!DOCTYPE html>
<html>
<head>
	<title>Study Tour - Where The Education Gets The Wings Of Experience</title>
	<?php include_once 'include/css.php'; ?>
</head>
<body class="about-page">
	<div class="container">
		<div class="main-wrap">
			<?php include_once 'include/header.php'; ?>
			<div class="owl-carousel banner-slider">
				<div class="slider-item">
					<img src="images/studytour1.jpg" class="img-fluid">
				</div>
				<div class="slider-item">
					<img src="images/studytour2.jpg" class="img-fluid">
				</div>
				<div class="slider-item">
					<img src="images/studytour3.jpg" class="img-fluid">
				</div>
			</div>
			<div class="inner-page-sec">
				<div class="row">
					<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<h1 class="inner-title">Study Tour - Where The Education Gets The Wings Of Experience</h1>
						<p>Every year students of BIMIT visit places of academic importance that spreads different corners of India and gain experience that is all together refreshing and educative to add substance to their career prospects. Apart from that a visit to Prasanthinilayam,Puttaparthy(Andhrapradesh) during the study tour is a must, to source the paramount benediction of the supreme soul, Bhagawan Sri Sathya Sai Baba.</p>		
					<?php include_once 'include/footer.php'; ?>
				</div>
			</div>
		</div>
	</div>




	
	<?php include_once 'include/js.php'; ?>

</body>
</html>