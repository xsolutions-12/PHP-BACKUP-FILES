<!doctype html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>DKM Group</title>
    <!-- CSS Start -->
    <?php include 'includes/css.php'; ?>
    <!-- CSS End -->
</head>

<body>
    <!-- Preloader Start -->
    <?php include 'includes/loader.php'; ?>
    <!-- Preloader End -->

    <!-- Header Start -->
    <?php include 'includes/header.php'; ?>
    <!-- Header End -->

    <!-- breadcumb start -->
    <div class="breadcumb-wrapper" data-bg-src="assets/img/bg/inn-ban.jpeg">
        <div class="container">
            <div class="breadcumb-content">
                <h1 class="breadcumb-title">Divison</h1>
                <ul class="breadcumb-menu">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="division.php">Divison</a></li>
                    <li>DKM Insurance</li>
                </ul>
            </div>
        </div>
    </div>
    <!-- breadcumb End -->

    <section class="space-top space-extra-bottom">
        <div class="container">
            <div class="row">
                <div class="col-xxl-12 col-lg-12">
                    <div class="page-single mb-40">
                        <div class="page-content">
                            <ul class="nav product-tab-style1 mt-40 pb-0" id="productTab" role="tablist">
                                <li class="nav-item" role="presentation"><a class="nav-link th-btn active"
                                        id="home-tab" data-bs-toggle="tab" href="#home" role="tab"
                                        aria-controls="description" aria-selected="false">Home</a></li>
                                <li class="nav-item" role="presentation"><a class="nav-link th-btn" id="reviews-tab"
                                        data-bs-toggle="tab" href="#about" role="tab" aria-controls="reviews"
                                        aria-selected="true">About Us</a></li>
                                <li class="nav-item" role="presentation"> <a class="nav-link th-btn" id="tech-tab"
                                        data-bs-toggle="tab" href="#services" role="tab" aria-controls="tech"
                                        aria-selected="true">Services</a></li>
                                <li class="nav-item" role="presentation"> <a class="nav-link th-btn" id="tech-tab"
                                        data-bs-toggle="tab" href="#team" role="tab" aria-controls="tech"
                                        aria-selected="true">Team</a></li>
                                <li class="nav-item" role="presentation"> <a class="nav-link th-btn" id="tech-tab"
                                        data-bs-toggle="tab" href="#choose" role="tab" aria-controls="tech"
                                        aria-selected="true">Why Choose Us?</a></li>
                                <li class="nav-item" role="presentation"> <a class="nav-link th-btn" id="tech-tab"
                                        data-bs-toggle="tab" href="#Clientele" role="tab" aria-controls="tech"
                                        aria-selected="true">Our Clientele </a></li>
                                <li class="nav-item" role="presentation"> <a class="nav-link th-btn" id="tech-tab"
                                        data-bs-toggle="tab" href="#tech" role="tab" aria-controls="tech"
                                        aria-selected="true">Gallery</a></li>
                                <li class="nav-item" role="presentation"> <a class="nav-link th-btn" id="tech-tab"
                                        data-bs-toggle="tab" href="#contact" role="tab" aria-controls="tech"
                                        aria-selected="true">Contact Us</a></li>
                            </ul>
                            <div class="tab-content" id="productTabContent">
                                <div class="tab-pane fade show active" id="home" role="tabpanel"
                                    aria-labelledby="description-tab">
                                    <p style="text-align: center; font-weight:600">Welcome to DKM Insurance Surveyors & Loss Assessors Pvt. Ltd.</p>
                                    <p class="mb-30">Established in 1986, this division serves as the cornerstone of DKM Group, providing expert marine surveying and loss assessment services to clients in Paradip port and beyond.</p>

                                </div>
                                <div class="tab-pane fade" id="about" role="tabpanel" aria-labelledby="reviews-tab">
                                    <p class="mb-30">Established in 2021, Captain Dilip Kumar Mishra Insurance Surveyor and Loss Assessor Pvt Ltd is one of the leading claims management solution providers in India. We are committed to delivering customized solutions in various fields of insurance, ensuring seamless end-to-end claim management from allotment to settlement. Our services encompass a wide range of insurance claims, including Fire, Engineering, Marine Cargo, Marine Hull, Miscellaneous, and Loss of Profit (LOP), all authorized under our IRDAI Corporate Surveyor License (Category A/ Fellow) (License No. IRDA/CORP/SLA-200110).<br>
                                    With a team of experienced professionals and loss adjusters led by Chief Executive Officer Capt. Jagat Krushna Patnaik (NAV ARCH, FIIISLA, FIIV), we handle high-value and small-value claims across PAN India, delivering excellence in claims management.</p>

                                </div>
                                <div class="tab-pane fade" id="services" role="tabpanel" aria-labelledby="tech-tab">
                                    <p style="font-weight: 600;">Loss Adjusting Services</p>
                                    <p>Our primary focus is on loss adjusting for various types of claims, ensuring precise and professional handling. Our services include:</p>
                                    <p>– Fire Claims: Comprehensive handling of property losses due to fire and other perils.</p>
                                    <p>– Marine Claims: Specialized surveys for marine cargo and hull claims.</p>
                                    <p>– Engineering Claims: Expertise in handling CAR, EAR, Machinery Breakdown, IAR, Mega Risk, CPM, and Electronics Insurance Policies.</p>
                                    <p>– Miscellaneous Claims: Coverage for Banker Indemnity Policies, Fidelity Guarantee Policies, Theft & Burglary, Jewelers Block, Sports & Specialties, Film & Media, Event Management Policies, Denial of Access Policies, and Special Contingency Policies.</p>
                                    <p>– LOP Claims: Detailed assessment of Loss of Profit claims.</p>
                                    <p>– Valuation: Accurate asset valuation to ensure correct insurance coverage.</p>
                                    <p>– Risk Inspections: Identifying and mitigating risks pre and post-incident.</p>
                                    <p>– Pre-dispatch Inspection (PDI): Ensuring cargo condition, packing, quantity, and weight before dispatch.</p>
                                    <p>– Forensic Audit of Books of Accounts: Uncovering fraud and financial discrepancies through detailed investigations.</p>

                                    <p style="font-weight: 600;">Marine Cargo Claims</p>
                                    <p>– Survey and loss assessment for cargo damages during transit.</p>
                                    <p>– P & I Surveys on behalf of P & I Clubs to assess potential risk</p>
                                    <p>– Route surveys for ODC cargo movement and heavy lift operations.</p>
                                    <p>– Cargo condition checks before export and upon arrival.</p>
                                    <p>– Supervision of loading operations and lashing studies for ODC and heavy lifts.</p>
                                    <p>– Specialized loss assessment for bulk cargo claims (liquid and dry).</p>
                                    

                                    <p style="font-weight: 600;">Additional Services</p>
                                    <p>– Risk Inspections: Comprehensive assessments to understand and mitigate risks.</p>
                                    <p>– Valuation: Accurate asset valuation for correct insurance coverage.</p>
                                    <p>– Pre-dispatch Inspection: Ensuring cargo condition and compliance before shipment.</p>
                                    <p>– Forensic Audit: Detailed investigations into financial records to uncover discrepancies and fraud.</p>
                                   




                                </div>
                                <div class="tab-pane fade" id="team" role="tabpanel" aria-labelledby="tech-tab">
                                    <p><b>– Managing Director:</b>Mr. Milan Mishra</p>
                                    <p><b>– CEO:</b>Mr. Jagat Krushna Patnaik (NAV ARCH, FIIISLA, FIIV)</p>
                                    <p><b>– Director:</b>Mr. Prasanjeet Mohanty</p>
                                    <p>Our team comprises highly specialized and dedicated professionals from various disciplines, including mechanical, electrical, and naval architecture engineering, as well as cost accountants. Our experts are well-versed in handling various claims, including CAR, EAR, Machinery Breakdown, IAR, Mega Risk, CPM, and Electronics Insurance Policies. Our experienced surveyors and staff are committed to delivering the highest standards of service. They are equipped to handle claims for manufacturing and engineering units, power generation stations, petrochemical units, warehouses, malls, shops, showrooms, and chemical units, ensuring comprehensive loss adjusting and risk management services.</p>                              
                                 
                                </div>
                                <div class="tab-pane fade" id="choose" role="tabpanel" aria-labelledby="tech-tab">
                                    <p class="mb-30">– Expertise: Our team consists of seasoned professionals with extensive experience in marine surveying, consultancy, and loss assessment.</p>
                                    <p>– Comprehensive Services: We offer a full range of services to meet all your marine operational needs.</p>
                                    <p>– Compliance: We ensure your operations comply with all relevant regulations and standards.</p>
                                    <p>– Efficiency: Our services are designed to enhance the efficiency and safety of your marine operations.</p>
                                    <p>– Client-Centric Approach: We prioritize our clients’ needs and provide tailored solutions to meet their specific requirements.</p>

                                </div>
                                <div class="tab-pane fade" id="Clientele" role="tabpanel" aria-labelledby="tech-tab">
                                    <div class="ship-table-section">
                                        <div class="table-container">
                                            <table>
                                                <tr>
                                                  <td>OPGC</td>
                                                  <td>IMFA</td>
                                                  <td>Paradeep Port</td>
                                                </tr>
                                                <tr>
                                                  <td>Gopalpur Port</td>
                                                  <td>Paradeep Phosphate Ltd</td>
                                                  <td>OTDC</td>
                                                </tr>
                                                <tr>
                                                  <td>IOCL</td>
                                                  <td>Rungta Mines Ltd</td>
                                                  <td>OSL</td>
                                                </tr>
                                                
                                               
                                            </table>
                                        </div>
                                    </div>

                                </div>
                                <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="tech-tab">
                                    <p style="font-weight:600">For more information or to request our services, please contact us at:</p>
                                    
                                    <p>B – 20, Ground Floor, Ananta Vihar, Phase II, Pokhariput, Bhubaneswar, Ph – 9853860321</p>
                                    <iframe src="https://www.google.com/maps/embed?pb=!1m13!1m8!1m3!1d7487.001161132967!2d85.806583!3d20.238064!3m2!1i1024!2i768!4f13.1!3m2!1m1!2zMjDCsDE0JzE3LjAiTiA4NcKwNDgnMzMuMCJF!5e0!3m2!1sen!2sin!4v1762940449498!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <!-- Footer Start -->
    <?php include 'includes/footer.php'; ?>
    <!-- Footer End -->

    <!-- ScrollToTop Start -->
    <?php include 'includes/scroll.php'; ?>
    <!-- ScrollToTop End -->

    <!-- JS Start -->
    <?php include 'includes/js.php'; ?>
    <!-- JS End -->
</body>

</html>