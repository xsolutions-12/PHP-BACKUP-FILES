<!doctype html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>DKM Group</title>
    <!-- CSS Start -->
    <?php include 'includes/css.php'; ?>
    <!-- CSS End -->
</head>

<body>
    <!-- Preloader Start -->
    <?php include 'includes/loader.php'; ?>
    <!-- Preloader End -->

    <!-- Header Start -->
    <?php include 'includes/header.php'; ?>
    <!-- Header End -->

    <!-- breadcumb start -->
    <div class="breadcumb-wrapper" data-bg-src="assets/img/bg/inn-ban.jpeg">
        <div class="container">
            <div class="breadcumb-content">
                <h1 class="breadcumb-title">Divison</h1>
                <ul class="breadcumb-menu">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="division.php">Divison</a></li>                  
                    <li>Maa Tarini Petrochemicals</li>
                </ul>
            </div>
        </div>
    </div>
    <!-- breadcumb End -->

    <section class="space-top space-extra-bottom">
        <div class="container">
            <div class="row">
                <div class="col-xxl-12 col-lg-12">
                    <div class="page-single mb-40">
                        <div class="page-content">
                            <ul class="nav product-tab-style1 mt-40 pb-0" id="productTab" role="tablist">
                                <li class="nav-item" role="presentation"><a class="nav-link th-btn active"
                                        id="home-tab" data-bs-toggle="tab" href="#home" role="tab"
                                        aria-controls="description" aria-selected="false">Home</a></li>
                                <li class="nav-item" role="presentation"><a class="nav-link th-btn" id="reviews-tab"
                                        data-bs-toggle="tab" href="#about" role="tab" aria-controls="reviews"
                                        aria-selected="true">About Us</a></li>
                                <li class="nav-item" role="presentation"> <a class="nav-link th-btn" id="tech-tab"
                                        data-bs-toggle="tab" href="#services" role="tab" aria-controls="tech"
                                        aria-selected="true">Services</a></li>
                                <li class="nav-item" role="presentation"> <a class="nav-link th-btn" id="tech-tab"
                                        data-bs-toggle="tab" href="#team" role="tab" aria-controls="tech"
                                        aria-selected="true">Team</a></li>
                                <li class="nav-item" role="presentation"> <a class="nav-link th-btn" id="tech-tab"
                                        data-bs-toggle="tab" href="#choose" role="tab" aria-controls="tech"
                                        aria-selected="true">Why Choose Us?</a></li>
                                <li class="nav-item" role="presentation"> <a class="nav-link th-btn" id="tech-tab"
                                        data-bs-toggle="tab" href="#Clientele" role="tab" aria-controls="tech"
                                        aria-selected="true">Our Clientele </a></li>
                                <li class="nav-item" role="presentation"> <a class="nav-link th-btn" id="tech-tab"
                                        data-bs-toggle="tab" href="#gallery" role="tab" aria-controls="tech"
                                        aria-selected="true">Gallery</a></li>
                                <li class="nav-item" role="presentation"> <a class="nav-link th-btn" id="tech-tab"
                                        data-bs-toggle="tab" href="#contact" role="tab" aria-controls="tech"
                                        aria-selected="true">Contact Us</a></li>
                            </ul>
                            <div class="tab-content" id="productTabContent">
                                <div class="tab-pane fade show active" id="home" role="tabpanel"
                                    aria-labelledby="description-tab">
                                    <p style="text-align: center; font-weight:600">Welcome to Maa Tarini Petrochemicals.</p>
                                    <p class="mb-30">Leading the Way in Marine Sludge Extraction and Waste Management.<br>
                                    Similar to Phoenix India, Maa Tarini Petrochemicals focuses on sludge extraction from vessels and follows the same refining and fuel transfer process. Located in Bobili, Vizianagaram, Maa Tarini Petrochemicals primarily serves the Vishakhapatnam port, ensuring efficient sludge management and fuel replenishment.</p>

                                </div>
                                <div class="tab-pane fade" id="about" role="tabpanel" aria-labelledby="reviews-tab">
                                    <p class="mb-30">At Phoenix India Refinery, we specialize in the extraction and management of sludge and waste from vessels anchored at Visakhapatnam port. Established in 2021, we have rapidly become a leading provider of sludge removal services at Visakhapatnam port. Our operations are fully certified by the State Pollution Control Board, Odisha Regional Office Paradeep, and the Department of Forest & Environment, Govt of Odisha. With our dedicated team and advanced equipment, we ensure that sludge and garbage are efficiently extracted, transported, and processed, contributing to cleaner seas and sustainable practices.</p>

                                </div>
                                <div class="tab-pane fade" id="services" role="tabpanel" aria-labelledby="tech-tab">
                                    <p style="font-weight: 600;">Sludge and Garbage Removal</p>
                                    <p>– Marine Sludge Removal: We extract sludge from ship bilges, engine rooms, and other areas where oily waste accumulates.</p>
                                    <p>– Garbage Collection: We manage the collection of general waste from vessels, including plastic, metal, food waste, and other refuse.</p>
                                    <p style="font-weight: 600;">Transportation and Logistics</p>
                                    <p>– Transport to Refinery: We ensure the safe and compliant transportation of sludge and waste to our refinery at Kaligharr, Jodupur, which is just 20 km away from Paradip port.</p>
                                    <p>– Logistics Management:Our team coordinates transport schedules, handles permits, and ensures compliance with environmental regulations.</p>
                                    <p style="font-weight: 600;">Waste Treatment and Refinement</p>
                                    <p>– Refining Services: We process sludge to separate valuable components such as oil, water, and solids.</p>
                                    <p>– Recycling and Reuse: We recover and recycle materials from the waste, reducing the overall environmental impact.</p>
                                    <p style="font-weight: 600;">Trade and Commerce</p>
                                    <p>– Product Trading: We market and sell refined products, such as reclaimed oil, to relevant companies and industries.</p>
                                    <p>– Market Development: We identify and develop new markets for products obtained from sludge refinement.</p>
                                    <p style="font-weight: 600;">Environmental Compliance and Documentation</p>
                                    <p>– Regulatory Compliance: All activities meet local and international environmental regulations and standards.</p>
                                    <p>– Documentation and Reporting: We provide necessary documentation and reports to authorities, clients, and stakeholders regarding our waste management activities and compliance status.</p>
                                    <p style="font-weight: 600;">Consultancy and Support</p>
                                    <p>– Environmental Consultancy: We advise clients on best practices for waste management and compliance.</p>
                                    <p>– Technical Support: We offer technical assistance and support related to sludge removal, transport, and refinement processes.</p>



                                </div>
                                <div class="tab-pane fade" id="team" role="tabpanel" aria-labelledby="tech-tab">
                                    <p style="font-weight: 600;">Mr. Milan Mishra – Managing Director</p>
                                    <p class="mb-30">Mr. Milan Mishra brings a wealth of experience and visionary leadership to Phoenix India Refinery. Under his guidance, the company has achieved significant milestones in marine waste management and sludge extraction.</p>
                                   
                                    <p style="font-weight: 600;">Dedicated & Technically Sound Team</p>
                                    <p class="mb-30">At Phoenix India Refinery, our success is driven by a dedicated and technically sound team of professionals. Our engineers and technicians possess deep expertise in marine waste management, equipped with cutting-edge tools and knowledge to handle complex sludge extraction and waste treatment processes. They work tirelessly to ensure safety, efficiency, and compliance in all our operations, reflecting our commitment to excellence and environmental stewardship.</p>


                                </div>
                                <div class="tab-pane fade" id="choose" role="tabpanel" aria-labelledby="tech-tab">
                                    <p class="mb-30">Maa Tarini Petrochemicals is dedicated to providing efficient, safe, and environmentally responsible sludge and waste management services. Here’s why you should choose us:</p>
                                    <p>– Expertise and Experience: With a team of seasoned professionals and state-of-the-art equipment, we ensure top-notch service quality.</p>
                                    <p>– Certified Operations: Our operations are certified by reputable authorities, ensuring compliance with environmental regulations and industry standards.</p>
                                    <p>– Comprehensive Services: From extraction to refinement and trading, we offer a complete suite of services tailored to meet your needs.</p>
                                    <p>– Environmental Commitment: We prioritize environmental protection, implementing strict containment measures and adhering to international maritime regulations.</p>
                                    <p>– Customer-Centric Approach: Our team is committed to providing exceptional customer service and support, ensuring your requirements are met efficiently and effectively. choosing us as your trusted distribution partner.</p>


                                </div>
                                <div class="tab-pane fade" id="Clientele" role="tabpanel" aria-labelledby="tech-tab">
                                
                                </div>
                                <div class="tab-pane fade" id="gallery" role="tabpanel" aria-labelledby="tech-tab">
                                    <div class="gallery-area pt-50 pb-50">
                                        <div class="container">
                                            <div class="row mt-none-30 justify-content-center">

                                                <div class="col-md-3 pb-30">
                                                    <div class="event-image-container" onclick="openGallery('pictureGallery', 0)">
                                                        <img src="assets/img/division-img/gallery4/img1.jpeg" class="event-image">
                                                        <div class="event-overlay">
                                                            <span>View</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3 pb-30">
                                                    <div class="event-image-container" onclick="openGallery('pictureGallery', 1)">
                                                        <img src="assets/img/division-img/gallery4/img2.jpeg" class="event-image">
                                                        <div class="event-overlay">
                                                            <span>View</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-3 pb-30">
                                                    <div class="event-image-container" onclick="openGallery('pictureGallery', 2)">
                                                        <img src="assets/img/division-img/gallery4/img3.jpeg" class="event-image">
                                                        <div class="event-overlay">
                                                            <span>View</span>
                                                        </div>
                                                    </div>
                                                </div>


                                                <div id="pictureGallery" class="d-none">
                                                    <a href="assets/img/division-img/gallery4/img1.jpeg"><img src="assets/img/division-img/gallery4/img1.jpeg"></a>
                                                    <a href="assets/img/division-img/gallery4/img2.jpeg"><img src="assets/img/division-img/gallery4/img2.jpeg"></a>
                                                    <a href="assets/img/division-img/gallery4/img3.jpeg"><img src="assets/img/division-img/gallery4/img3.jpeg"></a>
                                                </div>


                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="tech-tab">
                                    <p style="font-weight:600">Get in Touch :</p>
                                    <p>Door No. 44-6-3, Thatichetapalem, 80 feet Road, Visakhapatnam – 530016</p>
                                    
                                    <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d7600.432075745248!2d83.29093000000002!3d17.734457!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a3942d7a905bdad%3A0x452289f0bf3620dc!2s44-6-2%2F3%2C%20Thatichetlapalem%2C%20Akkayyapalem%2C%20Visakhapatnam%2C%20Andhra%20Pradesh%20530016!5e0!3m2!1sen!2sin!4v1762942687826!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <!-- Footer Start -->
    <?php include 'includes/footer.php'; ?>
    <!-- Footer End -->

    <!-- ScrollToTop Start -->
    <?php include 'includes/scroll.php'; ?>
    <!-- ScrollToTop End -->

    <!-- JS Start -->
    <?php include 'includes/js.php'; ?>
    <!-- JS End -->
</body>

</html>