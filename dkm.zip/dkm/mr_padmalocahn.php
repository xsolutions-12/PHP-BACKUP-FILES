<!doctype html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>DKM Group</title>
    <!-- CSS Start -->
    <?php include 'includes/css.php'; ?>
    <!-- CSS End -->
</head>

<body>
    <!-- Preloader Start -->
    <?php include 'includes/loader.php'; ?>
    <!-- Preloader End -->

    <!-- Header Start -->
    <?php include 'includes/header.php'; ?>
    <!-- Header End -->

    <!-- breadcumb start -->
    <div class="breadcumb-wrapper" data-bg-src="assets/img/bg/inn-ban.jpeg">
        <div class="container">
            <div class="breadcumb-content">
                <h1 class="breadcumb-title">Management</h1>
                <ul class="breadcumb-menu">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="management.php">Management</a></li>
                </ul>
            </div>
        </div>
    </div>
    <!-- breadcumb End -->


    <section>
        <div class="container">
            <div class="row mb-60">
                <div class="col-xl-4">
                    <div class="about-card-img mb-xl-0 mb-30"><img src="assets/img/team/padmalochan.jpg"
                            alt="team image">

                    </div>
                </div>
                <div class="col-xl-8">
                    <div class="about-card">
                        <h2 class="about-card_title h3">Capt. Padmalochan Santibhusan Behera </h2>
                        <p class="about-card_desig">CEO - Capt Dilip Kumar Mishra Marine Surveyor Consultants and Loss Assessors</p>
                        <p class="about-card_text">Capt. Padmalochan Santibhusan Behera, hailing from Bhadrak, Odisha, joined the DKM Group in 2024 as the CEO - Captain Dilip Kumar Mishra Marine Surveyors Consultants & Loss Assessors. With an illustrious career spanning over 20 years in the shipping industry, Capt. Behera brings a wealth of knowledge and experience to the company. <br>
                            Capt. Behera holds a Master's Certificate of Competency (CoC) in shipping and navigation from the Director General of Shipping, India. He completed his Science Graduation (Hons) from B.J.B College, Bhubaneswar in 2002. His professional journey includes key roles with prestigious shipping companies such as Synergy, Dockendale, and Dynacom Shipping Company..
                            <br>In addition to his extensive sea experience, Capt. Behera has a diverse shore-side portfolio. He served as Branch Head in a stevedoring company in Paradip, held a teaching position at a DG approved Maritime Institute, managed terminal operations at Ghogha port, and was the Craft In-charge at Gopalpur port.
                        </p>
                       


                    </div>
                </div>
                <div class="col-xl-12">
                    <!-- <h4 class="box-title">Career Highlights</h4> -->

                    <p> His multifaceted career highlights his versatility and deep understanding of the shipping and port sectors. Capt. Behera is also an accomplished author, having written two books on Sudoku, demonstrating his passion for mathematics and puzzles.</p>
                    <p><b>Ethics</b></p>
                    <p>Capt. Behera's professional ethics are rooted in integrity, honesty, and a genuine desire to help others. His positive outlook and result-oriented approach ensure that he consistently drives his team towards excellence.</p>
                    <h4 class="box-title">Work Expertise</h4>
                    <p>Capt. Behera excels in various aspects of the shipping and port sector. His expertise includes:</p>
                    <div class="checklist mb-30">
                        <ul>
                            <li>● Shipping and port sector operations</li>
                            <li>● Mentoring and managing staff</li>
                            <li>● Creating a positive and productive working environment</li>
                            <li>● Ensuring jobs are completed in the most economical and safest manner</li>
                        </ul>
                    </div>
                    <p>Under the visionary leadership of Capt. Behera, Captain Dilip Kumar Mishra Marine Surveyor Consultants and Loss Assessors continues to set industry standards in maritime services, consultancy, P & I and loss assessment. His commitment to excellence and innovation drives the company's ongoing success and growth.</p>
                </div>
            </div>


            <div class="d-block d-md-none mt-40 text-center">
                <div class="icon-box"><button data-slider-prev="#teamSlider1" class="slider-arrow default"><i
                            class="far fa-arrow-left"></i></button> <button data-slider-next="#teamSlider1"
                        class="slider-arrow default"><i class="far fa-arrow-right"></i></button></div>
            </div>
        </div>
    </section>

    <!-- Footer Start -->
    <?php include 'includes/footer.php'; ?>
    <!-- Footer End -->

    <!-- ScrollToTop Start -->
    <?php include 'includes/scroll.php'; ?>
    <!-- ScrollToTop End -->

    <!-- JS Start -->
    <?php include 'includes/js.php'; ?>
    <!-- JS End -->
</body>

</html>