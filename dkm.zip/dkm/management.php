<!doctype html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>DKM Group</title>
    <!-- CSS Start -->
    <?php include 'includes/css.php'; ?>
    <!-- CSS End -->
</head>

<body>
    <!-- Preloader Start -->
    <?php include 'includes/loader.php'; ?>
    <!-- Preloader End -->

    <!-- Header Start -->
    <?php include 'includes/header.php'; ?>
    <!-- Header End -->

    <!-- breadcumb start -->
    <div class="breadcumb-wrapper" data-bg-src="assets/img/bg/inn-ban.jpeg">
        <div class="container">
            <div class="breadcumb-content">
                <h1 class="breadcumb-title">Management</h1>
                <ul class="breadcumb-menu">
                    <li><a href="index.php">Home</a></li>
                    <li>Management</li>
                </ul>
            </div>
        </div>
    </div>
    <!-- breadcumb End -->

    <div class="overflow-hidden" id="faq-sec" data-bg-src="assets/img/bg/faq_bg_1.png" style="margin-top: 50px;">
        <div class="container">
            <div class="row justify-content-center flex-row-reverse align-items-center">
                <div class="col-xl-6">
                    <div class="faq-img1 text-xl-start text-center"><img src="assets/img/normal/faq_1_1.png" alt="faq">
                    </div>
                </div>
                <div class="col-xl-6 text-center text-xl-start align-self-center">
                    <div class="title-area text-center text-xl-start">
                        <span class="sub-title"><img class="me-2"
                                src="assets/img/theme-img/title_icon.svg" alt="shape">
                                <span style="font-size: 20px;">Shri Milan Mishra</span> <img class="ms-2"
                                src="assets/img/theme-img/title_icon.svg" alt="shape"></span>
                        <h6 class="sec-title">A Visionary Leader at the helm of DKM Group</h6>
                        <p>Shri Milan Mishra, born on July 11, 1988, in Cuttack, is the esteemed Managing Director of DKM Group. Raised in Cuttack and educated in Lonavala, Mumbai, and KIIT, Bhubaneswar, Milan Mishra joined DKM Group in 2015, following the path laid by his father, Captain Dilip Kumar Mishra, the company's founder. After Captain Mishra's passing in June 2021, Milan Mishra assumed leadership, honouring his father's legacy while introducing innovative practices. His leadership style is marked by transparency, empathy, and a commitment to ethical practices and sustainable growth. Milan Mishra fosters a supportive, inclusive work culture, ensuring every team member feels valued. His ability to navigate complex challenges, coupled with his strategic acumen, has positioned DKM Group as a leader in its diverse fields. Married to Ms. Vaishali Mandal, Milan Mishra draws strength and inspiration from his family, continuing to lead with integrity and compassion.</p>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>

      <section class="space">
        <div class="container z-index-common">
            <div class="row justify-content-center">
                <div class="col-xl-6 col-lg-7 col-md-8">
                    <div class="title-area text-center">
                        <h2 class="sec-title">OUR LEADERSHIP TEAM</h2>
                    </div>
                </div>
            </div>
            <div class="row gy-30">
                <!-- member 1 -->
                <div class="col-lg-3 col-md-6">
                    <div class="th-team team-card">
                        <div class="img-wrap">
                            <div class="team-img"><img src="assets/img/team/no image.jpg" alt="Team"></div>
                        </div>
                        <div class="team-card-content">
                            <h3 class="box-title"><a href="mr_pp.php">Mr. Priyadarshi Parida</a></h3><span
                                class="team-desig">General Manager - Milan Properties</span>
                        </div>
                    </div>
                </div>
                <!-- member 2 -->
                <div class="col-lg-3 col-md-6">
                    <div class="th-team team-card">
                        <div class="img-wrap">
                            <div class="team-img"><img src="assets/img/team/jagat_krushna.jpg" alt="Team"></div>
                            
                        </div>
                        <div class="team-card-content">
                            <h3 class="box-title"><a href="mr_jagat.php">Mr. Jagat Krushna Patnaik</a></h3><span
                                class="team-desig">CEO - DKM Insurance Surveyor</span>
                        </div>
                    </div>
                </div>
                <!-- member 3 -->
                <div class="col-lg-3 col-md-6">
                    <div class="th-team team-card">
                        <div class="img-wrap">
                            <div class="team-img"><img src="assets/img/team/prasanjit.jpg" alt="Team"></div>
                            
                        </div>
                        <div class="team-card-content">
                            <h3 class="box-title"><a href="mr_prasanjit.php">Mr. Prasanjit Mohanty</a></h3><span
                                class="team-desig">Director - DKM Insurance Surveyor</span>
                        </div>
                    </div>
                </div>
                <!-- member 4 -->
                <div class="col-lg-3 col-md-6">
                    <div class="th-team team-card">
                        <div class="img-wrap">
                            <div class="team-img"><img src="assets/img/team/padmalochan.jpg" alt="Team"></div>
                            
                        </div>
                        <div class="team-card-content">
                            <h3 class="box-title"><a href="mr_padmalocahn.php">Capt. Padmalochan Santibhusan Behera</a></h3><span
                                class="team-desig">CEO - Marine Division</span>
                        </div>
                    </div>
                </div>
                <!-- member 5 -->
                <div class="col-lg-3 col-md-6">
                    <div class="th-team team-card">
                        <div class="img-wrap">
                            <div class="team-img"><img src="assets/img/team/kishore mishra.jpg" alt="Team"></div>
                           
                        </div>
                        <div class="team-card-content">
                            <h3 class="box-title"><a href="mr_kishore.php">Mr. Kishore Chandra Mishra</a></h3><span
                                class="team-desig">General Manager - DKM Marine</span>
                        </div>
                    </div>
                </div>
                <!-- member 6 -->
                <div class="col-lg-3 col-md-6">
                    <div class="th-team team-card">
                        <div class="img-wrap">
                            <div class="team-img"><img src="assets/img/team/amarendra.jpg" alt="Team"></div>
                            
                        </div>
                        <div class="team-card-content">
                            <h3 class="box-title"><a href="mr_amarendra.php">Mr. Amarendra Nayak</a></h3><span
                                class="team-desig">General Manager - Phoenix India Refinery</span>
                        </div>
                    </div>
                </div>
                <!-- member 7 -->
                <div class="col-lg-3 col-md-6">
                    <div class="th-team team-card">
                        <div class="img-wrap">
                            <div class="team-img"><img src="assets/img/team/jayaprakash.jpg" alt="Team"></div>
                            
                        </div>
                        <div class="team-card-content">
                            <h3 class="box-title"><a href="mr_Jayaprakash.php">Mr. Jayaprakash C Nair</a></h3><span
                                class="team-desig">General Manager - Milan Trading</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer Start -->
    <?php include 'includes/footer.php'; ?>
    <!-- Footer End -->

    <!-- ScrollToTop Start -->
    <?php include 'includes/scroll.php'; ?>
    <!-- ScrollToTop End -->

    <!-- JS Start -->
    <?php include 'includes/js.php'; ?>
    <!-- JS End -->
</body>

</html>