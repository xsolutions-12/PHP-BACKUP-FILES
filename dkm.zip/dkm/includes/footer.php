<footer class="footer-wrapper footer-layout3 bg-title" data-bg-src="assets/img/bg/footer-bg.png">
        <div class="footer-top">
            <div class="container z-index-common">
                <div class="row gy-4 justify-content-between">
                    <div class="col-auto"><a href="index.html.htm"><img src="assets/img/logo/logo.png"
                                alt="Konsal"></a></div>
                    <!-- <div class="col-auto">
                        <div class="th-social style4"><a href="https://www.facebook.com/"><i
                                    class="fab fa-facebook-f"></i></a> <a href="https://www.twitter.com/"><i
                                    class="fab fa-twitter"></i></a> <a href="https://www.linkedin.com/"><i
                                    class="fab fa-linkedin-in"></i></a> <a href="https://www.whatsapp.com/"><i
                                    class="fab fa-whatsapp"></i></a></div>
                    </div> -->
                </div>
            </div>
        </div>
        <div class="widget-area">
            <div class="container">
                <div class="row justify-content-between">
                    <div class="col-md-6 col-xl-auto">
                        <div class="widget footer-widget">
                            <div class="th-widget-about">
                                <h3 class="widget_title">Address</h3>
                                <!-- <p class="about-text">Improving credit score involves paying bills on time, reducing
                                    credit card</p> -->
                                <!-- <div class="info-box">
                                    <div class="info-box_icon"><i class="far fa-phone"></i></div>
                                    <p class="info-box_text"><a href="tel:+11278956825" class="info-box_link">+112 (789)
                                            568 25</a></p>
                                </div> -->
                                <div class="info-box">
                                    <div class="info-box_icon"><i class="far fa-envelope-open"></i></div>
                                    <p class="info-box_text"><a href="mailto:hr@dkmgroup.co.in"
                                            class="info-box_link">hr@dkmgroup.co.in</a></p>
                                </div>
                                <div class="info-box">
                                    <div class="info-box_icon"><i class="far fa-envelope-open"></i></div>
                                    <p class="info-box_text"><a href="mailto:pamd@dkmgroup.co.in"
                                            class="info-box_link">pamd@dkmgroup.co.in</a></p>
                                </div>
                                <div class="info-box">
                                    <div class="info-box_icon"><i class="far fa-location-dot"></i></div>
                                    <p class="info-box_text">Meena Plaza, Buxi Bazar, Cuttack, <br>Odisha  - 753001</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- <div class="col-md-6 col-xl-auto">
                        <div class="widget footer-widget">
                            <h3 class="widget_title">Recent Posts</h3>
                            <div class="recent-post-wrap">
                                <div class="recent-post">
                                    <div class="media-img"><a href="blog-details.html.htm"><img
                                                src="assets/img/blog/recent-post-1-1.jpg" alt="Blog Image"></a></div>
                                    <div class="media-body">
                                        <div class="recent-post-meta"><a href="blog.html.htm"><i
                                                    class="fal fa-calendar-days"></i>21 June, 2024</a></div>
                                        <h4 class="post-title"><a class="text-inherit"
                                                href="blog-details.html.htm">Guiding Businesses to Success</a></h4>
                                    </div>
                                </div>
                                <div class="recent-post">
                                    <div class="media-img"><a href="blog-details.html.htm"><img
                                                src="assets/img/blog/recent-post-1-2.jpg" alt="Blog Image"></a></div>
                                    <div class="media-body">
                                        <div class="recent-post-meta"><a href="blog.html.htm"><i
                                                    class="fal fa-calendar-days"></i>22 June, 2024</a></div>
                                        <h4 class="post-title"><a class="text-inherit"
                                                href="blog-details.html.htm">Fueling Your Business Forward</a></h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> -->
                    <div class="col-md-6 col-xl-auto">
                        <div class="widget widget_nav_menu footer-widget">
                            <h3 class="widget_title" style="position: relative;left: 90%;">Our Services</h3>
                            <div class="menu-all-pages-container">
                                <ul class="menu">
                                    <li><a href="cdkmm.php">DKM Marine</a></li>
                                    <li><a href="phoenix.php">Phoenix India</a></li>
                                    <li><a href="dkm-insurance.php">DKM Insurance</a></li>
                                    <li><a href="#">Madhyam Arts</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-xl-auto">
                        <div class="widget widget_nav_menu footer-widget">
                            <!-- <h3 class="widget_title">Our Services</h3> -->
                            <div class="menu-all-pages-container">
                                <ul class="menu" style="padding-top: 54%;">
                                    <li><a href="milan-trading.php">Milan Trading</a></li>
                                    <li><a href="milan-properties.php">Milan Properties</a></li>
                                    <li><a href="mtp.php">MT Petrochemicals</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-xl-3">
                        <div class="widget newsletter-widget footer-widget">
                            <h3 class="widget_title">Connect With</h3>
                            <div class="th-social style4">
                                <a href="https://www.facebook.com/">
                                    <i class="fab fa-facebook-f"></i>
                                </a> 
                                <a href="https://www.twitter.com/">
                                    <i class="fab fa-twitter"></i>
                                </a> 
                                <a href="https://www.linkedin.com/">
                                    <i class="fab fa-linkedin-in"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="copyright-wrap bg-theme">
            <div class="container">
                <div class="row gy-2 align-items-center">
                    <div class="col-md-6">
                        <p class="copyright-text">Copyright <i class="fal fa-copyright"></i> 2025 <a
                                href="index.php">DKM Group</a>. All Rights Reserved.</p>
                    </div>
                    <div class="col-md-6 text-center text-md-end"><a href="#" class="#" style="color:#ffffff;">Privacy Policy</a> &nbsp; &nbsp;|&nbsp; &nbsp; <a href="#" class="#" style="color:#ffffff;">Terms & Condition</a></div>
                </div>
            </div>
        </div>
    </footer>