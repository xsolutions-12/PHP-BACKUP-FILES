<header class="th-header header-layout2">
        <div class="header-top">
            <div class="container">
                <div class="row justify-content-center justify-content-lg-between align-items-center gy-2">
                    <div class="col-auto d-none d-lg-block">
                        <p class="header-notice">Welcome to DKM Group</p>
                    </div>
                    <div class="col-auto">
                        <div class="header-links">
                            <ul>
                                <!-- <li class="d-none d-xl-inline-block"><i class="fa-regular fa-phone"></i><a
                                        href="tel:11278956825">+112 (789) 568 25</a></li> -->
                                <li class="d-none d-sm-inline-block">
                                    <i class="fa-regular fa-envelope-open"></i>
                                    <a href="mailto:">hr@dkmgroup.co.in</a>
                                </li>
                                <li class="d-none d-sm-inline-block">
                                    <i class="fa-regular fa-envelope-open"></i>
                                    <a href="mailto:">pamd@dkmgroup.co.in</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="sticky-wrapper">
            <div class="menu-area">
                <div class="container">
                    <div class="row align-items-center justify-content-between">
                        <div class="col-auto">
                            <div class="header-logo"><a href="index.php"><img src="assets/img/logo/logo.png"
                                        alt="Konsal" class="logo-img"></a></div>
                        </div>
                        <div class="col-auto">
                            <nav class="main-menu d-none d-lg-inline-block">
                                <ul>
                                    <li><a href="index.php">Home</a></li>
                                    <li><a href="about.php">About Us</a></li>
                                    <li><a href="division.php">Divisions</a></li>
                                    <li><a href="management.php">Management</a></li>
                                    <li><a href="#">Blog</a></li>
                                    <li><a href="gallery.php">Gallery</a></li>
                                    <!-- <li class="menu-item-has-children"><a href="#">Services</a>
                                        <ul class="sub-menu">
                                            <li><a href="service.html.htm">Service</a></li>
                                            <li><a href="service-details.html.htm">Service Details</a></li>
                                        </ul>
                                    </li> -->
                                    <li><a href="contact.php">Contact Us</a></li>
                                </ul>
                            </nav>
                            <div class="header-button d-flex d-lg-none"><button type="button"
                                    class="simple-icon sideMenuToggler"><span class="badge">5</span> <i
                                        class="fa-regular fa-cart-shopping"></i></button> <button type="button"
                                    class="th-menu-toggle"><i class="far fa-bars"></i></button></div>
                        </div>
                        <!-- <div class="col-auto d-none d-xl-block">
                            <div class="header-button"><button type="button" class="simple-icon searchBoxToggler"><i
                                        class="far fa-search"></i></button> <button type="button"
                                    class="simple-icon sideMenuToggler"><span class="badge">5</span> <i
                                        class="fa-regular fa-cart-shopping"></i></button> <button type="button"
                                    class="simple-icon sideMenuInfo"><i class="fa-solid fa-bars"></i></button></div> -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>