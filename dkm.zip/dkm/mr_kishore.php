<!doctype html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>DKM Group</title>
    <!-- CSS Start -->
    <?php include 'includes/css.php'; ?>
    <!-- CSS End -->
</head>

<body>
    <!-- Preloader Start -->
    <?php include 'includes/loader.php'; ?>
    <!-- Preloader End -->

    <!-- Header Start -->
    <?php include 'includes/header.php'; ?>
    <!-- Header End -->

    <!-- breadcumb start -->
    <div class="breadcumb-wrapper" data-bg-src="assets/img/bg/inn-ban.jpeg">
        <div class="container">
            <div class="breadcumb-content">
                <h1 class="breadcumb-title">Management</h1>
                <ul class="breadcumb-menu">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="management.php">Management</a></li>
                </ul>
            </div>
        </div>
    </div>
    <!-- breadcumb End -->


    <section>
        <div class="container">
            <div class="row mb-60">
                <div class="col-xl-4">
                    <div class="about-card-img mb-xl-0 mb-30"><img src="assets/img/team/kishore mishra.jpg"
                            alt="team image"    >
                       
                    </div>
                </div>
                <div class="col-xl-8">
                    <div class="about-card">
                        <h2 class="about-card_title h3">Mr. Kishore Chandra Mishra</h2>
                        <p class="about-card_desig">General Manager, Captain Dilip Kumar Mishra Marine Surveyor Consultants and Loss Assessors</p>
                        <p class="about-card_text">Mr. Kishore Chandra Mishra joined the company in 1985 as Deputy Manager. Hailing from Bhadrak district, he aligned with Captain Mishra's work ethics and values from the beginning. His dedicated leadership and commitment have been crucial in driving the company to new heights.<br>With his vast experience of 40 years, he has been continuing to enhance the company’s growth and reputation in the marine industry. Mr. Kishore’s journey reflects his dedication, professionalism, and pivotal role in the company’s success.</p>
                        
                       
                    </div>
                </div>
            </div>
        
         
            <div class="d-block d-md-none mt-40 text-center">
                <div class="icon-box"><button data-slider-prev="#teamSlider1" class="slider-arrow default"><i
                            class="far fa-arrow-left"></i></button> <button data-slider-next="#teamSlider1"
                        class="slider-arrow default"><i class="far fa-arrow-right"></i></button></div>
            </div>
        </div>
    </section>

    <!-- Footer Start -->
    <?php include 'includes/footer.php'; ?>
    <!-- Footer End -->

    <!-- ScrollToTop Start -->
    <?php include 'includes/scroll.php'; ?>
    <!-- ScrollToTop End -->

    <!-- JS Start -->
    <?php include 'includes/js.php'; ?>
    <!-- JS End -->
</body>

</html>