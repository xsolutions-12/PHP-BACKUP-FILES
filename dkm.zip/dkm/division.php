<!doctype html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>DKM Group</title>
    <!-- CSS Start -->
    <?php include 'includes/css.php'; ?>
    <!-- CSS End -->
</head>

<body>
    <!-- Preloader Start -->
    <?php include 'includes/loader.php'; ?>
    <!-- Preloader End -->

    <!-- Header Start -->
    <?php include 'includes/header.php'; ?>
    <!-- Header End -->

    <!-- breadcumb start -->
    <div class="breadcumb-wrapper" data-bg-src="assets/img/bg/inn-ban.jpeg">
        <div class="container">
            <div class="breadcumb-content">
                <h1 class="breadcumb-title">Divison</h1>
                <ul class="breadcumb-menu">
                    <li><a href="index.php">Home</a></li>
                    <li>Divison</li>
                </ul>
            </div>
        </div>
    </div>
    <!-- breadcumb End -->

    <section class="space" id="service-sec">
        <div class="container">
            <!-- <div class="row justify-content-center">
                <div class="col-lg-6">
                    <div class="title-area text-center"><span class="sub-title"><img class="me-2"
                                src="assets/img/theme-img/title_icon.svg" alt="shape">FINANCE SOLUTION<img class="ms-2"
                                src="assets/img/theme-img/title_icon.svg" alt="shape"></span>
                        <h2 class="sec-title">Precision in Finance Excellence in Life</h2>
                    </div>
                </div>
            </div> -->
            <div class="row gy-30 gx-30 justify-content-center">
                <div class="col-xl-4 col-md-6">
                    <div class="service-card3">
                        <div class="box-content">
                            <div class="service-card-icon"><img src="assets/img/icon/service_card_3-1.svg" alt="Icon">
                            </div>
                            <h3 class="box-title"><a href="cdkmm.php">DKM Marine</a></h3>
                        </div>

                        <a href="cdkmm.php"
                            class="link-btn style2"><i class="fas fa-plus-circle me-1"></i>Read More
                        </a>
                    </div>
                </div>
                <div class="col-xl-4 col-md-6">
                    <div class="service-card3">
                        <div class="box-content">
                            <div class="service-card-icon"><img src="assets/img/icon/service_card_3-5.svg" alt="Icon">
                            </div>
                            <h3 class="box-title"><a href="phoenix.php">Phoenix India
                                </a></h3>
                        </div>
                        <a href="phoenix.php" class="link-btn style2"><i
                                class="fas fa-plus-circle me-1"></i>Read More</a>
                    </div>
                </div>
                <div class="col-xl-4 col-md-6">
                    <div class="service-card3">
                        <div class="box-content">
                            <div class="service-card-icon"><img src="assets/img/icon/service_card_3-3.svg" alt="Icon">
                            </div>
                            <h3 class="box-title"><a href="dkm-insurance.php">DKM Insurance</a></h3>
                        </div>
                        <a href="dkm-insurance.php"
                            class="link-btn style2"><i class="fas fa-plus-circle me-1"></i>Read More</a>
                    </div>
                </div>
                <div class="col-xl-4 col-md-6">
                    <div class="service-card3">
                        <div class="box-content">
                            <div class="service-card-icon"><img src="assets/img/icon/service_card_3-4.svg" alt="Icon">
                            </div>
                            <h3 class="box-title"><a href="#">Madhyam Arts</a></h3>
                        </div>
                        <a href="#" class="link-btn style2"><i
                                class="fas fa-plus-circle me-1"></i>Read More</a>
                    </div>
                </div>
                <div class="col-xl-4 col-md-6">
                    <div class="service-card3">
                        <div class="box-content">
                            <div class="service-card-icon"><img src="assets/img/icon/service_card_3-2.svg" alt="Icon">
                            </div>
                            <h3 class="box-title"><a href="milan-trading.php">Milan Trading</a>
                            </h3>
                        </div>
                        <a href="milan-trading.php" class="link-btn style2"><i
                                class="fas fa-plus-circle me-1"></i>Read More</a>
                    </div>
                </div>
                <div class="col-xl-4 col-md-6">
                    <div class="service-card3">
                        <div class="box-content">
                            <div class="service-card-icon"><img src="assets/img/icon/service_card_3-6.svg" alt="Icon">
                            </div>
                            <h3 class="box-title"><a href="milan-properties.php">Milan Properties</a></h3>
                        </div>
                        <a href="milan-properties.php" class="link-btn style2"><i
                                class="fas fa-plus-circle me-1"></i>Read More</a>
                    </div>
                </div>
                <div class="col-xl-4 col-md-6"></div>
                <div class="col-xl-4 col-md-6">
                    <div class="service-card3">
                        <div class="box-content">
                            <div class="service-card-icon"><img src="assets/img/icon/service_card_3-6.svg" alt="Icon">
                            </div>
                            <h3 class="box-title"><a href="mtp.php">Maa Tarini Petrochemicals
                                </a></h3>
                        </div>
                        <a href="mtp.php" class="link-btn style2"><i
                                class="fas fa-plus-circle me-1"></i>Read More</a>
                    </div>
                </div>
                <div class="col-xl-4 col-md-6"></div>

            </div>
        </div>
    </section>

    <!-- Footer Start -->
    <?php include 'includes/footer.php'; ?>
    <!-- Footer End -->

    <!-- ScrollToTop Start -->
    <?php include 'includes/scroll.php'; ?>
    <!-- ScrollToTop End -->

    <!-- JS Start -->
    <?php include 'includes/js.php'; ?>
    <!-- JS End -->
</body>

</html>