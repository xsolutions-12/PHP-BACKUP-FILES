<!doctype html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>DKM Group</title>
    <!-- CSS Start -->
    <?php include 'includes/css.php'; ?>
    <!-- CSS End -->
</head>

<body>
    <!-- Preloader Start -->
    <?php include 'includes/loader.php'; ?>
    <!-- Preloader End -->

    <!-- Header Start -->
    <?php include 'includes/header.php'; ?>
    <!-- Header End -->

    <!-- breadcumb start -->
    <div class="breadcumb-wrapper" data-bg-src="assets/img/bg/inn-ban.jpeg">
        <div class="container">
            <div class="breadcumb-content">
                <h1 class="breadcumb-title">Management</h1>
                <ul class="breadcumb-menu">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="management.php">Management</a></li>
                </ul>
            </div>
        </div>
    </div>
    <!-- breadcumb End -->


    <section>
        <div class="container">
            <div class="row mb-60">
                <div class="col-xl-4">
                    <div class="about-card-img mb-xl-0 mb-30"><img src="assets/img/team/no image.jpg"
                            alt="team image" style="margin-top: -80px;">
                       
                    </div>
                </div>
                <div class="col-xl-8">
                    <div class="about-card">
                        <h2 class="about-card_title h3">Mr. Priyadarshi Parida</h2>
                        <p class="about-card_desig">General Manager - Milan Properties</p>
                        <p class="about-card_text">Joining DKM Group in 2000 as General Manager, Mr. Priyadarshi Parida has been a cornerstone of our company's growth and diversification. With unwavering dedication, he supported Captain Dilip Kumar Mishra, helping to expand the company's divisions beyond its marine origins. His sharp mind, integrity, and intelligence have been instrumental in managing and overseeing various departments, ensuring smooth operations across the board.<br><br>
                        Following Captain Mishra's passing in 2021, Mr. Parida has continued his dedicated service as General Manager of Milan Properties, while also supporting our Managing Director, Mr. Milan Mishra, who joined the company in 2015. Originally from Bhadrak, Mr. Parida is a key figure in our leadership team, embodying the core values of honesty and commitment that define DKM Group.</p>
                        
                       
                    </div>
                </div>
            </div>
        
         
            <div class="d-block d-md-none mt-40 text-center">
                <div class="icon-box"><button data-slider-prev="#teamSlider1" class="slider-arrow default"><i
                            class="far fa-arrow-left"></i></button> <button data-slider-next="#teamSlider1"
                        class="slider-arrow default"><i class="far fa-arrow-right"></i></button></div>
            </div>
        </div>
    </section>

    <!-- Footer Start -->
    <?php include 'includes/footer.php'; ?>
    <!-- Footer End -->

    <!-- ScrollToTop Start -->
    <?php include 'includes/scroll.php'; ?>
    <!-- ScrollToTop End -->

    <!-- JS Start -->
    <?php include 'includes/js.php'; ?>
    <!-- JS End -->
</body>

</html>