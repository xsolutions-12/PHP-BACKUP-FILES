<!doctype html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>DKM Group</title>
    <!-- CSS Start -->
    <?php include 'includes/css.php'; ?>
    <!-- CSS End -->
</head>

<body>
    <!-- Preloader Start -->
    <?php include 'includes/loader.php'; ?>
    <!-- Preloader End -->

    <!-- Header Start -->
    <?php include 'includes/header.php'; ?>
    <!-- Header End -->

    <!-- breadcumb start -->
    <div class="breadcumb-wrapper" data-bg-src="assets/img/bg/inn-ban.jpeg">
        <div class="container">
            <div class="breadcumb-content">
                <h1 class="breadcumb-title">Divison</h1>
                <ul class="breadcumb-menu">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="division.php">Divison</a></li>
                    <li>Milan Properties</li>
                </ul>
            </div>
        </div>
    </div>
    <!-- breadcumb End -->

    <section class="space-top space-extra-bottom">
        <div class="container">
            <div class="row">
                <div class="col-xxl-12 col-lg-12">
                    <div class="page-single mb-40">
                        <div class="page-content">
                            <ul class="nav product-tab-style1 mt-40 pb-0" id="productTab" role="tablist">
                                <li class="nav-item" role="presentation"><a class="nav-link th-btn active"
                                        id="home-tab" data-bs-toggle="tab" href="#home" role="tab"
                                        aria-controls="description" aria-selected="false">Home</a></li>
                                <li class="nav-item" role="presentation"><a class="nav-link th-btn" id="reviews-tab"
                                        data-bs-toggle="tab" href="#about" role="tab" aria-controls="reviews"
                                        aria-selected="true">About Us</a></li>
                                <li class="nav-item" role="presentation"> <a class="nav-link th-btn" id="tech-tab"
                                        data-bs-toggle="tab" href="#services" role="tab" aria-controls="tech"
                                        aria-selected="true">Services</a></li>
                                <li class="nav-item" role="presentation"> <a class="nav-link th-btn" id="tech-tab"
                                        data-bs-toggle="tab" href="#team" role="tab" aria-controls="tech"
                                        aria-selected="true">Team</a></li>
                                <li class="nav-item" role="presentation"> <a class="nav-link th-btn" id="tech-tab"
                                        data-bs-toggle="tab" href="#choose" role="tab" aria-controls="tech"
                                        aria-selected="true">Why Choose Us?</a></li>
                                <li class="nav-item" role="presentation"> <a class="nav-link th-btn" id="tech-tab"
                                        data-bs-toggle="tab" href="#Clientele" role="tab" aria-controls="tech"
                                        aria-selected="true">Our Clientele </a></li>
                                <li class="nav-item" role="presentation"> <a class="nav-link th-btn" id="tech-tab"
                                        data-bs-toggle="tab" href="#tech" role="tab" aria-controls="tech"
                                        aria-selected="true">Gallery</a></li>
                                <li class="nav-item" role="presentation"> <a class="nav-link th-btn" id="tech-tab"
                                        data-bs-toggle="tab" href="#contact" role="tab" aria-controls="tech"
                                        aria-selected="true">Contact Us</a></li>
                            </ul>
                            <div class="tab-content" id="productTabContent">
                                <div class="tab-pane fade show active" id="home" role="tabpanel"
                                    aria-labelledby="description-tab">
                                    <p style="text-align: center; font-weight:600">Welcome to Milan Properties & Hotels Pvt Ltd.</p>
                                    <p class="mb-30">Established in 2010, Milan Properties specializes in property stewarding, offering a range of services to property owners in Cuttack. With a focus on professionalism and customer satisfaction, Milan Properties is committed to excellence in property management.</p>

                                </div>
                                <div class="tab-pane fade" id="about" role="tabpanel" aria-labelledby="reviews-tab">
                                    <p class="mb-30">Milan Properties & Hotels Pvt Ltd is a premier real estate and property management company based in Odisha, with extended services in Kolkata. With a commitment to excellence and a focus on customer satisfaction, we provide comprehensive real estate solutions to meet all your needs. Our expertise spans across residential, commercial, and hospitality sectors, ensuring that we deliver top-notch services tailored to our clients’ unique requirements.</p>

                                </div>
                                <div class="tab-pane fade" id="services" role="tabpanel" aria-labelledby="tech-tab">
                                    <p style="font-weight: 600;">Real Estate Development:</p>
                                    <p>We specialize in the development of residential and commercial properties. From conceptualization to completion, we handle every aspect of the project, ensuring high-quality construction and timely delivery.</p>
                                   
                                    <p style="font-weight: 600;">Property Management:</p>
                                    <p>Our property management services include everything from tenant acquisition and lease administration to maintenance and repair services. We ensure that your property is well-maintained and generates optimal returns.</p>
                                   
                                    <p style="font-weight: 600;">Hotel Management:</p>
                                    <p>We manage a portfolio of hotels, providing exceptional hospitality services. Our team ensures that each guest experiences the highest standards of comfort and service.</p>
                                    
                                    <p style="font-weight: 600;">Leasing and Renting:</p>
                                    <p>Whether you’re looking to lease or rent a property, we offer a wide range of options to suit your needs. Our team assists you in finding the perfect space that meets your requirements and budget.</p>
                                    
                                    <p style="font-weight: 600;">Real Estate Consultancy:</p>
                                    <p>Our consultancy services provide expert advice on property investments, market trends, and legal compliance. We help you make informed decisions to maximize your real estate investments.</p>


                                </div>
                                <div class="tab-pane fade" id="team" role="tabpanel" aria-labelledby="tech-tab">
                                    <p><b>Managing Director:</b>Mr. Milan Mishra</p>
                                    <p><b>General Manager:</b>Mr. Priyadarshi Parida</p>
                                    <p>At Milan Properties & Hotels Pvt Ltd, our success is driven by a dedicated team of professionals. Our team includes experienced real estate developers, property managers, hospitality experts, and legal advisors. Each member of our team is committed to delivering excellence and ensuring client satisfaction.</p>


                                </div>
                                <div class="tab-pane fade" id="choose" role="tabpanel" aria-labelledby="tech-tab">
                                    
                                    <p style="font-weight: 600;">Expertise and Experience:</p>
                                    <p>With years of experience in the real estate and hospitality sectors, we bring unmatched expertise to every project. Our deep understanding of the market ensures that we deliver high-quality services that meet your expectatio</p>
                                    <p style="font-weight: 600;">Customer-Centric Approach:</p>
                                    <p>Our clients are at the heart of everything we do. We listen to your needs, understand your goals, and provide tailored solutions that deliver the best results. Your satisfaction is our priority.</p>
                                    <p style="font-weight: 600;">Comprehensive Services:</p>
                                    <p>We offer a one-stop solution for all your real estate and property management needs. From development and management to consultancy and leasing, we provide a comprehensive range of services under one roof.</p>
                                    <p style="font-weight: 600;">Commitment to Quality:</p>
                                    <p>We are committed to maintaining the highest standards of quality in all our projects and services. Our focus on quality ensures that we deliver properties and services that exceed your expectations.</p>

                                </div>
                                <div class="tab-pane fade" id="Clientele" role="tabpanel" aria-labelledby="tech-tab">
                                    <div class="ship-table-section">
                                        <div class="table-container">
                                            <table>
                                                <tr>
                                                    <td>MV.ISMINE</td>
                                                    <td>MV.SAFEEN AL AMAN</td>
                                                    <td>MV.KK MINERAL</td>
                                                    <td>MV.AMNSI MAXIMUS</td>
                                                    <td>MV.ELISABETH C</td>
                                                </tr>
                                                <tr>
                                                    <td>MV.ODYSSEUS N</td>
                                                    <td>MV.SEAMELODY</td>
                                                    <td>MV.CHENNAI SELVAM</td>
                                                    <td>MV.GCL YAMUNA</td>
                                                    <td>MV.DECCAN PRIDE</td>
                                                </tr>
                                                <tr>
                                                    <td>MV.JAG RADHA</td>
                                                    <td>MV.SHAIL AL LUASIL</td>
                                                    <td>MV.SHAIL AL WAJBAH</td>
                                                    <td>MV.VISHVA UDAY</td>
                                                    <td>MT.BLAAMANEN</td>
                                                </tr>
                                                <tr>
                                                    <td>MV.LOWLAND SAGE</td>
                                                    <td>MV.CL XUCHANG</td>
                                                    <td>MV.AMNSI STALLION</td>
                                                    <td>MV.GLADIATOR</td>
                                                    <td>MV.NAVIOUS AMITIE</td>
                                                </tr>
                                                <tr>
                                                    <td>MV.CHANNAI SELVAM</td>
                                                    <td>MT.LILA CONFIDENCE</td>
                                                    <td>MV.NAVIOUS FELIX</td>
                                                    <td>MV.AM UMANG</td>
                                                    <td>MV.GCL SABARMATI</td>
                                                </tr>
                                                <tr>
                                                    <td>MV.QUEST</td>
                                                    <td>MV.GCL TAPI</td>
                                                    <td>MV.SEAMENC GALLANT</td>
                                                    <td>MV.ARABELA</td>
                                                    <td>MV.GCL KRISHNA</td>
                                                </tr>
                                                <tr>
                                                    <td>MT.MTM ROTTERDAM</td>
                                                    <td>MV.VISHVA NIDHI</td>
                                                    <td>MV.GCL NARMADA</td>
                                                    <td>MV.JAG RAJIV</td>
                                                    <td>MT.ST RAMAN</td>
                                                </tr>
                                                <tr>
                                                    <td>MV.HYDRUS</td>
                                                    <td>MV.SERENE MONACO</td>
                                                    <td>MV.AMNSI STALIION</td>
                                                    <td>MV.MAHA JACQUELINE</td>
                                                    <td>MV.GCL GANGA</td>
                                                </tr>
                                                <tr>
                                                    <td>MV.VISHVA EKTA</td>
                                                    <td>MV.JAG RANI</td>
                                                    <td>MV.SAFEEN AL SAFA</td>
                                                    <td>MV.CHENNAI VALARCHI</td>
                                                    <td>MV.GCL MAHANADI</td>
                                                </tr>
                                                <tr>
                                                    <td>MV.JAG AKSHAY</td>
                                                    <td>MV.UNITY N</td>
                                                    <td>MV.KLIMA</td>
                                                    <td>MV.DAMON</td>
                                                    <td>MT.VAMSEE</td>
                                                </tr>
                                                <tr>
                                                    <td>MV.VISHVA MALHAR</td>
                                                    <td>MV.AG NEKTARIOS</td>
                                                    <td>MV.JAG RISHI</td>
                                                    <td>MV.THRASYVOULOS V</td>
                                                    <td></td>
                                                </tr>
                                               
                                            </table>
                                        </div>
                                    </div>

                                </div>
                                <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="tech-tab">
                                    <p style="font-weight:600">Get in Touch :</p>
                                    <p>If you have any questions or would like to learn more about our services, please feel free to contact us. We are here to assist you with all your real estate and property management needs.</p>
                                    <p>Milan Properties & Hotels Pvt Ltd. 5th Floor, Meena Plaza, Buxibazar, Cuttack 753001, Ph – 9348962756</p>
                                    <iframe src="https://www.google.com/maps/embed?pb=!1m13!1m8!1m3!1d7475.684274821711!2d85.869943!3d20.471676!3m2!1i1024!2i768!4f13.1!3m2!1m1!2zMjDCsDI4JzE4LjAiTiA4NcKwNTInMjEuMSJF!5e0!3m2!1sen!2sin!4v1762941632741!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <!-- Footer Start -->
    <?php include 'includes/footer.php'; ?>
    <!-- Footer End -->

    <!-- ScrollToTop Start -->
    <?php include 'includes/scroll.php'; ?>
    <!-- ScrollToTop End -->

    <!-- JS Start -->
    <?php include 'includes/js.php'; ?>
    <!-- JS End -->
</body>

</html>