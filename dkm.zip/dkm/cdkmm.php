<!doctype html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>DKM Group</title>
    <!-- CSS Start -->
    <?php include 'includes/css.php'; ?>
    <!-- CSS End -->
</head>

<body>
    <!-- Preloader Start -->
    <?php include 'includes/loader.php'; ?>
    <!-- Preloader End -->

    <!-- Header Start -->
    <?php include 'includes/header.php'; ?>
    <!-- Header End -->

    <!-- breadcumb start -->
    <div class="breadcumb-wrapper" data-bg-src="assets/img/bg/inn-ban.jpeg">
        <div class="container">
            <div class="breadcumb-content">
                <h1 class="breadcumb-title">Divison</h1>
                <ul class="breadcumb-menu">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="division.php">Divison</a></li>
                    <li>DKM Marine</li>
                </ul>
            </div>
        </div>
    </div>
    <!-- breadcumb End -->

    <section class="space-extra-bottom">
        <div class="container">
            <div class="row">
                <div class="col-xxl-12 col-lg-12">
                    <div class="page-single mb-40">
                        <div class="page-content">
                            <ul class="nav product-tab-style1 mt-40 pb-0" id="productTab" role="tablist">
                                <li class="nav-item" role="presentation"><a class="nav-link th-btn active"
                                        id="home-tab" data-bs-toggle="tab" href="#home" role="tab"
                                        aria-controls="description" aria-selected="false">Home</a></li>
                                <li class="nav-item" role="presentation"><a class="nav-link th-btn" id="reviews-tab"
                                        data-bs-toggle="tab" href="#about" role="tab" aria-controls="reviews"
                                        aria-selected="true">About Us</a></li>
                                <li class="nav-item" role="presentation"> <a class="nav-link th-btn" id="tech-tab"
                                        data-bs-toggle="tab" href="#services" role="tab" aria-controls="tech"
                                        aria-selected="true">Services</a></li>
                                <li class="nav-item" role="presentation"> <a class="nav-link th-btn" id="tech-tab"
                                        data-bs-toggle="tab" href="#team" role="tab" aria-controls="tech"
                                        aria-selected="true">Team</a></li>
                                <li class="nav-item" role="presentation"> <a class="nav-link th-btn" id="tech-tab"
                                        data-bs-toggle="tab" href="#choose" role="tab" aria-controls="tech"
                                        aria-selected="true">Why Choose Us?</a></li>
                                <li class="nav-item" role="presentation"> <a class="nav-link th-btn" id="tech-tab"
                                        data-bs-toggle="tab" href="#Clientele" role="tab" aria-controls="tech"
                                        aria-selected="true">Our Clientele </a></li>
                                <li class="nav-item" role="presentation"> <a class="nav-link th-btn" id="tech-tab"
                                        data-bs-toggle="tab" href="#gallery" role="tab" aria-controls="tech"
                                        aria-selected="true">Gallery</a></li>
                                <li class="nav-item" role="presentation"> <a class="nav-link th-btn" id="tech-tab"
                                        data-bs-toggle="tab" href="#contact" role="tab" aria-controls="tech"
                                        aria-selected="true">Contact Us</a></li>
                            </ul>
                            <div class="tab-content" id="productTabContent">
                                <div class="tab-pane fade show active" id="home" role="tabpanel"
                                    aria-labelledby="description-tab">
                                    <p style="text-align: center; font-weight:600">Welcome to Captain Dilip Kumar Mishra Marine Surveyor Consultants and Loss Assessors</p>
                                    <p class="mb-30">Established in 1982, Captain Dilip Kumar Mishra Marine Surveyor Consultants and Loss Assessors is a premier provider of marine surveying and loss assessment services. As the cornerstone of the DKM Group, our division has been serving clients in the ports of Paradip, Dhamra, Gopalpur, and Vishakhapatnam with unwavering dedication and expertise.</p>

                                </div>
                                <div class="tab-pane fade" id="about" role="tabpanel" aria-labelledby="reviews-tab">
                                    <p style="font-weight: 600;">Our Mission</p>
                                    <p class="mb-30">At Captain Dilip Kumar Mishra Marine Surveyor Consultants and Loss Assessors, our mission is to deliver precise, reliable, and comprehensive marine surveying and loss assessment services. We are committed to ensuring the safety, integrity, and operational efficiency of maritime vessels and cargoes, providing our clients with peace of mind.</p>
                                    <p style="font-weight: 600;">Our History</p>
                                    <p class="mb-30">Founded by Captain Dilip Kumar Mishra in 1982, our division has grown to become a trusted name in the marine surveying industry. With over four decades of experience, we have built a reputation for excellence, professionalism, and a steadfast commitment to our clients.</p>
                                    <p style="font-weight: 600;">Our Values</p>
                                    <ul style="text-align: left;">
                                        <li> Integrity: Upholding the highest ethical standards in all our dealings.</li>
                                        <li> Excellence: Striving for excellence in every service we provide.</li>
                                        <li> Reliability: Delivering dependable and timely services.</li>
                                        <li> Innovation: Continuously seeking innovative solutions to enhance our service offerings.</li>
                                        <li> Customer Focus: Placing our clients’ needs at the forefront of everything we do.</li>
                                    </ul>

                                </div>
                                <div class="tab-pane fade" id="services" role="tabpanel" aria-labelledby="tech-tab">
                                    <p style="font-weight: 600;">Marine Surveying Services</p>
                                    <p class="mb-30">Our marine surveying services are comprehensive and cover all aspects of marine operations. We provide the following types of surveys:
                                    </p>
                                    <ol style="text-align: left;">
                                        <li>Pre-Purchase Survey: Thorough inspections of vessels before purchase to assess their condition, maintenance needs, and market value.</li>
                                        <li>Condition Survey: Evaluating the current state of a vessel, including hull integrity, machinery, and safety equipment.</li>
                                        <li>On-Hire/Off-Hire Survey: Documenting the condition of vessels at the beginning and end of a charter period.</li>
                                        <li>Cargo Survey: Verifying the quantity, condition, and proper handling of cargo.</li>
                                        <li>Draught Survey: Determining the weight of cargo on a vessel by measuring displacement.</li>
                                        <li>Hull and Machinery Survey: Focusing on the structural integrity of the vessel’s hull and machinery condition.</li>
                                        <li>Safety and Environmental Survey: Ensuring compliance with safety and environmental regulations.</li>
                                        <li>Damage Survey: Assessing the extent and cause of damage to a vessel or its cargo.</li>
                                        <li>ISPS Code Survey: Evaluating the security measures in place on a vessel or port facility.</li>
                                        <li>P & I Survey: Conducting surveys on behalf of P & I clubs.</li>
                                        <li>Underwater Survey: Inspecting the vessel’s underwater hull, propellers, and other submerged structures.</li>
                                        <li>Bunker Survey: Measuring the amount of fuel on board a vessel.</li>
                                        <li>Warranty Survey: Ensuring that marine insurance policy terms and conditions are met.</li>
                                        <li>Tally Supervision Survey: Overseeing and verifying the loading and unloading processes to ensure accurate accounting of cargo quantities.</li>
                                        <li>Rake-loading Monitoring: Monitoring and verifying the loading and unloading of cargo onto railway rakes.</li>
                                        <li>Vessel Sampling Survey: Collecting and analyzing samples from various parts of a vessel, including cargo, fuel, and ballast water.</li>
                                        <li>Ullage Survey: Determining the quantity of liquid cargo in a tank by measuring the empty space (ullage) above the liquid.</li>
                                        <li>Moisture Analysis: Measuring the moisture content of bulk cargoes such as coal & ores.</li>
                                        <li>Barge Survey: Determining the quantity and condition of cargo loaded onto or discharged from barges.</li>
                                        <li>Tank/Lorry/Bunker Supplier Loading Survey: Monitoring and verifying the loading of cargo into tanks, lorries, or bunker suppliers.</li>
                                        <li>Cargo Condition and Moisture Analysis: Assessing the condition, quantity, and moisture content of cargoes such as grains/coal/ ores/steel at three critical stages: pre-loading, during loading, and during discharge.</li>
                                    </ol>
                                    <p>By incorporating these services, Captain Dilip Kumar Mishra Marine Surveyor Consultants and Loss Assessors ensure that every aspect of cargo handling, from loading to transport and discharge, is managed with precision and professionalism. Our comprehensive approach guarantees the highest levels of accuracy, compliance, and operational efficiency for all marine operations at the ports of Paradip, Dhamra, Gopalpur, and Vishakhapatnam.</p>
                                    <p style="font-weight: 600;">Marine Consultancy</p>
                                    <p>Our marine consultancy services are designed to support the maritime industry with expert advice and solutions. We provide tailored consultancy services that address a wide range of marine operations, ensuring compliance with international standards and optimizing operational efficiency. Our services include:</p>
                                    <ul>
                                        <li>Regulatory Compliance: Assisting clients in adhering to international maritime regulations and standards, such as SOLAS, MARPOL, and ISPS Code.</li>
                                        <li>Safety Management: Developing and implementing safety management systems to ensure the highest levels of safety on board.</li>
                                        <li> Environmental Management:Advising on best practices for environmental protection, including ballast water management and emissions control.</li>
                                        <li>Risk Assessment: Conducting thorough risk assessments to identify potential hazards and mitigate risks in marine operations.</li>
                                        <li>Operational Efficiency: Providing strategies to enhance the operational efficiency of vessels and marine facilities.</li>
                                    </ul>
                                    <p style="font-weight: 600;">Loss Assessment</p>
                                    <p>In the unfortunate event of a marine incident, our loss assessment services are crucial for determining the extent of damage and facilitating fair and accurate claims processing. Our expert loss assessors conduct detailed investigations and evaluations to provide unbiased reports. Our loss assessment services include:</p>
                                    <ul>
                                        <li>Damage Surveys: Assessing the extent and cause of damage to vessels, cargo, and marine structures.</li>
                                        <li>Claim Documentation: Preparing comprehensive documentation to support insurance claims, ensuring all necessary information is accurately recorded.</li>
                                        <li>Liability Determination: Identifying the parties responsible for damage or loss, facilitating the resolution of disputes.</li>
                                        <li>Salvage and Recovery: Coordinating salvage operations and recovery efforts to minimize losses and expedite the return to normal operations.</li>
                                        <li> Settlement Negotiation: Assisting clients in negotiating fair settlements with insurers and other stakeholders.</li>
                                    </ul>

                                </div>
                                <div class="tab-pane fade" id="team" role="tabpanel" aria-labelledby="tech-tab">
                                    <p style="font-weight: 600;">Our Dedicated Team</p>
                                    <p class="mb-30">Our team comprises highly skilled and experienced professionals who are dedicated to providing the best services to our clients. Each member of our team brings a wealth of knowledge and expertise, ensuring that we deliver accurate and reliable results every time. </p>
                                    <p>– General Manager:</p>
                                    <img src="assets/img/division-img/cdkmm-team.jpg" alt="" style="float: right;">
                                    <p>– Dedicated to the company since it’s inception, our General Manager’s leadership & commitment are integral to our mission of providing top-notch marine consultancy & Loss assessment services.</p>
                                    <p>– Marine Surveyors: Certified experts in various aspects of marine surveying, including hull inspections, cargo verification, and safety assessments.</p>
                                    <p>– Technical Staff:Skilled technicians who assist in conducting detailed surveys and assessments.</p>
                                    <p>– Administrative Team: Efficient and organized professionals who ensure smooth operations and client communication.</p>
                                    <p>Our management team is committed to maintaining the highest standards of service and operational excellence. Under the leadership of the Managing Director, Mr. Milan Mishra, we continue to innovate and improve our services to meet the evolving needs of the maritime industry. Our management team focuses on strategic planning, quality control, and client satisfaction, ensuring that we remain a trusted partner in the maritime sector.</p>

                                </div>
                                <div class="tab-pane fade" id="gallery" role="tabpanel" aria-labelledby="tech-tab">
                                    <div class="gallery-area pt-50 pb-50">
                                        <div class="container">
                                            <div class="row mt-none-30 justify-content-center">

                                                <div class="col-md-3 pb-30">
                                                    <div class="event-image-container" onclick="openGallery('pictureGallery', 0)">
                                                        <img src="assets/img/division-img/gallery1/img1.jpeg" class="event-image">
                                                        <div class="event-overlay">
                                                            <span>View</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3 pb-30">
                                                    <div class="event-image-container" onclick="openGallery('pictureGallery', 1)">
                                                        <img src="assets/img/division-img/gallery1/img2.jpeg" class="event-image">
                                                        <div class="event-overlay">
                                                            <span>View</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3 pb-30">
                                                    <div class="event-image-container" onclick="openGallery('pictureGallery', 2)">
                                                        <img src="assets/img/division-img/gallery1/img3.jpeg" class="event-image">
                                                        <div class="event-overlay">
                                                            <span>View</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3 pb-30">
                                                    <div class="event-image-container" onclick="openGallery('pictureGallery', 3)">
                                                        <img src="assets/img/division-img/gallery1/img4.jpg" class="event-image">
                                                        <div class="event-overlay">
                                                            <span>View</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3 pb-30">
                                                    <div class="event-image-container" onclick="openGallery('pictureGallery', 4)">
                                                        <img src="assets/img/division-img/gallery1/img5.jpeg" class="event-image">
                                                        <div class="event-overlay">
                                                            <span>View</span>
                                                        </div>
                                                    </div>
                                                </div>


                                                <div id="pictureGallery" class="d-none">
                                                    <a href="assets/img/division-img/gallery1/img1.jpeg"><img src="assets/img/division-img/gallery1/img1.jpeg"></a>
                                                    <a href="assets/img/division-img/gallery1/img2.jpeg"><img src="assets/img/division-img/gallery1/img2.jpeg"></a>
                                                    <a href="assets/img/division-img/gallery1/img3.jpeg"><img src="assets/img/division-img/gallery1/img3.jpeg"></a>
                                                    <a href="assets/img/division-img/gallery1/img4.jpg"><img src="assets/img/division-img/gallery1/img4.jpg"></a>
                                                    <a href="assets/img/division-img/gallery1/img5.jpeg"><img src="assets/img/division-img/gallery1/img5.jpeg"></a>
                                                </div>


                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div class="tab-pane fade" id="choose" role="tabpanel" aria-labelledby="tech-tab">
                                    <p class="mb-30">– Expertise: Our team comprises seasoned professionals with extensive experience in marine surveying, consultancy, and loss assessment.</p>
                                    <p>– Comprehensive Services:We offer a full range of services to meet all your marine operational needs.</p>
                                    <p>– Compliance: We ensure that your operations comply with all relevant regulations and standards.</p>
                                    <p>– Efficiency: Our services are designed to enhance the efficiency and safety of your marine operations.</p>
                                    <p>– Client-Centric Approach: We prioritize our clients’ needs and provide tailored solutions to meet their specific requirements.</p>
                                    <p>Trust Captain Dilip Kumar Mishra Marine Surveyor Consultants and Loss Assessors to be your reliable partner in marine operations.</p>

                                </div>
                                <div class="tab-pane fade" id="Clientele" role="tabpanel" aria-labelledby="tech-tab">
                                    <div class="table-container">
                                        <table class="styled-table">
                                            <thead>
                                                <tr>
                                                    <th>SL.NO.</th>
                                                    <th style="width: 40%;">Our Principals</th>
                                                    <th>Nature of Work</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>1</td>
                                                    <td>M/s Seatrans Ship Management Services Pvt. Ltd.</td>
                                                    <td>Draft Survey/On & Off-hire Bunker Survey, Bunker & Condition Survey, Ullage Survey i.e. (Phos. Acid, Ammonia, Sul. Acid), SBM Survey at Anchorage.</td>
                                                </tr>
                                                <tr>
                                                    <td>2</td>
                                                    <td>M/s Infinity Shipping Pvt. Ltd.</td>
                                                    <td>Draft Survey/Bunker Survey</td>
                                                </tr>
                                                <tr>
                                                    <td>3</td>
                                                    <td>M/s Therapeutics Research & Chemicals</td>
                                                    <td>Draft Survey/Bunker Survey</td>
                                                </tr>
                                                <tr>
                                                    <td>4</td>
                                                    <td>M/s Sical Logistics Ltd.</td>
                                                    <td>Draft Survey/Bunker Survey</td>
                                                </tr>
                                                <tr>
                                                    <td>5</td>
                                                    <td>M/s Chowgule Brothers Pvt. Ltd.</td>
                                                    <td>Draft Survey/Bunker Survey</td>
                                                </tr>
                                                <tr>
                                                    <td>6</td>
                                                    <td>M/s Deblines Pvt. Ltd.</td>
                                                    <td>Draft Survey/Bunker Survey</td>
                                                </tr>
                                                <tr>
                                                    <td>7</td>
                                                    <td>M/s Seaport Shipping Pvt. Ltd.</td>
                                                    <td>Draft Survey/Bunker Survey</td>
                                                </tr>
                                                <tr>
                                                    <td>8</td>
                                                    <td>M/s IOCL</td>
                                                    <td>Draft Survey/Bunker Survey</td>
                                                </tr>
                                                <tr>
                                                    <td>9</td>
                                                    <td>M/s BPCL</td>
                                                    <td>Draft Survey/Bunker Survey</td>
                                                </tr>
                                                <tr>
                                                    <td>10</td>
                                                    <td>M/s. Eveready Shipping Pvt. Ltd.</td>
                                                    <td>Draft Survey/Bunker Survey</td>
                                                </tr>
                                                <tr>
                                                    <td>11</td>
                                                    <td>M/s. Merchant Shipping Services Ltd.</td>
                                                    <td>Draft Survey/Bunker Survey</td>
                                                </tr>
                                                <tr>
                                                    <td>12</td>
                                                    <td>M/s. Samsara Shipping Pvt. Ltd.</td>
                                                    <td>Draft Survey/Bunker Survey</td>
                                                </tr>
                                                <tr>
                                                    <td>13</td>
                                                    <td>M/s. Admiral Shipping Ltd.</td>
                                                    <td>Draft Survey/Bunker Survey</td>
                                                </tr>
                                                <tr>
                                                    <td>14</td>
                                                    <td>M/s. Admiralty Marine Services </td>
                                                    <td>Draft Survey/Bunker Survey</td>
                                                </tr>
                                                <tr>
                                                    <td>15</td>
                                                    <td>M/s. Atlantic Shipping Pvt. Ltd.</td>
                                                    <td>Barge Bunker Survey/Ullage Survey</td>
                                                </tr>
                                                <tr>
                                                    <td>16</td>
                                                    <td>M/s. Gac Shipping India Pvt. Ltd.</td>
                                                    <td>On/Off- hire Bunker Survey/Ullage Survey</td>
                                                </tr>
                                                <tr>
                                                    <td>17</td>
                                                    <td>M/s. Shipping Corporation of India Ltd.</td>
                                                    <td>Ullage Survey</td>
                                                </tr>
                                                <tr>
                                                    <td>18</td>
                                                    <td>M/s. Navship Marine Services Pvt. Ltd.</td>
                                                    <td>Draft Survey</td>
                                                </tr>
                                                <tr>
                                                    <td>19</td>
                                                    <td>M/s. TM International Logistics Ltd.</td>
                                                    <td>Draft Survey/Bunker Survey</td>
                                                </tr>
                                                <tr>
                                                    <td>20</td>
                                                    <td>M/s. ASL Shipping and Logistics India Pvt. Ltd. </td>
                                                    <td>Draft Survey/Tally Survey</td>
                                                </tr>
                                                <tr>
                                                    <td>21</td>
                                                    <td>M/s. ACT Infraport Ltd.</td>
                                                    <td>Bunker & Condition Survey</td>
                                                </tr>
                                                <tr>
                                                    <td>22</td>
                                                    <td>M/s. Synergy Shipping Pvt. Ltd.</td>
                                                    <td>Draft Survey</td>
                                                </tr>
                                                <tr>
                                                    <td>23</td>
                                                    <td>M/s. Jyothi Marine Services Pvt. Ltd. </td>
                                                    <td>Draft Survey</td>
                                                </tr>
                                                <tr>
                                                    <td>24</td>
                                                    <td>M/s. Bothra Shipping Services Pvt. Ltd.</td>
                                                    <td>Draft Survey/Bunker Survey</td>
                                                </tr>
                                                <tr>
                                                    <td>25</td>
                                                    <td>M/s. Kalinga Allied Industries (Shipper side) </td>
                                                    <td>On board Continuous loading Supervision of Iron Ore Fines</td>
                                                </tr>
                                                <tr>
                                                    <td>26</td>
                                                    <td>M/s. Rungta Mines Ltd. (Shipper side)</td>
                                                    <td>On board Continuous loading Supervision of Iron Ore Fines</td>
                                                </tr>
                                                <tr>
                                                    <td>27</td>
                                                    <td>M/s. Kashvi Power & Steel Pvt. Ltd.</td>
                                                    <td>On board Continuous loading Supervision of Iron Ore Fines</td>
                                                </tr>
                                                <tr>
                                                    <td>28</td>
                                                    <td>M/s. S. M. NiryatPvt. Ltd.</td>
                                                    <td>On board Continuous loading Supervision of Iron Ore Fines</td>
                                                </tr>
                                                <tr>
                                                    <td>29</td>
                                                    <td>M/s. Praful Enterprises Pvt. Ltd.</td>
                                                    <td>On board Continuous loading Supervision of Iron Ore Fines</td>
                                                </tr>
                                                <tr>
                                                    <td>30</td>
                                                    <td>M/s. Kai International Pvt. Ltd.</td>
                                                    <td>On board Continuous loading Supervision of Iron Ore Fines</td>
                                                </tr>
                                                <tr>
                                                    <td>31</td>
                                                    <td>M/s. Bagadiya Brothers Pvt. Ltd. </td>
                                                    <td>On board Continuous loading Supervision of Iron Ore Fines</td>
                                                </tr>
                                                <tr>
                                                    <td>32</td>
                                                    <td>M/s. BS Minerals</td>
                                                    <td>On board Continuous loading Supervision of Iron Ore Fines</td>
                                                </tr>
                                                <tr>
                                                    <td>33</td>
                                                    <td>M/s. BS Metals Pvt. Ltd.</td>
                                                    <td>On board Continuous loading Supervision of Iron Ore Fines</td>
                                                </tr>
                                                <tr>
                                                    <td>34</td>
                                                    <td>M/s. Vedant Limited</td>
                                                    <td>On board Continuous loading Supervision of Iron Ore Fines</td>
                                                </tr>
                                                <tr>
                                                    <td>35</td>
                                                    <td>M/s. Crow Boda Company Private Ltd. </td>
                                                    <td>Kolkata P&I Survey, Sampling, Analysis & Monitor of loading of Iron Ore Fines in bulk.</td>
                                                </tr>
                                                <tr>
                                                    <td>36</td>
                                                    <td>M/s. Oldendorff Carriers Gmbh & Co.</td>
                                                    <td>Bunker Survey/B+C Survey</td>
                                                </tr>
                                                <tr>
                                                    <td>37</td>
                                                    <td>M/s. Sulian Shipping Pvt. Ltd.</td>
                                                    <td>Tank Lorry Survey</td>
                                                </tr>
                                                <tr>
                                                    <td>38</td>
                                                    <td>M/s. Cotecna Inspection India Pvt. Ltd.</td>
                                                    <td>Tank Lorry Survey</td>
                                                </tr>
                                                <tr>
                                                    <td>39</td>
                                                    <td>M/s. Leon Inspection & Testing India Pvt. Ltd.</td>
                                                    <td>Tank Lorry Survey</td>
                                                </tr>
                                                <tr>
                                                    <td>40</td>
                                                    <td>M/s. Inspectorate Griffith India Pvt. Ltd.</td>
                                                    <td>Draft Survey</td>
                                                </tr>
                                                <tr>
                                                    <td>47</td>
                                                    <td>M/s. Mitra S. K. Pvt. Ltd.</td>
                                                    <td>Draft Survey</td>
                                                </tr>
                                                <tr>
                                                    <td>42</td>
                                                    <td>M/s. Cargo Inspectors and Superintendence </td>
                                                    <td>Draft Survey</td>
                                                </tr>
                                                <tr>
                                                    <td>43</td>
                                                    <td>M/s. Alianz Bulk Carriers</td>
                                                    <td>Bunker Survey</td>
                                                </tr>
                                                <tr>
                                                    <td>44</td>
                                                    <td>M/s. Metcalfe & Hodgkinson Insurance India</td>
                                                    <td>Bunker Survey</td>
                                                </tr>
                                                <tr>
                                                    <td>45</td>
                                                    <td>M/s. Odisha Stevedores Ltd.</td>
                                                    <td>Initial, Intermediate & Final Draft Survey & Barge Bunker Survey</td>
                                                </tr>
                                                <tr>
                                                    <td>46</td>
                                                    <td>M/s. Karam Chand Thapar & Bros. (CS) Ltd.</td>
                                                    <td>Wagon Unloading Supervision Survey, Rake Re-conciliation, Cargo stacking Analysis survey, Railway siding clearance, Total Quantity measurement of Plot and Rake, Draft Survey of Vessels, Total quantity survey of the vessel loading and unloading & Thorough Quantity Analysis of 600 Rakes per month of KCT i.e. 8 million Ton of Cargo.
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="tech-tab">
                                    <p style="font-weight:600">Get in Touch :</p>
                                    <p>Plot No. 47, Room No. 201, Bank Street, Paradeep, Jagatsinghpur, Odisha – 754142, Ph – 8327723686</p>
                                    <p>For more information about our services or to request a survey, please contact us at our branches in Paradip, Dhamra, Gopalpur, and Vishakhapatnam.</p>
                                    <iframe src="https://www.google.com/maps/embed?pb=!1m13!1m8!1m3!1d7485.6604817722455!2d86.652531!3d20.265874!3m2!1i1024!2i768!4f13.1!3m2!1m1!2zMjDCsDE1JzU3LjIiTiA4NsKwMzknMTguNCJF!5e0!3m2!1sen!2sin!4v1762926366799!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <!-- Footer Start -->
    <?php include 'includes/footer.php'; ?>
    <!-- Footer End -->

    <!-- ScrollToTop Start -->
    <?php include 'includes/scroll.php'; ?>
    <!-- ScrollToTop End -->

    <!-- JS Start -->
    <?php include 'includes/js.php'; ?>
    <!-- JS End -->
</body>

</html>