<!doctype html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>DKM Group</title>
    <!-- CSS Start -->
    <?php include 'includes/css.php'; ?>
    <!-- CSS End -->
</head>

<body>
    <!-- Preloader Start -->
    <?php include 'includes/loader.php'; ?>
    <!-- Preloader End -->

    <!-- Header Start -->
    <?php include 'includes/header.php'; ?>
    <!-- Header End -->

    <!-- breadcumb start -->
    <div class="breadcumb-wrapper" data-bg-src="assets/img/bg/inn-ban.jpeg">
        <div class="container">
            <div class="breadcumb-content">
                <h1 class="breadcumb-title">Management</h1>
                <ul class="breadcumb-menu">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="management.php">Management</a></li>
                </ul>
            </div>
        </div>
    </div>
    <!-- breadcumb End -->


    <section>
        <div class="container">
            <div class="row mb-60">
                <div class="col-xl-4">
                    <div class="about-card-img mb-xl-0 mb-30"><img src="assets/img/team/jagat_krushna.jpg"
                            alt="team image">
                    </div>
                </div>
                <div class="col-xl-8">
                    <div class="about-card">
                        <h2 class="about-card_title h3">Mr. Jagat Krushna Patnaik</h2>
                        <p class="about-card_desig">CEO - Captain Dilip Kumar Mishra Insurance Surveyor and Loss Assessors Pvt Ltd</p>
                        <p class="about-card_text">Mr. Jagat Krushna Patnaik, the esteemed CEO of captain Dilip Kumar Mishra Insurance Surveyor and Loss Assessors Pvt Ltd, brings a wealth of experience and expertise to the helm of the company. As a seasoned Naval Mechanical Engineer with 38 years of experience in non-motor insurance claims, both in India and abroad, Mr. Patnaik's extensive knowledge and leadership are invaluable assets to our firm.</p>
                        <h4 class="box-title">Career Milestones</h4>
                        <p><span class="bullet-color">●</span> 1986-1996: Principal Surveyor, J.B. Boda Surveyors</p>
                        <p>- Conducted surveys and inspections for major insurance and shipping industry projects.</p>
                        <p>- Managed key projects including Nalco Smelter, Alumina Plants, BHEL/ABB Super Thermal Power Projects, and National Hydroelectric Power Corporation.</p>
                    </div>
                </div>
                <div class="col-xl-12">
                    <p>- Investigated casualties for P & I Clubs and handled insurance claims for fishing trawlers, dredgers, and ships.</p>
                    <p><span class="bullet-color">●</span> 1996-2002: General Manager & Principal Surveyor, Oman Loss Assessing Co. LLC </p>
                    <p>- Oversaw insurance claims related to hull and cargo across Oman, UAE, and the Gulf region.</p>
                    <p><span class="bullet-color">●</span> 2003-2006: Principal Surveyor, J.B. Boda Surveyor & Loss Assessor</p>
                    <p>- Managed the PAN India Reliance Telecom project and major hull claims.</p>
                    <p><span class="bullet-color">●</span> 2006-2009: General Manager & Principal Surveyor, Cunningham Lindsey International Pvt. Ltd.</p>
                    <p>- Led surveys for major steel plants and managed significant ship and cargo damages for underwriters.</p>
                    <p><span class="bullet-color">●</span> 2009-2011: General Manager & Principal Surveyor, Wilson Surveyor & Adjuster Pvt. Ltd.</p>
                    <p>- Oversaw major claims in marine cargo, engineering, fire departments, and hull & machinery claims.</p>
                    <p><span class="bullet-color">●</span> 2011-2021: Executive Director, McLarens Surveyor & Loss Assessors Pvt Ltd</p>
                    <p>- Coordinated catastrophic loss assessments for events including Cyclones Phailin, Hud Hud, Gaja, Titli, Fani, Bulbul, Amphan, Yaas, and major floods in Jammu & Kashmir, Chennai, Kerala, Bihar, Gujarat, Mumbai, Thane, Palghar, Kolhapur, Sangali, and Assam.</p>
                    <p>Mr. Patnaik's remarkable career and dedication to excellence position him as a pivotal leader in the insurance surveying and loss assessment industry, driving our commitment to integrity, precision, and client satisfaction.</p>
                </div>
            </div>


            <div class="d-block d-md-none mt-40 text-center">
                <div class="icon-box"><button data-slider-prev="#teamSlider1" class="slider-arrow default"><i
                            class="far fa-arrow-left"></i></button> <button data-slider-next="#teamSlider1"
                        class="slider-arrow default"><i class="far fa-arrow-right"></i></button></div>
            </div>
        </div>
    </section>

    <!-- Footer Start -->
    <?php include 'includes/footer.php'; ?>
    <!-- Footer End -->

    <!-- ScrollToTop Start -->
    <?php include 'includes/scroll.php'; ?>
    <!-- ScrollToTop End -->

    <!-- JS Start -->
    <?php include 'includes/js.php'; ?>
    <!-- JS End -->
</body>

</html>