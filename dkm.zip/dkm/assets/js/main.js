! function(e) {
    "use strict";

    function t(t) {
        e(t).length > 0 && e(t).each((function() {
            var t = e(this).find("a");
            e(this).find(t).each((function() {
                e(this).on("click", (function() {
                    var t = e(this.getAttribute("href"));
                    t.length && (event.preventDefault(), e("html, body").stop().animate({
                        scrollTop: t.offset().top - 10
                    }, 1e3))
                }))
            }))
        }))
    }
    if (e(window).on("load", (function() {
            e(".preloader").fadeOut()
        })), e(".preloader").length > 0 && e(".preloaderCls").each((function() {
            e(this).on("click", (function(t) {
                t.preventDefault(), e(".preloader").css("display", "none")
            }))
        })), e.fn.thmobilemenu = function(t) {
            var n = e.extend({
                menuToggleBtn: ".th-menu-toggle",
                bodyToggleClass: "th-body-visible",
                subMenuClass: "th-submenu",
                subMenuParent: "menu-item-has-children",
                thSubMenuParent: "th-item-has-children",
                subMenuParentToggle: "th-active",
                meanExpandClass: "th-mean-expand",
                appendElement: '<span class="th-mean-expand"></span>',
                subMenuToggleClass: "th-open",
                toggleSpeed: 400
            }, t);
            return this.each((function() {
                var t = e(this);

                function a() {
                    t.toggleClass(n.bodyToggleClass);
                    var a = "." + n.subMenuClass;
                    e(a).each((function() {
                        e(this).hasClass(n.subMenuToggleClass) && (e(this).removeClass(n.subMenuToggleClass), e(this).css("display", "none"), e(this).parent().removeClass(n.subMenuParentToggle))
                    }))
                }
                t.find("." + n.subMenuParent).each((function() {
                    var t = e(this).find("ul");
                    t.addClass(n.subMenuClass), t.css("display", "none"), e(this).addClass(n.subMenuParent), e(this).addClass(n.thSubMenuParent), e(this).children("a").append(n.appendElement)
                }));
                var i = "." + n.thSubMenuParent + " > a";
                e(i).each((function() {
                    e(this).on("click", (function(t) {
                        var a, i;
                        t.preventDefault(), a = e(this).parent(), (i = a.children("ul")).length > 0 && (a.toggleClass(n.subMenuParentToggle), i.slideToggle(n.toggleSpeed), i.toggleClass(n.subMenuToggleClass))
                    }))
                })), e(n.menuToggleBtn).each((function() {
                    e(this).on("click", (function() {
                        a()
                    }))
                })), t.on("click", (function(e) {
                    e.stopPropagation(), a()
                })), t.find("div").on("click", (function(e) {
                    e.stopPropagation()
                }))
            }))
        }, e(".th-menu-wrapper").thmobilemenu(), e(window).scroll((function() {
            e(this).scrollTop() > 500 ? (e(".sticky-wrapper").addClass("sticky"), e(".category-menu").addClass("close-category")) : (e(".sticky-wrapper").removeClass("sticky"), e(".category-menu").removeClass("close-category"))
        })), e(".menu-expand").each((function() {
            e(this).on("click", (function(t) {
                t.preventDefault(), e(".category-menu").toggleClass("open-category")
            }))
        })), t(".onepage-nav"), t(".scroll-down"), e(".scroll-top").length > 0) {
        var n = document.querySelector(".scroll-top"),
            a = document.querySelector(".scroll-top path"),
            i = a.getTotalLength();
        a.style.transition = a.style.WebkitTransition = "none", a.style.strokeDasharray = i + " " + i, a.style.strokeDashoffset = i, a.getBoundingClientRect(), a.style.transition = a.style.WebkitTransition = "stroke-dashoffset 10ms linear";
        var o = function() {
            var t = e(window).scrollTop(),
                n = e(document).height() - e(window).height(),
                o = i - t * i / n;
            a.style.strokeDashoffset = o
        };
        o(), e(window).scroll(o);
        jQuery(window).on("scroll", (function() {
            jQuery(this).scrollTop() > 50 ? jQuery(n).addClass("show") : jQuery(n).removeClass("show")
        })), jQuery(n).on("click", (function(e) {
            return e.preventDefault(), jQuery("html, body").animate({
                scrollTop: 0
            }, 750), !1
        }))
    }
    e("[data-bg-src]").length > 0 && e("[data-bg-src]").each((function() {
        var t = e(this).attr("data-bg-src");
        e(this).css("background-image", "url(" + t + ")"), e(this).removeAttr("data-bg-src").addClass("background-image")
    })), e("[data-bg-color]").length > 0 && e("[data-bg-color]").each((function() {
        var t = e(this).attr("data-bg-color");
        e(this).css("background-color", t), e(this).removeAttr("data-bg-color")
    })), e("[data-border]").each((function() {
        var t = e(this).data("border");
        e(this).css("--th-border-color", t)
    })), e("[data-mask-src]").length > 0 && e("[data-mask-src]").each((function() {
        var t = e(this).attr("data-mask-src");
        e(this).css({
            "mask-image": "url(" + t + ")",
            "-webkit-mask-image": "url(" + t + ")"
        }), e(this).addClass("bg-mask"), e(this).removeAttr("data-mask-src")
    })), e(".th-slider").each((function() {
        var t = e(this),
            n = e(this).data("slider-options"),
            a = t.find(".slider-prev"),
            i = t.find(".slider-next"),
            o = t.find(".slider-pagination"),
            s = n.autoplay,
            r = {
                slidesPerView: 1,
                spaceBetween: n.spaceBetween ? n.spaceBetween : 24,
                loop: 0 != n.loop,
                speed: n.speed ? n.speed : 1e3,
                autoplay: s || {
                    delay: 6e3,
                    disableOnInteraction: !1
                },
                navigation: {
                    nextEl: i.get(0),
                    prevEl: a.get(0)
                },
                pagination: {
                    el: o.get(0),
                    clickable: !0,
                    renderBullet: function(e, t) {
                        return '<span class="' + t + '" aria-label="Go to Slide ' + (e + 1) + '"></span>'
                    }
                }
            },
            l = JSON.parse(t.attr("data-slider-options"));
        l = e.extend({}, r, l);
        new Swiper(t.get(0), l);
        e(".slider-area").length > 0 && e(".slider-area").closest(".container").parent().addClass("arrow-wrap")
    })), e("[data-ani]").each((function() {
        var t = e(this).data("ani");
        e(this).addClass(t)
    })), e("[data-ani-delay]").each((function() {
        var t = e(this).data("ani-delay");
        e(this).css("animation-delay", t)
    })), e("[data-slider-prev], [data-slider-next]").on("click", (function() {
        var t = e(this).data("slider-prev") || e(this).data("slider-next"),
            n = e(t);
        if (n.length) {
            var a = n[0].swiper;
            a && (e(this).data("slider-prev") ? a.slidePrev() : a.slideNext())
        }
    }));
    var s, r, l, c = ".ajax-contact",
        d = '[name="email"]',
        u = e(".form-messages");

    function h() {
        var t = e(c).serialize();
        (function() {
            var t, n = !0;

            function a(a) {
                a = a.split(",");
                for (var i = 0; i < a.length; i++) t = c + " " + a[i], e(t).val() ? (e(t).removeClass("is-invalid"), n = !0) : (e(t).addClass("is-invalid"), n = !1)
            }
            a('[name="name"],[name="email"],[name="subject"],[name="number"],[name="message"]'), e(d).val() && e(d).val().match(/^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/) ? (e(d).removeClass("is-invalid"), n = !0) : (e(d).addClass("is-invalid"), n = !1);
            return n
        })() && jQuery.ajax({
            url: e(c).attr("action"),
            data: t,
            type: "POST"
        }).done((function(t) {
            u.removeClass("error"), u.addClass("success"), u.text(t), e(c + ' input:not([type="submit"]),' + c + " textarea").val("")
        })).fail((function(e) {
            u.removeClass("success"), u.addClass("error"), "" !== e.responseText ? u.html(e.responseText) : u.html("Oops! An error occured and your message could not be sent.")
        }))
    }

    function p(t, n, a, i) {
        e(n).on("click", (function(n) {
            n.preventDefault(), e(t).addClass(i)
        })), e(t).on("click", (function(n) {
            n.stopPropagation(), e(t).removeClass(i)
        })), e(t + " > div").on("click", (function(n) {
            n.stopPropagation(), e(t).addClass(i)
        })), e(a).on("click", (function(n) {
            n.preventDefault(), n.stopPropagation(), e(t).removeClass(i)
        }))
    }

    function f(e) {
        return parseInt(e, 10)
    }
    e(c).on("submit", (function(e) {
        e.preventDefault(), h()
    })), s = ".popup-search-box", r = ".searchClose", l = "show", e(".searchBoxToggler").on("click", (function(t) {
        t.preventDefault(), e(s).addClass(l)
    })), e(s).on("click", (function(t) {
        t.stopPropagation(), e(s).removeClass(l)
    })), e(s).find("form").on("click", (function(t) {
        t.stopPropagation(), e(s).addClass(l)
    })), e(r).on("click", (function(t) {
        t.preventDefault(), t.stopPropagation(), e(s).removeClass(l)
    })), p(".sidemenu-cart", ".sideMenuToggler", ".sideMenuCls", "show"), p(".sidemenu-info", ".sideMenuInfo", ".sideMenuCls", "show"), e(".popup-image").magnificPopup({
        type: "image",
        mainClass: "mfp-zoom-in",
        removalDelay: 260,
        gallery: {
            enabled: !0
        }
    }), e(".popup-video").magnificPopup({
        type: "iframe",
        mainClass: "mfp-zoom-in"
    }), e(".popup-content").magnificPopup({
        type: "inline",
        midClick: !0
    }), e.fn.sectionPosition = function(t, n) {
        e(this).each((function() {
            var a, i, o, s, r, l = e(this);
            a = Math.floor(l.height() / 2), i = l.attr(t), o = l.attr(n), s = f(e(o).css("padding-top")), r = f(e(o).css("padding-bottom")), "top-half" === i ? (e(o).css("padding-bottom", r + a + "px"), l.css("margin-top", "-" + a + "px")) : "bottom-half" === i && (e(o).css("padding-top", s + a + "px"), l.css("margin-bottom", "-" + a + "px"))
        }))
    };
    e("[data-sec-pos]").length && e("[data-sec-pos]").imagesLoaded((function() {
        e("[data-sec-pos]").sectionPosition("data-sec-pos", "data-pos-for")
    })), e(".filter-active").imagesLoaded((function() {
        if (e(".filter-active").length > 0) {
            var t = e(".filter-active").isotope({
                itemSelector: ".filter-item",
                filter: "*",
                masonry: {}
            });
            e(".filter-menu-active").on("click", "button", (function() {
                var n = e(this).attr("data-filter");
                t.isotope({
                    filter: n
                })
            })), e(".filter-menu-active").on("click", "button", (function(t) {
                t.preventDefault(), e(this).addClass("active"), e(this).siblings(".active").removeClass("active")
            }))
        }
    })), e(".masonary-active, .woocommerce-Reviews .comment-list").imagesLoaded((function() {
        var t = ".masonary-active, .woocommerce-Reviews .comment-list";
        e(t).length > 0 && e(t).isotope({
            itemSelector: ".filter-item, .woocommerce-Reviews .comment-list li",
            filter: "*",
            masonry: {
                columnWidth: 1
            }
        }), e('[data-bs-toggle="tab"]').on("shown.bs.tab", (function(n) {
            e(t).isotope({
                filter: "*"
            })
        }))
    })), e(".counter-number").counterUp({
        delay: 10,
        time: 1e3
    }), e.fn.shapeMockup = function() {
        e(this).each((function() {
            var t = e(this),
                n = t.data("top"),
                a = t.data("right"),
                i = t.data("bottom"),
                o = t.data("left");
            t.css({
                top: n,
                right: a,
                bottom: i,
                left: o
            }).removeAttr("data-top").removeAttr("data-right").removeAttr("data-bottom").removeAttr("data-left").parent().addClass("shape-mockup-wrap")
        }))
    }, e(".shape-mockup") && e(".shape-mockup").shapeMockup(), e(".progress-bar").waypoint((function() {
        e(".progress-bar").css({
            animation: "animate-positive 1.8s",
            opacity: "1"
        })
    }), {
        offset: "75%"
    }), e.fn.countdown = function() {
        e(this).each((function() {
            var t = e(this),
                n = new Date(t.data("offer-date")).getTime();

            function a(e) {
                return t.find(e)
            }
            var i = setInterval((function() {
                var e = (new Date).getTime(),
                    o = n - e,
                    s = Math.floor(o / 864e5),
                    r = Math.floor(o % 864e5 / 36e5),
                    l = Math.floor(o % 36e5 / 6e4),
                    c = Math.floor(o % 6e4 / 1e3);
                s < 10 && (s = "0" + s), r < 10 && (r = "0" + r), l < 10 && (l = "0" + l), c < 10 && (c = "0" + c), o < 0 ? (clearInterval(i), t.addClass("expired"), t.find(".message").css("display", "block")) : (a(".day").html(s), a(".hour").html(r), a(".minute").html(l), a(".seconds").html(c))
            }), 1e3)
        }))
    }, e(".counter-list").length && e(".counter-list").countdown();
    const m = {};

    function g() {
        const t = e(this),
            n = t.attr("src");
        if (!m[n]) {
            const t = e.Deferred();
            e.get(n, n => {
                t.resolve(e(n).find("svg"))
            }), m[n] = t.promise()
        }
        m[n].then(n => {
            const a = e(n).clone();
            t.attr("id") && a.attr("id", t.attr("id")), t.attr("class") && a.attr("class", t.attr("class")), t.attr("style") && a.attr("style", t.attr("style")), t.attr("width") && (a.attr("width", t.attr("width")), t.attr("height") || a.removeAttr("height")), t.attr("height") && (a.attr("height", t.attr("height")), t.attr("width") || a.removeAttr("width")), a.insertAfter(t), t.trigger("svgInlined", a[0]), t.remove()
        })
    }

    function v() {
        e(".feature-circle .progressbar").each((function() {
            var t = e(this).offset().top,
                n = e(window).scrollTop(),
                a = e(this).find(".circle").attr("data-percent"),
                i = (parseInt(a, 10), parseInt(100, 10), e(this).data("animate"));
            t < n + e(window).height() - 30 && !i && (e(this).data("animate", !0), e(this).find(".circle").circleProgress({
                startAngle: -Math.PI / 2,
                value: a / 100,
                size: 100,
                thickness: 5,
                emptyFill: "#B7B7B7",
                fill: {
                    color: "#F84923"
                }
            }).on("circle-animation-progress", (function(t, n, a) {
                e(this).find(".circle-num").text((100 * a).toFixed(0) + "%")
            })).stop())
        }))
    }

    function y(t) {
        var n = t.touches ? t.touches[0].clientX : t.clientX,
            a = t.touches ? t.touches[0].clientY : t.clientY,
            i = window.innerWidth / 2,
            o = window.innerHeight / 2,
            s = -(n - i) / (i / 1) - 1,
            r = -(a - o) / (o / 1) - 1;
        TweenMax.to(e(".hero-tweenmax"), 1, {
            top: r + "%",
            left: s + "%"
        })
    }

    function w(t, n, a, i) {
        var o = t.text().split(n),
            s = "";
        o.length && (e(o).each((function(e, t) {
            s += '<span class="' + a + (e + 1) + '">' + t + "</span>" + i
        })), t.empty().append(s))
    }
    e.fn.inlineSvg = function() {
        return this.each(g), this
    }, e(".svg-img").inlineSvg(), v(), e(window).scroll(v), e("#ship-to-different-address-checkbox").on("change", (function() {
        e(this).is(":checked") ? e("#ship-to-different-address").next(".shipping_address").slideDown() : e("#ship-to-different-address").next(".shipping_address").slideUp()
    })), e(".woocommerce-form-login-toggle a").on("click", (function(t) {
        t.preventDefault(), e(".woocommerce-form-login").slideToggle()
    })), e(".woocommerce-form-coupon-toggle a").on("click", (function(t) {
        t.preventDefault(), e(".woocommerce-form-coupon").slideToggle()
    })), e(".shipping-calculator-button").on("click", (function(t) {
        t.preventDefault(), e(this).next(".shipping-calculator-form").slideToggle()
    })), e('.wc_payment_methods input[type="radio"]:checked').siblings(".payment_box").show(), e('.wc_payment_methods input[type="radio"]').each((function() {
        e(this).on("change", (function() {
            e(".payment_box").slideUp(), e(this).siblings(".payment_box").slideDown()
        }))
    })), e(".rating-select .stars a").each((function() {
        e(this).on("click", (function(t) {
            t.preventDefault(), e(this).siblings().removeClass("active"), e(this).parent().parent().addClass("selected"), e(this).addClass("active")
        }))
    })), e(".quantity-plus").each((function() {
        e(this).on("click", (function(t) {
            t.preventDefault();
            var n = e(this).siblings(".qty-input"),
                a = parseInt(n.val(), 10);
            isNaN(a) || n.val(a + 1)
        }))
    })), e(".quantity-minus").each((function() {
        e(this).on("click", (function(t) {
            t.preventDefault();
            var n = e(this).siblings(".qty-input"),
                a = parseInt(n.val(), 10);
            !isNaN(a) && a > 1 && n.val(a - 1)
        }))
    })), window.addEventListener("mousemove", y), window.addEventListener("touchstart", y), window.addEventListener("touchmove", y);
    var b = {
        init: function() {
            return this.each((function() {
                w(e(this), "", "char", "")
            }))
        },
        words: function() {
            return this.each((function() {
                w(e(this), " ", "word", " ")
            }))
        },
        lines: function() {
            return this.each((function() {
                var t = "eefec303079ad17405c889e092e105b0";
                w(e(this).children("br").replaceWith(t).end(), t, "line", "")
            }))
        }
    };
    e.fn.lettering = function(t) {
        return t && b[t] ? b[t].apply(this, [].slice.call(arguments, 1)) : "letters" !== t && t ? (e.error("Method " + t + " does not exist on jQuery.lettering"), this) : b.init.apply(this, [].slice.call(arguments, 0))
    }, e(".circle-title-anime").lettering(), e.fn.countdown = function() {
        e(this).each((function() {
            var t = e(this),
                n = new Date(t.data("offer-date")).getTime();

            function a(e) {
                return t.find(e)
            }
            var i = setInterval((function() {
                var e = (new Date).getTime(),
                    o = n - e,
                    s = Math.floor(o / 864e5),
                    r = Math.floor(o % 864e5 / 36e5),
                    l = Math.floor(o % 36e5 / 6e4),
                    c = Math.floor(o % 6e4 / 1e3);
                s < 10 && (s = "0" + s), r < 10 && (r = "0" + r), l < 10 && (l = "0" + l), c < 10 && (c = "0" + c), o < 0 ? (clearInterval(i), t.addClass("expired"), t.find(".message").css("display", "block")) : (a(".day").html(s), a(".hour").html(r), a(".minute").html(l), a(".seconds").html(c))
            }), 1e3)
        }))
    }, e(".counter-list").length && e(".counter-list").countdown(); 
    // window.addEventListener("contextmenu", (function(e) {
    //     e.preventDefault()
    // }), !1), document.onkeydown = function(e) {
    //     return 123 != event.keyCode && ((!e.ctrlKey || !e.shiftKey || e.keyCode != "I".charCodeAt(0)) && ((!e.ctrlKey || !e.shiftKey || e.keyCode != "C".charCodeAt(0)) && ((!e.ctrlKey || !e.shiftKey || e.keyCode != "J".charCodeAt(0)) && ((!e.ctrlKey || e.keyCode != "U".charCodeAt(0)) && void 0))))
    // }
}(jQuery);

// gallery
//   Thumbnail LightGallery Scripts 
function openGallery(id, index = 0) {
      const galleryEl = document.getElementById(id);
      const lg = lightGallery(galleryEl, {
        plugins: [lgThumbnail],
        thumbnail: true,
        download: true,
        zoom: true,
        hideBarsDelay: 3000,
        mode: 'lg-fade'
      });
      lg.openGallery(index);
    }