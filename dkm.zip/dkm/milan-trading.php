<!doctype html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>DKM Group</title>
    <!-- CSS Start -->
    <?php include 'includes/css.php'; ?>
    <!-- CSS End -->
</head>

<body>
    <!-- Preloader Start -->
    <?php include 'includes/loader.php'; ?>
    <!-- Preloader End -->

    <!-- Header Start -->
    <?php include 'includes/header.php'; ?>
    <!-- Header End -->

    <!-- breadcumb start -->
        <div class="breadcumb-wrapper" data-bg-src="assets/img/bg/inn-ban.jpeg">
        <div class="container">
            <div class="breadcumb-content">
                <h1 class="breadcumb-title">Divison</h1>
                <ul class="breadcumb-menu">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="division.php">Divison</a></li>
                    <li>Milan Trading</li>
                </ul>
            </div>
        </div>
    </div>
    <!-- breadcumb End -->

    <section class="space-top space-extra-bottom">
        <div class="container">
            <div class="row">
                <div class="col-xxl-12 col-lg-12">
                    <div class="page-single mb-40">
                        <div class="page-content">
                            <ul class="nav product-tab-style1 mt-40 pb-0" id="productTab" role="tablist">
                                <li class="nav-item" role="presentation"><a class="nav-link th-btn active"
                                        id="home-tab" data-bs-toggle="tab" href="#home" role="tab"
                                        aria-controls="description" aria-selected="false">Home</a></li>
                                <li class="nav-item" role="presentation"><a class="nav-link th-btn" id="reviews-tab"
                                        data-bs-toggle="tab" href="#about" role="tab" aria-controls="reviews"
                                        aria-selected="true">About Us</a></li>
                                <li class="nav-item" role="presentation"> <a class="nav-link th-btn" id="tech-tab"
                                        data-bs-toggle="tab" href="#services" role="tab" aria-controls="tech"
                                        aria-selected="true">Services</a></li>
                                <li class="nav-item" role="presentation"> <a class="nav-link th-btn" id="tech-tab"
                                        data-bs-toggle="tab" href="#team" role="tab" aria-controls="tech"
                                        aria-selected="true">Team</a></li>
                                <li class="nav-item" role="presentation"> <a class="nav-link th-btn" id="tech-tab"
                                        data-bs-toggle="tab" href="#choose" role="tab" aria-controls="tech"
                                        aria-selected="true">Why Choose Us?</a></li>
                                <li class="nav-item" role="presentation"> <a class="nav-link th-btn" id="tech-tab"
                                        data-bs-toggle="tab" href="#Clientele" role="tab" aria-controls="tech"
                                        aria-selected="true">Our Clientele </a></li>
                                <li class="nav-item" role="presentation"> <a class="nav-link th-btn" id="tech-tab"
                                        data-bs-toggle="tab" href="#gallery" role="tab" aria-controls="tech"
                                        aria-selected="true">Gallery</a></li>
                                <li class="nav-item" role="presentation"> <a class="nav-link th-btn" id="tech-tab"
                                        data-bs-toggle="tab" href="#contact" role="tab" aria-controls="tech"
                                        aria-selected="true">Contact Us</a></li>
                            </ul>
                            <div class="tab-content" id="productTabContent">
                                <div class="tab-pane fade show active" id="home" role="tabpanel"
                                    aria-labelledby="description-tab">
                                    <p style="text-align: center; font-weight:600">Welcome to Milan Trading.</p>
                                    <p class="mb-30">Operating since 2000, Milan Trading is a super stockist, super distributorship, and C & F agent of renowned brands such as Amul products, Perfetti chocolates, Emami cosmetics, and Livguard inverters. With a strong distribution network, Milan Trading ensures timely delivery and exceptional service.</p>

                                </div>
                                <div class="tab-pane fade" id="about" role="tabpanel" aria-labelledby="reviews-tab">
                                    <p class="mb-30">Welcome to Milan Trading, your trusted super-distributor and stockist for top-quality FMCG products and electronic items in Odisha. We pride ourselves on partnering with renowned brands such as Amul, Emami, and Perfetti chocolates in the FMCG sector, and Livguard inverters and batteries in the electronics domain. Our robust distribution network spans across Cuttack, Jajpur, Kendrapada districts, and throughout Odisha, ensuring that our products reach you timely and in excellent condition.<br>
                                    With a commitment to quality and customer satisfaction, we hold the necessary Trade License Certificate and FSSAI Certificate from the Government of Odisha under the FSS Act, 2006.</p>

                                </div>
                                <div class="tab-pane fade" id="services" role="tabpanel" aria-labelledby="tech-tab">
                                    <p style="font-weight: 600;">FMCG Products:</p>
                                    <p>We offer a wide selection of FMCG products from leading brands such as:</p>
                                    <p>– Amul:  Dairy products and beverages.</p>
                                    <p>– Emami:  Personal care and health products.</p>
                                    <p>– Perfetti:  Wide range of chocolates and confectionery.</p>

                                    <p style="font-weight: 600;">Electronic Items:</p>
                                    <p>Our electronics section includes high-performance products from Livguard:</p>
                                    <p>– Inverters: Reliable power solutions for uninterrupted electricity.</p>
                                    <p>– Batteries: Durable and efficient batteries for various applications.</p>
                                   
                                </div>
                                <div class="tab-pane fade" id="team" role="tabpanel" aria-labelledby="tech-tab">
                                    <p style="font-weight: 600;">Leadership:</p>
                                    <p class="mb-30">– Managing Director: Mr. Milan Mishra</p>
                                    <p class="mb-30">– General Manager: Mr. Jayaprakash Nair</p>
                                    <img src="assets/img/division-img/phoenix-team.jpg" alt="" style="float: right;">
                                    <p style="font-weight: 600;">Our Dedicated Team:</p>
                                    <p class="mb-30">Our success is driven by a dedicated team comprising experts in various domains:</p>
                                    <p class="mb-30">– Accounts: Ensuring accurate and efficient financial management.</p>
                                    <p class="mb-30">– Sales: Focused on building strong customer relationships and driving sales growth.</p>
                                    <p class="mb-30">– Marketing: Creating impactful marketing strategies to promote our brands.</p>
                                    <p class="mb-30">– Logistics:  Managing the seamless transportation and timely delivery of products.</p>
                                    <p class="mb-30">– Drivers: Ensuring the safe and punctual delivery of goods to our customers.</p>


                                </div>
                                <div class="tab-pane fade" id="choose" role="tabpanel" aria-labelledby="tech-tab">
                                    <p>– Branded Products: We stock a wide range of high-quality products from trusted brands like Amul, Emami, Perfetti, and Livguard.</p>
                                    <p>– Strong Distribution Network: Our extensive network across multiple districts ensures timely and reliable delivery.</p>
                                    <p>– Government Certified: We are fully certified with Trade License and FSSAI Certificate, ensuring compliance with all regulatory standards.</p>
                                    <p>– Exceptional Customer Service: Our dedicated team is always ready to assist with any queries and provide exceptional service.</p>
                                    <p>– Timely Delivery: Our efficient logistics system guarantees that your orders are delivered promptly.</p>
                                    <p>At Milan Trading, we are committed to delivering quality products and exceptional service, ensuring that our customers always come first. Thank you for choosing us as your trusted distribution partner.</p>

                                </div>
                                <div class="tab-pane fade" id="Clientele" role="tabpanel" aria-labelledby="tech-tab">
                                    

                                </div>
                                <div class="tab-pane fade" id="gallery" role="tabpanel" aria-labelledby="tech-tab">
                                    <div class="gallery-area pt-50 pb-50">
                                        <div class="container">
                                            <div class="row mt-none-30 justify-content-center">

                                                <div class="col-md-3 pb-30">
                                                    <div class="event-image-container" onclick="openGallery('pictureGallery', 0)">
                                                        <img src="assets/img/division-img/gallery3/img1.jpg" class="event-image">
                                                        <div class="event-overlay">
                                                            <span>View</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3 pb-30">
                                                    <div class="event-image-container" onclick="openGallery('pictureGallery', 1)">
                                                        <img src="assets/img/division-img/gallery3/img2.jpeg" class="event-image">
                                                        <div class="event-overlay">
                                                            <span>View</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3 pb-30">
                                                    <div class="event-image-container" onclick="openGallery('pictureGallery', 2)">
                                                        <img src="assets/img/division-img/gallery3/img3.jpeg" class="event-image">
                                                        <div class="event-overlay">
                                                            <span>View</span>
                                                        </div>
                                                    </div>
                                                </div>


                                                <div id="pictureGallery" class="d-none">
                                                    <a href="assets/img/division-img/gallery3/img1.jpg"><img src="assets/img/division-img/gallery3/img1.jpg"></a>
                                                    <a href="assets/img/division-img/gallery3/img2.jpeg"><img src="assets/img/division-img/gallery3/img2.jpeg"></a>
                                                    <a href="assets/img/division-img/gallery3/img3.jpeg"><img src="assets/img/division-img/gallery3/img3.jpeg"></a>
                                                </div>


                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="tech-tab">
                                    <p style="font-weight:600">Get in Touch :</p>
                                    <p>Gamandia New Colony, Buxibazar, Cuttack -1, Cuttack Municipal Corporation, Odisha – 753012, PH – 06713591604/9338105086</p>
                                   
                                    <iframe src="https://www.google.com/maps/embed?pb=!1m13!1m8!1m3!1d7475.8777298576215!2d85.880459!3d20.467704!3m2!1i1024!2i768!4f13.1!3m2!1m1!2zMjDCsDI4JzAzLjciTiA4NcKwNTInNTguOSJF!5e0!3m2!1sen!2sin!4v1762940978374!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <!-- Footer Start -->
    <?php include 'includes/footer.php'; ?>
    <!-- Footer End -->

    <!-- ScrollToTop Start -->
    <?php include 'includes/scroll.php'; ?>
    <!-- ScrollToTop End -->

    <!-- JS Start -->
    <?php include 'includes/js.php'; ?>
    <!-- JS End -->
</body>

</html>