<!doctype html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>DKM Group</title>
    <!-- CSS Start -->
    <?php include 'includes/css.php'; ?>
    <!-- CSS End -->
</head>

<body>
    <!-- Preloader Start -->
    <?php include 'includes/loader.php'; ?>
    <!-- Preloader End -->

    <!-- Header Start -->
    <?php include 'includes/header.php'; ?>
    <!-- Header End -->

    <!-- breadcumb start -->
    <div class="breadcumb-wrapper" data-bg-src="assets/img/bg/inn-ban.jpeg">
        <div class="container">
            <div class="breadcumb-content">
                <h1 class="breadcumb-title">Management</h1>
                <ul class="breadcumb-menu">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="management.php">Management</a></li>
                </ul>
            </div>
        </div>
    </div>
    <!-- breadcumb End -->


    <section>
        <div class="container">
            <div class="row mb-60">
                <div class="col-xl-4">
                    <div class="about-card-img mb-xl-0 mb-30"><img src="assets/img/team/amarendra.jpg"
                            alt="team image">

                    </div>
                </div>
                <div class="col-xl-8">
                    <div class="about-card">
                        <h2 class="about-card_title h3">Mr. Amarendra Nayak</h2>
                        <p class="about-card_desig">General Manager, Phoenix India Refinery</p>
                        <p class="about-card_text">Hailing from Kendrapada, Mr. Amarendra joined Phoenix India Refinery in 2021 and has since been a pivotal force in driving the company’s success.<br><br>
                        With over 20 years of experience in the shipping industry, including notable tenures at Startek (Paradip) and KM Oils Pvt Ltd (Paradip), Mr. Nayak brings a wealth of knowledge and expertise to his role. His leadership ensures seamless coordination and execution of services, maintaining Phoenix India Refinery’s high standards in operations, logistics and environmental management.<br><br>

                        Mr. Nayak's dedication to excellence and his deep understanding of industry dynamics have been instrumental in enhancing the company’s operations and reputation. Under his guidance, Phoenix India Refinery continues to thrive, delivering top-notch services and contributing to sustainable practices in the maritime sector.</p>


                    </div>
                </div>
            </div>


            <div class="d-block d-md-none mt-40 text-center">
                <div class="icon-box"><button data-slider-prev="#teamSlider1" class="slider-arrow default"><i
                            class="far fa-arrow-left"></i></button> <button data-slider-next="#teamSlider1"
                        class="slider-arrow default"><i class="far fa-arrow-right"></i></button></div>
            </div>
        </div>
    </section>

    <!-- Footer Start -->
    <?php include 'includes/footer.php'; ?>
    <!-- Footer End -->

    <!-- ScrollToTop Start -->
    <?php include 'includes/scroll.php'; ?>
    <!-- ScrollToTop End -->

    <!-- JS Start -->
    <?php include 'includes/js.php'; ?>
    <!-- JS End -->
</body>

</html>