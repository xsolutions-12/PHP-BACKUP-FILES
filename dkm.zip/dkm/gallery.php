<!doctype html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Gallery - DKM Group</title>
    <!-- CSS Start -->
    <?php include 'includes/css.php';?>
    <!-- CSS End -->
</head>

<body>
    <?php include 'includes/loader.php';?>
    <!-- Header Start -->
    <?php include 'includes/header.php';?>
    <!-- Header End -->

    <div class="breadcumb-wrapper" data-bg-src="assets/img/bg/inn-ban.jpeg">
        <div class="container">
            <div class="breadcumb-content">
                <h1 class="breadcumb-title">Gallery</h1>
                <ul class="breadcumb-menu">
                    <li><a href="index.php">Home</a></li>
                    <li>Gallery</li>
                </ul>
            </div>
        </div>
    </div>


    <!-- Green House start -->
    <section class="gallery-area pt-50 pb-50">
        <div class="container">
            <div class="row mt-none-30 justify-content-center">

                <div class="col-md-12">
                    <div class="title-area text-center"><span class="sub-title"><img class="me-2"
                                src="assets/img/theme-img/title_icon.svg" alt="shape">GALLERY<img class="ms-2"
                                src="assets/img/theme-img/title_icon.svg" alt="shape"></span>
                    </div>
                </div>

                <div class="col-md-3 pb-30">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 0)">
                        <img src="assets/img/gallery/1.jpg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 pb-30">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 1)">
                        <img src="assets/img/gallery/2.jpeg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 pb-30">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 2)">
                        <img src="assets/img/gallery/3.jpeg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 pb-30">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 3)">
                        <img src="assets/img/gallery/4.jpeg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 pb-30">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 4)">
                        <img src="assets/img/gallery/5.jpg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 pb-30">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 5)">
                        <img src="assets/img/gallery/6.jpg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 pb-30">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 6)">
                        <img src="assets/img/gallery/7.jpeg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 pb-30">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 7)">
                        <img src="assets/img/gallery/8.jpeg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 pb-30">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 8)">
                        <img src="assets/img/gallery/9.jpeg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 pb-30">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 9)">
                        <img src="assets/img/gallery/10.jpeg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 pb-30">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 10)">
                        <img src="assets/img/gallery/11.jpeg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 pb-30">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 11)">
                        <img src="assets/img/gallery/12.jpeg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 pb-30">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 12)">
                        <img src="assets/img/gallery/13.jpeg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 pb-30">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 13)">
                        <img src="assets/img/gallery/14.jpeg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 pb-30">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 14)">
                        <img src="assets/img/gallery/15.jpeg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 pb-30">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 15)">
                        <img src="assets/img/gallery/16.jpeg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 pb-30">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 16)">
                        <img src="assets/img/gallery/17.jpeg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 pb-30">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 17)">
                        <img src="assets/img/gallery/18.jpg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 pb-30">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 18)">
                        <img src="assets/img/gallery/19.jpeg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 pb-30">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 19)">
                        <img src="assets/img/gallery/20.jpeg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 pb-30">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 20)">
                        <img src="assets/img/gallery/21.jpeg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 pb-30">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 21)">
                        <img src="assets/img/gallery/22.jpeg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 pb-30">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 22)">
                        <img src="assets/img/gallery/23.jpeg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 pb-30">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 23)">
                        <img src="assets/img/gallery/24.jpeg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 pb-30">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 24)">
                        <img src="assets/img/gallery/25.jpeg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 pb-30">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 25)">
                        <img src="assets/img/gallery/26.jpeg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 pb-30">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 26)">
                        <img src="assets/img/gallery/27.jpeg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 pb-30">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 27)">
                        <img src="assets/img/gallery/28.jpeg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 pb-30">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 28)">
                        <img src="assets/img/gallery/29.jpeg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 pb-30">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 29)">
                        <img src="assets/img/gallery/30.jpeg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 pb-30">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 30)">
                        <img src="assets/img/gallery/31.jpeg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 pb-30">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 31)">
                        <img src="assets/img/gallery/32.jpeg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 pb-30">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 32)">
                        <img src="assets/img/gallery/33.jpeg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 pb-30">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 33)">
                        <img src="assets/img/gallery/34.jpeg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 pb-30">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 34)">
                        <img src="assets/img/gallery/35.jpeg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 pb-30">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 35)">
                        <img src="assets/img/gallery/36.jpeg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 pb-30">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 36)">
                        <img src="assets/img/gallery/37.jpeg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 pb-30">
                    <div class="event-image-container" onclick="openGallery('pictureGallery', 37)">
                        <img src="assets/img/gallery/38.jpeg" class="event-image">
                        <div class="event-overlay">
                            <span>View</span>
                        </div>
                    </div>
                </div>

                <div id="pictureGallery" class="d-none">
                    <a href="assets/img/gallery/1.jpg"><img src="assets/img/gallery/1.jpg"></a>
                    <a href="assets/img/gallery/2.jpeg"><img src="assets/img/gallery/2.jpeg"></a>
                    <a href="assets/img/gallery/3.jpeg"><img src="assets/img/gallery/3.jpeg"></a>
                    <a href="assets/img/gallery/4.jpeg"><img src="assets/img/gallery/4.jpeg"></a>
                    <a href="assets/img/gallery/5.jpg"><img src="assets/img/gallery/5.jpg"></a>
                    <a href="assets/img/gallery/6.jpg"><img src="assets/img/gallery/6.jpg"></a>
                    <a href="assets/img/gallery/7.jpeg"><img src="assets/img/gallery/7.jpeg"></a>
                    <a href="assets/img/gallery/8.jpeg"><img src="assets/img/gallery/8.jpeg"></a>
                    <a href="assets/img/gallery/9.jpeg"><img src="assets/img/gallery/9.jpeg"></a>
                    <a href="assets/img/gallery/10.jpeg"><img src="assets/img/gallery/10.jpeg"></a>
                    <a href="assets/img/gallery/11.jpeg"><img src="assets/img/gallery/11.jpeg"></a>
                    <a href="assets/img/gallery/12.jpeg"><img src="assets/img/gallery/12.jpeg"></a>
                    <a href="assets/img/gallery/13.jpeg"><img src="assets/img/gallery/13.jpeg"></a>
                    <a href="assets/img/gallery/14.jpeg"><img src="assets/img/gallery/14.jpeg"></a>
                    <a href="assets/img/gallery/15.jpeg"><img src="assets/img/gallery/15.jpeg"></a>
                    <a href="assets/img/gallery/16.jpeg"><img src="assets/img/gallery/16.jpeg"></a>
                    <a href="assets/img/gallery/17.jpeg"><img src="assets/img/gallery/17.jpeg"></a>
                    <a href="assets/img/gallery/18.jpg"><img src="assets/img/gallery/18.jpg"></a>
                    <a href="assets/img/gallery/19.jpeg"><img src="assets/img/gallery/19.jpeg"></a>
                    <a href="assets/img/gallery/20.jpeg"><img src="assets/img/gallery/20.jpeg"></a>
                    <a href="assets/img/gallery/21.jpeg"><img src="assets/img/gallery/21.jpeg"></a>
                    <a href="assets/img/gallery/22.jpeg"><img src="assets/img/gallery/22.jpeg"></a>
                    <a href="assets/img/gallery/23.jpeg"><img src="assets/img/gallery/23.jpeg"></a>
                    <a href="assets/img/gallery/24.jpeg"><img src="assets/img/gallery/24.jpeg"></a>
                    <a href="assets/img/gallery/25.jpeg"><img src="assets/img/gallery/25.jpeg"></a>
                    <a href="assets/img/gallery/26.jpeg"><img src="assets/img/gallery/26.jpeg"></a>
                    <a href="assets/img/gallery/27.jpeg"><img src="assets/img/gallery/27.jpeg"></a>
                    <a href="assets/img/gallery/28.jpeg"><img src="assets/img/gallery/28.jpeg"></a>
                    <a href="assets/img/gallery/29.jpeg"><img src="assets/img/gallery/29.jpeg"></a>
                    <a href="assets/img/gallery/30.jpeg"><img src="assets/img/gallery/30.jpeg"></a>
                    <a href="assets/img/gallery/31.jpeg"><img src="assets/img/gallery/31.jpeg"></a>
                    <a href="assets/img/gallery/32.jpeg"><img src="assets/img/gallery/32.jpeg"></a>
                    <a href="assets/img/gallery/33.jpeg"><img src="assets/img/gallery/33.jpeg"></a>
                    <a href="assets/img/gallery/34.jpeg"><img src="assets/img/gallery/34.jpeg"></a>
                    <a href="assets/img/gallery/35.jpeg"><img src="assets/img/gallery/35.jpeg"></a>
                    <a href="assets/img/gallery/36.jpeg"><img src="assets/img/gallery/36.jpeg"></a>
                    <a href="assets/img/gallery/37.jpeg"><img src="assets/img/gallery/37.jpeg"></a>
                    <a href="assets/img/gallery/38.jpeg"><img src="assets/img/gallery/38.jpeg"></a>
                </div>


            </div>
        </div>
    </section>
    <!--Green House end -->




    <!-- Footer Start -->
    <?php include 'includes/footer.php';?>
    <!-- Footer End -->

    <!-- ScrollToTop Start -->
    <?php include 'includes/scroll.php';?>
    <!-- ScrollToTop End -->

    <!-- JS Start -->
    <?php include 'includes/js.php';?>
    <!-- JS End -->

</body>

</html>