<!doctype html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>DKM Group</title>
    <!-- CSS Start -->
    <?php include 'includes/css.php'; ?>
    <!-- CSS End -->
</head>

<body>
    <!-- Preloader Start -->
    <?php include 'includes/loader.php'; ?>
    <!-- Preloader End -->

    <!-- Header Start -->
    <?php include 'includes/header.php'; ?>
    <!-- Header End -->

    <!-- breadcumb start -->
    <div class="breadcumb-wrapper" data-bg-src="assets/img/bg/inn-ban.jpeg">
        <div class="container">
            <div class="breadcumb-content">
                <h1 class="breadcumb-title">Divison</h1>
                <ul class="breadcumb-menu">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="division.php">Divison</a></li>
                    <li>Phoenix India Refinery</li>
                </ul>
            </div>
        </div>
    </div>
    <!-- breadcumb End -->

    <section class="space-top space-extra-bottom">
        <div class="container">
            <div class="row">
                <div class="col-xxl-12 col-lg-12">
                    <div class="page-single mb-40">
                        <div class="page-content">
                            <ul class="nav product-tab-style1 mt-40 pb-0" id="productTab" role="tablist">
                                <li class="nav-item" role="presentation"><a class="nav-link th-btn active"
                                        id="home-tab" data-bs-toggle="tab" href="#home" role="tab"
                                        aria-controls="description" aria-selected="false">Home</a></li>
                                <li class="nav-item" role="presentation"><a class="nav-link th-btn" id="reviews-tab"
                                        data-bs-toggle="tab" href="#about" role="tab" aria-controls="reviews"
                                        aria-selected="true">About Us</a></li>
                                <li class="nav-item" role="presentation"> <a class="nav-link th-btn" id="tech-tab"
                                        data-bs-toggle="tab" href="#services" role="tab" aria-controls="tech"
                                        aria-selected="true">Services</a></li>
                                <li class="nav-item" role="presentation"> <a class="nav-link th-btn" id="tech-tab"
                                        data-bs-toggle="tab" href="#team" role="tab" aria-controls="tech"
                                        aria-selected="true">Team</a></li>
                                <li class="nav-item" role="presentation"> <a class="nav-link th-btn" id="tech-tab"
                                        data-bs-toggle="tab" href="#choose" role="tab" aria-controls="tech"
                                        aria-selected="true">Why Choose Us?</a></li>
                                <li class="nav-item" role="presentation"> <a class="nav-link th-btn" id="tech-tab"
                                        data-bs-toggle="tab" href="#Clientele" role="tab" aria-controls="tech"
                                        aria-selected="true">Our Clientele </a></li>
                                <li class="nav-item" role="presentation"> <a class="nav-link th-btn" id="tech-tab"
                                        data-bs-toggle="tab" href="#gallery" role="tab" aria-controls="tech"
                                        aria-selected="true">Gallery</a></li>
                                <li class="nav-item" role="presentation"> <a class="nav-link th-btn" id="tech-tab"
                                        data-bs-toggle="tab" href="#contact" role="tab" aria-controls="tech"
                                        aria-selected="true">Contact Us</a></li>
                            </ul>
                            <div class="tab-content" id="productTabContent">
                                <div class="tab-pane fade show active" id="home" role="tabpanel"
                                    aria-labelledby="description-tab">
                                    <p style="text-align: center; font-weight:600">Welcome to Phoenix India Refinery.</p>
                                    <p class="mb-30">Leading the Way in Marine Sludge Extraction and Waste Management.Phoenix India specializes in the extraction of sludge from vessels anchored at Paradip, Dhamra, Gopalpur, and Visakhapatnam ports. The extracted sludge is transported to refineries for processing. The refined product is then transferred back to the vessels as fresh fuel.</p>

                                </div>
                                <div class="tab-pane fade" id="about" role="tabpanel" aria-labelledby="reviews-tab">
                                    <p class="mb-30">At Phoenix India Refinery, we specialize in the extraction and management of sludge and waste from vessels anchored at Paradip, Dhamra, Gopalpur, and Visakhapatnam ports. Established in 2021, we have rapidly become a leading provider of sludge removal services at Paradeep port. Our operations are fully certified by the State Pollution Control Board, Odisha Regional Office Paradeep, and the Department of Forest & Environment, Govt of Odisha. With our dedicated team and advanced equipment, we ensure that sludge and garbage are efficiently extracted, transported, and processed, contributing to cleaner seas and sustainable practices.</p>

                                </div>
                                <div class="tab-pane fade" id="services" role="tabpanel" aria-labelledby="tech-tab">
                                    <p style="font-weight: 600;">Sludge and Garbage Removal</p>
                                    <p>– Marine Sludge Removal: We extract sludge from ship bilges, engine rooms, and other areas where oily waste accumulates.</p>
                                    <p>– Garbage Collection: We manage the collection of general waste from vessels, including plastic, metal, food waste, and other refuse.</p>

                                    <p style="font-weight: 600;">Transportation and Logistics</p>
                                    <p>– Transport to Refinery: We ensure the safe and compliant transportation of sludge and waste to our refinery at Kaligharr, Jodupur, which is just 20 km away from Paradip port.</p>
                                    <p>– Logistics Management:Our team coordinates transport schedules, handles permits, and ensures compliance with environmental regulations.</p>
                                    <p style="font-weight: 600;">Waste Treatment and Refinement</p>
                                    <p>– Refining Services: We process sludge to separate valuable components such as oil, water, and solids.</p>
                                    <p>– Recycling and Reuse: We recover and recycle materials from the waste, reducing the overall environmental impact.</p>
                                    <p style="font-weight: 600;">Trade and Commerce</p>
                                    <p>– Product Trading: We market and sell refined products, such as reclaimed oil, to relevant companies and industries.</p>
                                    <p>– Market Development: We identify and develop new markets for products obtained from sludge refinement.</p>
                                    <p style="font-weight: 600;">Environmental Compliance and Documentation</p>
                                    <p>– Regulatory Compliance: All activities meet local and international environmental regulations and standards.</p>
                                    <p>– Documentation and Reporting: We provide necessary documentation and reports to authorities, clients, and stakeholders regarding our waste management activities and compliance status.</p>
                                    <p style="font-weight: 600;">Consultancy and Support</p>
                                    <p>– Environmental Consultancy: We advise clients on best practices for waste management and compliance.</p>
                                    <p>– Technical Support: We offer technical assistance and support related to sludge removal, transport, and refinement processes.</p>



                                </div>
                                <div class="tab-pane fade" id="team" role="tabpanel" aria-labelledby="tech-tab">
                                    <p style="font-weight: 600;">Mr. Milan Mishra – Managing Director</p>
                                    <p class="mb-30">Mr. Milan Mishra brings a wealth of experience and visionary leadership to Phoenix India Refinery. Under his guidance, the company has achieved significant milestones in marine waste management and sludge extraction.</p>
                                    <img src="assets/img/division-img/phoenix-team.jpg" alt="" style="float: right;">
                                    <p style="font-weight: 600;">Mr. Amarendra Nayak – General Manager</p>
                                    <p class="mb-30">Mr. Amarendra Nayak oversees the day-to-day operations at Phoenix India Refinery, ensuring seamless coordination and execution of our services. His expertise in logistics and environmental management is instrumental in maintaining our high standards.</p>
                                    <p style="font-weight: 600;">Dedicated & Technically Sound Team</p>
                                    <p class="mb-30">At Phoenix India Refinery, our success is driven by a dedicated and technically sound team of professionals. Our engineers and technicians possess deep expertise in marine waste management, equipped with cutting-edge tools and knowledge to handle complex sludge extraction and waste treatment processes. They work tirelessly to ensure safety, efficiency, and compliance in all our operations, reflecting our commitment to excellence and environmental stewardship.</p>


                                </div>
                                <div class="tab-pane fade" id="choose" role="tabpanel" aria-labelledby="tech-tab">
                                    <p class="mb-30">– Expertise: Our team comprises seasoned professionals with extensive experience in marine surveying, consultancy, and loss assessment.</p>
                                    <p>– Comprehensive Services:We offer a full range of services to meet all your marine operational needs.</p>
                                    <p>– Compliance: We ensure that your operations comply with all relevant regulations and standards.</p>
                                    <p>– Efficiency: Our services are designed to enhance the efficiency and safety of your marine operations.</p>
                                    <p>– Client-Centric Approach: We prioritize our clients’ needs and provide tailored solutions to meet their specific requirements.</p>
                                    <p>Trust Captain Dilip Kumar Mishra Marine Surveyor Consultants and Loss Assessors to be your reliable partner in marine operations.</p>

                                </div>
                                <div class="tab-pane fade" id="Clientele" role="tabpanel" aria-labelledby="tech-tab">
                                    <div class="ship-table-section">
                                        <div class="table-container">
                                            <table>
                                                <tr>
                                                    <td>MV.ISMINE</td>
                                                    <td>MV.SAFEEN AL AMAN</td>
                                                    <td>MV.KK MINERAL</td>
                                                    <td>MV.AMNSI MAXIMUS</td>
                                                    <td>MV.ELISABETH C</td>
                                                </tr>
                                                <tr>
                                                    <td>MV.ODYSSEUS N</td>
                                                    <td>MV.SEAMELODY</td>
                                                    <td>MV.CHENNAI SELVAM</td>
                                                    <td>MV.GCL YAMUNA</td>
                                                    <td>MV.DECCAN PRIDE</td>
                                                </tr>
                                                <tr>
                                                    <td>MV.JAG RADHA</td>
                                                    <td>MV.SHAIL AL LUASIL</td>
                                                    <td>MV.SHAIL AL WAJBAH</td>
                                                    <td>MV.VISHVA UDAY</td>
                                                    <td>MT.BLAAMANEN</td>
                                                </tr>
                                                <tr>
                                                    <td>MV.LOWLAND SAGE</td>
                                                    <td>MV.CL XUCHANG</td>
                                                    <td>MV.AMNSI STALLION</td>
                                                    <td>MV.GLADIATOR</td>
                                                    <td>MV.NAVIOUS AMITIE</td>
                                                </tr>
                                                <tr>
                                                    <td>MV.CHANNAI SELVAM</td>
                                                    <td>MT.LILA CONFIDENCE</td>
                                                    <td>MV.NAVIOUS FELIX</td>
                                                    <td>MV.AM UMANG</td>
                                                    <td>MV.GCL SABARMATI</td>
                                                </tr>
                                                <tr>
                                                    <td>MV.QUEST</td>
                                                    <td>MV.GCL TAPI</td>
                                                    <td>MV.SEAMENC GALLANT</td>
                                                    <td>MV.ARABELA</td>
                                                    <td>MV.GCL KRISHNA</td>
                                                </tr>
                                                <tr>
                                                    <td>MT.MTM ROTTERDAM</td>
                                                    <td>MV.VISHVA NIDHI</td>
                                                    <td>MV.GCL NARMADA</td>
                                                    <td>MV.JAG RAJIV</td>
                                                    <td>MT.ST RAMAN</td>
                                                </tr>
                                                <tr>
                                                    <td>MV.HYDRUS</td>
                                                    <td>MV.SERENE MONACO</td>
                                                    <td>MV.AMNSI STALIION</td>
                                                    <td>MV.MAHA JACQUELINE</td>
                                                    <td>MV.GCL GANGA</td>
                                                </tr>
                                                <tr>
                                                    <td>MV.VISHVA EKTA</td>
                                                    <td>MV.JAG RANI</td>
                                                    <td>MV.SAFEEN AL SAFA</td>
                                                    <td>MV.CHENNAI VALARCHI</td>
                                                    <td>MV.GCL MAHANADI</td>
                                                </tr>
                                                <tr>
                                                    <td>MV.JAG AKSHAY</td>
                                                    <td>MV.UNITY N</td>
                                                    <td>MV.KLIMA</td>
                                                    <td>MV.DAMON</td>
                                                    <td>MT.VAMSEE</td>
                                                </tr>
                                                <tr>
                                                    <td>MV.VISHVA MALHAR</td>
                                                    <td>MV.AG NEKTARIOS</td>
                                                    <td>MV.JAG RISHI</td>
                                                    <td>MV.THRASYVOULOS V</td>
                                                    <td></td>
                                                </tr>

                                            </table>
                                        </div>
                                    </div>

                                </div>
                                <div class="tab-pane fade" id="gallery" role="tabpanel" aria-labelledby="tech-tab">
                                    <div class="gallery-area pt-50 pb-50">
                                        <div class="container">
                                            <div class="row mt-none-30 justify-content-center">

                                                <div class="col-md-3 pb-30">
                                                    <div class="event-image-container" onclick="openGallery('pictureGallery', 0)">
                                                        <img src="assets/img/division-img/gallery2/img1.jpg" class="event-image">
                                                        <div class="event-overlay">
                                                            <span>View</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3 pb-30">
                                                    <div class="event-image-container" onclick="openGallery('pictureGallery', 1)">
                                                        <img src="assets/img/division-img/gallery2/img2.jpg" class="event-image">
                                                        <div class="event-overlay">
                                                            <span>View</span>
                                                        </div>
                                                    </div>
                                                </div>


                                                <div id="pictureGallery" class="d-none">
                                                    <a href="assets/img/division-img/gallery2/img1.jpg"><img src="assets/img/division-img/gallery2/img1.jpg"></a>
                                                    <a href="assets/img/division-img/gallery2/img2.jpg"><img src="assets/img/division-img/gallery2/img2.jpg"></a>
                                                </div>


                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="tech-tab">
                                    <p style="font-weight:600">Get in Touch :</p>
                                    <p>Contact us today to learn more about our services and how we can assist you.</p>
                                    <p>Plot No. 47, Room No. 201, Bank Street, Paradeep, Jagatsinghpur, Odisha – 754142, Ph – 9556250855</p>
                                    <iframe src="https://www.google.com/maps/embed?pb=!1m13!1m8!1m3!1d7485.6604817722455!2d86.652531!3d20.265874!3m2!1i1024!2i768!4f13.1!3m2!1m1!2zMjDCsDE1JzU3LjIiTiA4NsKwMzknMTguNCJF!5e0!3m2!1sen!2sin!4v1762937775458!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <!-- Footer Start -->
    <?php include 'includes/footer.php'; ?>
    <!-- Footer End -->

    <!-- ScrollToTop Start -->
    <?php include 'includes/scroll.php'; ?>
    <!-- ScrollToTop End -->

    <!-- JS Start -->
    <?php include 'includes/js.php'; ?>
    <!-- JS End -->
</body>

</html>