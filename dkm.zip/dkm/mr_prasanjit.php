<!doctype html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>DKM Group</title>
    <!-- CSS Start -->
    <?php include 'includes/css.php'; ?>
    <!-- CSS End -->
</head>

<body>
    <!-- Preloader Start -->
    <?php include 'includes/loader.php'; ?>
    <!-- Preloader End -->

    <!-- Header Start -->
    <?php include 'includes/header.php'; ?>
    <!-- Header End -->

    <!-- breadcumb start -->
    <div class="breadcumb-wrapper" data-bg-src="assets/img/bg/inn-ban.jpeg">
        <div class="container">
            <div class="breadcumb-content">
                <h1 class="breadcumb-title">Management</h1>
                <ul class="breadcumb-menu">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="management.php">Management</a></li>
                </ul>
            </div>
        </div>
    </div>
    <!-- breadcumb End -->


    <section>
        <div class="container">
            <div class="row mb-60">
                <div class="col-xl-4">
                    <div class="about-card-img mb-xl-0 mb-30"><img src="assets/img/team/prasanjit.jpg"
                            alt="team image">

                    </div>
                </div>
                <div class="col-xl-8">
                    <div class="about-card">
                        <h2 class="about-card_title h3">Mr. Prasanjit Mohanty</h2>
                        <p class="about-card_desig">Director - Captain Dilip Kumar Mishra Insurance Surveyor and Loss Assessors Pvt Ltd</p>
                        <p class="about-card_text">Joining DKM Group in 2000 as General Manager, Mr. Priyadarshi Parida has been a cornerstone   of   our company's growth and diversification. With unwavering dedication, he   supported Captain Dilip Kumar Mishra, helping to expand the company's   divisions beyond   its marine origins. His sharp mind,   integrity,   and intelligence   have been instrumental in managing   and   overseeing   various   departments,   ensuring smooth operations across the board.</p>
                        <h4 class="box-title">Professional Credentials</h4>
                        <div class="checklist mb-30">
                            <ul>
                                <li>Fellow Member of the Cost Accountants of India</li>
                                <li>MBA (Finance and IT)</li>
                                <li>LLB</li>
                                <li>DISSA (Diploma in Information System Audit)</li>
                                <li>Surveyor and Loss Assessor</li>
                                <li>Forensic Auditor</li>
                            </ul>
                        </div>                   


                    </div>
                </div>
                <div class="col-xl-12">
                    <h4 class="box-title">Career Highlights</h4>

                    <p>- Comprehensive Experience: Proficient in establishment accounts, handling income tax, indirect taxes (Service Tax, GST, TDS, Excise), and ensuring compliance with statutory requirements.</p>
                    <p>- MIS Reports & Budgeting: Expert in preparing Management Information System (MIS) reports, budgeting, and managing receivables and payables.</p>
                    <p>- Cost Analysis: Skilled in department and item-wise cost-benefit analysis, process costing, and project costing.</p>
                    <p>- Fixed Asset Management: Experienced in maintaining the Fixed Asset Register and conducting management reviews to identify deficiencies and suggest improvements.</p>
                    <p>- Control Functions: Proficient in inventory, debtors, and working capital management, project reports, and project financing.</p>
                    <p>- Audit Expertise: Extensive experience in statutory, internal, stock, and cost audits for both government and private organizations.</p>
                    <p>- ERP Implementation: Served as a core team member for implementing ERP software, enhancing operational efficiency.</p>
                    <p><b>Survey & Loss Assessment</b></p>
                    <p>- Fire, Miscellaneous, and LOP Claims: Conducted numerous surveys and loss assessments for various companies and individuals.</p>
                    <p>- Quality & Quantity Survey: Provided nourishment and support to insured parties during insurance claims, ensuring accurate assessments and optimal outcomes.</p>
                    <p>- Lashing & Loss Prevention: Reviewed personal and business assets' risk coverage and insurance documents, minimizing errors before or after taking risk coverages.</p>
                    <p>Mr. Mohanty's robust background and multifaceted expertise position him as a pivotal leader, driving our commitment to precision, compliance, and client satisfaction. His dedication to excellence and strategic vision continues to strengthen our company’s reputation and service quality.</p>
                </div>
            </div>


            <div class="d-block d-md-none mt-40 text-center">
                <div class="icon-box"><button data-slider-prev="#teamSlider1" class="slider-arrow default"><i
                            class="far fa-arrow-left"></i></button> <button data-slider-next="#teamSlider1"
                        class="slider-arrow default"><i class="far fa-arrow-right"></i></button></div>
            </div>
        </div>
    </section>

    <!-- Footer Start -->
    <?php include 'includes/footer.php'; ?>
    <!-- Footer End -->

    <!-- ScrollToTop Start -->
    <?php include 'includes/scroll.php'; ?>
    <!-- ScrollToTop End -->

    <!-- JS Start -->
    <?php include 'includes/js.php'; ?>
    <!-- JS End -->
</body>

</html>