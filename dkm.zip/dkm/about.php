<!doctype html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>About || DKM</title>
    <!-- CSS Start -->
    <?php include 'includes/css.php';?>
    <!-- CSS End -->
</head>

<body>
    <!-- Preloader Start -->
    <?php include 'includes/loader.php';?>
    <!-- Preloader End -->

    <!-- Header Start -->
    <?php include 'includes/header.php';?>
    <!-- Header End -->

    <div class="breadcumb-wrapper" data-bg-src="assets/img/bg/inn-ban.jpeg">
        <div class="container">
            <div class="breadcumb-content">
                <h1 class="breadcumb-title">About Us</h1>
                <ul class="breadcumb-menu">
                    <li><a href="index.php">Home</a></li>
                    <li>About Us</li>
                </ul>
            </div>
        </div>
    </div>

    <div class="overflow-hidden space" id="about-sec">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-xl-6 mb-50 mb-xl-0">
                    <div class="img-box2">
                        <div class="shape1"><img src="assets/img/normal/about_shape2_1.png" alt="About"></div>
                        <div class="img1"><img src="assets/img/normal/abt1.jpg" alt="About">
                            <div class="year-counter bg-title" data-bg-src="assets/img/normal/about_shape2_2.png">
                                <div class="year-counter_number"><span class="counter-number">43</span></div>
                                <p class="year-counter_text">Year Of Experience</p>
                            </div>
                        </div>
                        <div class="img2"><img src="assets/img/normal/abt2.jpg" alt="Image"></div>
                        <div class="about-since-wrap jump">
                            <div class="about-since">Since 1982</div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-6">
                    <div class="title-area mb-32">
                        <!-- <span class="sub-title"><img class="me-2" src="assets/img/theme-img/title_icon.svg" alt="shape">ABOUT OUR COMPANY<img class="ms-1" src="assets/img/theme-img/title_icon.svg" alt="img"></span> -->
                        <h2 class="sec-title">About DKM Group</h2>
                        <p class="sec-text">Established in 1982, DKM Group has been a trailblazer in the maritime, entertainment, trading, real estate, oil refining, and insurance sectors. Our journey began with the inception of “Captain Dilip Kumar Mishra Marine Surveyor Consultants and Loss Assessors” at Paradip Port, Odisha. Since then, we have grown into a diversified conglomerate, renowned for our excellence and integrity across various industries.</p>
                    </div>
                    <div class="about-feature-wrap2">
                        <div class="about-feature">
                            <div class="box-icon"><img src="assets/img/icon/about_feature_2-1.svg" alt="Icon"></div>
                            <div class="about-feature-content">
                                <h3 class="box-title">Marine Survey Services</h3>
                                <p class="about-feature-text">Expert marine survey and consultancy services, leveraging decades of industry experience.</p>
                            </div>
                        </div>
                        <div class="about-feature">
                            <div class="box-icon"><img src="assets/img/icon/about_feature_2-2.svg" alt="Icon"></div>
                            <div class="about-feature-content">
                                <h3 class="box-title">Maritime Expertise</h3>
                                <p class="about-feature-text">Proven track record in maritime sector, ensuring excellence in operations and client satisfaction.</p>
                            </div>
                        </div>
                    </div>
                    <!-- <div class="btn-wrap mt-50"><a href="about.html.htm" class="th-btn">Read More<div class="icon"><i
                                    class="fa-solid fa-arrow-up-right ms-3"></i></div></a></div> -->
                </div>
            </div>
        </div>
    </div>

    <div class="overflow-hidden" id="faq-sec" data-bg-src="assets/img/bg/faq_bg_1.png">
        <div class="container" style="padding-bottom: 70px;">
            <div class="row justify-content-center flex-row-reverse align-items-center">
                <div class="col-xl-5">
                    <div class="faq-img1 text-xl-start text-center"><img src="assets/img/normal/late_dilip.jpg" alt="faq" style="border: 1px solid #045a95; padding: 5px; box-shadow: 0 4px 10px rgb(56 123 169 / 64%);">
                    </div>
                </div>
                <div class="col-xl-7 text-center text-xl-start align-self-center">
                    <div class="title-area text-center text-xl-start"><span class="sub-title"><img class="me-2"
                                src="assets/img/theme-img/title_icon.svg" alt="shape">Late Captain Dilip Kumar Mishra</span>
                        <h2 class="sec-title" style="font-size: 30px; color: #444443;">"Always plan for the next generation and not for the next fiscal year,"</h2>
                    </div>
                    <div class="accordion" id="faqAccordion">
                        <div class="accordion-card">
                            <div class="accordion-header" id="collapse-item-1"><button class="accordion-button"
                                    type="button" data-bs-toggle="collapse" data-bs-target="#collapse-1"
                                    aria-expanded="true" aria-controls="collapse-1">Early Life and Career</button></div>
                            <div id="collapse-1" class="accordion-collapse collapse show"
                                aria-labelledby="collapse-item-1" data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    <p class="faq-text">Born on January 1, 1956, in the small town of Baripada in Mayurbhanj district, Odisha, Captain Dilip Kumar Mishra was an epitome of enterprise, leadership, and humility. Growing up with his three siblings, he showcased early on the qualities that would later define his illustrious career. At just 26 years old, Captain Mishra achieved his Master's in the Merchant Navy, becoming one of Odisha's youngest captains (ex. Rajendra) at the time. His maritime journey saw him sailing extensively for eight years, gathering invaluable experience and insight. Despite his promising career on the seas, his dedication to his home state called him back to Odisha.</p>
                                </div>
                            </div>
                        </div>
                        <div class="accordion-card">
                            <div class="accordion-header" id="collapse-item-2"><button
                                    class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapse-2" aria-expanded="false" aria-controls="collapse-2">Leader & Founder</button></div>
                            <div id="collapse-2" class="accordion-collapse collapse" aria-labelledby="collapse-item-2"
                                data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    <p class="faq-text">Upon returning, Captain Mishra joined the OSL Group as its first director, where his effective leadership and guidance significantly contributed to the company's steady growth until 2001. His vision for maritime excellence led him to establish DKM Surveyors in 1986, a venture he nurtured with his profound knowledge and dynamic vision over the next 36 years. His entrepreneurial spirit didn't stop there. Captain Mishra founded Phoenix India Refinery, a FO refinery with an impressive production capacity of 12,000 metric tons per year. His influence extended beyond marine and insurance services into the realm of arts and entertainment, resulting in the creation of Madhyam Arts, a production house for numerous Odia albums, movies, and TV serials.</p>
                                </div>
                            </div>
                        </div>
                        <div class="accordion-card">
                            <div class="accordion-header" id="collapse-item-3"><button
                                    class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapse-3" aria-expanded="false" aria-controls="collapse-3">His Entrepreneurial Journey</button></div>
                            <div id="collapse-3" class="accordion-collapse collapse" aria-labelledby="collapse-item-3"
                                data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    <p class="faq-text">In 2001, he continued his entrepreneurial journey by establishing Milan Trading and Milan Properties in Cuttack, further diversifying his business interests. His famous quote, "Always plan for the next generation and not for the next fiscal year," encapsulates his forward-thinking philosophy, one that continues to inspire and guide the next generation. Captain Mishra's charismatic personality and unwavering honesty in his work earned him a reputation as a dedicated and reliable professional in Paradip, Gopalpur, Haldia, Vizag, Dhamara, and beyond. His ability to swiftly scale the business landscape in Odisha was a testament to his exceptional leadership and vision.</p>
                                </div>
                            </div>
                        </div>
                        <div class="accordion-card">
                            <div class="accordion-header" id="collapse-item-4"><button
                                    class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapse-4" aria-expanded="false" aria-controls="collapse-4">Captain Mishra left for his heavenly abode in 2021</button></div>
                            <div id="collapse-4" class="accordion-collapse collapse" aria-labelledby="collapse-item-4"
                                data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    <p class="faq-text">Remembered as a great enthusiast, entrepreneur, leader, caregiver, and visionary, Captain Dilip Kumar Mishra left an indelible mark on everyone who knew him. His legacy lives on through the robust manpower and infrastructure he built, poised to tackle any shipping job with the same dedication and integrity that he exemplified throughout his career.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer Start -->
    <?php include 'includes/footer.php';?>
    <!-- Footer End -->

    <!-- ScrollToTop Start -->
    <?php include 'includes/scroll.php';?>
    <!-- ScrollToTop End -->
    
    <!-- JS Start -->
    <?php include 'includes/js.php';?>
    <!-- JS End -->

</body>

</html>