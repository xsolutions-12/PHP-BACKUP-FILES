<!doctype html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>DKM Group</title>
    <!-- CSS Start -->
    <?php include 'includes/css.php';?>
    <!-- CSS End -->
</head>

<body>
    <!-- Preloader Start -->
    <?php include 'includes/loader.php';?>
    <!-- Preloader End -->
    <!-- <div class="sidemenu-wrapper sidemenu-cart">
        <div class="sidemenu-content"><button class="closeButton sideMenuCls"><i class="far fa-times"></i></button>
            <div class="widget woocommerce widget_shopping_cart">
                <h3 class="widget_title">Shopping cart</h3>
                <div class="widget_shopping_cart_content">
                    <ul class="woocommerce-mini-cart cart_list product_list_widget">
                        <li class="woocommerce-mini-cart-item mini_cart_item"><a href="#"
                                class="remove remove_from_cart_button"><i class="far fa-times"></i></a> <a href="#"><img
                                    src="assets/img/product/product_thumb_1_1.png" alt="Cart Image">School Bag</a> <span
                                class="quantity">1 × <span class="woocommerce-Price-amount amount"><span
                                        class="woocommerce-Price-currencySymbol">$</span>940.00</span></span></li>
                        <li class="woocommerce-mini-cart-item mini_cart_item"><a href="#"
                                class="remove remove_from_cart_button"><i class="far fa-times"></i></a> <a href="#"><img
                                    src="assets/img/product/product_thumb_1_2.png" alt="Cart Image">Leather Jacket</a>
                            <span class="quantity">1 × <span class="woocommerce-Price-amount amount"><span
                                        class="woocommerce-Price-currencySymbol">$</span>899.00</span></span></li>
                        <li class="woocommerce-mini-cart-item mini_cart_item"><a href="#"
                                class="remove remove_from_cart_button"><i class="far fa-times"></i></a> <a href="#"><img
                                    src="assets/img/product/product_thumb_1_3.png" alt="Cart Image">Leather Jacket</a>
                            <span class="quantity">1 × <span class="woocommerce-Price-amount amount"><span
                                        class="woocommerce-Price-currencySymbol">$</span>756.00</span></span></li>
                        <li class="woocommerce-mini-cart-item mini_cart_item"><a href="#"
                                class="remove remove_from_cart_button"><i class="far fa-times"></i></a> <a href="#"><img
                                    src="assets/img/product/product_thumb_1_4.png" alt="Cart Image">Baby Shoes</a> <span
                                class="quantity">1 × <span class="woocommerce-Price-amount amount"><span
                                        class="woocommerce-Price-currencySymbol">$</span>723.00</span></span></li>
                        <li class="woocommerce-mini-cart-item mini_cart_item"><a href="#"
                                class="remove remove_from_cart_button"><i class="far fa-times"></i></a> <a href="#"><img
                                    src="assets/img/product/product_thumb_1_5.png" alt="Cart Image">Sports Shoes</a>
                            <span class="quantity">1 × <span class="woocommerce-Price-amount amount"><span
                                        class="woocommerce-Price-currencySymbol">$</span>1080.00</span></span></li>
                    </ul>
                    <p class="woocommerce-mini-cart__total total"><strong>Subtotal:</strong> <span
                            class="woocommerce-Price-amount amount"><span
                                class="woocommerce-Price-currencySymbol">$</span>4398.00</span></p>
                    <p class="woocommerce-mini-cart__buttons buttons"><a href="cart.html.htm"
                            class="th-btn wc-forward">View cart <span class="icon"><i
                                    class="fa-solid fa-arrow-up-right ms-3"></i></span></a> <a href="checkout.html.htm"
                            class="th-btn checkout wc-forward">Checkout <span class="icon"><i
                                    class="fa-solid fa-arrow-up-right ms-3"></i></span></a></p>
                </div>
            </div>
        </div>
    </div>
    <div class="sidemenu-wrapper sidemenu-info d-none d-lg-block">
        <div class="sidemenu-content"><button class="closeButton sideMenuCls"><i class="far fa-times"></i></button>
            <div class="widget">
                <div class="th-widget-about">
                    <div class="about-logo"><a href="index.html.htm"><img src="assets/img/logo.svg" alt="Konsal"></a>
                    </div>
                    <p class="about-text">Consulting services can provide valuable insights, strategic guidance,
                        pecialized</p>
                    <div class="info-box">
                        <div class="info-box_icon"><i class="far fa-phone"></i></div>
                        <p class="info-box_text"><a href="tel:+11278956825" class="info-box_link">+112 (789) 568 25</a>
                        </p>
                    </div>
                    <div class="info-box">
                        <div class="info-box_icon"><i class="far fa-envelope-open"></i></div>
                        <p class="info-box_text"><a href="mailto:help@gmail.com"
                                class="info-box_link">help@gmail.com</a></p>
                    </div>
                    <div class="info-box">
                        <div class="info-box_icon"><i class="far fa-location-dot"></i></div>
                        <p class="info-box_text">1901 Shiloh, Hawaii 81063</p>
                    </div>
                </div>
            </div>
            <div class="widget">
                <h3 class="widget_title">Recent Posts</h3>
                <div class="recent-post-wrap">
                    <div class="recent-post">
                        <div class="media-img"><a href="blog-details.html.htm"><img
                                    src="assets/img/blog/recent-post-1-1.jpg" alt="Blog Image"></a></div>
                        <div class="media-body">
                            <div class="recent-post-meta"><a href="blog.html.htm"><i
                                        class="fa-light fa-calendar-days"></i>21 June, 2024</a></div>
                            <h4 class="post-title"><a class="text-inherit" href="blog-details.html.htm">Guiding
                                    Businesses to Success</a></h4>
                        </div>
                    </div>
                    <div class="recent-post">
                        <div class="media-img"><a href="blog-details.html.htm"><img
                                    src="assets/img/blog/recent-post-1-2.jpg" alt="Blog Image"></a></div>
                        <div class="media-body">
                            <div class="recent-post-meta"><a href="blog.html.htm"><i
                                        class="fa-light fa-calendar-days"></i>22 June, 2024</a></div>
                            <h4 class="post-title"><a class="text-inherit" href="blog-details.html.htm">Fueling Your
                                    Business Forward</a></h4>
                        </div>
                    </div>
                    <div class="recent-post">
                        <div class="media-img"><a href="blog-details.html.htm"><img
                                    src="assets/img/blog/recent-post-1-3.jpg" alt="Blog Image"></a></div>
                        <div class="media-body">
                            <div class="recent-post-meta"><a href="blog.html.htm"><i
                                        class="fa-light fa-calendar-days"></i>23 June, 2024</a></div>
                            <h4 class="post-title"><a class="text-inherit" href="blog-details.html.htm">Improve Your
                                    Health By Organic Eating</a></h4>
                        </div>
                    </div>
                </div>
            </div>
            <div class="widget newsletter-widget">
                <h3 class="widget_title">Subscribe Now</h3>
                <form class="newsletter-form">
                    <div class="form-group"><input class="form-control" type="email" placeholder="Email Address"
                            required=""> <button type="submit" class="th-btn"><i class="far fa-paper-plane"></i>
                            Subscribe</button></div>
                </form>
                <div class="th-social style2"><a href="https://www.facebook.com/"><i class="fab fa-facebook-f"></i></a>
                    <a href="https://www.twitter.com/"><i class="fab fa-twitter"></i></a> <a
                        href="https://www.linkedin.com/"><i class="fab fa-linkedin-in"></i></a> <a
                        href="https://www.behance.com/"><i class="fab fa-behance"></i></a> <a
                        href="https://www.vimeo.com/"><i class="fab fa-vimeo-v"></i></a></div>
            </div>
        </div>
    </div>
    <div class="popup-search-box d-none d-lg-block"><button class="searchClose"><i class="fal fa-times"></i></button>
        <form action="#"><input type="text" placeholder="What are you looking for?"> <button type="submit"><i
                    class="fal fa-search"></i></button></form>
    </div>
    <div class="th-menu-wrapper">
        <div class="th-menu-area text-center"><button class="th-menu-toggle"><i class="fal fa-times"></i></button>
            <div class="mobile-logo"><a href="index.html.htm"><img src="assets/img/logo.svg" alt="Konsal"></a></div>
            <div class="th-mobile-menu">
                <ul>
                    <li class="menu-item-has-children"><a href="index.html.htm">Home</a>
                        <ul class="sub-menu">
                            <li><a href="index.html.htm">Home Business Consult</a></li>
                            <li><a href="home-2.html.htm">Home Corporate</a></li>
                            <li><a href="home-3.html.htm">Home Finance</a></li>
                            <li><a href="home-4.html.htm">Home Consultancy</a></li>
                            <li><a href="home-5.html.htm">Home Business Startup</a></li>
                            <li><a href="home-6.html.htm">Home Advisory Agency</a></li>
                            <li><a href="home-7.html.htm">Home Event Conference</a></li>
                            <li><a href="home-8.html.htm">Home Marketing Agency</a></li>
                        </ul>
                    </li>
                    <li><a href="about.html.htm">About Us</a></li>
                    <li class="menu-item-has-children"><a href="#">Services</a>
                        <ul class="sub-menu">
                            <li><a href="service.html.htm">Service</a></li>
                            <li><a href="service-details.html.htm">Service Details</a></li>
                        </ul>
                    </li>
                    <li class="menu-item-has-children"><a href="#">Pages</a>
                        <ul class="sub-menu">
                            <li class="menu-item-has-children"><a href="#">Shop</a>
                                <ul class="sub-menu">
                                    <li><a href="shop.html.htm">Shop</a></li>
                                    <li><a href="shop-details.html.htm">Shop Details</a></li>
                                    <li><a href="cart.html.htm">Cart Page</a></li>
                                    <li><a href="checkout.html.htm">Checkout</a></li>
                                    <li><a href="wishlist.html.htm">Wishlist</a></li>
                                </ul>
                            </li>
                            <li><a href="team.html.htm">Team</a></li>
                            <li><a href="team-details.html.htm">Team Details</a></li>
                            <li><a href="project.html.htm">Project Gallery</a></li>
                            <li><a href="project-details.html.htm">Project Details</a></li>
                            <li><a href="pricing.html.htm">Pricing</a></li>
                            <li><a href="error.html.htm">Error Page</a></li>
                        </ul>
                    </li>
                    <li class="menu-item-has-children"><a href="#">News</a>
                        <ul class="sub-menu">
                            <li><a href="blog.html.htm">Blog</a></li>
                            <li><a href="blog-details.html.htm">Blog Details</a></li>
                        </ul>
                    </li>
                    <li><a href="contact.html.htm">Contact Us</a></li>
                </ul>
            </div>
        </div>
    </div> -->
    
    <!-- Header Start -->
    <?php include 'includes/header.php';?>
    <!-- Header End -->

    <div class="th-hero-wrapper hero-3" id="hero">
        <div class="swiper th-slider" id="heroSlider3" data-slider-options='{"effect":"fade"}'>
            <div class="swiper-wrapper">
                <div class="swiper-slide" data-bg-src="assets/img/hero/hero_bg_3_1.jpg" data-overlay="black"
                    data-opacity="9">
                    <div class="hero-inner">
                        <div class="container">
                            <div class="hero-style3">
                                <!-- <span class="sub-title" data-ani="slideinup"
                                    data-ani-delay="0.2s">RISK GUARD ADVISORY</span> -->
                                <h1 class="hero-title">
                                    <span class="title1" data-ani="slideinup"
                                        data-ani-delay="0.4s">Welcome To DKM Group</span>
                            </div>
                        </div>
                        <div class="hero-img"><img src="assets/img/home/ban1.png" alt="Image"></div>
                        <div class="hero-shape1 bg-theme" data-bg-src="assets/img/hero/hero_bg_shape3_1.jpg"></div>
                    </div>
                </div>
                <div class="swiper-slide" data-bg-src="assets/img/hero/hero_bg_3_2.jpg" data-overlay="black"
                    data-opacity="9">
                    <div class="hero-inner">
                        <div class="container">
                            <div class="hero-style3">
                                <!-- <span class="sub-title" data-ani="slideinup"
                                    data-ani-delay="0.2s">MARKET ANALYSIS PRO</span> -->
                                <h1 class="hero-title">
                                    <span class="title1" data-ani="slideinup"
                                        data-ani-delay="0.4s">Welcome To DKM Group</span>
                            </div>
                        </div>
                        <div class="hero-img"><img src="assets/img/home/ban2.png" alt="Image"></div>
                        <div class="hero-shape1 bg-theme" data-bg-src="assets/img/hero/hero_bg_shape3_1.jpg"></div>
                    </div>
                </div>
                <div class="swiper-slide" data-bg-src="assets/img/hero/hero_bg_3_3.jpg" data-overlay="black"
                    data-opacity="9">
                    <div class="hero-inner">
                        <div class="container">
                            <div class="hero-style3">
                                <!-- <span class="sub-title" data-ani="slideinup"
                                    data-ani-delay="0.2s">SALES ACCELERATION PRO</span> -->
                                <h1 class="hero-title">
                                    <span class="title1" data-ani="slideinup"
                                        data-ani-delay="0.4s">Welcome To DKM Group</span>
                            </div>
                        </div>
                        <div class="hero-img"><img src="assets/img/home/ban3.png" alt="Image"></div>
                        <div class="hero-shape1 bg-theme" data-bg-src="assets/img/hero/hero_bg_shape3_1.jpg"></div>
                    </div>
                </div>
            </div>
            <div class="slider-pagination"></div>
        </div>
    </div>
    
    <div class="overflow-hidden" id="about-sec">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-xl-6 mb-50 mb-xl-0">
                    <div class="img-box3">
                        <div class="img1"><img src="assets/img/home/abt1.jpg" alt="About"></div>
                        <div class="img2 jump"><img src="assets/img/home/abt2.jpg" alt="About"></div>
                    </div>
                </div>
                <div class="col-xl-6">
                    <div class="title-area mb-25">
                        <!-- <span class="sub-title">
                            <img class="me-2" src="assets/img/theme-img/title_icon.svg" alt="shape">ABOUT OUR COMPANY<img class="ms-1"
                                src="assets/img/theme-img/title_icon.svg" alt="img">
                        </span> -->
                        <h2 class="sec-title">Welcome to DKM Group</h2>
                        <p class="sec-text">Welcome to DKM Group, a diverse conglomerate with a rich history spanning over four decades. From our humble beginnings as marine surveyors and loss assessors at Paradip Port in Odisha, we have evolved to cover a broad spectrum of industries and services, including entertainment, trading, real estate, oil refining, and insurance.</p>
                    </div>
                    <!-- <div class="about-checklist-wrap mb-40">
                        <div class="checklist">
                            <ul>
                                <li><i class="fas fa-square-check"></i> Fin Tech Forge Solutions</li>
                                <li><i class="fas fa-square-check"></i> Risk Guard Financial Services</li>
                                <li><i class="fas fa-square-check"></i> Portfolio Pilot Management</li>
                            </ul>
                        </div>
                        <div class="checklist">
                            <ul>
                                <li><i class="fas fa-square-check"></i> Credit Crafter Solutions</li>
                                <li><i class="fas fa-square-check"></i> Retirement Realm Advisory</li>
                                <li><i class="fas fa-square-check"></i> Cash Flow Craft Consulting</li>
                            </ul>
                        </div>
                    </div> -->
                    <div class="btn-wrap"><a href="about.html.htm" class="th-btn">Read More<div class="icon"><i
                                    class="fa-solid fa-arrow-up-right ms-3"></i></div></a></div>
                </div>
            </div>
        </div>
    </div>

    <section>
        <!-- <h2>Our Mission & Vision</h2> -->
        <div class="mission-vision">
            <div class="box">
                <h3>Our Mission</h3>
                <p>
                    DKM Group is committed to delivering excellence across all its divisions, providing exceptional services and products that exceed customer expectations. We strive to uphold the highest standards of integrity, professionalism, and innovation in everything we do, ensuring sustainable growth and long-term success for our stakeholders.
                </p>
            </div>
            <div class="box">
                <h3>Our Vision</h3>
                <p>
                    To be a globally recognized conglomerate, known for its commitment to quality, integrity, and innovation. We aim to expand our presence across international markets, leveraging our expertise and experience to become a leader in the industries we operate in. Guided by the vision of our founder, Late Captain Dilip Kumar Mishra, we are dedicated to taking DKM Group to new heights and making a positive impact on the world stage.
                </p>
            </div>
        </div>
    </section>

    <section id="service-sec">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-6">
                    <div class="title-area text-center">
                        <!-- <span class="sub-title">
                            <img class="me-2" src="assets/img/theme-img/title_icon.svg" alt="shape">FINANCE SOLUTION<img class="ms-2"
                                src="assets/img/theme-img/title_icon.svg" alt="shape">
                        </span> -->
                        <h2 class="sec-title">Divisions</h2>
                    </div>
                </div>
            </div>
            <div class="row gy-30 gx-30 justify-content-center">
                <div class="col-xl-4 col-md-6">
                    <div class="service-card3">
                        <div class="box-content">
                            <div class="service-card-icon"><img src="assets/img/icon/service_card_3-1.svg" alt="Icon">
                            </div>
                            <h3 class="box-title"><a href="#">DKM Marine</a></h3>
                        </div>
                        <!-- <p class="box-text">Financial consultants provide expertise in managing wealth, investments,
                            taxes, and overall financial planning</p> -->
                            <a href="#" class="link-btn style2"><i class="fas fa-plus-circle me-1"></i>Read More</a>
                    </div>
                </div>
                <div class="col-xl-4 col-md-6">
                    <div class="service-card3">
                        <div class="box-content">
                            <div class="service-card-icon"><img src="assets/img/icon/service_card_3-5.svg" alt="Icon">
                            </div>
                            <h3 class="box-title"><a href="#">Phoenix India</a></h3>
                        </div>
                        <!-- <p class="box-text">Financial consultants can help assess your risk tolerance by considering
                            factors such as your financial goals, time horizon, and comfor</p> -->
                            <a href="#" class="link-btn style2"><i
                                class="fas fa-plus-circle me-1"></i>Read More</a>
                    </div>
                </div>
                <div class="col-xl-4 col-md-6">
                    <div class="service-card3">
                        <div class="box-content">
                            <div class="service-card-icon"><img src="assets/img/icon/service_card_3-3.svg" alt="Icon">
                            </div>
                            <h3 class="box-title"><a href="#">DKM Insurance</a></h3>
                        </div>
                        <!-- <p class="box-text">Financial consultants can provide guidance on improving your credit score by
                            managing debts responsibly, making timely payments</p> -->
                            <a href="#" class="link-btn style2"><i class="fas fa-plus-circle me-1"></i>Read More</a>
                    </div>
                </div>
                <div class="col-xl-4 col-md-6">
                    <div class="service-card3">
                        <div class="box-content">
                            <div class="service-card-icon"><img src="assets/img/icon/service_card_3-4.svg" alt="Icon">
                            </div>
                            <h3 class="box-title"><a href="#">Madhyam Arts</a></h3>
                        </div>
                        <!-- <p class="box-text">Retirement planning ensures that individuals can maintain their desired
                            lifestyle after retirement. It involves saving, investing, and creating</p> -->
                            <a href="#" class="link-btn style2"><i
                                class="fas fa-plus-circle me-1"></i>Read More</a>
                    </div>
                </div>
                <div class="col-xl-4 col-md-6">
                    <div class="service-card3">
                        <div class="box-content">
                            <div class="service-card-icon"><img src="assets/img/icon/service_card_3-2.svg" alt="Icon">
                            </div>
                            <h3 class="box-title"><a href="#">Milan Trading</a>
                            </h3>
                        </div>
                        <!-- <p class="box-text">Financial consultants offer a range of services, including investment
                            management, tax planning, retirement planning, budgeting, and overall</p> -->
                            <a href="#" class="link-btn style2"><i
                                class="fas fa-plus-circle me-1"></i>Read More</a>
                    </div>
                </div>
                <div class="col-xl-4 col-md-6">
                    <div class="service-card3">
                        <div class="box-content">
                            <div class="service-card-icon"><img src="assets/img/icon/service_card_3-6.svg" alt="Icon">
                            </div>
                            <h3 class="box-title"><a href="#">Milan Properties</a></h3>
                        </div>
                        <!-- <p class="box-text">Investment advisors analyze market trends, man assess risk tolerance, and
                            tailor investment strategies to help clients make informed</p> -->
                            <a href="#" class="link-btn style2"><i
                                class="fas fa-plus-circle me-1"></i>Read More</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <div class="client-area-1" data-bg-src="assets/img/bg/team_bg_3_1.png" data-overlay="white" data-opacity="1">
        <div class="container-fluid p-0">
            <div class="swiper th-slider client-slider1"
                data-slider-options='{"breakpoints":{"0":{"slidesPerView":1},"400":{"slidesPerView":"2"},"768":{"slidesPerView":"3"},"992":{"slidesPerView":"4"},"1200":{"slidesPerView":"6"}}, "spaceBetween": "0", "loop": "true"}'>
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <a href="#" class="client-card"><img src="assets/img/client/br1.png" alt="Image" class="client-img"></a>
                    </div>
                    <div class="swiper-slide">
                        <a href="#" class="client-card"><img src="assets/img/client/br2.png" alt="Image" class="client-img"></a>
                    </div>
                    <div class="swiper-slide">
                        <a href="#" class="client-card"><img src="assets/img/client/br3.png" alt="Image" class="client-img"></a>
                    </div>
                    <div class="swiper-slide">
                        <a href="#" class="client-card"><img src="assets/img/client/br4.png" alt="Image" class="client-img"></a>
                    </div>
                    <div class="swiper-slide">
                        <a href="#" class="client-card"><img src="assets/img/client/br5.png" alt="Image" class="client-img"></a>
                    </div>
                    <div class="swiper-slide">
                        <a href="#" class="client-card"><img src="assets/img/client/br6.jpg" alt="Image" class="client-img"></a>
                    </div>
                    <div class="swiper-slide">
                        <a href="#" class="client-card"><img src="assets/img/client/br1.png" alt="Image" class="client-img"></a>
                    </div>
                    <div class="swiper-slide">
                        <a href="#" class="client-card"><img src="assets/img/client/br2.png" alt="Image" class="client-img"></a>
                    </div>
                    <div class="swiper-slide">
                        <a href="#" class="client-card"><img src="assets/img/client/br3.png" alt="Image" class="client-img"></a>
                    </div>
                    <div class="swiper-slide">
                        <a href="#" class="client-card"><img src="assets/img/client/br4.png" alt="Image" class="client-img"></a>
                    </div>
                    <div class="swiper-slide">
                        <a href="#" class="client-card"><img src="assets/img/client/br5.png" alt="Image" class="client-img"></a>
                    </div>
                    <div class="swiper-slide">
                        <a href="#" class="client-card"><img src="assets/img/client/br6.jpg" alt="Image" class="client-img"></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Footer Start -->
    <?php include 'includes/footer.php';?>
    <!-- Footer End -->

    <!-- ScrollToTop Start -->
    <?php include 'includes/scroll.php';?>
    <!-- ScrollToTop End -->
    
    <!-- JS Start -->
    <?php include 'includes/js.php';?>
    <!-- JS End -->

</body>

</html>