﻿<!DOCTYPE html>
<html>
<head>
<title>Demos</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php
	include("external.php");
?>
</head>
<body>
<?php
	include("header.php");
?>
<section class="main__middle__container homepage">
  <div class="row three__blocks no_padding no-margin" id="product">
    <div class="container">
      <h2 class="page__title text-center" style="margin-top:50px;"><span>Our Products</span></h2>
      <div align="justify">
        <h3 align="center">We Produce premium quality soft drinks and juices loved by generations.</h3>
        <h4 align="center"><strong>“Explore our site, try our range, and join the Demos family”</strong></h4><br>
        <h4 align="center">“Demos has a better variety of products that there would be through other leading brands”</h4><br>
        <h4 align="center">With our experience in the industry, our customers can expect a service and product that only comes with experience and real passion.</h4><br>
        <h4 align="center">To us, quality is everything and we believe it is the cornerstone of our company.</h4>
        <hr>
        <h3 align="center"><strong>Crisp and refreshing naturally flavoured soft drinks.</strong></h3>
        <p>
        	Natural, refreshing and different. Our flavour experts have crafted modern flavours, thinking carefully about the ingredients you love, to give you a brighter, crisper drink experience. Each flavour combines skilfully blended fruit extracts with our unique signature blend of fruits and botanicals.
        </p>
        <p>
       		The tang and cut of lemons and limes. The tartness of Natural Guava and sweetness of Litchi. Imaginative new combinations like peach blended with Mango. Old friends like cola...reinvented for today with a spiced twist zeera masala, Pudina. Discover our bright, fresh world yourself.
        </p>
        <h3 align="center"><strong>NON CARBONATED SYNTHETIC JUICE</strong></h3>
        <div id="tab1">
            <ul class="nav nav-tabs" role="tablist">
                <li class="active"><a href="#home" data-toggle="tab">LAALACH LITCHI</a></li>
                <li><a href="#profile" data-toggle="tab">PINK GUAVA WITH RED CHILLI</a></li>
                <li><a href="#messages" data-toggle="tab">MANGO MASTI</a></li>
                <li><a href="#settings" data-toggle="tab">PINEAPPLE</a></li>
            </ul>
            <div class="tab-content">
                <div class="tab-pane active" id="home">
                	<h3 style="margin-top:15px;">LAALACH LITCHI</h3>
                    <p>
                    	Delicious, sweet, juicy lychee (litchi) is one of the popular summer fruits that contains an impressive list of essential nutrients like oligonol, vitamins, minerals…….. Litchi  juice is one of the tastiest fruit drinks which is loved by all age groups.
                    </p>
                    <div class="row" style="padding-top:20px;">
                    	<div class="col-md-6">
                            <table class="table-bordered product" width="100%">
                                <tr>
                                    <th>Contents</th>
                                    <th>Amount</th>
                                </tr>
                                <tr>
                                    <td>Energy Kcals per 100ml</td>
                                    <td>11</td>
                                </tr>
                                <tr>
                                    <td>Fat g per 100ml/td>
                                    <td>0</td>
                                </tr>
                                <tr>
                                    <td>of which saturates g per 100ml</td>
                                    <td>0</td>
                                </tr>
                                <tr>
                                    <td>Carbohydrate g per 100ml</td>
                                    <td>2.3</td>
                                </tr>
                                <tr>
                                    <td>of which sugar g per 100ml</td>
                                    <td>2.3</td>
                                </tr>
                                <tr>
                                    <td>Protein g per 100ml</td>
                                    <td>0</td>
                                </tr>
                                <tr>
	                                <td>Salt g per 100ml</td>
                                    <td>0</td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-md-6">
                        	<p><strong>Ingredients</strong></p>
							<p style="margin-top:0;">RO water, sugar, Natural flavourings, Citric acid, Colouring Food (concentrate of anthocyanins), Stabiliser. Class II Preservative.</p>
                            <div class="row">
                            	<div id="Grid" class="gallery">
                                	<div class="mix webdesign col-sm-5"> <a href="images/litchi.jpg"><img alt="" src="images/litchi.jpg" class="img-responsive"></a>
                                    </div>
        						</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="tab-pane" id="profile">
                	<h3 style="margin-top:15px;">PINK GUAVA WITH RED CHILLI</h3>
                    <p>
                    	Full-on peachy sweetness, countered with the citrusy bite of juicy, ruby Pink Guava with Red Chilli. Set that against zeo’s underscore of fruits and botanicals. Fresh and tangy and beautiful.
                    </p>
                    <div class="row" style="padding-top:20px;">
                    	<div class="col-md-6">
                            <table class="table-bordered product" width="100%">
                                <tr>
                                    <th>Contents</th>
                                    <th>Amount</th>
                                </tr>
                                <tr>
                                    <td>Energy Kcals per 100ml</td>
                                    <td>11</td>
                                </tr>
                                <tr>
                                    <td>Fat g per 100ml/td>
                                    <td>0</td>
                                </tr>
                                <tr>
                                    <td>of which saturates g per 100ml</td>
                                    <td>0</td>
                                </tr>
                                <tr>
                                    <td>Carbohydrate g per 100ml</td>
                                    <td>2.3</td>
                                </tr>
                                <tr>
                                    <td>of which sugar g per 100ml</td>
                                    <td>2.3</td>
                                </tr>
                                <tr>
                                    <td>Protein g per 100ml</td>
                                    <td>0</td>
                                </tr>
                                <tr>
	                                <td>Salt g per 100ml</td>
                                    <td>0</td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-md-6">
                        	<p><strong>Ingredients</strong></p>
							<p style="margin-top:0;">RO water, sugar, Natural flavourings, Citric acid, Colouring Food (concentrate of anthocyanins), Stabiliser. Class II Preservative.</p>
                        </div>
                    </div>
                </div>
                <div class="tab-pane" id="messages">
                	<h3 style="margin-top:15px;">MANGO MASTI</h3>
                    <p>
                    	Mango juice is one of the tastiest fruit drinks which is loved by all age groups.
                    </p>
                    <div class="row" style="padding-top:20px;">
                    	<div class="col-md-6">
                            <table class="table-bordered product" width="100%">
                                <tr>
                                    <th>Contents</th>
                                    <th>Amount</th>
                                </tr>
                                <tr>
                                    <td>Energy Kcals per 100ml</td>
                                    <td>11</td>
                                </tr>
                                <tr>
                                    <td>Fat g per 100ml/td>
                                    <td>0</td>
                                </tr>
                                <tr>
                                    <td>of which saturates g per 100ml</td>
                                    <td>0</td>
                                </tr>
                                <tr>
                                    <td>Carbohydrate g per 100ml</td>
                                    <td>2.3</td>
                                </tr>
                                <tr>
                                    <td>of which sugar g per 100ml</td>
                                    <td>2.3</td>
                                </tr>
                                <tr>
                                    <td>Protein g per 100ml</td>
                                    <td>0</td>
                                </tr>
                                <tr>
	                                <td>Salt g per 100ml</td>
                                    <td>0</td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-md-6">
                        	<p><strong>Ingredients</strong></p>
							<p style="margin-top:0;">RO water, sugar, Natural flavourings, Citric acid, Colouring Food (concentrate of anthocyanins), Stabiliser. Class II Preservative.</p>
                            <div class="row">
                            	<div id="Grid" class="gallery">
                                	<div class="mix webdesign col-sm-5"> <a href="images/mangomasti.jpg"><img alt="" src="images/mangomasti.jpg" class="img-responsive"></a>
                                    </div>
        						</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="tab-pane" id="settings">
                	<h3 style="margin-top:15px;">PINEAPPLE</h3>
                    <p>
                    	The pineapple (Ananas comosus) is a tropical plant with edible multiple fruit consisting of coalesced berries, also called pineapples,
                    </p>
                    <div class="row" style="padding-top:20px;">
                    	<div class="col-md-6">
                            <table class="table-bordered product" width="100%">
                                <tr>
                                    <th>Contents</th>
                                    <th>Amount</th>
                                </tr>
                                <tr>
                                    <td>Energy Kcals per 100ml</td>
                                    <td>11</td>
                                </tr>
                                <tr>
                                    <td>Fat g per 100ml/td>
                                    <td>0</td>
                                </tr>
                                <tr>
                                    <td>of which saturates g per 100ml</td>
                                    <td>0</td>
                                </tr>
                                <tr>
                                    <td>Carbohydrate g per 100ml</td>
                                    <td>2.3</td>
                                </tr>
                                <tr>
                                    <td>of which sugar g per 100ml</td>
                                    <td>2.3</td>
                                </tr>
                                <tr>
                                    <td>Protein g per 100ml</td>
                                    <td>0</td>
                                </tr>
                                <tr>
	                                <td>Salt g per 100ml</td>
                                    <td>0</td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-md-6">
                        	<p><strong>Ingredients</strong></p>
							<p style="margin-top:0;">RO water, sugar, Natural flavourings, Citric acid, Colouring Food (concentrate of anthocyanins), Stabiliser. Class II Preservative.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <h3 align="center"><strong>CARBONATED SYNTHETIC JUICE</strong></h3>
        <div>
            <ul class="nav nav-tabs" role="tablist" id="tab2">
                <li class="active"><a href="#home1" data-toggle="tab">ZEERA MASALA SODA</a></li>
                <li><a href="#profile1" data-toggle="tab">MINT</a></li>
                <li><a href="#messages1" data-toggle="tab">AAPCY</a></li>
                <li><a href="#settings1" data-toggle="tab">CLUB SODA</a></li>
            </ul>
            <div class="tab-content">
                <div class="tab-pane active" id="home1">
                	<h3 style="margin-top:15px;">ZEERA MASALA SODA</h3>
                    <p>
                    	We bring forth for our valued clients a wide range of Jeera Masala Concentrate. These products are widely demanded in the market because of their rich taste & freshness. The test of real roasted zeera.
                    </p>
                </div>
                <div class="tab-pane" id="profile1">
                	<h3 style="margin-top:15px;">MINT</h3>
                    <p>
                    	A fresh minty flavour. A tasty digestive on its own with all the goodness of mint, A twist test of Pudina mixed with masala soda. These products are widely demanded in the market because of their rich taste & freshness.
                    </p>
                </div>
                <div class="tab-pane" id="messages1">
                	<h3 style="margin-top:15px;">AAPCY</h3>
                    <p>
                    	The 'Granny Smith' is a tip-bearing apple cultivar, which originated in Australia in 1868. .... Seeds of the 'Granny Smith' apple, when grown, tend to produce a tart green apple with a much less appealing taste.<br><br>
                        Test the real green apple mixed with soft soda
                    </p>
                </div>
                <div class="tab-pane" id="settings1">
                	<h3 style="margin-top:15px;">CLUB SODA</h3>
                    <div class="row">
                        <div id="Grid" class="gallery">
                            <div class="mix webdesign col-sm-5"> <a href="images/soda.jpg"><img alt="" src="images/soda.jpg" class="img-responsive"></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      </div>
    </div>
  </div>
</section>
<script>
	
</script>
<?php
	include("footer.php");
?>
</body>
</html>