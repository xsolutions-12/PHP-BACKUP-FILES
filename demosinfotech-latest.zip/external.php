<?php
	$url=basename($_SERVER["PHP_SELF"]);
?>
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href='http://fonts.googleapis.com/css?family=Dosis:200,300,400,500,600,700,800' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,700,800' rel='stylesheet' type='text/css'>
<link href="css/style.css" rel="stylesheet">
<link rel="stylesheet" href="css/magnific-popup.css">
<link href="images/favicon.png" rel="shortcut icon">
<link href="https://fonts.googleapis.com/css?family=Kaushan+Script" rel="stylesheet"> 
<link href="popup/popup_style.css" rel="stylesheet" type="text/css">