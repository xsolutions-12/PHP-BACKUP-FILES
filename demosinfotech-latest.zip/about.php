﻿<!DOCTYPE html>
<html>
<head>
<title>Demos</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php
	include("external.php");
?>
</head>
<body>
<?php
	include("header.php");
?>
<section class="main__middle__container homepage">
  <div class="row three__blocks no_padding no-margin" id="product">
    <div class="container">
      <h2 class="page__title text-center" style="margin-top:50px;"><span>About Us</span></h2>
      <div align="justify">
        <p>Demos  is a rapidly growing organization offering a uniquely conducive environment, intellectual value, expertise and management practices that help transform thoughts and needs to successful realities - both for its customers and its people.</p>
        <p>Demos Infotech Private Limited was established in year 2012, with the vision to provide various tool room products. We are one of the leading Manufacturer of package drinking water and Pet bottles. We serve not only products, but the designing, developing and manufacturing services also for Pet Products. We took up this as challenge and dedicated ourselves for the said task and successfully filled in the gap. Today we can proudly say that we Really have won our customers' trust by full satisfaction with our Products and services.</p>
        <p>We are bound to full support to all our Customers, for Products Design & Developments, Commissioning, increasing customers' awareness, educating for good quality Products when it's required. We are having powerful background, Fully equipped manufacturing Facilities to provide the High Precision Products, The knowledgeable Technical team and Sudden acting customer support department for our clients' 100% satisfaction.</p>
        <p>Demos Infotech Private Limited has always believed that establishing a strong and ethical foundation is an essential prerequisite for long-term sustainable growth. We focus on maintaining the quality of business and creation of long-term value for Consumer and business partners.
        </p>
        <p>Demos Infotech Pvt. Ltd. Started its business as trader and later on started it’s first manufacturing unit of packaged drinking water in keonjhar district, Odisha.</p>
        <p>After completion of four successful years of our brand “Aqua Pyasa” and Looking into the rapid growth of Beverage industry we started manufacturing carbonated and non carbonated drinks in the year 2016 under brand name of “GET N Go”.</p>
        <p>
        	<strong>Our Mission</strong><br>
            Our mission is to help our customers in "Overcoming Limits" of competitiveness, productivity, technology complexity, time and budget constraints.
        </p>
        <p>
        	<strong>Social Commitments</strong><br>
            In Demos InfoTech, we build technology solutions that meet the highest quality standards of products through which we get our customers satisfaction. We strive hard to meet the highest customer satisfaction levels by providing high quality products on time… every time.
        </p>
        <p>
        	<strong>Our Focus</strong><br>
            To be more focused is to be more close to your Customers. To achieve this , we at Demos infotech have organized the range of services according to business Sectors and application specialization that meet the needs of these Sectors. We have the perfect balance of Technology and experience in beverages industries.
        </p>
        <p>
        	<strong>Quality Assurance</strong><br>
            Quality is not a function at Demos. It is a rule; our religion, by which we swear. It is this spirit of quality that has won us numerous accolades and has kept us on top of all vendor charts in the BEVERAGE circles. In order to keep us at the helm of assurance on quality of our products, we have invested in various special purpose equipments and machines. With these equipments in place, we have a high degree of accuracy in our standards and are able to minimize errors.
        </p>
        <p>
        	<strong>Quality Policy</strong><br>
            Rather than define quality by industry standards alone, Demos InfoTech goes a step further to take a customer-backwards view. We see quality as “value as perceived by the customer”.
        </p>
        <p>To us, standards compliance is a given. However, we believe that there can be no ‘one size fits all’ definition of quality. Based on varying needs and expectations, customers take varying views of quality during each individual engagement. The company may be seeking value from timelines, cost-effectiveness, performance, service, or other parameters.</p>
        <p>Demos InfoTech has a unique way of defining quality processes. Our process methodology is context-composed We measure our success through periodic formal independent feedback mechanisms.</p>
        <p style="margin-top:0;">Our focus on project-level quality systems ensures that every customer engagement progresses smoothly. Our Project Management capabilities are enhanced and driven by : </p>
      </div>
    </div>
  </div>
</section>
<?php
	include("footer.php");
?>
</body>
</html>