<footer>
  <div class="container">
    <div class="row">
    	<div class="col-md-3">
            <h3>Contact Us</h3>
            <p>Plot No. 00<br>
               Bhubaneswar<br />
               Odisha, India - 751013<br /><br />
               Mobile : +91-9876-543-210<br />
               Email : info@demosinfotech.com<br />
            </p>
            <div class="social__icons">
                <a href="#" target="_blank" class="socialicon socialicon-twitter"></a>
                <a href="#" target="_blank" class="socialicon socialicon-facebook"></a>
                <a href="#" target="_blank" class="socialicon socialicon-google"></a>
            </div>
      </div>
      <div class="col-md-3">
        <h3>Quick Links</h3>
        <ul>
        	<li><a href="#">Get N Go Litchi</a></li>
            <li><a href="#">Get N Go Soda</a></li>
            <li><a href="#">Aqua Pyasa</a></li>
            <li><a href="#">Get N Go Litchi</a></li>
            <li><a href="#">Get N Go Soda</a></li>
            <li><a href="#">Aqua Pyasa</a></li>
        </ul>
      </div>
      <div class="col-md-3">
        <h3>Our Location</h3>
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d239486.6343504424!2d85.68036489068385!3d20.3011503477819!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a1909d2d5170aa5%3A0xfc580e2b68b33fa8!2sBhubaneswar%2C+Odisha!5e0!3m2!1sen!2sin!4v1475143995812" width="100%" height="180" frameborder="0" style="border:0" allowfullscreen></iframe>
      </div>
      <div class="col-md-3">
        <div  style="margin-top:25px;"class="fb-page" data-href="https://www.facebook.com/facebook" data-tabs="timeline" data-width="253" data-height="236" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://www.facebook.com/facebook" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/facebook">Facebook</a></blockquote></div>
      </div>
    </div>
  </div>
</footer>
<p class="text-center copyright">&copy; 2016 Demos | Designed by <a href="http://www.xprosolutions.co.in" target="_blank">XPRO</a></p>
<script type="text/javascript" src="js/jquery.min.js"></script> 
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.magnific-popup.js"></script>
<script type="text/javascript">
$('.carousel').carousel({
  interval: 3500,
  pause: 'none'
})
</script>

<script type="text/javascript">
$( "a.submenu" ).click(function() {
	$( ".menuBar" ).slideToggle( "normal", function() {
	});
});
$( "ul li.dropdown a" ).click(function() {
	$( "ul li.dropdown ul" ).slideToggle( "normal", function() {
	});
	$('ul li.dropdown').toggleClass('current');
});
</script>
<script>
	$(document).ready(function () {
		$('.gallery').each(function() { // the containers for all your galleries
			$(this).magnificPopup({
				delegate: 'a', // the selector for gallery item
				type: 'image',
				gallery: {
				  enabled:true
				}
			});
		});
	});
</script>

<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v2.7";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<script type="text/javascript">
    var shadow = $('<div id="shadowElem"></div>');
    var speed = 1000;
    $(document).ready(function() {
        $('body').prepend(shadow);
    });
    $(window).load( function() {
        screenHeight = $(window).height();
        screenWidth = $(window).width();
        elemWidth = $('#dropElem').outerWidth(true);
        elemHeight = $('#dropElem').outerHeight(true)
         
        leftPosition = (screenWidth / 2) - (elemWidth / 2);
        topPosition = (screenHeight / 2) - (elemHeight / 2);
         
        $('#dropElem').css({
            'left' : leftPosition + 'px',
            'top' : -elemHeight + 'px'
        });
        $('#dropElem').show().animate({
            'top' : topPosition
        }, speed);
         
        shadow.animate({
            'opacity' : 0.7
        }, speed);
         
        $('#dropClose').click( function() {
            shadow.animate({
                'opacity' : 0
            }, speed);
            $('#dropElem').animate({
            'top' : -elemHeight + 'px'
        }, speed, function() {
                shadow.remove();
                $(this).remove();
            });
             
        });
    });
</script>