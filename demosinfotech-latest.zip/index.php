<!DOCTYPE html>
<html>
<head>
<title>Demos</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php
	include("external.php");
?>
</head>
<body>
<!--<div id="dropElem">
        <div id="dropContent">
            <div id="dropClose"><img src="popup/close.png" width="29" height="28"></div>
            <img src="popup/offer.jpg" alt="blue" class="imgs" />
        </div>
</div>-->
<?php
	include("header.php");
?>
<section class="slider" style="background:url(images/main-bg2.jpg) no-repeat; background-size:cover;">
  <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <div class="carousel-inner">
      <div class="item active"> <img data-src="images/product1.png" alt="first slide" src="images/product1.png">
        <div class="container">
          <div class="carousel-caption">
            <h1 class="">Get N Go Soda</h1>
            <p class="">Life begins after Get N Go</p>
          </div>
        </div>
      </div>
      <div class="item"> <img data-src="images/product2.png" alt="first slide" src="images/product2.png">
        <div class="container">
          <div class="carousel-caption">
            <h1 class="">Get N Go Litchi</h1>
            <p class="">Refresh your test</p>
          </div>
        </div>
      </div>
      <div class="item"> <img data-src="images/product3.png" alt="first slide" src="images/product3.png">
        <div class="container">
          <div class="carousel-caption">
            <h1 class="">Big Mango Masti</h1>
            <p class="">Flavoured drink</p>
          </div>
        </div>
      </div>
      <!--<div class="item"> <img data-src="images/slider/product1.jpg" alt="second slide" src="images/slider/slider5.jpg">
        <div class="container">
          <div class="carousel-caption">
            <h1 class="">We are committed clean water is life</h1>
          </div>
        </div>
      </div>-->
    </div>
    <a class="left carousel-control" href="index.php#myCarousel" data-slide="prev"><span class="glyphicon carousel-control-left"></span></a> <a class="right carousel-control" href="index.php#myCarousel" data-slide="next"><span class="glyphicon carousel-control-right"></span></a> </div>
</section>
<!--end of slider section-->
<section class="main__middle__container homepage">
  <div class="row text-center headings no-margin nothing">
    <div class="container">
      <h1 class="page_title">About Us</h1>
      <p>Demos  is a rapidly growing organization offering a uniquely conducive environment, intellectual value, expertise and management practices that help transform thoughts and needs to successful realities - both for its customers and its people.</p>
      <p><a class="btn btn-default btn-lg" href="about.php" role="button">Know more</a></p>
    </div>
  </div>
  <div class="row three__blocks no_padding no-margin" id="product">
    <div class="container">
      <h2 class="page__title text-center"><span>Our Products</span></h2>
      <div class="col-md-4">
        <h3><a href="index.php#">Get N Go Litchi</a><span class="small-paragraph">Maecenas fermentum semper porta.</span></h3>
        <img src="images/prd1.jpg" alt="image" class="img-responsive img-rounded">
        <p align="justify">Lorem ipsum dolor sit amet, consectetuer elit adipiscing elit. Donec odio. Quisque volutpat mattis eros volutpat mattis. </p>
        <p><a class="btn btn-primary btn-md" href="index.php#" role="button">View Products</a> 
      </div>
      <div class="col-md-4 middle">
        <h3><a href="index.php#">Get N Go Soda</a><span class="small-paragraph">Maecenas fermentum semper porta.</span></h3>
        <img src="images/prd2.jpg" alt="image" class="img-responsive img-rounded">
        <p align="justify">Lorem ipsum dolor sit amet, consectetuer elit adipiscing elit. Donec odio. Quisque volutpat mattis eros volutpat mattis. </p>
        <p><a class="btn btn-primary btn-md" href="index.php#" role="button">View Products</a> 
      </div>
      <div class="col-md-4">
        <h3><a href="index.php#">Aqua Pyasa</a><span class="small-paragraph">Maecenas fermentum semper porta.</span></h3>
        <img src="images/prd3.jpg" alt="image" class="img-responsive img-rounded">
        <p align="justify">Lorem ipsum dolor sit amet, consectetuer elit adipiscing elit. Donec odio. Quisque volutpat mattis eros volutpat mattis. </p>
        <p><a class="btn btn-primary btn-md" href="index.php#" role="button">View Products</a> 
      </div>
    </div>
  </div>
  <div class="row grey-info-block text-center">
    <div class="container">
      <h2 class="page__title"><span>WHAT WE DO</span></h2>
      <p class="small-paragraph">Vivamus vestibulum nulla nec ante.</p>
      <div class="col-md-6"> <img src="images/content__images/pic1.jpg" alt="pic" class="img-rounded img-responsive" id="picture">
        <h3>Commodo id natoque malesuada sollicitudin elit suscipit. Nam nec turpis consequat.</h3>
        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis eros. Nullam malesuada erat ut turpis. Suspendisse urna nibh, viverra non, semper suscipit, posuere a, pede.</p>
        <p><a class="btn btn-info" href="index.php#" role="button">Learn more</a></p>
      </div>
      <div class="col-md-6"> <img src="images/content__images/pic2.jpg" alt="pic" class="img-rounded img-responsive">
        <h3>Commodo id natoque malesuada sollicitudin elit suscipit. Nam nec turpis consequat.</h3>
        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis eros. Nullam malesuada erat ut turpis. Suspendisse urna nibh, viverra non, semper suscipit, posuere a, pede.</p>
        <p><a class="btn btn-info" href="index.php#" role="button">Learn more</a></p>
      </div>
    </div>
  </div>
</section>
<?php
	include("footer.php");
?>
</body>
</html>