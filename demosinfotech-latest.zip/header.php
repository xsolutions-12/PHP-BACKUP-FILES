<header class="main__header">
  <div class="container">
    <nav class="navbar navbar-default" role="navigation"> 
      <div class="navbar-header">
        <h1 class="navbar-brand"><a href="index.php"><img src="images/logo.jpg" width="250"></a></h1>
        <a href="index.html" class="submenu">Menus</a> </div>
      <div class="menuBar">
        <ul class="menu">
          <li <?php if($url=='index.php'){echo "class='active'";} ?>><a href="index.php">Home</a></li>
          <!--<li class="dropdown"><a href="index.html#">Pages</a>
            <ul>
              <li><a href="indedx.php">Home / Fixed</a></li>
              <li><a href="#">Home + Blog</a></li>
              <li><a href="#">Portfolio</a></li>
              <li><a href="#">Typography</a></li>
              <li><a href="shortcodes.html">Shortcodes</a></li>
              <li><a href="blog.html">Blog & News</a></li>
              <li><a href="tables.html">Tables</a></li>
              <li><a href="faq.html">FAQ</a></li>
            </ul>
          </li>-->
          <li><a href="#">Our Company</a></li>
          <li><a href="#">Quality</a></li>
          <li <?php if($url=='product.php'){echo "class='active'";} ?>><a href="product.php">Products</a></li>
          <li><a href="#">Contact us</a></li>
        </ul>
      </div>
      <!-- /.navbar-collapse --> 
    </nav>
  </div>
</header>