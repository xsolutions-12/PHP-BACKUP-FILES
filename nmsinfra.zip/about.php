<!DOCTYPE html>
<html lang="en">

 <head>
	<meta charset="UTF-8">
	<title>NMS INFRASTRUCTURE Pvt. Ltd.</title> 

	<!-- mobile responsive meta -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<?php
		include("external.php");
	?>

</head>

<body>
	<div class="boxed_wrapper">
		<?php
			include("header.php");
		?>

		<!--Page Title-->
        <section class="page-title" style="background:url(images/page_nav/pic1.jpg) bottom left no-repeat">
        	<div class="container">
            	<div class="row clearfix">
                    <div class="col-md-6 col-sm-6 col-xs-12 pull-left">
						
						<!--<h1>about us</h1><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit </p>-->
					</div>
                    <!--<div class="col-md-6 col-sm-6 col-xs-12 pull-right text-right path"><a href="index.html">Home</a>&ensp;/&ensp;<a href="about.html">about us</a></div>-->
					<div class="overlay"></div>
                </div>
            </div>
        </section>
        <!--Page Title Ends-->
		
		<section class="about-us">
		    <div class="container">
		        <div class="sec-title">
					<h2>about <span>us</span> </h2>
					
				</div>
		        
					<div class="row">
                        <div class="col-md-8 col-sm-7 col-xs-12">
                            <div class="about-info">
			                    <h3>Complete hardware and networking solution</h3>
			                    <br>
			                    <div class="text">
			                        <p>
We are a leading Hardware and Network Solutions company, bringing together various technologies from world leaders to meet the networking and communication infrastructure needs of distributed Enterprises. NMS Works strong industry certified design and implementation team, turnkey project management skills, ability to translate customer needs into actions and a highly professional and motivated team have been the key factors in building an ever-growing list of satisfied list of customers.<br><br>

The Company is a well established, professionally managed organization of qualified and highly experienced computer engineers in various fields of computers like LAN, WAN etc. NMS Works has grown steadily and earned a reputation for services and reliability.<br><br>

We believe in customer satisfaction with clean track record of satisfying them time to time. We don’t do hard marketing rather believe in performance and referenced by the clients.</p><br>
			                    
			                    </div>
			                     

			                    
			                </div>
                            
                        </div>
                        <div class="col-md-4 col-sm-5 col-xs-12">
                            <div class="video-image-box">
                                <figure class="image"><img src="images/project/pic1.jpe" alt=""></figure>
                                
                            </div>
                        </div>
                    </div>

		    </div>
		</section>
		

		<?php
			include("footer.php");
		?>

	<!-- Scroll Top Button -->
	<button class="scroll-top tran3s color2_bg">
		<span class="fa fa-angle-up"></span>
	</button>
	<!-- pre loader  -->
	<!--<div class="preloader"></div>-->

		

	</div>
	
</body>

</html>



