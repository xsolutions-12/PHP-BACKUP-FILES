<!DOCTYPE html>
<html lang="en">

 <head>
	<meta charset="UTF-8">
	<title>NMS INFRASTRUCTURE Pvt. Ltd.</title> 

	<!-- mobile responsive meta -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<?php
		include("external.php");
	?>

</head>

<body>
	<div class="boxed_wrapper">
		<?php
			include("header.php");
		?>

		<!--Page Title-->
        <section class="page-title"  style="background:url(images/page_nav/pic4.jpg) center center no-repeat">
        	<div class="container">
            	<div class="row clearfix">
                    <div class="col-md-6 col-sm-6 col-xs-12 pull-left">
						<h1>
Clients
</h1>
						<!--<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit </p>-->
					</div>
                    <!--<div class="col-md-6 col-sm-6 col-xs-12 pull-right text-right path"><a href="index.html">Home</a>&ensp;/&ensp;<a href="client.html">
Clients</a></div>-->
					<div class="overlay"></div>
                </div>
            </div>
        </section>
        <!--Page Title Ends-->
		
		<section class="service" style="background:url(images/header-bar1.jpg) no-repeat center top #F3F3F3">
		    <div class="container">
		        <div class="sec-title">
					<h2>

Our <span>Clients</span> </h2>
					
				</div>
		        
					<div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                             <div class="service_carousel" style="width:100%;">
                                <!--Featured Service -->
                                <article class="single-column">
                                    <div class="item">
                                        <figure class="img-box" >
                                            <img src="images/client/logo1.png" alt="">
                                            <figcaption class="default-overlay-outer">
                                                <div class="inner">
                                                    <div class="content-layer">
                                                        <a href="#" class="thm-btn thm-tran-bg">NISER</a>
                                                    </div>
                                                </div>
                                            </figcaption>
                                        </figure>
                                        
                                    </div>
                                </article>
                                 
                                <!--Featured Service -->
                                <article class="single-column">
                                    <div class="item">
                                        <figure class="img-box">
                                            <img src="images/client/logo3.png" alt="">
                                            <figcaption class="default-overlay-outer">
                                                <div class="inner">
                                                    <div class="content-layer">
                                                        <a href="#" class="thm-btn thm-tran-bg">JINDAL</a>
                                                    </div>
                                                </div>
                                            </figcaption>
                                        </figure>
                                        
                                    </div>
                                </article>
                                <!--Featured Service -->
                                <article class="single-column">
                                    <div class="item">
                                        <figure class="img-box">
                                            <img src="images/client/logo8.png" alt="" width="250">
                                            <figcaption class="default-overlay-outer">
                                                <div class="inner">
                                                    <div class="content-layer">
                                                        <a href="#" class="thm-btn thm-tran-bg">HINDALCO</a>
                                                    </div>
                                                </div>
                                            </figcaption>
                                        </figure>
                                        
                                    </div>
                                </article>
                                <!--Featured Service -->
             					<article class="single-column">
                                    <div class="item">
                                        <figure class="img-box">
                                            <img src="images/client/logo2.png" alt="" width="250">
                                            <figcaption class="default-overlay-outer">
                                                <div class="inner">
                                                    <div class="content-layer">
                                                        <a href="#" class="thm-btn thm-tran-bg">L & T</a>
                                                    </div>
                                                </div>
                                            </figcaption>
                                        </figure>
                                        
                                    </div>
                                </article>
                                <article class="single-column">
                                    <div class="item">
                                        <figure class="img-box">
                                            <img src="images/client/logo4.png" alt="" width="250">
                                            <figcaption class="default-overlay-outer">
                                                <div class="inner">
                                                    <div class="content-layer">
                                                        <a href="#" class="thm-btn thm-tran-bg">TATA Power Sed</a>
                                                    </div>
                                                </div>
                                            </figcaption>
                                        </figure>
                                        
                                    </div>
                                </article>
            
        					</div>
                            
                        </div>
                        
                    </div>

		    </div>
		</section>
		 

     

		<?php
			include("footer.php");
		?>

	<!-- Scroll Top Button -->
	<button class="scroll-top tran3s color2_bg">
		<span class="fa fa-angle-up"></span>
	</button>
	<!-- pre loader  -->
	<!--<div class="preloader"></div>-->

		

	</div>
	
</body>

 </html>



