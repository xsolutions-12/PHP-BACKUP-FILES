<!DOCTYPE html>
<html lang="en">

 <head>
	<meta charset="UTF-8">
	<title>NMS INFRASTRUCTURE Pvt. Ltd.</title> 

	<!-- mobile responsive meta -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<?php
		include("external.php");
	?>

</head>

<body>
	<div class="boxed_wrapper">
		<?php
			include("header.php");
		?>

		<!--Page Title-->
        <section class="page-title" style="background:url(images/page_nav/pic7_ntwrk.jpg) no-repeat center center">
        	<div class="container">
            	<div class="row clearfix">
                    <div class="col-md-6 col-sm-6 col-xs-12 pull-left">
						<h1>
Network Management
</h1>
						<!--<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit </p>-->
					</div>
                     
					<div class="overlay"></div>
                </div>
            </div>
        </section>
        <!--Page Title Ends-->
		
		<section class="about-us">
		    <div class="container">
		        <div class="sec-title">
					<h2>Network <span>Management</span> </h2>
					
				</div>
            	<div class="row">
                    <div class="col-md-7 col-sm-7 col-xs-12">
                        <div class="about-info">
                           <!-- <h3>Complete hardware and networking solution</h3>-->
                            <br>
                            <div class="text data">
                                <h3>We provide the following:</h3>
                                <ul style="font-weight:normal">
        <li><strong>Desktop Computer Networking </strong></li>
        <li><strong>Office Computer Networking </strong></li>
         <li><strong>Computer to Computer Network </strong></li>
          <li><strong>PC to PC Networking </strong></li>
          <li><strong>Network Troubleshooting </strong></li>
           <li><strong>LAN / WAN Installation &amp; Failure Recovery. </strong></li>
      </ul>
                                <p>
We use branded quality of Network Cables and Connectors, providing our clients a very secured and robust network for data communication. Your home or office network is laid out extremely carefully avoiding any sort of wear and tear that may occur due to human contacts.<br><br>
We have all the resources that are needed to construct a complete network at your workplace, home or location of your choice. Putting together a temporary on- location network or a training classroom, we have the necessary equipment and devices. We can deliver, set up and pickup your computer network nationwide. Your satisfaction and repeat business is our primary goal. Our responsive executives teamed with reliable and certified technicians, offer a hassle-free experience from
start to finish. We offer proactive and end-to-end management of Local Area Network
(LAN), Wide Area Network (WAN) and VPN (Virtual private Network) connectivities.<br><br>

We are committed to provide a very efficient and smooth functioning for LAN / WAN Communications to all our clients. Whether it's wired or wireless, our network service such as local area network services, wide area network services and virtual private network services provides comprehensive management solutions that engage telephony and wireless experts.
We also provide networking solutions in Windows,Unix, Linux and NetWare. You can
trust us for a small home office Network (LAN) to wide area connectivity involving usage of latest hubs, switches and routers etc.</p>


                            </div>
                             

                            
                        </div>
                        
                    </div>
                    <div class="col-md-5 col-sm-5 col-xs-12">
                        <div class="video-image-box">
                            <figure class="image"><img src="images/ntwrkng.gif" alt=""></figure>
                            
                        </div>
                    </div>
                </div>
                <div class="row">
                    
                    <div class="col-md-3 col-sm-3 col-xs-12 row_1">
                        <div class="video-image-box">
                            <figure class="image"><img src="images/wirles.png" alt=""></figure>
                            
                        </div>
                    </div>
                    <div class="col-md-9 col-sm-9 col-xs-12">
                        <div class="about-info">
                           <!-- <h3>Complete hardware and networking solution</h3>-->
                            <br>
                            <div class="text data">
                                <h3>Wireless Networking</h3><br>

<p>

In computer networking, wireless technology is a modern alternative to networks that use cables. A wireless network transmits data by microwave and other radio signals.<br><br>

Wireless networks utilize radio waves and/or microwaves to maintain communication channels between computers. Wireless networking is a more modern alternative to wired networking that relies on copper and/or fiber optic cabling between network devices.<br><br>

A wireless network offers advantages and disadvantages compared to a wired network. Advantages of wireless include mobility and elimination of unsightly cables. Disadvantages of wireless include the potential for radio interference due to weather, other wireless devices, or obstructions like walls.<br><br>

Wireless is rapidly gaining in popularity for both home and business networking. Wireless technology continues to improve, and the cost of wireless products continues to decrease. Popular wireless local area networking (WLAN) products conform to the 802.11 "Wi -Fi" standards. The gear a person needs to build wireless networks includes network adapters (NICs), access points (APs), and  routers.
</p><br><br>
                        </div>
                        
                    </div>
                </div>
                
		    </div>
            
            	<div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="about-info">
                           <!-- <h3>Complete hardware and networking solution</h3>-->
                            <br>
                            <div class="text data">
                                
<h3>VPN</h3>

<br>
<h5>Overview</h5>
<p>VPN is a secure, private communication tunnel between two (or more) devices across a public network (like the Internet). These devices can be computers running some type of VPN software, or VPN-enabled routers. All of the VPN data is secure regardless of the fact it travels over a public network. VPN implementations use strong encryption and monitor traffic to ensure no packets have been altered. The encryption and data verification are very processor intensive, and the few SOHO broadband routers on the market that can act as VPN servers have somewhat limited throughput.</p><br><br>

<h5>VPN Protocols</h5>
<p>There are two major protocols that VPN supports. Microsoft uses PPTP (Point to Point Tunneling Protocol) and other companies often use IPSec (Internet Protocol Security). Most broadband routers can pass PPTP traffic by forwarding port 1723 but IPSec is more complex. If your router does not explicitly support IPSEC pass-through, then even placing your computer in the DMZ might not work. PPTP has decent encryption and also features "authentication" for verifying user IDs and passwords. IPSec is purely an encryption model and is much safer but does not include authentication routines. A third standard, L2TP is IPSec with authentication built in.</p><br><br>

<h5>VPN Servers and Clients</h5>
<p>VPN servers are hardware or software that listens for incoming connections, and acts as a gateway into a local network (or a single computer). VPN Clients are most often software based, and have the ability to "call" VPN servers, logon and communicate as they're on the same "virtual" network. Many broadband routers can pass such sessions (one or more, depending on the router) over the Internet, but very few SOHO models can act as VPN servers themselves. For as ubiquitous as connectivity has become and how reliant we've grown on it, the Internet is still a digital jungle where hackers easily steal sensitive information from the ill-equipped and where the iron- fisted tactics of totalitarian regimes bent on controlling what their subjects can access are common. So instead of mucking around in public networks, just avoid them. Use a VPN instead. </p>
</p><br><br>

                            

                            
                            </div>
                             

                            
                        </div>
                        
                    </div>
                     
                    
                </div>
                <div class="row">
                    <div class="col-md-7 col-sm-7 col-xs-12">
                        <div class="about-info">
                           <!-- <h3>Complete hardware and networking solution</h3>-->
                            <br>
                            <div class="text data">
                                
<h3>Internet VPN</h3><br>
<p>
For this reason, VPNs are hugely popular with corporations as a means of securing sensitive data when connecting remote data centers. These networks are also becoming increasingly common among individual users—and not just torrenters. Because VPNs use a combination of dedicated connections and encryption protocols to generate virtual P2P connections, even if snoopers did manage to siphon off some of the transmitted data, they'd be unable to access it on account of the encryption.<br><br>

Establishing one of these secure connections—say you want to log into your private corporate network remotely—is surprisingly easy. The user first connects to the public internet through an ISP, then initiates a VPN connection with the company VPN server using client software. And that's it! The client software on the server establishes the secure connection, grants the remote user access to the internal network.<br><br>

Many security protocols have been developed as VPNs, each offering differing levels of security and features. Among the more common are:
</p>

<ul>
        <li><strong>IP security (IPSec)</strong>: IPSec is often used to secure Internet communications and can  operate in<strong> </strong>two modes. Transport mode only encrypts the data packet  message itself while Tunneling mode encrypts the entire data packet. This  protocol can also be used in tandem with other protocols to increase their  combined level of security.          </li>
        
         
        <li><strong>Layer 2 Tunneling Protocol (L2TP)/IPsec</strong>: The L2TP and  IPsec protocols combine their best<strong> </strong>individual features to create a  highly secure VPN client. Since <a href="http://en.wikipedia.org/wiki/Layer_2_Tunneling_Protocol">&nbsp;L2TP</a><u> </u>isn't capable of encryption, it instead generates the tunnel while the  IPSec protocol handles encryption, channel security, and 
      data integrity checks to ensure all of the packets have arrived and  that the channel has not been compromised.          </li>
    
    
        <li><strong>Layer 2 Tunneling Protocol (L2TP)/IPsec</strong>: The L2TP and  IPsec protocols combine their best<strong> </strong>individual features to create a  highly secure VPN client. Since <a href="http://en.wikipedia.org/wiki/Layer_2_Tunneling_Protocol">&nbsp;L2TP</a><u> </u>isn't capable of encryption, it instead generates the tunnel while the  IPSec protocol handles encryption, channel security, and 
      data integrity checks to ensure all of the packets have arrived and  that the channel has not been compromised.          </li>
     
      
        <li><strong>Secure Sockets  Layer (SSL) </strong>and<strong> Transport Layer Security (TLS)</strong>:  SSL and TLS are used extensively<strong> </strong>in the security of online retailers and  service providers. These protocols operate using a handshake method. As IBM  explains, "A HTTP-based SSL connection is always initiated by the client  using a URL starting with https:// instead of with http://. At the beginning of  an SSL session, an SSL handshake is performed. This handshake produces the  cryptographic parameters of the session." These parameters, typically  digital certificates, are the means by which the two systems exchange  encryption keys, authenticate the session, and create the secure connection. </li>
  
   
        <li><strong>Point-to-Point  Tunneling Protocol (PPTP)</strong>: PPTP is a  ubiquitous VPN protocol used since the mid<strong> </strong>1990s and can be installed on  a huge variety of operating systems has been around since the days of Windows  95. But, like L2TP, PPTP doesn't do encryption, it simply tunnels and  encapsulates the data packet. Instead, a secondary protocol such as GRE or TCP  has to be used as well to handle the encryption. And while the level of  security PPTP provides has been eclipsed by new methods, the protocol remains a  strong one, albeit not the most secure. </li>
       
        
        <li><strong>Secure Shell (SSH)</strong>: SSH creates both the VPN tunnel and the encryption that protects it.  This<strong> </strong>allows users to transfer information unsecured data by routing the  traffic from remote fileservers through an encrypted channel. The data itself  isn't encrypted but the channel its moving through is. SSH connections are  created by the SSH client, which forwards traffic from a local port one on the  remote server. All data between the two ends of the tunnel flow through these  specified ports. </li>
       
      </ul>                           

                            
                            </div>
                             

                             
                        </div>
                        
                    </div>
                    <div class="col-md-5 col-sm-5 col-xs-12 row_1">
                        <div class="video-image-box">
                            <figure class="image"><img src="images/vpn.png" alt=""></figure>
                            
                        </div>
                    </div>
                    
                </div>
                
		    </div>
		</section>
		

		<?php
			include("footer.php");
		?>

	<!-- Scroll Top Button -->
	<button class="scroll-top tran3s color2_bg">
		<span class="fa fa-angle-up"></span>
	</button>
	<!-- pre loader  -->
	<!--<div class="preloader"></div>-->

		

	</div>
	
</body>

 </html>



