<!DOCTYPE html>
<html lang="en">

 
<head>
	<meta charset="UTF-8">
	<title>NMS INFRASTRUCTURE Pvt. Ltd.</title> 

	<!-- mobile responsive meta -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<?php
		include("external.php");
	?>

</head>
<body>
	<div class="boxed_wrapper">
		<?php
			include("header.php");
		?>

		<!--Page Title-->
        <section class="page-title" style="background:url(images/page_nav/pic6.jpg) right center no-repeat">
        	<div class="container">
            	<div class="row clearfix">
                    <div class="col-md-6 col-sm-6 col-xs-12 pull-left">
						 
						 
					</div>
                    
					<div class="overlay"></div>
                </div>
            </div>
        </section>
        <!--Page Title Ends-->
		
		
		 

		<section class="contact_us about-us">
			<div class="container">   
                <div class="sec-title text-center">
                    <h2>Car<span>eer</span></h2>
					<p style="text-align:center">Career @ NMS Infrastructures Pvt. Ltd.</p>
                </div>
                <div class="default-form-area">
					<form id="contact-form" name="contact_form" class="default-form" action="http://wp.hostlin.com/electrician-press/inc/sendmail.php" method="post">
						<div class="row clearfix">
							<div class="col-md-6 col-sm-6 col-xs-12">
												
								<div class="form-group style-two">
									<input type="text" name="first_name" class="form-control" value="" placeholder="First Name" required>
								</div>
							</div>
                            <div class="col-md-6 col-sm-6 col-xs-12">
												
								<div class="form-group style-two">
									<input type="text" name="last_name" class="form-control" value="" placeholder="Last Name" required>
								</div>
							</div>
							<div class="col-md-6 col-sm-6 col-xs-12">
								<div class="form-group style-two">
									<input type="email" name="form_email" class="form-control required email" value="" placeholder="Email Id" required>
								</div>
							</div>
							<div class="col-md-6 col-sm-6 col-xs-12">
								<div class="form-group style-two">
									<input type="text" name="form_phone" class="form-control" value="" placeholder="Phone">
								</div>
							</div>
                            <div class="col-md-6 col-sm-12 col-xs-12">
								<div class="form-group style-two">
									<input type="text" id="datetimepicker2" name="form_Date" class="form-control" value="" placeholder="Click to get Date of Birth">
								</div>
							</div>
							<div class="col-md-6 col-sm-6 col-xs-6">
								<div class="form-group style-two">
									<!--<span style="color:#999"><strong>Gender:</strong> &nbsp;<input name="from_gender" type="radio" value=""  class="option-input radio" > <span style="margin-right:100px;">Male </span><input name="from_gender" type="radio" value="" class="option-input radio" >  Female</span>-->
                                   <div style="color:#999; float:left;  padding-top:15px;">Gender </div><div class="radio-group">
<input type="radio" id="option-one" name="selector" checked><label for="option-one">Male</label><input type="radio" id="option-two" name="selector"><label for="option-two">Female</label>
  </div>
								</div>
							</div>	
                            
                            <div class="col-md-6 col-sm-6 col-xs-12">
												
								<div class="form-group style-two">
									<input type="text" name="Skill" class="form-control" value="" placeholder="Skill" required>
								</div>
							</div>
                            <div class="col-md-6 col-sm-6 col-xs-12">
												
								<div class="form-group style-two">
									<input type="text" name="cover_note" class="form-control" value="" placeholder="Cover Note" required>
								</div>
							</div>
                            <div class="col-md-6 col-sm-6 col-xs-12">
								<div class="form-group style-two">
									<input type="text" name="verification_code" class="form-control" value="" placeholder="Verification Code">
								</div>
							</div>
							<div class="col-md-12 col-sm-6 col-xs-12">
								<div class="form-group style-two">
									
								</div>
							</div>   											  
						</div>
						<div class="contact-section-btn text-center">
							<div class="form-group style-two">
								<input id="form_botcheck" name="form_botcheck" class="form-control" type="hidden" value="">
								<button class="thm-btn thm-color" type="submit" data-loading-text="Please wait...">send message</button>
							</div>
						</div> 
					</form>
                    
                    
				</div>          
			</div>
		</section>
		 

		<?php
			include("footer.php");
		?>


<!-- Scroll Top Button -->
	<button class="scroll-top tran3s color2_bg">
		<span class="fa fa-angle-up"></span>
	</button>
	<!-- pre loader  -->


	
    
    <link rel="stylesheet" type="text/css" href="date/jquery.datetimepicker.css"/ >
 
<script src="date/jquery.datetimepicker.full.min.js"></script>
    
    <script>
	jQuery.datetimepicker.setLocale();
</script>
<script>
jQuery('#datetimepicker2').datetimepicker({
 i18n:{
  de:{
   months:[
    'Januar','Februar','März','April',
    'Mai','Juni','Juli','August',
    'September','Oktober','November','Dezember',
   ],
   dayOfWeek:[
    "So.", "Mo", "Di", "Mi", 
    "Do", "Fr", "Sa.",
   ]
  }
 },
 timepicker:false,
 format:'d.m.Y'
});
	</script>

</div>
	
</body>

 </html>