<!DOCTYPE html>
<html lang="en">

 <head>
	<meta charset="UTF-8">
	<title>NMS INFRASTRUCTURE Pvt. Ltd.</title> 

	<!-- mobile responsive meta -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<?php
		include("external.php");
	?>

</head>

<body>
	<div class="boxed_wrapper">
		<?php
			include("header.php");
		?>
		<!--Page Title-->
        <section class="page-title" style="background:url(images/page_nav/pic5.jpg) center center no-repeat">
        	<div class="container">
            	<div class="row clearfix">
                    <div class="col-md-6 col-sm-6 col-xs-12 pull-left">
						<h1>
Contact Us
</h1>
 					</div>
                     
					<div class="overlay"></div>
                </div>
            </div>
        </section>
        <!--Page Title Ends-->
		
		<section class="about-us">
		    <div class="container">
		        <div class="sec-title">
					<h2>

Contact <span>Us</span> </h2>
					
				</div>
		        
					<div class="row">
                        <div class="col-md-7 col-sm-7 col-xs-12">
                            <div class="about-info">
			                   <!-- <h3>Complete hardware and networking solution</h3>-->
			                    <br>
			                    <div class="text data">
			                        

<h3>Corporate Office:</h3><br>
<p>
<strong>NMS INFRASTRUCTURE (P) LTD.</strong><br>
DCB 315,3rd FLOOR,DLF CYBERCITY BUILDING<br>
PATIA, PS-INFOCITY, BHUBANESWAR - 751024<br>
Tel:0674-6509777</p>
 <br>
<h3>Administrative Office:</h3><br>
<p>
<strong>Branches :</strong><br> Kolkata, Jharkhand, Sambalpur<br>
<strong>Contact :</strong><br> info@nmsinfra.com<br>
 </p>
 <br>
			                    
			                    </div>
			                     

			                   <!-- <div class="link_btn">
			                        <a href="infra_mngmnt.html" class="thm-btn">read more</a>
			                        
			                    </div>-->
			                </div>
                            
                        </div>
                        <div class="col-md-5 col-sm-5 col-xs-12">
                            <div class="video-image-box">
                                <figure class="image"><img src="images/project/cntc.jpg" alt=""></figure>
                                
                            </div>
                        </div>
                    </div>

		    </div>
		</section>
		 

		<?php
			include("footer.php");
		?>

	<!-- Scroll Top Button -->
	<button class="scroll-top tran3s color2_bg">
		<span class="fa fa-angle-up"></span>
	</button>
	<!-- pre loader  -->
	<!--<div class="preloader"></div>-->

		

	</div>
	
</body>

 </html>



