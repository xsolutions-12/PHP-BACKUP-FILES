<footer class="footer bg-style" style="background-image:url(images/background/bg-3.jpg);">
			<div class="container">
				<div class="footer-upper">
				
					<div class="row">
						<div class="item col-md-5 col-sm-6">
							<div class="footer-widget about-widget">
								<a href="index.html">
									<img src="images/logo/logonew_w.png" alt="Awesome Image"  />
								</a>
								<p>
                                DCB 315, 3rd FLOOR, DLF CYBERCITY BUILDING<br>
PATIA, PS-INFOCITY, BHUBANESWAR - 751024<br>
Tel:0674-6509777
                                </p>
								 
							</div>
						</div>
						<div class="item col-md-3 col-sm-6">
							<div class="footer-widget quick-links links">
								<!--<h3 class="title">Our Services</h3>-->
								<ul class="">
									<li><a href="infra_mngmnt.php">Infrastructure Management</a></li>
									<li><a href="oline_app.php">Online Application</a></li>
									<li><a href="why.php">Why NMS</a></li>
									
									
								</ul>
							</div>
						</div>
						 
						<div class="item col-md-4 col-sm-6">
							<div class="footer-widget contact-widget">
								<h3 class="title">our location</h3>
								 <div class="footer-map">
			
										<div class="home-google-map">
											<div 
												class="google-map" 
												id="footer-map" 
												data-map-lat="20.34907" 
												data-map-lng="85.807577" 
												data-icon-path="images/logo/footer-marker.png"
												data-map-title="Chester"
												data-map-zoom="15" >
											</div>
										</div>
									
								</div>
							</div>
						</div>
					</div>
				</div>
				<!--Footer Bottom-->
				<div class="footer-bottom">					
					<div class="pull-left"><div class="copyright-text">Copyright &copy; NMS Infrastructure Pvt. Ltd. 2017. All Rights Reserved </div></div>
					<div class="pull-right">
						<div class="social-links pull-right">
							<a href="#"><span class="fa fa-facebook-f"></span></a>
							<a href="http://twitter.com/nmsinfra"><span class="fa fa-twitter"></span></a>
							<a href="#"><span class="fa fa-linkedin"></span></a>
														
						</div>
					</div>			         
				</div>
			</div>
		</footer>