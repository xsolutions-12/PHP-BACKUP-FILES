<!DOCTYPE html>
<html lang="en">

 <head>
	<meta charset="UTF-8">
	<title>NMS INFRASTRUCTURE Pvt. Ltd.</title> 

	<!-- mobile responsive meta -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<?php
		include("external.php");
	?>

</head>

<body>
	<div class="boxed_wrapper">
		<?php
			include("header.php");
		?>

		<!--Page Title-->
        <section class="page-title" style="background:url(images/page_nav/pic2_2.jpg) no-repeat center top">
        	<div class="container">
            	<div class="row clearfix">
                    <div class="col-md-6 col-sm-6 col-xs-12 pull-left">
						<h1>
Project Management
</h1>
						<!--<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit </p>-->
					</div>
                     
					<div class="overlay"></div>
                </div>
            </div>
        </section>
        <!--Page Title Ends-->
		
		<section class="about-us">
		    <div class="container">
		        <div class="sec-title">
					<h2>

Project <span>Management</span> </h2>
					
				</div>
		        
					<div class="row data">
                      		<div class="col-md-8 col-sm-7 col-xs-12">
                            <div class="about-info">
			                     <h3>Facility Management</h3> 
			                    <br>
			                    <div class="text">
			                        <p>
 
      NMSIPL has the team of technocrats, proficient in various domains of the IT sector. It will be updating the latest technological revolutions. The entire team is capable and confident of tuning the clients’ IT requirements to latest paradigm in the most economical way using the best possible combinations of the facilities available. Once the study of client’s requirements is done, the plan, with the list of available resources be its infrastructure, hardware and software, man power, technical expertise of the users etc. is made ready, simultaneously understanding the existing system. The solution is then proposed making use of the available resources and man power at the client’s premises. The responsibility starts from the study and ends at the effective implementation and maintenance.<br><br>

The solutions may vary from simple supply of hardware to setting up WAN, LAN, E-Business infrastructure, maintenance of Client/Server Systems (Windows), Database Administration, ERP, Development and Implementation / Maintenance of Web applications, Mail Services etc. The client will be updated from time to time regarding the latest technological innovations by the technical team and its implementation for client’s best usage. This gives client an edge on the latest technology available in their Organization. The information and regular meetings give further improvement on the implication. Special Value Added Service attention will be always given to the client in terms of time and expertise available. Also, an exclusive dedicated team can be provided to the client at times of need.<br><br>

Through our Total Facilities Management Solution, we offer a range of service options, customized to the specific requirements of yours. These include: <br>
      </p><br>
      <ul>
      	<li>    365x24x7 Support for mission critical sites</li>
    <li>Value added Support Services</li>
    <li>System Administration</li>
    <li>Helpdesk Services</li>
    <li>Network Consulting</li>
    <li>Network Implementation and Management</li>
    <li>Asset Management etc.</li><br>

      </ul>
      <p>All this helps customer in deriving maximum value from the investment in IT hardware and software. </p>
      <br><br>
      </div>
      						</div>
                            </div>
                            <div class="col-md-4 col-sm-5 col-xs-12">
                                                        <div class="video-image-box">
                                                            <figure class="image"><img src="images/project/pic5.jpe" alt=""></figure>
                                                            
                                                        </div>
                                                    </div>
                                                    </div>
                     <div class="row data">
                     		<div class="col-md-4 col-sm-5 col-xs-12">
                                                                        <div class="video-image-box">
                                                                            <figure class="image"><img src="images/project/asset.jpg" alt=""></figure>
                                                                            
                                                                        </div>
                                                                    </div>
                            <div class="col-md-8 col-sm-7 col-xs-12">
                                <div class="about-info">
                      <h3>Asset Management</h3><br>
                      <div class="text">
                      <p>
                Software asset management (SAM) is a business practice that involves managing and optimizing the purchase, deployment, maintenance, utilization, and disposal of software applications within an organization. According to the  Information Technology Infrastructure  Library (ITIL), SAM is defined as “…all of the infrastructure and processes necessary for the effective management, control and protection of the software assets…throughout all stages of their lifecycle. Fundamentally intended to be part of an organization’s information technology  business strategy, the goals of SAM are to reduce  information technology (IT) costs and limit business and legal risk related to the ownership and use of software, while maximizing IT responsiveness and end-user  productivity.[2] SAM is particularly important for large corporations in regards to redistribution of licenses and managing legal risks associated with software ownership and expiration. SAM technologies track license expiration, thus allowing the company to function ethically and within software compliance regulations. This can be important for both eliminating legal costs associated with license agreement violations and as part of a company's reputation management strategy. Both are important forms of risk management and are critical for large corporations' long-term business strategies.<br><br>
                
                SAM is one facet of a broader business  discipline known as  IT asset management, which includes overseeing both software and hardware that comprise an organiza tion’s computers and network.<br><br>
                
                A number of technologies are available to support key SAM processes:
                       </p>
                        
                       <br>
                       
                      <h3> Other levels of support are available:</h3><br>
                      <ul>
                            <li><strong>Software inventory </strong>tools  intelligently “discover” software installed across the &nbsp;computer &nbsp;network, and collect software file  information such as title, product ID, size, date, path, and version.          </li>
                                      <li><strong>License manager</strong>solutions<strong> </strong>provide an intelligent repository for license entitlements<strong> </strong>which can  then be reconciled against data provided by Software inventory tools to provide  the organization with an 'Effective License Position' or view of where the  organization is under-licensed (at risk of a compliance audit) or over-licensed  (wasting money on unnecessary software purchases). </li>
                            <li><strong>Software metering </strong>tools<strong> </strong>monitor the utilization of software applications across a<strong> </strong>network.  They can also provide real-time enforcement of compliance for applications  licensed based on usage. </li>
                            <li><strong>Application control </strong>tools  restrict what and by whom particular software can be run on a<strong> </strong>computer  as a means of avoiding security and other risks. </li>
                            <li><strong>Software deployment</strong> tools<strong> </strong>automate and regulate the deployment of new software.<strong> </strong></li>
                            <li><strong>&nbsp;Patch management </strong>tools  automate the deployment of software patches to ensure that<strong> </strong>computers are  up-to-date and meet applicable security and efficiency standards. </li>
                          </ul><br>
                          
                          </div>
                            </div>
                            </div>
                            
                          </div>
                       
                     <div class="row">
                        <div class="col-md-8 col-sm-7 col-xs-12">
                        <div class="about-info">
                        <h3>Backup Management</h3><br>
                        <h5>Backups</h5>
                        <div class="text data">
                        <p>
                        Keeping reliable backups is an integral part of data management. Your personal computer, external hard drives, departmental or university servers are examples of tools used for backing up data. CDs or DVDs are not recommended because they fail so frequently.</p><br><br>
            
            
            <h5>Backup Your Data</h5>
            
            <ul>
                        <li>Make 3 copies (e.g.  original + external/local + external/remote) </li>
                        <li>Have them  geographically distributed (local vs. remote depends on recovery time needed)          </li>
                      </ul><br><br>
                      <h5>Data Backup Options</h5>
                        <ul>
                        <li>Hard drive  (examples: via Vista backup, Mac Timeline, UNIX rsync) </li>
                        <li>Tape backup system          </li>
                        <li>MIT’s &nbsp;TSM service (Basic is free, up to  15 Gb; Enterprise has a fee, and provides up to 10Tb, includes an off-site  copy) </li>
                        <li>Cloud Storage -  some examples of private sector storage resources include: 
                            <ol><li>  Amazon S3 -Requires client software, no  encryption support (http://aws.amazon.com/s3/#pricing) </li>
                   <li> S3-based Remote Hard Drive Services such  as Elephant Drive (www.elephantdrive.com) and Jungle  Disk (www.jungledisk.com)</li>
                   <li> Mozy (from EMC) Free client software,  448-bit Blowfish encryption or AES key (http:// mozy.com/)</li>
                    <li>Carbonite Free  client software, 1024Free 1024-bit Blowfish encryption (www.carbonite.com) </li>
                    </ol>
                        </li>
                      </ul> <br>
            <h5>Secure Your Data</h5>
            
            <ul ><li><strong> Unencrypted </strong>is ideal for storing your data because it  will make it most easily read by you and<strong> </strong>others in the future. But if  you do need to encrypt your data because its sensitivity:
                      <ol style="padding-left:40px">
                      <li> Keep passwords and  keys on paper (2 copies), and in a PGP (pretty good privacy) encrypted digital  file </li>
                       <li>   Don’t rely on 3rd  party encryption alone</li></ol>
                   </li>
            
                        <li><strong>Uncompressed </strong>is also ideal for storage, but if you need to do so to conserve space,  limit<strong> </strong>compression to your 3rd backup copy </li>
                      </ul><br>
                      
                      <h5>Test your backup system</h5>
            
            
            <p>
            In order to make sure that your backup system is working properly, try to retrieve your data files and make sure that you can read them. You should do this upon initial setup of the system and on a regular schedule thereafter. 
                               </p>             
                                            </div>
                        </div>
                        </div>
                         <div class="col-md-4 col-sm-5 col-xs-12">
                                                            <div class="video-image-box">
                                                                <figure class="image"><img src="images/project/back.png" alt=""></figure>
                                                                
                                                            </div>
                                                        </div>            
            
                    </div>
                            
                        </div>
                        
                    </div>

		    </div>
		</section>
		 

		<?php
			include("footer.php");
		?>

	<!-- Scroll Top Button -->
	<button class="scroll-top tran3s color2_bg">
		<span class="fa fa-angle-up"></span>
	</button>
	<!-- pre loader  -->
	<!--<div class="preloader"></div>-->

		

	</div>
	
</body>

 </html>



