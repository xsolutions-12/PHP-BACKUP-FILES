<!DOCTYPE html>
<html lang="en">

 <head>
	<meta charset="UTF-8">
	<title>NMS INFRASTRUCTURE Pvt. Ltd.</title> 

	<!-- mobile responsive meta -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<?php
		include("external.php");
	?>
</head>

<body>
	<div class="boxed_wrapper">
		<?php
			include("header.php");
		?>

		<!--Page Title-->
        <section class="page-title">
        	<div class="container">
            	<div class="row clearfix">
                    <div class="col-md-6 col-sm-6 col-xs-12 pull-left">
						<h1>
Web Application Management
</h1>
						<!--<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit </p>-->
					</div>
                    <div class="col-md-6 col-sm-6 col-xs-12 pull-right text-right path"><a href="index.html">Home</a>&ensp;/&ensp;<a href="web.html">
Web Application Management</a></div>
					<div class="overlay"></div>
                </div>
            </div>
        </section>
        <!--Page Title Ends-->
		
		<section class="about-us">
		    <div class="container">
		        <div class="sec-title">
					<h2>

Web Application <span>Management</span> </h2>
					
				</div>
		        
					<div class="row data">
                        <div class="col-md-8 col-sm-7 col-xs-12">
                            <div class="about-info">
			                       
			                    <br>
			                    <div class="text">
                                	<h3>Web Applications or Website Widgets</h3><br><br>

<p>
In particular, the web provides a way for marketers to get to know the people visiting their sites and start communicating with them. One way of doing this is asking web visitors to subscribe to newsletters, to submit an application form when requesting information on products or provide details to customize their browsing experience when next visiting a particular website.<br><br>

The web is also an excellent sales channel for a myriad of organizations, large or small: with over 1 billion Internet users as on 2007.<br><br>

All this data must be somehow captured, stored, processed and transmitted to be used immediately or at a later date. Web applications, in the form of submit fields, enquiry and login forms, shopping carts, and content management systems, are those website widgets that allow this to happen.<br><br>

They are, therefore, fundamental to businesses for leveraging their online presence thus creating long-lasting and profitable relationships with prospects and customers.<br><br>

No wonder web applications have become such a ubiquitous phenomenon. However, due to their highly technical and complex nature, web applications are a widely unknown and a grossly misunderstood fixture in our everyday cyber-life.</p><br><br>
 
<h3>Web Applications Defined</h3>
<p>
From a technical view-point, the web is a highly programmable environment that allows mass customization through the immediate deployment of a large and diverse range of applications, to millions of global users. Two important components of a modern website are flexible web browsers and web applications; both available to all and sundry at no expense.<br><br>

Web browsers are software applications that allow users to retrieve data and interact with content located on web pages within a website.<br><br>

Today’s websites are a far cry from the static text and graphics showcases of the early and mid - nineties: modern web pages allow personalized dynamic content to be pulled down by users according to individual preferences and settings. Furthermore, web pages may also run client - side scripts that “change” the Internet browser into an interface for such applications as web mail and interactive mapping software (e.g., Yahoo Mail and Google Maps).<br><br>

Most importantly, modern web sites allow the capture, processing, storage and transmission of sensitive customer data (e.g., personal details, credit card numbers, social security information, etc.) for immediate and recurrent use. And, this is done through web applications. Such features as webmail, login pages, support and product request forms, shopping carts and content management systems, shape modern websites and provide businesses with the means necessary to communicate with prospects and customers. These are all common examples of web applications.<br><br>

Web applications are, therefore, computer programs allowing website visitors to submit and retrieve data to/from a database over the Internet using their preferred web browser. The data is then presented to the user within their browser as information is generated dynamically (in a specific format, e.g. in HTML using CSS) by the web application through a web server.<br><br>

For the more technically oriented, Web applications query the content server (essentially a content repository database) and dynamically generate web documents to serve to the client (people surfing the website). The documents are generated in a standard format to allow support by all browsers (e.g., HTML or XHTML).  JavaScript is one form of client side script that permits dynamic elements on each page (e.g., an image changes once the user hovers over it with a mouse). The web browser is key - it interprets and runs all scripts etc. while displaying the requested pages and content. Wikipedia brilliantly terms the web browser as the “universal client for any web application”.<br><br>

Another significant advantage of building and maintaining web applications is that they perform their function irrespective of the operating system and browsers running client side. Web applications are quickly deployed anywhere at no cost and without any installation requirements
(almost) at the user’s end.<br><br>

As the number of businesses embracing the benefits of doing business over the web increases, so will the use of web applications and other related technologies continue to grow. Moreover, since the increasing adoption of intranets and extranets, web applications become greatly entrenched in any organization’s communication infrastructures, further broadening their scope and possibility of technological complexity and prowess.<br><br>

Web applications may either be purchased off-the-shelf or  created in-house.</p><br><br>
 
<h3>How do web applications work?</h3><br><br>
<p>
The figure below details the three-layered web application model. The first layer is normally a web browser or the user interface; the second layer is the dynamic content generation technology tool such as Java servlets (JSP) or Active Server Pages (ASP), and the third layer is the database containing content (e.g., news) and customer data (e.g., usernames and passwords, social security numbers and credit card details).<br><br>

The figure below shows how the initial request is triggered by the user through the browser over the Internet to the web application server. The web application accesses the databases servers to perform the requested task updating and retrieving the information lying within the database. The web application then presents the information to the user through the browser.</p></div>
                                </div>
			                     

			                   
			                </div>
                            
                        </div>
                        <div class="col-md-4 col-sm-5 col-xs-12">
                            <div class="video-image-box">
                                <figure class="image"><img src="images/project/pic5.jpe" alt=""></figure>
                                
                            </div>
                        </div>
                    </div>

		    </div>
		</section>
		 

		<?php
			include("footer.php");
		?>

	<!-- Scroll Top Button -->
	<button class="scroll-top tran3s color2_bg">
		<span class="fa fa-angle-up"></span>
	</button>
	<!-- pre loader  -->
	<!--<div class="preloader"></div>-->

		 

	</div>
	
</body>

 </html>



