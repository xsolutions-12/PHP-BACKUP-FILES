	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/responsive.css">
	<link rel="stylesheet" href="fonts/flaticon.css" />

	<!--favicon-->
	<link rel="apple-touch-icon" sizes="180x180" href="images/favicon/LOGOICO.png">
	<link rel="icon" type="image/png" href="images/favicon/LOGOICO.png">
	<link rel="icon" type="image/png" href="images/favicon/LOGOICO.png" sizes="16x16">
    
    
    
		<!-- jQuery js -->
		<script src="js/jquery.js"></script>
		<!-- bootstrap js -->
		<script src="js/bootstrap.min.js"></script>
		<!-- jQuery ui js -->
		<script src="js/jquery-ui.js"></script>
		<!-- owl carousel js -->
		<script src="js/owl.carousel.min.js"></script>
		<!-- jQuery validation -->
		<script src="js/jquery.validate.min.js"></script>
		<!-- google map -->
		<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCRvBPo3-t31YFk588DpMYS6EqKf-oGBSI"></script> 
		<script src="js/gmap.js"></script>
		<!-- mixit up -->
		<script src="js/wow.js"></script>
		<script src="js/jquery.mixitup.min.js"></script>
		<script src="js/jquery.fitvids.js"></script>
		<script src="js/bootstrap-select.min.js"></script>

		<!-- revolution slider js -->
		<script src="assets/revolution/js/jquery.themepunch.tools.min.js"></script>
		<script src="assets/revolution/js/jquery.themepunch.revolution.min.js"></script>
		<script src="assets/revolution/js/extensions/revolution.extension.actions.min.js"></script>
		<script src="assets/revolution/js/extensions/revolution.extension.carousel.min.js"></script>
		<script src="assets/revolution/js/extensions/revolution.extension.kenburn.min.js"></script>
		<script src="assets/revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
		<script src="assets/revolution/js/extensions/revolution.extension.migration.min.js"></script>
		<script src="assets/revolution/js/extensions/revolution.extension.navigation.min.js"></script>
		<script src="assets/revolution/js/extensions/revolution.extension.parallax.min.js"></script>
		<script src="assets/revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
		<script src="assets/revolution/js/extensions/revolution.extension.video.min.js"></script>

		<!-- fancy box -->
		<script src="js/jquery.fancybox.pack.js"></script>
		<script src="js/jquery.polyglot.language.switcher.js"></script>
		<script src="js/nouislider.js"></script>
		<script src="js/jquery.bootstrap-touchspin.js"></script>
		<script src="js/SmoothScroll.js"></script>
		<script src="js/jquery.appear.js"></script>
		<script src="js/jquery.countTo.js"></script>
		<script src="js/jquery.flexslider.js"></script>
		<script src="js/imagezoom.js"></script>	
		<script src="js/isotope.js"></script>
		<script src="js/validation.js"></script>
		<script id="map-script" src="js/default-map.js"></script>
		<script src="js/custom.js"></script>