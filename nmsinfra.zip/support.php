<!DOCTYPE html>
<html lang="en">

 <head>
	<meta charset="UTF-8">
	<title>NMS INFRASTRUCTURE Pvt. Ltd.</title> 

	<!-- mobile responsive meta -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<?php
		include("external.php");
	?>

</head>

<body>
	<div class="boxed_wrapper">
		<?php
			include("header.php");
		?>

		<!--Page Title-->
        <section class="page-title" style="background:url(images/page_nav/pic3.jpg) center center no-repeat">
        	<div class="container">
            	<div class="row clearfix">
                    <div class="col-md-6 col-sm-6 col-xs-12 pull-left">
						 
						<!--<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit </p>-->
					</div>
                     
					<div class="overlay"></div>
                </div>
            </div>
        </section>
        <!--Page Title Ends-->
		
		<section class="about-us">
		    <div class="container">
		        <div class="sec-title">
					<h2>

Sup<span>port</span> </h2>
					
				</div>
		        
					<div class="row data">
                        <div class="col-md-8 col-sm-7 col-xs-12">
                            <div class="about-info">
			                     <!--<h3>Support</h3> -->
			                    
			                    <div class="text">
       
      <p>
IT support &amp; network management, with more than 18 staff operating network of support and logistic centers, NMSIPL and associates, provide an unrivalled Computer and network maintenance service to maintain maximum uptime and productivity for your business.NMSIPL support means that we are involved in rectifying equipment failures, rather than your IT staff and is a response based service which provides an on-site engineer within 12 hours. The engineer then diagnoses the problem and works through until the problem is resolved.<br>
<br>
The support is its standard cover for multiple PCs, printers, servers &amp; networking and communications equipment. It provides
cost-effective cover which is ideal for non-critical items which do not have a significant impact on business operations.
With us, you may also price your maintenance for yourself on screen, now! Our support means the involvement in rectifying equipment failures, rather than your IT staff and is a response based service which provides an on-site engineer within 12 hours. The engineer then diagnoses the problem and works through until the problem is resolved.
       </p><br>
       
      <h3> Other levels of support are available:</h3><br>
      <ul>
	  	<li>Superior support for priority IT equipment</li>
	  	<li>Focus on fast problem resolution</li>
	  	<li>Agreed fix time service</li>
	  	<li>Ideal for IT-dependant organizations</li>
	  	<li>Ultimate level of protection for mission-critical IT systems</li>
	  	<li>Combines high level support with disaster recovery</li>
	  	<li>Improved business continuity and maximum uptime</li>
	  	<li>Premium support for your IT infrastructure</li>
	  	<li>Can include dedicated on-site support staff and bonded stock</li>
	  	<li>Ensures maximum uptime possible in business critical IT environment</li>
        </ul><br>
  	  	 
<p>
NMSIPL and associates have the ability to provide a unique package of high quality support, value for money, commitment and flexibility, in line with your changing IT requirements.<br>
Operating 24 hours a day, 6 days a week, NMSIPL enable you to benefit from improved levels of service through the use of skilled resources and the very latest technologies.</p><br>
<h3>IT Solutions & IT Services Company, Odisha, India</h3><br>
<p>
NMS is an Odisha based Computer IT Solutions & Computer IT Services Company. NMS Techworks deals with various computer related problems and computer solutions such as Computer Assembling, Branded Computer Installation, Computer Repairing, Software Installation, Lan Support, AMC, WAN Support and IT Infrastructure.<br><br>

Our IT Services & Solution areas are mainly directed to cover companies and offices which are based in and around Odisha, Ranchi, Jharkhand. Our close proximity to all these industrial areas further ensure and enable us to quickly and actively complete or resolve any computer related issues and major breakdown problems that may occur. Our engineers instantly visit problem areas and provide immediate and effective computer troubleshooting, network recovery.
			       </p>             
			                    </div>
			                     

			                   
			                </div>
                            
                        </div>
                        <div class="col-md-4 col-sm-5 col-xs-12">
                            <div class="video-image-box">
                                <figure class="image"><img src="images/project/pic5.jpe" alt=""></figure>
                                
                            </div>
                        </div>
                    </div>

		    </div>
		</section>
		 

		<?php
			include("footer.php");
		?>

	<!-- Scroll Top Button -->
	<button class="scroll-top tran3s color2_bg">
		<span class="fa fa-angle-up"></span>
	</button>
	<!-- pre loader  -->
	<!--<div class="preloader"></div>-->

		

	</div>
	
</body>

 </html>



