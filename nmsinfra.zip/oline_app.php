<!DOCTYPE html>
<html lang="en">

 <head>
	<meta charset="UTF-8">
	<title>NMS INFRASTRUCTURE Pvt. Ltd.</title> 

	<!-- mobile responsive meta -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<?php
		include("external.php");
	?>

</head>

<body>
	<div class="boxed_wrapper">
		<?php
			include("header.php");
		?>
		<!--Page Title-->
        <section class="page-title" style="background:url(images/page_nav/ftr.jpg) top center no-repeat">
        	<div class="container">
            	<div class="row clearfix">
                    <div class="col-md-6 col-sm-6 col-xs-12 pull-left">
						<h1>Online Application</h1>
						<!--<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit </p>-->
					</div>
                    
					<div class="overlay"></div>
                </div>
            </div>
        </section>
        <!--Page Title Ends-->
		
		<section class="about-us">
		    <div class="container">
		        <div class="sec-title">
					<h2>
Online 
 <span>Application</span> </h2>
					
				</div>
		        
					<div class="row">
                        <div class="col-md-8 col-sm-7 col-xs-12">
                            <div class="about-info">
			                   <!-- <h3>Complete hardware and networking solution</h3>-->
			                    
			                    <div class="text">
			                        <p>


NMS Technology is a custom software development company and a reputation of trust companies core business of high-performance web applications. We have experience with all leading software technology company to create multi-level web applications, technology-based business management. Working with the exact solution of software development processes, which are based on teamwork, we are able to produce quality custom web-based solutions for companies in different time. Our developed software is flexible and scalable for our customers for future development.<br><br>

NMS technology uses the following well-known and widely accepted web technologies to provide unique solutions and performance-oriented software:<br><br>

The open source technologies (<strong>PHP</strong> and <strong>MySQL</strong>)<br>
Microsoft Technologies (<strong>ASP, ASP.NET, C #. NET, VB, VB.NET</strong>)<br>
Java technologies  </p><br>
			                    
			                    </div>
			                     

			                     
			                </div>
                            
                        </div>
                        <div class="col-md-4 col-sm-5 col-xs-12">
                            <div class="video-image-box">
                                <figure class="image"><img src="images/project/pic3.jpe" alt=""></figure>
                                
                            </div>
                        </div>
                    </div>

		    </div>
		</section>
		 

		<?php
			include("footer.php");
			
		?>

	<!-- Scroll Top Button -->
	<button class="scroll-top tran3s color2_bg">
		<span class="fa fa-angle-up"></span>
	</button>
	<!-- pre loader  -->
	<!--<div class="preloader"></div>-->

		

	</div>
	
</body>

 </html>



