<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<title>NMS INFRASTRUCTURE Pvt. Ltd.</title> 

	<!-- mobile responsive meta -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<?php
		include("external.php");
	?>

</head>

<body>
	<div class="boxed_wrapper">
		<?php
			include("header.php");
		?>

		<!--Page Title-->
        <section class="page-title">
        	<div class="container">
            	<div class="row clearfix">
                    <div class="col-md-6 col-sm-6 col-xs-12 pull-left">
						<h1>
Hardware Management
</h1>
						<!--<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit </p>-->
					</div>
                    
					<div class="overlay"></div>
                </div>
            </div>
        </section>
        <!--Page Title Ends-->
		
		<section class="about-us">
		    <div class="container">
		        <div class="sec-title">
					<h2>

Hardware <span>Management</span> </h2>
					
				</div>
		        
					<div class="row">
                        <div class="col-md-7 col-sm-7 col-xs-12">
                            <div class="about-info">
			                   <!-- <h3>Complete hardware and networking solution</h3>-->
			                     
			                    <div class="text data">
			                        <p>

We also provide support for installation, configuration and troubleshooting for your desktop computer problems like Motherboards, RAM and Hard Disk Drives etc.. Implementation of PC upgrades such as System Memory, Graphic Cards, Modems, Network Cards, Wireless Networks, CD-ROMs, DVD, DVD- RAMs, DVD-RWs etc. Installing and configuring licensed software applications, fixing / replacing corrupt or faulty memory devices (RAM & Hard-Drives), customising your desktop environment and software applications according to your specific needs and to enhance system performance by optimizing.</p><br>
<h3>Computer Hardware Products</h3><br>
<p>We deliver all kinds of Desktop Computers (Branded or Assembled), Laptops, Notebooks, Printer, Switches. Selling of branded PC’s and peripherals. All kinds of parts including Laptops, Desktops, Printers , Hard Disks and other related peripherals available at best prices around odisha.</p>
 
 <table id="grid" width="100%" cellspacing="0" cellpadding="0" border="" class="hw">
      <tbody><tr>
        <th width="11%">Desktops</td>
        <td width="89%">Laptops of all the companies including Lenovo, Dell, Toshiba, Compaq, HP, Sony, and Acer are available.<br></td>
      </tr>
      <tr>
        <th valign="top">
          Laptops</td>
        <td>We provide assembled as well branded PC’s in bulk as well as single to our esteemed clients.</td>
      </tr>
      <tr>
        <th>Printers</td>
        <td>We provide printers of all companies include HP, Canon and Samsung to the customers.</td>
      </tr>
      <tr>
        <th>Peripherals</td>
        <td>We also provide peripherals like mouse, LCD Monitors, Hard Disks as well as DVD writers and Web Cameras with speakers with best prices.</td>
      </tr>
    </tbody></table>
<h3>Annual Maintenance Contract (AMC)</h3><br>

<h5>Lowest and Affordable Annual Maintenance Contract Service (AMC) in Odisha.</h5><br>
<p>
Our Annual Maintenance Service (AMC) or Computer Services Contract is available with regular check-up or with on call basis.<br><br>

We undertake maintenance for all computer network related products and also the complete IT infrastructure of organizations and small business companies based in Odisha.<br><br>

We are glad to announce computer maintenance service for computer hardware and computer software. Under this service depending on your requirement we will allot dedicated linking experts to your campaigns and we will be managing your campaigns over a period of one year. All the services like managing the campaign, following standard parameters and troubleshooting on frequent basis are included. 
</p>
<p>A look at some of the hgihlights of our annual computer maintenance services: </p>
 <ul>
     <li> 	Annual Computer Maintenance services are available at lowest and affordable prices. In case of major breakdown, standby machines and other computer related equipments are available. </li> 
     <li>Technical support is available at your place within short time.Online support is offered during office hours, at your service through phone/ internet. </li> 
     <li>We offer maintenance and replacement service to your hardware problems at your place to reduce your machine's down time. We are equipped with a team of highly energetic IT Professionals.</li> 
     <li>We serve you to get parts repaired at good competitive charges and arrange computer parts at best prices available in the industry.</li>  
       </ul><br>
			                    
			                    </div>
			                     

			                    
			                </div>
                            
                        </div>
                        <div class="col-md-5 col-sm-5 col-xs-12">
                            <div class="video-image-box">
                                <figure class="image"><img src="images/hover_box/pic5.jpg" alt=""></figure>
                                
                            </div>
                        </div>
                    </div>

		    </div>
		</section>
		

		<?php
			include("footer.php");
		?>

	<!-- Scroll Top Button -->
	<button class="scroll-top tran3s color2_bg">
		<span class="fa fa-angle-up"></span>
	</button>
	<!-- pre loader  -->
	<!--<div class="preloader"></div>-->

		 

	</div>
	
</body>

 </html>



