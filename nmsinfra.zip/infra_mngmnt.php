<!DOCTYPE html>
<html lang="en">

 <head>
	<meta charset="UTF-8">
	<title>NMS INFRASTRUCTURE Pvt. Ltd.</title> 

	<!-- mobile responsive meta -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<?php
		include("external.php");
	?>

</head>

<body>
	<div class="boxed_wrapper">
		<?php
			include("header.php");
		?>

		<!--Page Title-->
        <section class="page-title" >
        	<div class="container">
            	<div class="row clearfix">
                    <div class="col-md-6 col-sm-6 col-xs-12 pull-left">
						<h1>Infrastructure Management</h1>
						<!--<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit </p>-->
					</div>
                     
					<div class="overlay"></div>
                </div>
            </div>
        </section>
        <!--Page Title Ends-->
		
		<section class="about-us">
		    <div class="container">
		        <div class="sec-title">
					<h2>
Infrastructure 
 <span>Management</span> </h2>
					
				</div>
		        
					<div class="row">
                        <div class="col-md-7 col-sm-7 col-xs-12">
                            <div class="about-info">
			                   <!-- <h3>Complete hardware and networking solution</h3>-->
			                    <br>
			                    <div class="text">
			                        <p>

IT and infrastructure management services have undergone a significant change and increasingly. IT teams are focused on delivering business value, improved efficiency and variabilization of costs. The focus of business nowadays has turned to: "How can we leverage IT infrastructure for business growth and innovation? and, How can IT infrastructure management help businesses to be more agile and flexible, addressing demands such as ramp-up or ramp-down considering the prevailing macroeconomic scenarios?" </p><br>
			                    
			                    </div>
			                     

			                    
			                </div>
                            
                        </div>
                        <div class="col-md-5 col-sm-5 col-xs-12">
                            <div class="video-image-box">
                                <figure class="image"><img src="images/project/pic2.jpe" alt=""></figure>
                                
                            </div>
                        </div>
                    </div>

		    </div>
		</section>
	 

		<?php
			include("footer.php");
		?>

	<!-- Scroll Top Button -->
	<button class="scroll-top tran3s color2_bg">
		<span class="fa fa-angle-up"></span>
	</button>
	<!-- pre loader  -->
	<!--<div class="preloader"></div>-->

		

	</div>
	
</body>

 </html>



