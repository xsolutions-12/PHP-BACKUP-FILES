<?php
	$url=basename($_SERVER["PHP_SELF"]);
?>

<div class="header-top">
			<div class="container clearfix">
				<!--Top Left-->
				<div class="top-left pull-left">
					<ul class="links-nav clearfix">
						<li><a href="#"><span class="fa fa-phone"></span> Call:  0674-6509777 </a></li>
						<li><a href="mailto:info@nmsinfra.com"><span class="fa fa-envelope"></span>Email:  info@nmsinfra.com</a></li>
					</ul>
				</div>
				<!--Top Right-->
                    <div class="top-right pull-right">
					<div class="social-links clearfix">
						<a href="#"><span class="fa fa-facebook-f"></span></a>
						<a href="http://twitter.com/nmsinfra"><span class="fa fa-twitter"></span></a>
						<a href="#"><span class="fa fa-linkedin"></span></a>
						
					</div>
				</div>
			</div>
		</div><!-- Header Top End -->

		


		<section class="mainmenu-area stricky">
		    <div class="container">
		    	<div class="row">
		    		<div class="col-md-6">
						<div class="main-logo">
							<a href="index.html"><img src="images/logo/logo_nms.png" alt=""  class="h_img" ></a>
						</div>
					</div>
					<div class="col-md-6 menu-column">
						<nav class="main-menu">
				            <div class="navbar-header">     
				                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
				                    <span class="icon-bar"></span>
				                    <span class="icon-bar"></span>
				                    <span class="icon-bar"></span>
				                    <span class="icon-bar"></span>
				                </button>
				            </div>
				            <div class="navbar-collapse collapse clearfix">
				                <ul class="navigation clearfix">

				                    <li <?php if($url=='index.php') {echo 'class="current"';} ?>><a href="index.php">Home</a></li>

									<li <?php if($url=='about.php') {echo 'class="current"';} ?>><a href="about.php">About</a></li>

									<li class="dropdown" <?php if($url=='infra_mngmnt.php' || $url=='oline_app.php' || $url=='why.php') {echo 'class="current dropdown"';} ?>><a href="#">Services</a>
										<ul>
											<li><a href="infra_mngmnt.php">Infrastructure Management</a></li>
                                            <li><a href="oline_app.php">Online Application</a></li>
                                            <li><a href="why.php">Why NMS</a></li>
										</ul>
									</li>

					                <li  <?php if($url=='client.php') {echo 'class="current"';} ?> ><a href="client.php">Client</a></li>

									<li  <?php if($url=='support.php') {echo 'class="current"';} ?>><a href="support.php">Support</a></li>
									
									<li <?php if($url=='career.php') {echo 'class="current"';} ?>><a href="career.php">Career</a></li>
									<li <?php if($url=='contact_us.php') {echo 'class="current"';} ?>><a href="contact_us.php">Contact Us</a></li>
								</ul>

				                <ul class="mobile-menu clearfix">

				                    <li><a href="index.php">Home</a></li>

									<li><a href="about.php">About</a></li>

									<li class="dropdown"><a href="#">Services</a>
									<ul>
										<li><a href="infra_mngmnt.php">Infrastructure Management</a></li>
										<li><a href="oline_app.php">Online Application</a></li>
										<li><a href="why.php">Why NMS</a></li>
										 
									 </ul>
									</li>

					                <li><a href="client.php">Client</a>
										 
									</li>

									<li><a href="support.php">Support</a></li>
									
									<li><a href="career.php">Career</a></li>
									<li><a href="contact_us.php">Contact Us</a></li>

				                </ul>
				            </div>
				        </nav>
					</div>
					<!--<div class="col-md-2">
						<div class="right-area">
						   <div class="link_btn float_right">
							   <a href="#" class="thm-btn">GET A Quote?</a>
						   </div>
						</div>	
					</div>-->
		    	</div>
		        
		    </div>
		</section>
